
DBM_SpellTimers_Settings = {
	["enabled"] = true,
	["active_in_pvp"] = true,
	["showlocal"] = true,
	["disable_encounter"] = true,
	["only_from_raid"] = true,
	["own_bargroup"] = false,
	["portal_alliance"] = {
		{
			["spell"] = 10059,
			["cooldown"] = 60,
			["bartext"] = "%spell: %player",
		}, -- [1]
		{
			["spell"] = 11416,
			["cooldown"] = 60,
			["bartext"] = "%spell: %player",
		}, -- [2]
		{
			["spell"] = 11419,
			["cooldown"] = 60,
			["bartext"] = "%spell: %player",
		}, -- [3]
		{
			["spell"] = 32266,
			["cooldown"] = 60,
			["bartext"] = "%spell: %player",
		}, -- [4]
		{
			["spell"] = 33691,
			["cooldown"] = 60,
			["bartext"] = "%spell: %player",
		}, -- [5]
	},
	["portal_horde"] = {
		{
			["spell"] = 11417,
			["cooldown"] = 60,
			["bartext"] = "%spell: %player",
		}, -- [1]
		{
			["spell"] = 11418,
			["cooldown"] = 60,
			["bartext"] = "%spell: %player",
		}, -- [2]
		{
			["spell"] = 11420,
			["cooldown"] = 60,
			["bartext"] = "%spell: %player",
		}, -- [3]
		{
			["spell"] = 32667,
			["cooldown"] = 60,
			["bartext"] = "%spell: %player",
		}, -- [4]
		{
			["spell"] = 35717,
			["cooldown"] = 60,
			["bartext"] = "%spell: %player",
		}, -- [5]
	},
	["show_portal"] = true,
	["spells"] = {
		{
			["spell"] = 22700,
			["cooldown"] = 600,
			["bartext"] = "%spell: %player",
		}, -- [1]
	},
}
