
MasqueDB = {
	["profileKeys"] = {
		["猎猎思密达 - 阿什坎迪"] = "Default",
		["暗黑界面 - 阿什坎迪"] = "Default",
		["今晚就动手 - 阿什坎迪"] = "Default",
		["简洁界面 - 阿什坎迪"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["Groups"] = {
				["WeakAuras_R2ysYimvxvp"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_tEL8MyLASNc"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_NJwvJYt)uFb"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_gsFENwmX5Vi"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_YUN()RdsO9G"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_yTkjD4ckMp1"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_M8o8Y1AgiKn"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_)hCCKl94PQR"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_GKt9wmucJtY"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_OyOp60Y7fPi"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_rcunwsaraXE"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_ghQ)3i1qIkY"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_elAnNhLxnti"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_CkmZZHytB15"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_rI28jqbznfB"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_vJy(9DCdJpT"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_Hl27AlE0apM"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_RKfOql)NMRr"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_qouL1RByb3("] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_aNwUM9WjC26"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_VoWoe3Nrqn1"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_Hv5VJYkRw8Q"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_BT0)gycFjET"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_xGAaHi(vjUz"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_ZVAvkXSAIWB"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_PSBeTAN5SX6"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_)eB9w5jhbSA"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_giqX)H67fxz"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_wD3AKYYIFa0"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_pdC1j9i13(B"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_Xt4Dkm2rC56"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_qoCvpEKminH"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras"] = {
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_NIWDWgrZ5nj"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_01deS1TdBzm"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_StlgAqUaViB"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_ngXc(IBI6Gf"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_ONRYRoLHt5p"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_WPZURpxZvdl"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_oV7OGH88nbS"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_OCPY1FXIVsn"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_Lzi7swxwsPc"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_OsXEamCC6gs"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_LTA2xmmpOre"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_eewQ)qNXbGj"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_4Kkrq2XIyNO"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_R10FQk7abTD"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_(G6vQxNrw8u"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_Eu(qaWsfBoh"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_CWKA5taO1Wi"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_GJAdXrNNt(F"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_9bZJ0zPDfG0"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_TY32QcOltoa"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_wlYKnWkraer"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_Hrv9qCAltmA"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_vQEdFWFyTI9"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_r9Lz933VczK"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_i8B5zmW(zdG"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_wfhbcltdoxL"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_KqNkd2l95Qn"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_o38HtJEQjum"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_wHBa6E2dq2k"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_K48rnlhfHQZ"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_KbLNyE9wnQj"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_sYKPdk2L4)i"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_zwzJT3U)fRN"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_KyKTKBJFkVf"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_ga8gybetWTN"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_CZSiASTm)mH"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_IAzKObGM4EC"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_oLckeGnuPG4"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_sszQePISw6T"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_xiH76ucXldG"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_Whrr63XxLOu"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["ElvUI_Buffs"] = {
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_qwzaK8yPVVI"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_DQlRlF6H6AL"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_CQFFiV9Z21i"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_6dp2F8AYWWq"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_P9JYRZWc2(C"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["ElvUI"] = {
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_i3BT3bA34NC"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_0)e8iH2Ip)0"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_A5v9XTch4SJ"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_jbN6VOf10nb"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_5oSU0la1zLU"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_1VgZojlPoeg"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_BahRxduMOeC"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_Gutx0ViM)ZH"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_RQOB8LmlmCa"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_rb6tNEEMnA3"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_seC7yheCnR2"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_qf))RTsQ3oB"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_ezhhmZKIwCB"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_GHjQIVFGzlE"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_zqFrYox03ca"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_NH2He)NnhcY"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_AaDdyEM8yNd"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_QlfEVnjjf5t"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_EtTCeAt7SDE"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_4tOSf2PDAFr"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_3YN7NpZpu(n"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_yxTmMiBUZ(g"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_XQy2XkbeT7m"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_0yze2HVF5l3"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_OLgT086E6aq"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_lGqDy6amJ)7"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_5w8xf3qLS42"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_Im2qUbth5TA"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_QraHI)R8Jxe"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_Q9IWhK232ZJ"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_z26pPgVxv4m"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_sfd9VguzQ1l"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_bgcjWHi5X0C"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_(fCkjKRYtNH"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_sg6nbQPlCIH"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_g3AZvfAtd1b"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_CKGb5GhfJhw"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_wMv5h1pvWfn"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_rsIPzYfUBJI"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_lrPPSbnG5jg"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_RehYZUeQIVP"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_J36Gfr1w38C"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_3KWC6glEE7R"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_HCzrUoTzeXL"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_t6bOHEq1LGc"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_5yvpgvErTh)"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_rVmzj0u2Am4"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_fMy2Zod)kkx"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_5L5enVOpsJo"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_xT057N7xy2O"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_8XnaAL2a6h2"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_M76HhFqDMGN"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_jbB1alGGm5X"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_YNQ3yLY5hS("] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_ImJwWEUG2SD"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_xiJLrXG4kuz"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_ZvYA0Rto9QN"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_o9xBWsGWHnx"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_dK1BAXirHtv"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_B3rDPDm8aCV"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_cTzorRyjxJE"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_vAE(9jqff86"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_Gu(OnCQb5SN"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_VkpwcHowkHx"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_GxeJjwvUN0P"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_8DH3r61qd1t"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_HSW68EXOwvC"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_zLHj98fOCac"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_FW5o()Q6(aO"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_zVHTa0vtfqJ"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_5RWYBpvlxwz"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_)KYVc6UbCnT"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_3mEdd)RVMV3"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_rczclzcgvNu"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_SfAYsT3AVre"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_5Utqfgnawim"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_b)x2CoRZ7tp"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_soJl7(TULvs"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_sAKzdUtJoZj"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_PYYn8c3L(8z"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_rKCq3i3uivd"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["TellMeWhen"] = {
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_L(XcLlJwdHz"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_aDfAOH4XO6j"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_szP2zErA353"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_LSpSsxP(NIf"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_98PmZp(9HxH"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_ID4cTuqpaqj"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_KbFQd8TKWCD"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_rbJ4Nj0fEwG"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_9PdU(SCgKRF"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_LzsMtn8QsQa"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_zw(fgXq5IH0"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_rrruP1di3wc"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_AwSC)NsmfsA"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_5mtGP5EcHbH"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_hxiKkj)l(Ay"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_3fSNtiG7uTb"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_06(teiKBOBS"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_ajSl73m5aa("] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_u7aRmuomenV"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_qDU2lCa9O2A"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_r4cUzgfuvy9"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_Ux96ACN3FJO"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_PBHfo)tCzce"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_ySnnnDHxfss"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_WPv0FdvcViG"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_7PXlsEfw6om"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_Ro6Y2I4L0tn"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_qUUsC5B8WFQ"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_Lt7RfId7)gv"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_OAoOJAKef0Z"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["Masque"] = {
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
				},
				["WeakAuras_A4Itc5smDNq"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_RgVq)lXxTRM"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_65yf7oFlURe"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_EOncD5K0vp4"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_OOreyvkXNum"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_PE)w7y89aWN"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_mWqU)DwK52f"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_ZR5N1BFdeyi"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_Vhmmf)bRUaX"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_)g1w9pj98VE"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_Wo(mdEPwUYM"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_rrNyPijhOAe"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_827rF1461qd"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_krJIqDoBF7C"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_12R66zDk06K"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_)vbszEt8abZ"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_sX41UxrG9Ac"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_trHNMw(XjBN"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_ebhudRMa3UF"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_mF7w6KWRBv0"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_sqir7qHUyXE"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_m1R3oPznjKt"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_HQLcHR(kJHF"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_UuOiRy6yE78"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_HTM5MOYRbi4"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_6D6mcgmJusU"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_A(RV(O7QKh0"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_YCKGqem9Xeb"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_OPcMG1qIrdt"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_XeyPWMtzugP"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_AnFyAGDKMFr"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_bvmrYBogR0q"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_NSk(ivi7h(u"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_Bk)9GHvMb0m"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_y9jk7pzA52G"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_nc3GpCQWTE3"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_JuKWMd2BySH"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_EJVKauSI43x"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_LVcSSRy97uU"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_PVqJMpSGeXZ"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_doyTTBXx)aG"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_LxgTxTTUIGZ"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_8usJhREkYan"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_0scnWxbelYV"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_UUFQJ2dsydk"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_dAWDANJ5uE9"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_HHGZULaPpqA"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_UEQEu)NvI(u"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_7txLr2(wFOS"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_LcfjUSy8NXU"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_MwaFU99tiUk"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_oNSbPIDvOMw"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_0qpgmBoFP7W"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_mW)RwiRNYAf"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_AwRiY0wRYYf"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_fuyw)hy5uZ8"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_FoGa2LwAFVh"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_JuO0IMp0cUW"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_y0OJq)sKRH3"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_zpV8RS8LryK"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_w83D0Lovz9N"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_FzrbqhOcDK8"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_dOpSm5ZQnn1"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_EaV((AOfVOW"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_UIvvhZtNIU8"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_HcmSi89)(Ks"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_AwEPqr7LF8I"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_)ciAyJs(q6m"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_oa6qAn2uz7c"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_qO5A87W(GK1"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_dC0keq9)AYd"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_553xP3WoVBL"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_(Rf7CxzdBWj"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_GeQf9)v83XE"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_HSu03omFsuz"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["ElvUI_Pet Bar"] = {
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_KfBhtIaXqHT"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_P)cH2DC3PGV"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_d0XI3(Yv4xX"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_4fDAaZR217H"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_J6YvHk0faMV"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_LWSQTHuP6ku"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_3IT5hBScIRE"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_0Ud0qZm2Znb"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_kk)tG4ZrAUR"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_MNELpfjgiE4"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_8lbUw3FvnD0"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_qAmMniBXUNx"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_2g0WJfb76Go"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_N2VcG)7ClIu"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_IlmBqpplJ(R"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_EvpYrDW(kDv"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_ELze9SvUIIW"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_flVXna1dtuQ"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_xztDgSIkQ2g"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_q8R2fr)gOjp"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_W4LhrTt8bf5"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_(rjX2)akWhz"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_kS1T)qN39Ju"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_jSfwskF70PJ"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_g53e5Ws0P3L"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_KDeBeGSYZRK"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_WQPzCr02rvB"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_uPXSd6twadC"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_cXuSGOuakgq"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_)2P6wODgpOd"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_Z0mjtUPlaIW"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_tckqFKfgGy2"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_APb6(jGwggx"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_g)MLgF9EQLo"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_2siOcknoDcX"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_GsA28ml6aTO"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_cAI60uu2kjl"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_Ha4PorRbcMs"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_)LQ3)6hrTdz"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_cWTPyJcgrWV"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_KCtWOgHQ96V"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["TrufiGCD"] = {
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_R3Th)RqCnHo"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_DvATF0auZCR"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_wroROj6DFLe"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_BDQvI8HtAOa"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_X33nno(ZopQ"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_aJyTspXsqB0"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_a7HLYINWYLL"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_nplGuoD4n93"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_7zTMKyMAiIZ"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_wTYhRtpSDBy"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_)kdRXcFhGCq"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_QflFKfJ1SQ)"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_Ay(OyltsgPT"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_z2nO9ES2aYe"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_Ubbe7)c4zME"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_t27H632HDiv"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_16PDDXXxllG"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_((0GGr(A8Gv"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_of2cIJBdNW3"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_r5SMDCujlcn"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_xygWVLMi2vW"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_iblMih4QexS"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_SusLX8)8BgF"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_(TRRZ(uk3CA"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_688Fq6cN1Po"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_LQlkb0JjT3F"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_)aEEPdY2aTt"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_esE633vv0KS"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_2RBpqHiYPjY"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_wPf4Ow30Njz"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_obdgQanDodn"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_G)SooKJUuHE"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_6bNoECxEvdD"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_4jGE28W8cIO"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_N1(PbFTJSvW"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_FlMW26fyu8u"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_jNjeu3IZLj0"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_tx0Wcf(uuES"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_7JuhoyYcHXu"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_nvE6oi6Jksa"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_75DF4O2TOMv"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_IuPrs5(TPTG"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["TellMeWhen_分组: 1"] = {
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["GladiusEx_减益"] = {
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_SJ9aGrHHNWb"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["TrinketMenu"] = {
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_HWW2HCawJpb"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_BSRBV6sK0iL"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_i53BUbQ6qJi"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_sFfGO5lSS6h"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_Powlj))Xyt3"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_bx6UkGrdaOp"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_0NJM7xB5EgB"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_t9XXcGKFB8e"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_6JQbBX(9oNC"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_JgKD53MISK9"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_qe2Obd36hEF"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["GladiusEx_增益"] = {
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_tHMfQNysivc"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_jorwyGynA(("] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_FXj2bMkQ6vk"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["ElvUI_ActionBars"] = {
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_qm)w2LvHUPI"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_wOsR(rDfhbT"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_t2lE)HwvhWt"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_SObCNWXhhIu"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_B8yOfxme(V1"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_rixW7HYVvI9"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_T2Nk3eaFcvj"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_1tvZOU7w8Y7"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_iUwC67yE(U)"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_YEuFSA(NAUg"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_awPT(2odk(m"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_AlKP8ti21Lw"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_EUy80uqQYkk"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_15X5nTGpmiB"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_eNG4ugnqPfg"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_GMfJ9mszDko"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_jwowMTfqGSk"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_NXi(Fj0882P"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_hx5DUsaR113"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_RZdqs4XLZV1"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_IqtpyWuUHYJ"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_rwTiPwji9I4"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_pK1SpNVEiIV"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_gIxtEcLmgda"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_iWcWLqLaGqZ"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_QThOon3)UuW"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_3sPS1YjPbZ1"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_W2saEK0cs5b"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_SLNXjH5qQUe"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_zxFkI03OXw4"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_ddkzXtcnE1c"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_OfuNGuW33qX"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_opB0vkDoI9h"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_QVQ6AW6uRoE"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_TU7(230sBPl"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_b7FaMmKaJMV"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_9(DaQ8d6k8O"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_rXsS5SVCbaQ"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_n7QQ0FXtrPs"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_9a6Q9Tqf4B("] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_qXCFRde2sui"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_5EwHJPn4s8K"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_g2NhXZ6vF8X"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_jrdKuv4kqOa"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_3Kh7b5SPisQ"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_ynC(m)ZDOGX"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_XOiM4bRuuuk"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_QoezhPk7o3W"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_8ufpl1T4ohL"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_ev7DUSbiFxA"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_YEf20dLOD8o"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_vxfDMIjGlCO"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_ZnvhlBjZOHd"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_wV1x)B6t7l0"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_2xCNeTbV9v8"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_5Xv9eG7rh3B"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_(YdHyLYxlKX"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_ZBSFz51p9HZ"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_USNo7sNYD15"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_Ef9rmQ(SOQE"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_tFHru)eXbtz"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_g()KUeTejL9"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_EKazP6dlf(Q"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_P4RB0sbSLj5"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_NyZ7ZqAxWoE"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_m1w95TauGcp"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_Elt1myYkz7B"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_jTUs36WN)fJ"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_zFLY)16VXo7"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_FsRkF88w1hc"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_rIfS5FuJrZ9"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_)QfT4aqWnHS"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_L3zu3Gye1Ug"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_S7vjNzQupkm"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_pCyT9dNhaJY"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_TnJCaG(hiC3"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_)uNmRCG4mDU"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_ZERLeTNqN83"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_C8sWG6Xkmn8"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_IkjI6stobmj"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_YUTkYrhRLdi"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_kadwTdr2GLE"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_X3aYJHLos6g"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_yKSkqUGAT45"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_brxnqFaYk6E"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_2W(NZ9Zu69a"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_WAf1mfFlXb8"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_6g(HLjTc2tp"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_UI)vjfTYKdp"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_yw)IN(eppPO"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_wD0oNN6Eg(S"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_WBpY1V75pZc"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_fUfiigs4l(9"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_b83pcLYWFlz"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_Bg9Q8Djcu1p"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_EVfWoJVPezm"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_o2yJdzvUMP("] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_1k6HuycK3R2"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_q)u3M63Jqgd"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["GladiusEx"] = {
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_GVR6JUrnfNn"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_hV7VhCNtWju"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_jYFTR)NBLUS"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_M6mSWwyS7S("] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_RuNDEQDdVvs"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_hlsgExPse2a"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_6EkuOnVhsuj"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_Vde32FBGfVq"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_uhC71)GI0FG"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_2ncuBA16bVT"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_19cjLEPT8Q8"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_wqwzfBwAHEF"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_CAA2vkoMbLK"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_l0MPl(Xm71w"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_CQQqQGrYaS7"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_27Oyzy6BiS4"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["TrufiGCD_All Icons"] = {
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_2Cd)A3xtuav"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_JbuOUoP9JRo"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_5Gy0M8sM)BC"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_myb)mVywbb2"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_4JH1rebDRsF"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_Bnd00pK8gyl"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_Yf77cqtMFYH"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_DHmQMggbcMR"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_vYPfjp2aXTF"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_kAWH1ClkAb6"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_zHhRoF8fm5)"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_911lYlHB1lD"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_S9SqVIDuzb9"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_9sOwYXSR4N("] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_kJA6EefT19l"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_J9(92(03wi2"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_BYNjNV4pYR9"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_8H1qSO2EAly"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_(BKRn3GfZQW"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_aw8kGZLHPoH"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_BM6O95EZXsg"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_sMX6cs5RNSc"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_(4hN7DWzNcB"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_Kl5Bah0uxb8"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_y5ujrjoiv)d"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_Af9UYobj)qs"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_0PDlyvdHtVl"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_OWXnbwHviSi"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_zB9385J80pr"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_WeQcHkzdVzj"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_oNcsnfsynvt"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_iy(re9XN0eG"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_vCjyRkA6qQA"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_pPvQFnTUclc"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["ElvUI_Debuffs"] = {
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_ZZGc5342Las"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_bWo80vaiMBE"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_HTiFtnOx71s"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_)sbDd3lSSIp"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_ekWMqDiGkNQ"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_V7d7buiqtNv"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_YKMcIM5Jw1t"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_(TRpplGLclW"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_T2HjrIKv38n"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_wDSDmBg1MsW"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_HvyJzKiq3wv"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_0UVyfJ(kvN9"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_9tG(kA22Lef"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_sIAtoRCXXd7"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_vJJMj(eRAI5"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_2LA(SRvNQ86"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_Xlmq3u9HPUF"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_48mP(4LuIM9"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_GMbAR6xfznb"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["ElvUI_Stance Bar"] = {
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_mXx065qMh1o"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_C27bH(PTeGe"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_0JDj)Dc(2Oi"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_teniUjOcVGg"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_KFg8aBpqlAy"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_7vw1aObjERb"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_KaVqf4KCgep"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_cfX1ZDdkETu"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_bu7lzkfct8v"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_9(wssH567lA"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_efP1N9SvEe7"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_grHzZ7(r4Tf"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_NCNIbxrSlz3"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_rt92GEa60cE"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_aBRLvgmNrEI"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_sBlI6zkjiKR"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_69iIbkvAkWZ"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_dHE0AdDNA55"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_SJwl8x49IWV"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_gE1b)DLGXtE"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_(qCbfFc3LCW"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_kMTbkVGeUTe"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_l1ZN3WK12(r"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_WjMYy9tx21c"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_Nfvyx0AvydZ"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_g5FFUDT3Dd7"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_HqJOg4nioGh"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_Y(XnAqyMRL7"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_LnXKBcErqaf"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_XPmIY8L9UWO"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_)zNrqePQqoW"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_Zq18Ot5j3ob"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_S5Vdf86u7j3"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_mKochjWwwHr"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_GV6zEX)zi9D"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_fBCJOv3acFn"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_qpc0g)iw2ld"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_cxNXxCCnmJw"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_0c8vNs()yvc"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_jnmJsMDe(6y"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_ffDhViEpkax"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_FN44FIWjlG5"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_68)xaGF9Tac"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_ctDHquAU7Zf"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_)E3aI7L(hjs"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_reLhqLjY(W0"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_n5Pb3Dhhkb5"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_mYILDqNn0yQ"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_L3Nhy6IhR3Z"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_kN8B6wjArgr"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_gHYAR7UddNp"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_oZLVqyqchSH"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["OmniBar"] = {
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
			},
		},
	},
}
