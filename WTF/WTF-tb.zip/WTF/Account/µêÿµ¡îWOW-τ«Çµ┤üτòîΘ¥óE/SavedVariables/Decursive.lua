
DecursiveDB = {
	["class"] = {
		["HUNTER"] = {
			["CureOrder"] = {
				-11, -- [1]
				-15, -- [2]
				nil, -- [3]
				-12, -- [4]
				[8] = -13,
				[16] = -14,
				[32] = -16,
			},
		},
		["WARRIOR"] = {
			["CureOrder"] = {
				-11, -- [1]
				-15, -- [2]
				nil, -- [3]
				-12, -- [4]
				[8] = -13,
				[16] = -14,
				[32] = -16,
			},
		},
		["DRUID"] = {
			["CureOrder"] = {
				-11, -- [1]
				-15, -- [2]
				nil, -- [3]
				-12, -- [4]
				[8] = -13,
				[16] = -14,
				[32] = -16,
			},
		},
		["ROGUE"] = {
			["CureOrder"] = {
				-11, -- [1]
				-15, -- [2]
				nil, -- [3]
				-12, -- [4]
				[8] = -13,
				[16] = -14,
				[32] = -16,
			},
		},
	},
	["profileKeys"] = {
		["大哥别开火 - 阿什坎迪"] = "Default",
		["简洁界面 - 阿什坎迪"] = "Default",
		["今晚就动手 - 阿什坎迪"] = "Default",
		["猎猎思密达二 - 阿什坎迪"] = "Default",
		["暗黑界面 - 阿什坎迪"] = "Default",
		["猎猎思密达 - 阿什坎迪"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["HideLiveList"] = true,
			["AutoHideMUFs"] = 2,
			["DebuffsFrameContainer_y"] = 494.933327687581,
			["MainBarX"] = 1001.872833251953,
			["MainBarY"] = -201.2096099853516,
			["ShowDebuffsFrame"] = false,
			["Print_CustomFrame"] = false,
			["DebuffsFrameContainer_x"] = 1024.00006408691,
			["Print_Error"] = false,
			["Print_ChatFrame"] = false,
		},
	},
}
