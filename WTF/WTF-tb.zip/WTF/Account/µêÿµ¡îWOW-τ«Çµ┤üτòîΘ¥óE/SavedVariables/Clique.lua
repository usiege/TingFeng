
CliqueDB = nil
CliqueDB3 = {
	["char"] = {
		["简洁界面 - 阿什坎迪"] = {
			["spec1_profileKey"] = "简洁界面 - 阿什坎迪",
			["specswap"] = false,
			["downclick"] = false,
			["fastooc"] = false,
		},
	},
	["profileKeys"] = {
		["猎猎思密达 - 阿什坎迪"] = "简洁界面 - 阿什坎迪",
		["暗黑界面 - 阿什坎迪"] = "暗黑界面 - 阿什坎迪",
		["简洁界面 - 阿什坎迪"] = "简洁界面 - 阿什坎迪",
	},
	["profiles"] = {
		["暗黑界面 - 阿什坎迪"] = {
			["bindings"] = {
				{
					["type"] = "target",
					["sets"] = {
						["default"] = true,
					},
					["key"] = "BUTTON1",
					["unit"] = "mouseover",
				}, -- [1]
				{
					["type"] = "menu",
					["key"] = "BUTTON2",
					["sets"] = {
						["default"] = true,
					},
				}, -- [2]
			},
		},
		["简洁界面 - 阿什坎迪"] = {
			["bindings"] = {
				{
					["type"] = "target",
					["sets"] = {
						["default"] = true,
					},
					["key"] = "BUTTON1",
					["unit"] = "mouseover",
				}, -- [1]
				{
					["type"] = "menu",
					["key"] = "BUTTON2",
					["sets"] = {
						["default"] = true,
					},
				}, -- [2]
			},
		},
	},
}
