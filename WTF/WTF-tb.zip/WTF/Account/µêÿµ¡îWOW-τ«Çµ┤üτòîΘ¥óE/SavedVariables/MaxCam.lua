
MaxCamDB = {
	["increment"] = 4,
	["db_version"] = 2.3,
	["nearIncrement"] = 1,
	["distance"] = 3.34,
	["nearDistance"] = 5,
	["speed"] = 20,
}
