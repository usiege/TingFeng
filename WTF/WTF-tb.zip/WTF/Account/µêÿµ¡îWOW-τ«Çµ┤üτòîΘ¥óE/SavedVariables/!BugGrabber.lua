
BugGrabberDB = {
	["session"] = 184,
	["lastSanitation"] = 3,
	["errors"] = {
		{
			["message"] = "Couldn't open Interface\\AddOns\\MobHealthClassic\\MobHealthClassic.toc",
			["time"] = "2021/05/05 23:07:00",
			["session"] = 8,
			["counter"] = 2,
		}, -- [1]
		{
			["message"] = "Interface\\AddOns\\ElvUI\\Core\\Core.lua:1838: Usage: SaveBindings(1||2)",
			["time"] = "2021/05/21 15:21:41",
			["stack"] = "[string \"=[C]\"]: ?\n[string \"@Interface\\AddOns\\ElvUI\\Core\\Core.lua\"]:1838: in function `ConvertActionBarKeybinds'\n[string \"@Interface\\AddOns\\ElvUI\\Core\\Core.lua\"]:1822: in function `DBConversions'\n[string \"@Interface\\AddOns\\ElvUI\\Core\\Core.lua\"]:1904: in function `Initialize'\n[string \"@Interface\\AddOns\\ElvUI\\init.lua\"]:151: in function <Interface\\AddOns\\ElvUI\\init.lua:150>\n[string \"=[C]\"]: ?\n[string \"@Interface\\AddOns\\Masque\\Libs\\AceAddon-3.0\\AceAddon-3.0-13.lua\"]:70: in function <...ace\\AddOns\\Masque\\Libs\\AceAddon-3.0\\AceAddon-3.0.lua:65>\n[string \"@Interface\\AddOns\\Masque\\Libs\\AceAddon-3.0\\AceAddon-3.0-13.lua\"]:527: in function `EnableAddon'\n[string \"@Interface\\AddOns\\Masque\\Libs\\AceAddon-3.0\\AceAddon-3.0-13.lua\"]:630: in function <...ace\\AddOns\\Masque\\Libs\\AceAddon-3.0\\AceAddon-3.0.lua:615>",
			["session"] = 26,
			["counter"] = 1,
		}, -- [2]
		{
			["message"] = "Interface\\AddOns\\Mapster\\Mapster-1.9.2.lua:201: attempt to call method 'IsMaximized' (a nil value)",
			["time"] = "2021/05/21 15:21:41",
			["stack"] = "[string \"@Interface\\AddOns\\Mapster\\Mapster-1.9.2.lua\"]:201: in function `SetScale'\n[string \"@Interface\\AddOns\\Mapster\\Mapster-1.9.2.lua\"]:129: in function <Interface\\AddOns\\Mapster\\Mapster.lua:54>\n[string \"=[C]\"]: ?\n[string \"@Interface\\AddOns\\Masque\\Libs\\AceAddon-3.0\\AceAddon-3.0-13.lua\"]:70: in function <...ace\\AddOns\\Masque\\Libs\\AceAddon-3.0\\AceAddon-3.0.lua:65>\n[string \"@Interface\\AddOns\\Masque\\Libs\\AceAddon-3.0\\AceAddon-3.0-13.lua\"]:527: in function `EnableAddon'\n[string \"@Interface\\AddOns\\Masque\\Libs\\AceAddon-3.0\\AceAddon-3.0-13.lua\"]:630: in function <...ace\\AddOns\\Masque\\Libs\\AceAddon-3.0\\AceAddon-3.0.lua:615>",
			["session"] = 31,
			["counter"] = 6,
		}, -- [3]
		{
			["message"] = "Interface\\AddOns\\CodexLite\\map.lua:716: attempt to call upvalue 'mm_check_func' (a nil value)",
			["time"] = "2021/05/23 11:07:11",
			["locals"] = "map = 1429\nnum_changed = 0\nmeta = <table> {\n  = <table> {\n }\n}\n(for generator) = <function> defined =[C]:-1\n(for state) = <table> {\n  = <table> {\n }\n}\n(for control) = <table> {\n 1 = \"unit\"\n 2 = 6\n 3 = <table> {\n }\n 4 = <table> {\n }\n}\nuuid = <table> {\n 1 = \"unit\"\n 2 = 6\n 3 = <table> {\n }\n 4 = <table> {\n }\n}\ndata = <table> {\n 1 = <table> {\n }\n 2 = <table> {\n }\n}\ncolor3 = <table> {\n 1 = 0.752941\n 2 = 0\n 3 = 0\n}\ncoords = <table> {\n 1 = <table> {\n }\n 2 = <table> {\n }\n 3 = <table> {\n }\n 4 = <table> {\n }\n 5 = <table> {\n }\n 6 = <table> {\n }\n 7 = <table> {\n }\n 8 = <table> {\n }\n 9 = <table> {\n }\n 10 = <table> {\n }\n 11 = <table> {\n }\n 12 = <table> {\n }\n 13 = <table> {\n }\n 14 = <table> {\n }\n 15 = <table> {\n }\n 16 = <table> {\n }\n 17 = <table> {\n }\n 18 = <table> {\n }\n 19 = <table> {\n }\n 20 = <table> {\n }\n 21 = <table> {\n }\n 22 = <table> {\n }\n 23 = <table> {\n }\n 24 = <table> {\n }\n 25 = <table> {\n }\n 26 = <table> {\n }\n 27 = <table> {\n }\n 28 = <table> {\n }\n 29 = <table> {\n }\n 30 = <table> {\n }\n 31 = <table> {\n }\n 32 = <table> {\n }\n 33 = <table> {\n }\n}\n(for index) = 1\n(for limit) = 33\n(for step) = 1\nindex = 1\ncoord = <table> {\n 1 = 50.500000\n 2 = 37.600000\n 3 = 1429\n 4 = 180\n 5 = <table> {\n }\n}\nval = <table> {\n 1 = -217.354166\n 2 = -8809.866586\n 3 = 0\n 4 = 180\n}\ndx = -57.754160\ndy = 93.234000\n(*temporary) = nil\n(*temporary) = -57.754160\n(*temporary) = 93.234000\n(*temporary) = 150\n(*temporary) = \"attempt to call upvalue 'mm_check_func' (a nil value)\"\n__ns = <table> {\n __comm_obj_lookup = <table> {\n }\n __comm_meta = <table> {\n }\n __player_level = 1\n QUEST_GREETING = <function> defined @Interface\\AddOns\\CodexLite\\core.lua:1399\n __opt_log = <function> defined @Interface\\AddOns\\CodexLite\\init.lua:927\n __sv = <table> {\n }\n PLAYER_LEVEL_CHANGED = <function> defined @Interface\\AddOns\\CodexLite\\core.lua:1313\n QUEST_LOG_UPDATE = <function> defined @Interface\\AddOns\\CodexLite\\core.lua:1325\n _log_ = <function> defined @Interface\\AddOns\\CodexLite\\init.lua:873\n GetColor3NextIndex = <function> defined @Interface\\AddOns\\CodexLite\\core.lua:165\n ____bn_tag = \"奥特兰克#5882\"\n DelUnit = <function> defined @Interface\\AddOns\\CodexLite\\core.lua:409\n QUEST_REMOVED = <function> defined @Interface\\AddOns\\CodexLite\\core.lua:1367\n _F_devDebugProfileTick = <function> defined @Interface\\AddOns\\CodexLite\\init.lua:48\n __map_meta = <table> {\n }\n MapDelVariedNodes = <function> defined @Interface\\AddOns\\CodexLite\\map.lua:1065\n QUEST_PROGRESS = <function> defined @Interface\\AddOns\\CodexLite\\core.lua:1423\n QUEST_COMPLETE = <function> defined @Interface\\AddOns\\CodexLite\\core.lua:1430\n __toc = 20501\n apply_patch = <function> defined @Interface\\AddOns\\CodexLite\\patch.lua:52\n UpdateQuestGivers = <function> defined @Interface\\AddOns\\CodexLite\\core.lua:1093\n MapHideNodes = <function> defined @Interface\\AddOns\\CodexLite\\map.lua:1076\n __maxLevel = 70\n SetLargePinSize = <function> defined @Interface\\AddOns\\CodexLite\\map.lua:944\n db = <table> {\n }\n GOSSIP_SHOW = <function> defined @Interface\\AddOns\\CodexLite\\core.lua:1373\n NAME_PLATE_UNIT_REMOVED = <function> defined @Interface\\AddOns\\CodexLite\\init.lua:97\n NAME_PLATE_UNIT_ADDED = <function> defined @Interface\\AddOns\\CodexLite\\init.lua:97\n __ui_setting = CODEX_LITE_SETTING_UI {\n }\n PushAddLine = <function> defined @Interface\\AddOns\\CodexLite\\comm.lua:615\n __PLAYER_ZONE_CHANGED = <function> defined @Interface\\AddOns\\CodexLite\\map.lua:1168\n GetQuestTagInfo = <function> defined @Interface\\AddOns\\CodexLite\\init.lua:852\n core_reset = <function> defined @Interface\\AddOns\\CodexLite\\core.lua:1301\n GROUP_JOINED = <function> defined @Interface\\AddOns\\CodexLite\\comm.lua:791\n map_setup = <function> defined @Interface\\AddOns\\CodexLite\\map.lua:1174\n CoreAddUUID = <function> defined @Interface\\AddOns\\CodexLite\\core.lua:195\n _F_devDebugProfileStart = <function> defined @Interface\\AddOns\\CodexLite\\init.lua:45\n QUEST_DETAIL = <function> defined @Interface\\AddOns\\CodexLite\\core.lua:1417\n CreateSettingUI = <function> defined @Interface\\AddOns\\CodexLite\\setting.lua:270\n DelObject = <function> defined @Interface\\AddOns\\CodexLite\\core.lua:434\n MapDelLa",
			["stack"] = "[string \"@Interface\\AddOns\\CodexLite\\map.lua\"]:716: in function <Interface\\AddOns\\CodexLite\\map.lua:702>\n[string \"@Interface\\AddOns\\CodexLite\\map.lua\"]:1171: in function <Interface\\AddOns\\CodexLite\\map.lua:1168>\n[string \"=(tail call)\"]: ?\n[string \"@Interface\\AddOns\\CodexLite\\init.lua\"]:430: in function <Interface\\AddOns\\CodexLite\\init.lua:426>",
			["session"] = 44,
			["counter"] = 5152,
		}, -- [4]
		{
			["message"] = "Interface\\AddOns\\Questie\\Modules\\Libs\\QuestieLib.lua:256: attempt to call field 'QueryQuest' (a nil value)",
			["time"] = "2021/05/23 11:07:10",
			["locals"] = "self = <table> {\n GetTbcLevel = <function> defined @Interface\\AddOns\\Questie\\Modules\\Libs\\QuestieLib.lua:255\n PrintDifficultyColor = <function> defined @Interface\\AddOns\\Questie\\Modules\\Libs\\QuestieLib.lua:29\n UnpackBinary = <function> defined @Interface\\AddOns\\Questie\\Modules\\Libs\\QuestieLib.lua:614\n ProfileFunction = <function> defined @Interface\\AddOns\\Questie\\Modules\\Libs\\QuestieLib.lua:353\n Levenshtein = <function> defined @Interface\\AddOns\\Questie\\Modules\\Libs\\QuestieLib.lua:551\n GetLevelString = <function> defined @Interface\\AddOns\\Questie\\Modules\\Libs\\QuestieLib.lua:274\n CacheItemNames = <function> defined @Interface\\AddOns\\Questie\\Modules\\Libs\\QuestieLib.lua:378\n GetQuestObjectives = <function> defined @Interface\\AddOns\\Questie\\Modules\\Libs\\QuestieLib.lua:141\n MathRandom = <function> defined @Interface\\AddOns\\Questie\\Modules\\Libs\\QuestieLib.lua:593\n GetRGBForObjective = <function> defined @Interface\\AddOns\\Questie\\Modules\\Libs\\QuestieLib.lua:81\n private = <table> {\n }\n MathRandomSeed = <function> defined @Interface\\AddOns\\Questie\\Modules\\Libs\\QuestieLib.lua:589\n SortQuestIDsByLevel = <function> defined @Interface\\AddOns\\Questie\\Modules\\Libs\\QuestieLib.lua:532\n GetDifficultyColorPercent = <function> defined @Interface\\AddOns\\Questie\\Modules\\Libs\\QuestieLib.lua:48\n SanitizePattern = <function> defined @Interface\\AddOns\\Questie\\Modules\\Libs\\QuestieLib.lua:497\n SortQuestsByLevel = <function> defined @Interface\\AddOns\\Questie\\Modules\\Libs\\QuestieLib.lua:517\n Count = <function> defined @Interface\\AddOns\\Questie\\Modules\\Libs\\QuestieLib.lua:488\n GetColoredQuestName = <function> defined @Interface\\AddOns\\Questie\\Modules\\Libs\\QuestieLib.lua:173\n GetAddonVersionString = <function> defined @Interface\\AddOns\\Questie\\Modules\\Libs\\QuestieLib.lua:456\n GetRandomColor = <function> defined @Interface\\AddOns\\Questie\\Modules\\Libs\\QuestieLib.lua:201\n GetAddonVersionInfo = <function> defined @Interface\\AddOns\\Questie\\Modules\\Libs\\QuestieLib.lua:433\n AddonPath = \"Interface\\AddOns\\Questie\\\"\n GetTableSize = <function> defined @Interface\\AddOns\\Questie\\Modules\\Libs\\QuestieLib.lua:420\n Remap = <function> defined @Interface\\AddOns\\Questie\\Modules\\Libs\\QuestieLib.lua:416\n Maxdist = <function> defined @Interface\\AddOns\\Questie\\Modules\\Libs\\QuestieLib.lua:412\n GetRaceString = <function> defined @Interface\\AddOns\\Questie\\Modules\\Libs\\QuestieLib.lua:311\n CacheAllItemNames = <function> defined @Interface\\AddOns\\Questie\\Modules\\Libs\\QuestieLib.lua:363\n Euclid = <function> defined @Interface\\AddOns\\Questie\\Modules\\Libs\\QuestieLib.lua:406\n IsResponseCorrect = <function> defined @Interface\\AddOns\\Questie\\Modules\\Libs\\QuestieLib.lua:109\n GetQuestString = <function> defined @Interface\\AddOns\\Questie\\Modules\\Libs\\QuestieLib.lua:214\n}\nquestId = 7\n(*temporary) = <function> defined =[C]:-1\n(*temporary) = nil\n(*temporary) = 7\n(*temporary) = \"questLevel\"\n(*temporary) = \"requiredLevel\"\n(*temporary) = \"attempt to call field 'QueryQuest' (a nil value)\"\nQuestieDB = <table> {\n FactionGroup = \"Alliance\"\n questDataOverrides = <table> {\n }\n _QueryItemSingle = <function> defined @Interface\\AddOns\\Questie\\Database\\compiler.lua:1116\n itemCompilerOrder = <table> {\n }\n questKeys = <table> {\n }\n npcFlags = <table> {\n }\n objectDataOverrides = <table> {\n }\n _npcAdapterQueryOrder = <table> {\n }\n questData = \"return {\n[2] = {\"Sharptalon's Claw\",{nil,nil,{16305,},},{{12696,},nil,},20,30,178,nil,{\"Bring Sharptalon's Claw to Senani Thunderheart at Splintertree Post, Ashenvale.\",},nil,{nil,nil,nil,nil,},16305,nil,{6383,},nil,{23,24,},nil,331,nil,nil,nil,nil,nil,nil,nil,nil,},\n[5] = {\"Jitters' Growling Gut\",{{288,},nil,nil,},{{272,},nil,},17,20,77,nil,{\"Speak with Chef Grual.\",},nil,{nil,nil,nil,nil,},nil,nil,{163,},nil,nil,nil,10,nil,nil,nil,nil,93,8,nil,nil,},\n[6] = {\"Bounty on Garrick Padfoot\",{{823,},nil,nil,},{{823,},nil,},2,5,77,nil,{\"Kill Garrick Padfoot and bring his head to Deputy Willem at Northshire Abbey.\",},nil,{nil,nil,{{182,nil},},nil,},nil,nil,{18,},nil,nil,nil,9,nil,nil,nil,nil,nil,8,nil,nil,},\n[7] = {\"Kobold Camp Cleanup\",{{197,},nil,nil,},{{197,},nil,},1,2,77,n",
			["stack"] = "[string \"@Interface\\AddOns\\Questie\\Modules\\Libs\\QuestieLib.lua\"]:256: in function `GetTbcLevel'\n[string \"@Interface\\AddOns\\Questie\\Database\\QuestieDB.lua\"]:624: in function `GetQuest'\n[string \"@Interface\\AddOns\\Questie\\Modules\\Libs\\QuestieLib.lua\"]:379: in function `CacheItemNames'\n[string \"@Interface\\AddOns\\Questie\\Modules\\Libs\\QuestieLib.lua\"]:374: in function `CacheAllItemNames'\n[string \"@Interface\\AddOns\\Questie\\Modules\\QuestieEventHandler.lua\"]:154: in function <...rface\\AddOns\\Questie\\Modules\\QuestieEventHandler.lua:152>",
			["session"] = 46,
			["counter"] = 2,
		}, -- [5]
		{
			["message"] = "Interface\\AddOns\\Clique\\BlizzardFrames.lua:188: attempt to concatenate local 'name' (a nil value)",
			["time"] = "2021/05/24 23:21:59",
			["locals"] = "frame = <unnamed> {\n 0 = <userdata>\n healthBar = <unnamed> {\n }\n unitExists = false\n optionTable = <table> {\n }\n selectionHighlight = <unnamed> {\n }\n maxDebuffs = 0\n maxBuffs = 0\n CastBar = <unnamed> {\n }\n maxDispelDebuffs = 0\n disableMouse = true\n name = <unnamed> {\n }\n ignoreCUFNameRequirement = true\n statusText = <unnamed> {\n }\n RaidTargetFrame = <unnamed> {\n }\n LevelFrame = <unnamed> {\n }\n}\nname = nil\n(for index) = 1\n(for limit) = 3\n(for step) = 1\ni = 1\n(*temporary) = <table> {\n UpdateOnBarHighlightMarksBySpell = <function> defined =[C]:-1\n ERR_OUT_OF_CHI = \"真气不足\"\n DH_HAVOC_CORE_ABILITY_2 = \"强大的近战攻击，消耗恶魔之怒。如果攻击造成爆击，将恢复部分恶魔之怒。\"\n MerchantItem9ItemButtonStock = MerchantItem9ItemButtonStock {\n }\n GetTrainerServiceTypeFilter = <function> defined =[C]:-1\n UNIT_NAMES_COMBATLOG_TOOLTIP = \"彩色标记单位名。\"\n ElvUI_Bar5Button11Count = ElvUI_Bar5Button11Count {\n }\n SetTrainerServiceTypeFilter = <function> defined =[C]:-1\n LE_GAME_ERR_CHAT_RAID_RESTRICTED_TRIAL = 773\n HandyNotesPin61 = HandyNotesPin61 {\n }\n SPELL_FAILED_CUSTOM_ERROR_71 = \"这名聚会者想要和你一起跳舞。\"\n LE_GAME_ERR_PET_SPELL_TARGETS_DEAD = 399\n ERROR_CLUB_TICKET_COUNT_AT_MAX_COMMUNITY = \"此群组无法再创建更多邀请链接。\"\n CompactUnitFrameProfilesGeneralOptionsFrameHealthTextDropdownButtonNormalTexture = CompactUnitFrameProfilesGeneralOptionsFrameHealthTextDropdownButtonNormalTexture {\n }\n PawnUI_RefreshCompareScrollFrame = <function> defined @Interface\\AddOns\\Pawn\\PawnUI.lua:1489\n ERR_TRADE_EQUIPPED_BAG = \"你无法交易已经装备的包裹。\"\n PVP_RANK_6_1 = \"下士\"\n MultiBarLeftButton7 = MultiBarLeftButton7 {\n }\n InterfaceOptionsNamesPanelUnitNameplatesShowAll = InterfaceOptionsNamesPanelUnitNameplatesShowAll {\n }\n ElvUI_Bar6Button9Shine = ElvUI_Bar6Button9Shine {\n }\n VideoOptionsFrameDefaults = VideoOptionsFrameDefaults {\n }\n MerchantItem2AltCurrencyFrameItem1Text = MerchantItem2AltCurrencyFrameItem1Text {\n }\n DetailsWindowOptionsBarTextEditorEntryNumberLines = DetailsWindowOptionsBarTextEditorEntryNumberLines {\n }\n OPTION_TOOLTIP_ACTION_BUTTON_USE_KEY_DOWN = \"在按下快捷键时施法，而不是在松开快捷键时施法。\"\n BINDING_NAME_NAMEPLATES = \"显示敌方姓名板\"\n CHAT_HEADER_SUFFIX = \": \"\n MultiBarBottomRightButton8Shine5 = MultiBarBottomRightButton8Shine5 {\n }\n IsReferAFriendLinked = <function> defined =[C]:-1\n MAIL_LETTER_TOOLTIP = \"点击这里来获得一份这封信\n永久性的副本。\"\n UnitFrameManaBar_UnregisterDefaultEvents = <function> defined @Interface\\FrameXML\\UnitFrame.lua:600\n ElvUI_Bar4Button9Shine7 = ElvUI_Bar4Button9Shine7 {\n }\n DUNGEON_FLOOR_UPPERBLACKROCKSPIRE3 = \"黑手大厅\"\n CraftExpandTabLeft = CraftExpandTabLeft {\n }\n CHAT_CONFIG_OTHER_COMBAT = <table> {\n }\n FCFDockOverflowButton_OnClick = <function> defined @Interface\\FrameXML\\FloatingChatFrame.lua:2379\n BOOST2_WARRIOR_COLOSSUSSMASH = \"使用|cFFFFFFFF巨人打击|r。\n\n|cFFFFFFFF巨人打击|r能提高你的伤害值。\"\n BN_UNABLE_TO_RESOLVE_NAME = \"无法向'%s'发送悄悄话。暴雪游戏服务也许暂时不可用。\"\n AutoCompleteEditBox_OnKeyDown = <function> defined @Interface\\FrameXML\\AutoComplete.lua:368\n ElvUI_Bar5Button12Shine7 = ElvUI_Bar5Button12Shine7 {\n }\n CompactRaidFrameManagerDisplayFrameHiddenModeToggleTopRight = CompactRaidFrameManagerDisplayFrameHiddenModeToggleTopRight {\n }\n LE_GAME_ERR_ONLY_ONE_QUIVER = 32\n SpellButton6Cooldown = SpellButton6Cooldown {\n }\n SLASH_LibQTip1 = \"/qtip\"\n LOSS_OF_CONTROL_DISPLAY_FEAR = \"恐惧\"\n Graphics_QualityText = Graphics_QualityText {\n }\n ROGUE_COMBAT_CORE_ABILITY_4 = \"射程延长的近战攻击，消耗连击点数。\"\n JoinSkirmish = <function> defined =[C]:-1\n HandyNotesPin174 = HandyNotesPin174 {\n }\n Advanced_GraphicsAPIDropDownButtonHighlightTexture = Advanced_GraphicsAPIDropDownButtonHighlightTexture {\n }\n MultiBarRightButton7Shine9 = MultiBarRightButton7Shine9 {\n }\n BankFrameItem17SearchOverlay = BankFrameItem17SearchOverlay {\n }\n ElvUI_Bar6Button6 = ElvUI_Bar6Button6 {\n }\n DMG_LCD = ",
			["stack"] = "[string \"@Interface\\AddOns\\Clique\\BlizzardFrames.lua\"]:188: in function <Interface\\AddOns\\Clique\\BlizzardFrames.lua:180>\n[string \"=[C]\"]: in function `CompactUnitFrame_SetUpFrame'\n[string \"@Interface\\AddOns\\Blizzard_NamePlates\\Blizzard_NamePlates.lua\"]:133: in function `ApplyFrameOptions'\n[string \"@Interface\\AddOns\\Blizzard_NamePlates\\Blizzard_NamePlates.lua\"]:111: in function `OnNamePlateAdded'\n[string \"@Interface\\AddOns\\Blizzard_NamePlates\\Blizzard_NamePlates.lua\"]:48: in function <...e\\AddOns\\Blizzard_NamePlates\\Blizzard_NamePlates.lua:39>\n[string \"=[C]\"]: ?",
			["session"] = 55,
			["counter"] = 53,
		}, -- [6]
		{
			["message"] = "Interface\\AddOns\\Questie\\Localization\\l10n.lua:81: attempt to call field 'QueryObjectSingle' (a nil value)",
			["time"] = "2021/05/23 11:07:11",
			["locals"] = "self = <table> {\n npcNameLookup = <table> {\n }\n GetUILocale = <function> defined @Interface\\AddOns\\Questie\\Localization\\l10n.lua:155\n objectNameLookup = <table> {\n }\n SetUILocale = <function> defined @Interface\\AddOns\\Questie\\Localization\\l10n.lua:147\n questLookup = <table> {\n }\n Initialize = <function> defined @Interface\\AddOns\\Questie\\Localization\\l10n.lua:34\n zoneLookup = <table> {\n }\n translations = <table> {\n }\n questCategoryLookup = <table> {\n }\n PostBoot = <function> defined @Interface\\AddOns\\Questie\\Localization\\l10n.lua:78\n objectLookup = <table> {\n }\n private = <table> {\n }\n continentLookup = <table> {\n }\n zoneCategoryLookup = <table> {\n }\n itemLookup = <table> {\n }\n}\n(for generator) = <function> defined =[C]:-1\n(for state) = <table> {\n 4270593 = 585663\n 25353 = 20861\n 71180 = 147784\n 12404994 = 2748351\n 98054 = 323519\n 22602 = 126911\n 4795136 = 5042111\n 95751 = 323519\n 66319 = 192447\n 2042882 = 15712189\n 67087 = 192447\n 197103 = 12565796\n 12405760 = 5858049\n 78349 = 2087\n 2083 = 31727\n 2131 = 192447\n 93450 = 192447\n 550657 = 3338175\n 552706 = 5369791\n 210415 = 12565763\n 556802 = 15712189\n 12405761 = 1732096\n 2324482 = 15712189\n 22603 = 126911\n 3421954 = 3141567\n 3430146 = 15712189\n 152064 = 61375\n 4925954 = 15712189\n 323519 = 12405504\n 7235586 = 15712189\n 12406272 = 5369791\n 20812 = 126911\n 665346 = 14129152\n 681729 = 3348224\n 94222 = 323519\n 70676 = 192447\n 12406528 = 520127\n 4664066 = 15712189\n 6826497 = 15712189\n 19021 = 126911\n 50831 = 126911\n 4992001 = 1458178\n 5008130 = 2191362\n 75285 = 192447\n 751 = 12565999\n 389055 = 12386314\n 8284162 = 520127\n 12406784 = 15712189\n 24332 = 192447\n 8333824 = 15712189\n 82452 = 32569\n 141327 = 192447\n 141839 = 1639\n 3187 = 198895\n 1645826 = 15712189\n 12406020 = 15712189\n 6842882 = 15712189\n 91412 = 192447\n 878336 = 13312\n 158735 = 192447\n 19534 = 126911\n 4255679 = 12387055\n 157712 = 192447\n 5074432 = 15712189\n 4321215 = 12386395\n 454591 = 12387311\n 12407296 = 15712189\n 32587 = 126911\n 4452287 = 12386543\n 269295 = 12565762\n 4271876 = 15712189\n 4583359 = 12386845\n 21070 = 126911\n 96789 = 192447\n 4648895 = 12387055\n 3691 = 126911\n 89623 = 192447\n 4714431 = 12387055\n 282607 = 12565762\n 945922 = 5500863\n 4779967 = 12386376\n 4845503 = 12387055\n 4911039 = 12387055\n 4976575 = 12387055\n 22606 = 126911\n 70429 = 61375\n 1973506 = 13415939\n 3883 = 115866\n 5107647 = 12387055\n 3915 = 115886\n 5173183 = 12387055\n 3939 = 32751\n 3947 = 126911\n 3955 = 199945\n 5238719 = 12386319\n 19471 = 27375\n 1011458 = 5576962\n 5304255 = 12387055\n 145947 = 192447\n 5369791 = 12387055\n 520127 = 12387311\n 5435327 = 12386380\n 162328 = 2576\n 5500863 = 12387055\n 4118 = 126911\n 12361 = 192447\n 5566399 = 12387055\n 5631935 = 12387055\n 5697471 = 12387055\n 21327 = 126911\n 5763007 = 12386543\n 5828543 = 12386799\n 141856 = 1655\n 142368 = 2031\n 5894079 = 12386543\n 5959615 = 12386380\n 6025151 = 12386310\n 6090687 = 12386310\n 1187330 = 13409795\n 1203712 = 23808\n 6156223 = 12386311\n 144930 = 192447\n 68898 = 192447\n 19536 = 126911\n 6352831 = 12387055\n 1269248 = 3165187\n 142884 = 192447\n 68131 = 192447\n 6483903 = 12386331\n 141861 = 126911\n 143397 = 19765\n 82976 = 377\n 20816 = 126911\n 67876 = 192447\n 3750144 = 5107647\n 150053 = 192447\n 69156 = 147765\n 6811583 = 12387055\n 143399 = 19951\n 5516802 = 15712189\n 6877119 = 12387055\n 71204 = 192447\n 6942655 = 12387055\n 7008191 = 12387055\n 133163 = 142131\n 5713410 = 15712189\n 279572 = 192447\n 7139263 = 12387055\n 6892802 = 15712189\n 91680 = 152047\n 7204799 = 12387055\n 7270335 = 12387055\n 80931 = 184744\n 7335871 = 12387055\n 4993025 = 2374914\n 148522 = 192447\n 7401407 = 12387128\n 1515010 = 13413635\n 7466943 = 12387055\n 7532479 = 12387055\n 32590 = 126911\n 7598015 = 12387055\n 7663551 = 12386621\n 4272385 = 801794\n 140335 = 192447\n 7794623 = 12387055\n 7860159 = 12387055\n 7925695 = 12387055\n 149550 = 192447\n 7991231 = 12387055\n 1634 = 61375\n 412674 = 13078532\n 585663 = 12387020\n 1654 = 126911\n 415746 = 7794623\n 8122303 = 12386312\n 422913 = 5912576\n 8187839 = 12386314\n 8253375 = 12387055\n 8318911 = 12387055\n 8384447 = 12386320\n 160303 = 28027\n 131127 = 15712189\n 135734 = 192447\n 12408834 = 15712",
			["stack"] = "[string \"@Interface\\AddOns\\Questie\\Localization\\l10n.lua\"]:81: in function `PostBoot'\n[string \"@Interface\\AddOns\\Questie\\Modules\\QuestieEventHandler.lua\"]:167: in function <...rface\\AddOns\\Questie\\Modules\\QuestieEventHandler.lua:161>",
			["session"] = 57,
			["counter"] = 5,
		}, -- [7]
		{
			["message"] = "Interface\\AddOns\\Questie\\Database\\QuestieDB.lua:582: attempt to call field 'QueryQuest' (a nil value)",
			["time"] = "2021/05/25 15:30:14",
			["locals"] = "self = <table> {\n FactionGroup = \"Alliance\"\n questDataOverrides = <table> {\n }\n itemCompilerOrder = <table> {\n }\n questKeys = <table> {\n }\n npcFlags = <table> {\n }\n objectDataOverrides = <table> {\n }\n _npcAdapterQueryOrder = <table> {\n }\n questData = \"return {\n[2] = {\"Sharptalon's Claw\",{nil,nil,{16305,},},{{12696,},nil,},20,30,178,nil,{\"Bring Sharptalon's Claw to Senani Thunderheart at Splintertree Post, Ashenvale.\",},nil,{nil,nil,nil,nil,},16305,nil,{6383,},nil,{23,24,},nil,331,nil,nil,nil,nil,nil,nil,nil,nil,},\n[5] = {\"Jitters' Growling Gut\",{{288,},nil,nil,},{{272,},nil,},17,20,77,nil,{\"Speak with Chef Grual.\",},nil,{nil,nil,nil,nil,},nil,nil,{163,},nil,nil,nil,10,nil,nil,nil,nil,93,8,nil,nil,},\n[6] = {\"Bounty on Garrick Padfoot\",{{823,},nil,nil,},{{823,},nil,},2,5,77,nil,{\"Kill Garrick Padfoot and bring his head to Deputy Willem at Northshire Abbey.\",},nil,{nil,nil,{{182,nil},},nil,},nil,nil,{18,},nil,nil,nil,9,nil,nil,nil,nil,nil,8,nil,nil,},\n[7] = {\"Kobold Camp Cleanup\",{{197,},nil,nil,},{{197,},nil,},1,2,77,nil,{\"Kill 10 Kobold Vermin, then return to Marshal McBride.\",},nil,{{{6,nil},},nil,nil,nil,},nil,nil,{783,},nil,nil,nil,9,nil,nil,nil,nil,nil,8,nil,nil,},\n[8] = {\"A Rogue's Deal\",{{6784,},nil,nil,},{{5688,},nil,},1,5,178,nil,{\"De IsActiveEventQuest = <function> defined @Interface\\AddOns\\Questie\\Database\\QuestieDB.lua:359\n IsComplete = <function> defined @Interface\\AddOns\\Questie\\Database\\QuestieDB.lua:334\n factionTemplate = <table> {\n }\n IsParentQuestActive = <function> defined @Interface\\AddOns\\Questie\\Database\\QuestieDB.lua:404\n objectKeys = <table> {\n }\n questCompilerTypes = <table> {\n }\n objectKeysReversed = <table> {\n }\n GetQuestsByZoneId = <function> defined @Interface\\AddOns\\Questie\\Database\\QuestieDB.lua:1054\n itemKeys = <table> {\n }\n objectData = \"return {\n[31] = {\"Old Lion Statue\",{248,249,},{94,},{[44]={{84.49,46.83},},},44,},\n[32] = {\"Sunken Chest\",nil,nil,{[44]={{41.52,54.66},},},44,},\n[33] = {\"Locked Chest\",nil,{140,},{[40]={{25.97,16.91},},},40,},\n[34] = {\"Old Jug\",{140,},{139,},{[40]={{40.63,17.03},},},40,},\n[35] = {\"Captain's Footlocker\",{138,},{136,},{[40]={{25.91,47.75},},},40,},\n[36] = {\"Broken Barrel\",{139,},{138,},{[40]={{40.52,47.79},},},40,},\n[38] = {\"Captain Sanders Chest\",nil,nil,nil,0,},\n[41] = {\"Ambassador's Locker\",nil,nil,{[10]={{64.99,66.12},},},10,},\n[47] = {\"Wanted: Lieutenant Fangore\",{180,},nil,{[44]={{26.75,46.44},},},44,},\n[52] = {\"Fall of Gurubashi\",nil,nil,{[33]={{22.95,12.02},},},33,},\n[54] = {\"The Emperor's Tomb\",nil,nil,{[33]={{24.7,8.93},},},33,},\n[55] = {\"A half-eaten body\",{45,},{37,},{[12]={{72.66,60.34},},},12,},\n[56] = {\"Rolf's corpse\",{71,},{45,},{[12]={{79.8,55.5},},},12,},\n[57] = {\"Moon Over the Vale\",nil,nil,{[33]={{29.48,19.14},},},33,},\n[58] = {\"Gri'lek the Wanderer\",nil,nil,{[33]={{24.82,23. itemData = \"return {\n[25] = {'Worn Shortsword',nil,nil,nil,nil,nil,nil,nil,2,1,0,2,7,nil,},\n[35] = {'Bent Staff',nil,nil,nil,nil,nil,nil,nil,2,1,0,2,10,nil,},\n[36] = {'Worn Mace',nil,nil,nil,nil,nil,nil,nil,2,1,0,2,4,nil,},\n[37] = {'Worn Axe',nil,nil,nil,nil,nil,nil,nil,2,1,0,2,0,nil,},\n[38] = {'Recruit\\'s Shirt',nil,nil,nil,nil,nil,nil,nil,1,0,0,4,0,nil,},\n[39] = {'Recruit\\'s Pants',nil,nil,nil,nil,nil,nil,nil,1,1,0,4,1,nil,},\n[40] = {'Recruit\\'s Boots',nil,nil,nil,nil,nil,nil,nil,1,0,0,4,0,nil,},\n[43] = {'Squire\\'s Boots',nil,nil,nil,nil,nil,nil,nil,1,0,0,4,0,nil,},\n[44] = {'Squire\\'s Pants',nil,nil,nil,nil,nil,nil,nil,1,1,0,4,1,nil,},\n[45] = {'Squire\\'s Shirt',{5623,},nil,nil,nil,nil,nil,nil,1,0,0,4,0,nil,},\n[47] = {'Footpad\\'s Shoes',nil,nil,nil,nil,nil,nil,nil,1,0,0,4,0,nil,},\n[48] = {'Footpad\\'s Pants',nil,nil,nil,nil,nil,nil,nil,1,1,0,4,1,nil,},\n[49] = {'Footpad\\'s Shirt',nil,nil,nil,nil,nil,nil,nil,1,0,0,4,0,nil,},\n[51] = {'Neophyte\\'s Boots',nil,nil,nil,nil,nil,nil,nil,1,0,0,4,0,nil,},\n[52] = {'Neo GetNPC = <function> defined @Interface\\AddOns\\Questie\\Database\\QuestieDB.lua:992\n _itemAdapterQueryOrder = <table> {\n }\n IsRaidQuest = <function> defined @Interface\\AddOns\\Questie\\Database\\QuestieDB.lua:293\n npcDataOverrides = <table> {\n }\n GetQuest = <function> d",
			["stack"] = "[string \"@Interface\\AddOns\\Questie\\Database\\QuestieDB.lua\"]:582: in function `GetQuest'\n[string \"@Interface\\AddOns\\ButterQuestTracker\\LibQuestHelpers\\LibQuestHelpers.lua\"]:178: in function `SetIconsVisibility'\n[string \"@Interface\\AddOns\\ButterQuestTracker\\LibQuestHelpers\\LibQuestHelpers.lua\"]:153: in function `RefreshIconsVisibilityForQuests'\n[string \"@Interface\\AddOns\\ButterQuestTracker\\LibQuestHelpers\\LibQuestHelpers.lua\"]:139: in function `SetAutoHideQuestHelperIcons'\n[string \"@Interface\\AddOns\\ButterQuestTracker\\ButterQuestTracker-1.9.27.lua\"]:146: in function <...ace\\AddOns\\ButterQuestTracker\\ButterQuestTracker.lua:145>",
			["session"] = 58,
			["counter"] = 3,
		}, -- [8]
		{
			["message"] = "Interface\\AddOns\\WeakAuras\\WeakAuras-3.4.1.lua:2701: bad argument #1 to 'pairs' (table expected, got nil)",
			["time"] = "2021/05/21 15:34:42",
			["locals"] = "(*temporary) = nil\n(*temporary) = \"table expected, got nil\"\n = <function> defined =[C]:-1\n",
			["stack"] = "[string \"=[C]\"]: in function `pairs'\n[string \"@Interface\\AddOns\\WeakAuras\\WeakAuras-3.4.1.lua\"]:2701: in function <Interface\\AddOns\\WeakAuras\\WeakAuras.lua:2681>\n[string \"@Interface\\AddOns\\WeakAuras\\WeakAuras-3.4.1.lua\"]:2813: in function `Add'\n[string \"@Interface\\AddOns\\WeakAurasOptions\\OptionsFrames\\MoverSizer.lua\"]:645: in function <...AddOns\\WeakAurasOptions\\OptionsFrames\\MoverSizer.lua:564>",
			["session"] = 62,
			["counter"] = 3,
		}, -- [9]
		{
			["message"] = "Couldn't open Interface\\AddOns\\MeetingHorn\\Libs\\tdGUI\\Libs\\LibClass-2.0-10\\LibClass-2.0.xml",
			["time"] = "2021/05/21 15:21:42",
			["session"] = 120,
			["counter"] = 546,
		}, -- [10]
		{
			["message"] = "Interface\\AddOns\\GladiatorlosSA2\\GladiatorlosSA2-TBC-B2.lua:5: Usage: GetLocale(application[, silent]): 'application' - No locales registered for 'GladiatorlosSA'",
			["time"] = "2021/06/05 16:23:07",
			["locals"] = "(*temporary) = \"Usage: GetLocale(application[, silent]): 'application' - No locales registered for 'GladiatorlosSA'\"\n",
			["stack"] = "[string \"=[C]\"]: ?\n[string \"@Interface\\AddOns\\ClassicCodex-loader\\lib\\AceLocale-3.0\\AceLocale-3.0-6.lua\"]:134: in function `GetLocale'\n[string \"@Interface\\AddOns\\GladiatorlosSA2\\GladiatorlosSA2-TBC-B2.lua\"]:5: in main chunk",
			["session"] = 124,
			["counter"] = 4,
		}, -- [11]
		{
			["message"] = "Interface\\AddOns\\GladiatorlosSA2\\options-设置选项.lua:5: Usage: GetLocale(application[, silent]): 'application' - No locales registered for 'GladiatorlosSA'",
			["time"] = "2021/06/05 16:23:07",
			["locals"] = "(*temporary) = \"Usage: GetLocale(application[, silent]): 'application' - No locales registered for 'GladiatorlosSA'\"\n",
			["stack"] = "[string \"=[C]\"]: ?\n[string \"@Interface\\AddOns\\ClassicCodex-loader\\lib\\AceLocale-3.0\\AceLocale-3.0-6.lua\"]:134: in function `GetLocale'\n[string \"@Interface\\AddOns\\GladiatorlosSA2\\options-设置选项.lua\"]:5: in main chunk",
			["session"] = 124,
			["counter"] = 4,
		}, -- [12]
		{
			["message"] = "...e\\AddOns\\GladiatorlosSA_zhCN\\GladiatorlosSA_zhCN-20201129.lua:3: bad argument #1 to 'rawset' (table expected, got nil)",
			["time"] = "2021/06/05 16:23:07",
			["locals"] = "(*temporary) = nil\n(*temporary) = \"GladiatorlosSA_zhCN\\Voice_zhCN\"\n(*temporary) = \"Chinese(female)\"\n(*temporary) = \"table expected, got nil\"\n",
			["stack"] = "[string \"=[C]\"]: in function `rawset'\n[string \"@Interface\\AddOns\\GladiatorlosSA_zhCN\\GladiatorlosSA_zhCN-20201129.lua\"]:3: in main chunk",
			["session"] = 124,
			["counter"] = 4,
		}, -- [13]
		{
			["message"] = "Error loading Interface\\AddOns\\GladiatorlosSA2\\libs\\LibStub\\LibStub.lua",
			["session"] = 124,
			["time"] = "2021/06/05 16:23:16",
			["counter"] = 4,
		}, -- [14]
		{
			["message"] = "Error loading Interface\\AddOns\\GladiatorlosSA2\\libs\\CallbackHandler-1.0\\CallbackHandler-1.0-7.lua",
			["session"] = 124,
			["time"] = "2021/06/05 16:23:16",
			["counter"] = 4,
		}, -- [15]
		{
			["message"] = "Couldn't open Interface\\AddOns\\GladiatorlosSA2\\libs\\AceAddon-3.0-13\\AceAddon-3.0.xml",
			["session"] = 124,
			["time"] = "2021/06/05 16:23:16",
			["counter"] = 4,
		}, -- [16]
		{
			["message"] = "Couldn't open Interface\\AddOns\\GladiatorlosSA2\\libs\\AceEvent-3.0-4\\AceEvent-3.0.xml",
			["session"] = 124,
			["time"] = "2021/06/05 16:23:16",
			["counter"] = 4,
		}, -- [17]
		{
			["message"] = "Couldn't open Interface\\AddOns\\GladiatorlosSA2\\libs\\AceTimer-3.0-17\\AceTimer-3.0.xml",
			["session"] = 124,
			["time"] = "2021/06/05 16:23:16",
			["counter"] = 4,
		}, -- [18]
		{
			["message"] = "Couldn't open Interface\\AddOns\\GladiatorlosSA2\\libs\\AceDB-3.0-27\\AceDB-3.0.xml",
			["session"] = 124,
			["time"] = "2021/06/05 16:23:16",
			["counter"] = 4,
		}, -- [19]
		{
			["message"] = "Couldn't open Interface\\AddOns\\GladiatorlosSA2\\libs\\AceDBOptions-3.0-15\\AceDBOptions-3.0.xml",
			["session"] = 124,
			["time"] = "2021/06/05 16:23:16",
			["counter"] = 4,
		}, -- [20]
		{
			["message"] = "Couldn't open Interface\\AddOns\\GladiatorlosSA2\\libs\\AceLocale-3.0-6\\AceLocale-3.0.xml",
			["session"] = 124,
			["time"] = "2021/06/05 16:23:16",
			["counter"] = 4,
		}, -- [21]
		{
			["message"] = "Couldn't open Interface\\AddOns\\GladiatorlosSA2\\libs\\AceConsole-3.0-7\\AceConsole-3.0.xml",
			["session"] = 124,
			["time"] = "2021/06/05 16:23:16",
			["counter"] = 4,
		}, -- [22]
		{
			["message"] = "Couldn't open Interface\\AddOns\\GladiatorlosSA2\\libs\\AceGUI-3.0-41\\AceGUI-3.0.xml",
			["session"] = 124,
			["time"] = "2021/06/05 16:23:16",
			["counter"] = 4,
		}, -- [23]
		{
			["message"] = "AceLocale-3.0-6: GladiatorlosSA: Missing entry for 'Russian(Andrewqtx)'",
			["time"] = "2021/07/02 18:14:10",
			["stack"] = "[string \"@Interface\\AddOns\\GladiatorlosSA3_TBC(Rus by Andrewqtx)\\GladiatorlosSA3_TBC(Rus by Andrewqtx)-TBC-1.0.lua\"]:32: in main chunk",
			["session"] = 127,
			["counter"] = 1,
		}, -- [24]
		{
			["message"] = "AceLocale-3.0-6: GladiatorlosSA: Missing entry for 'Spell_CastSuccess'",
			["time"] = "2021/07/02 18:14:10",
			["stack"] = "[string \"@Interface\\AddOns\\GladiatorlosSA3_TBC(Rus by Andrewqtx)\\GladiatorlosSA3_TBC(Rus by Andrewqtx)-TBC-1.0.lua\"]:37: in main chunk",
			["session"] = 127,
			["counter"] = 1,
		}, -- [25]
		{
			["message"] = "AceLocale-3.0-6: GladiatorlosSA: Missing entry for 'Spell_CastStart'",
			["time"] = "2021/07/02 18:14:10",
			["stack"] = "[string \"@Interface\\AddOns\\GladiatorlosSA3_TBC(Rus by Andrewqtx)\\GladiatorlosSA3_TBC(Rus by Andrewqtx)-TBC-1.0.lua\"]:38: in main chunk",
			["session"] = 127,
			["counter"] = 1,
		}, -- [26]
		{
			["message"] = "AceLocale-3.0-6: GladiatorlosSA: Missing entry for 'Spell_AuraApplied'",
			["time"] = "2021/07/02 18:14:10",
			["stack"] = "[string \"@Interface\\AddOns\\GladiatorlosSA3_TBC(Rus by Andrewqtx)\\GladiatorlosSA3_TBC(Rus by Andrewqtx)-TBC-1.0.lua\"]:39: in main chunk",
			["session"] = 127,
			["counter"] = 1,
		}, -- [27]
		{
			["message"] = "AceLocale-3.0-6: GladiatorlosSA: Missing entry for 'Spell_AuraRemoved'",
			["time"] = "2021/07/02 18:14:10",
			["stack"] = "[string \"@Interface\\AddOns\\GladiatorlosSA3_TBC(Rus by Andrewqtx)\\GladiatorlosSA3_TBC(Rus by Andrewqtx)-TBC-1.0.lua\"]:40: in main chunk",
			["session"] = 127,
			["counter"] = 1,
		}, -- [28]
		{
			["message"] = "AceLocale-3.0-6: GladiatorlosSA: Missing entry for 'Spell_Interrupt'",
			["time"] = "2021/07/02 18:14:10",
			["stack"] = "[string \"@Interface\\AddOns\\GladiatorlosSA3_TBC(Rus by Andrewqtx)\\GladiatorlosSA3_TBC(Rus by Andrewqtx)-TBC-1.0.lua\"]:41: in main chunk",
			["session"] = 127,
			["counter"] = 1,
		}, -- [29]
		{
			["message"] = "AceLocale-3.0-6: GladiatorlosSA: Missing entry for 'Spell_Summon'",
			["time"] = "2021/07/02 18:14:10",
			["stack"] = "[string \"@Interface\\AddOns\\GladiatorlosSA3_TBC(Rus by Andrewqtx)\\GladiatorlosSA3_TBC(Rus by Andrewqtx)-TBC-1.0.lua\"]:42: in main chunk",
			["session"] = 127,
			["counter"] = 1,
		}, -- [30]
		{
			["message"] = "AceLocale-3.0-6: GladiatorlosSA: Missing entry for 'Any'",
			["time"] = "2021/07/02 18:14:10",
			["stack"] = "[string \"@Interface\\AddOns\\GladiatorlosSA3_TBC(Rus by Andrewqtx)\\GladiatorlosSA3_TBC(Rus by Andrewqtx)-TBC-1.0.lua\"]:48: in main chunk",
			["session"] = 127,
			["counter"] = 1,
		}, -- [31]
		{
			["message"] = "AceLocale-3.0-6: GladiatorlosSA: Missing entry for 'Player'",
			["time"] = "2021/07/02 18:14:10",
			["stack"] = "[string \"@Interface\\AddOns\\GladiatorlosSA3_TBC(Rus by Andrewqtx)\\GladiatorlosSA3_TBC(Rus by Andrewqtx)-TBC-1.0.lua\"]:49: in main chunk",
			["session"] = 127,
			["counter"] = 1,
		}, -- [32]
		{
			["message"] = "AceLocale-3.0-6: GladiatorlosSA: Missing entry for 'Target'",
			["time"] = "2021/07/02 18:14:10",
			["stack"] = "[string \"@Interface\\AddOns\\GladiatorlosSA3_TBC(Rus by Andrewqtx)\\GladiatorlosSA3_TBC(Rus by Andrewqtx)-TBC-1.0.lua\"]:50: in main chunk",
			["session"] = 127,
			["counter"] = 1,
		}, -- [33]
		{
			["message"] = "Error loading Interface\\AddOns\\GladiatorlosSA3_TBC(Rus by Andrewqtx)\\Locales\\enUS-英语（US）.lua",
			["session"] = 127,
			["time"] = "2021/07/02 18:14:19",
			["counter"] = 2,
		}, -- [34]
		{
			["message"] = "Error loading Interface\\AddOns\\GladiatorlosSA3_TBC(Rus by Andrewqtx)\\Locales\\zhTW-繁体中文.lua",
			["session"] = 127,
			["time"] = "2021/07/02 18:14:19",
			["counter"] = 2,
		}, -- [35]
		{
			["message"] = "Error loading Interface\\AddOns\\GladiatorlosSA3_TBC(Rus by Andrewqtx)\\Locales\\zhCN-简体中文.lua",
			["session"] = 127,
			["time"] = "2021/07/02 18:14:19",
			["counter"] = 2,
		}, -- [36]
		{
			["message"] = "Error loading Interface\\AddOns\\GladiatorlosSA3_TBC(Rus by Andrewqtx)\\Locales\\frFR-法语.lua",
			["session"] = 127,
			["time"] = "2021/07/02 18:14:19",
			["counter"] = 2,
		}, -- [37]
		{
			["message"] = "Error loading Interface\\AddOns\\GladiatorlosSA3_TBC(Rus by Andrewqtx)\\Locales\\koKR-韩语.lua",
			["session"] = 127,
			["time"] = "2021/07/02 18:14:19",
			["counter"] = 2,
		}, -- [38]
		{
			["message"] = "...sEx\\libs\\LibGroupInSpecT-1.1\\LibGroupInSpecT-1.1-92.lua:166: attempt to index field 'C_SpecializationInfo' (a nil value)",
			["time"] = "2021/07/26 15:28:09",
			["locals"] = "MAJOR = \"LibGroupInSpecT-1.1\"\nMINOR = 92\nlib = <table> {\n static_cache = <table> {\n }\n debug = false\n cache = <table> {\n }\n RegisterCallback = <function> defined @Interface\\AddOns\\alaCalendar\\libs\\CallbackHandler-1.0\\CallbackHandler-1.0.lua:90\n state = <table> {\n }\n UnregisterCallback = <function> defined @Interface\\AddOns\\alaCalendar\\libs\\CallbackHandler-1.0\\CallbackHandler-1.0.lua:153\n NotifyInspect = <function> defined @Interface\\AddOns\\GladiusEx\\libs\\LibGroupInSpecT-1.1\\LibGroupInSpecT-1.1.lua:154\n hooked = true\n frame = LibGroupInSpecT-1.1_Frame {\n }\n events = <table> {\n }\n UnregisterAllCallbacks = <function> defined @Interface\\AddOns\\alaCalendar\\libs\\CallbackHandler-1.0\\CallbackHandler-1.0.lua:174\n}\nUPDATE_EVENT = \"GroupInSpecT_Update\"\nREMOVE_EVENT = \"GroupInSpecT_Remove\"\nINSPECT_READY_EVENT = \"GroupInSpecT_InspectReady\"\nQUEUE_EVENT = \"GroupInSpecT_QueueChanged\"\nCOMMS_PREFIX = \"LGIST11\"\nCOMMS_FMT = \"1\"\nCOMMS_DELIM = \"\"\nINSPECT_DELAY = 1.500000\nINSPECT_TIMEOUT = 10\nMAX_ATTEMPTS = 2\ndebug = <function> defined @Interface\\AddOns\\GladiusEx\\libs\\LibGroupInSpecT-1.1\\LibGroupInSpecT-1.1.lua:100\nframe = LibGroupInSpecT-1.1_Frame {\n 0 = <userdata>\n OnEvent = <function> defined @Interface\\AddOns\\GladiusEx\\libs\\LibGroupInSpecT-1.1\\LibGroupInSpecT-1.1.lua:127\n}\nCanInspect = <function> defined =[C]:-1\nClearInspectPlayer = <function> defined =[C]:-1\nGetClassInfo = <function> defined =[C]:-1\nGetNumSubgroupMembers = <function> defined =[C]:-1\nGetNumSpecializationsForClassID = nil\nGetPlayerInfoByGUID = <function> defined =[C]:-1\n(*temporary) = nil\n(*temporary) = nil\n(*temporary) = nil\n(*temporary) = nil\n(*temporary) = nil\n(*temporary) = nil\n(*temporary) = nil\n(*temporary) = nil\n(*temporary) = nil\n(*temporary) = nil\n(*temporary) = nil\n(*temporary) = nil\n(*temporary) = nil\n(*temporary) = nil\n(*temporary) = nil\n(*temporary) = nil\n(*temporary) = nil\n(*temporary) = nil\n(*temporary) = nil\n(*temporary) = nil\n(*temporary) = nil\n(*temporary) = nil\n(*temporary) = nil\n(*temporary) = nil\n(*temporary) = nil\n(*temporary) = nil\n(*temporary) = nil\n(*temporary) = nil\n(*temporary) = nil\n(*temporary) = nil\n(*temporary) = nil\n(*temporary) = nil\n(*temporary) = nil\n(*temporary) = nil\n(*temporary) = nil\n(*temporary) = nil\n(*temporary) = nil\n(*temporary) = nil\n(*temporary) = nil\n(*temporary) = nil\n(*temporary) = \"attempt to index field 'C_SpecializationInfo' (a nil value)\"\n",
			["stack"] = "[string \"@Interface\\AddOns\\GladiusEx\\libs\\LibGroupInSpecT-1.1\\LibGroupInSpecT-1.1-92.lua\"]:166: in main chunk",
			["session"] = 138,
			["counter"] = 1,
		}, -- [39]
		{
			["message"] = "Error loading Interface\\AddOns\\GladiusEx\\libs\\LibCooldownTracker-1.0-10\\cooldowns_bcc_racials.lua",
			["time"] = "2021/07/26 15:28:18",
			["session"] = 138,
			["counter"] = 3,
		}, -- [40]
		{
			["message"] = "Error loading Interface\\AddOns\\GladiusEx\\libs\\LibCooldownTracker-1.0-10\\cooldowns_bcc_items.lua",
			["time"] = "2021/07/26 15:28:18",
			["session"] = 138,
			["counter"] = 3,
		}, -- [41]
		{
			["message"] = "Interface\\AddOns\\MerInspect\\templates\\templates.lua:23: CreateFrame(): Couldn't find inherited node \"CharacterStatFrameTemplate\"",
			["time"] = "2021/05/26 00:13:28",
			["locals"] = "(*temporary) = \"Frame\"\n(*temporary) = nil\n(*temporary) = <unnamed> {\n BottomLeftCorner = <unnamed> {\n }\n PortraitFrame = <unnamed> {\n }\n PixelSnapDisabled = true\n AttributesCategory = <unnamed> {\n }\n backdropInfo = <table> {\n }\n SuitCategory = <unnamed> {\n }\n TopLeftCorner = <unnamed> {\n }\n RightEdge = <unnamed> {\n }\n TopEdge = <unnamed> {\n }\n BottomEdge = <unnamed> {\n }\n backdrop = <table> {\n }\n SetStats = <function> defined @Interface\\AddOns\\MerInspect\\templates\\templates.lua:16\n Center = <unnamed> {\n }\n 0 = <userdata>\n TopRightCorner = <unnamed> {\n }\n BottomRightCorner = <unnamed> {\n }\n EnhancementsCategory = <unnamed> {\n }\n LeftEdge = <unnamed> {\n }\n ResistanceCategory = <unnamed> {\n }\n}\n(*temporary) = \"CharacterStatFrameTemplate\"\n",
			["stack"] = "[string \"=[C]\"]: in function `CreateFrame'\n[string \"@Interface\\AddOns\\MerInspect\\templates\\templates.lua\"]:23: in function <Interface\\AddOns\\MerInspect\\templates\\templates.lua:22>\n[string \"@Interface\\AddOns\\MerInspect\\templates\\templates.lua\"]:89: in function `ClassicStatsFrameTemplate_Onload'\n[string \"*:OnLoad\"]:1: in function <[string \"*:OnLoad\"]:1>\n[string \"=[C]\"]: in function `CreateFrame'\n[string \"@Interface\\AddOns\\MerInspect\\InspectUnit.lua\"]:307: in main chunk",
			["session"] = 146,
			["counter"] = 61,
		}, -- [42]
		{
			["message"] = "Interface\\AddOns\\MerInspect\\templates\\templates.lua:126: attempt to perform arithmetic on field 'maxStaticIndex' (a nil value)",
			["time"] = "2021/05/26 00:15:27",
			["locals"] = "self = <unnamed> {\n BottomLeftCorner = <unnamed> {\n }\n PortraitFrame = <unnamed> {\n }\n PixelSnapDisabled = true\n AttributesCategory = <unnamed> {\n }\n backdropInfo = <table> {\n }\n SuitCategory = <unnamed> {\n }\n TopLeftCorner = <unnamed> {\n }\n RightEdge = <unnamed> {\n }\n TopEdge = <unnamed> {\n }\n BottomEdge = <unnamed> {\n }\n backdrop = <table> {\n }\n data = <table> {\n }\n SetStats = <function> defined @Interface\\AddOns\\MerInspect\\templates\\templates.lua:16\n Center = <unnamed> {\n }\n 0 = <userdata>\n TopRightCorner = <unnamed> {\n }\n BottomRightCorner = <unnamed> {\n }\n EnhancementsCategory = <unnamed> {\n }\n LeftEdge = <unnamed> {\n }\n ResistanceCategory = <unnamed> {\n }\n}\nbutton = nil\n(*temporary) = nil\n(*temporary) = nil\n(*temporary) = nil\n(*temporary) = nil\n(*temporary) = nil\n(*temporary) = nil\n(*temporary) = nil\n(*temporary) = nil\n(*temporary) = nil\n(*temporary) = nil\n(*temporary) = nil\n(*temporary) = nil\n(*temporary) = nil\n(*temporary) = nil\n(*temporary) = nil\n(*temporary) = nil\n(*temporary) = \"attempt to perform arithmetic on field 'maxStaticIndex' (a nil value)\"\nHandlePortraitFrame = <function> defined @Interface\\AddOns\\MerInspect\\templates\\templates.lua:46\nGetStatsName = <function> defined @Interface\\AddOns\\MerInspect\\libs\\LibItemStats\\LibItemStats.lua:295\nGetStatsValue = <function> defined @Interface\\AddOns\\MerInspect\\libs\\LibItemStats\\LibItemStats.lua:300\nGetStatFrame = <function> defined @Interface\\AddOns\\MerInspect\\templates\\templates.lua:33\n",
			["stack"] = "[string \"@Interface\\AddOns\\MerInspect\\templates\\templates.lua\"]:126: in function `ClassicStatsFrameTemplate_OnShow'\n[string \"*:OnShow\"]:1: in function <[string \"*:OnShow\"]:1>\n[string \"=[C]\"]: in function `Show'\n[string \"@Interface\\FrameXML\\UIParent.lua\"]:2088: in function `SetUIPanel'\n[string \"@Interface\\FrameXML\\UIParent.lua\"]:1933: in function `ShowUIPanel'\n[string \"@Interface\\FrameXML\\UIParent.lua\"]:1794: in function <Interface\\FrameXML\\UIParent.lua:1790>\n[string \"=[C]\"]: in function `SetAttribute'\n[string \"@Interface\\FrameXML\\UIParent.lua\"]:2559: in function `ShowUIPanel'\n[string \"@Interface\\FrameXML\\CharacterFrame.lua\"]:23: in function `ToggleCharacter'\n[string \"*:OnMouseUp\"]:4: in function <[string \"*:OnMouseUp\"]:1>",
			["session"] = 146,
			["counter"] = 3,
		}, -- [43]
		{
			["message"] = "Interface\\AddOns\\ShadowedUnitFrames\\localization\\frFR-法语.lua:536: unfinished string near '\"Filtres de liste prioritair'",
			["time"] = "2021/06/12 23:56:48",
			["locals"] = "",
			["stack"] = "",
			["session"] = 152,
			["counter"] = 159,
		}, -- [44]
		{
			["message"] = "Interface\\AddOns\\Masque_Epix\\Masque_Epix-1.0.lua:9: attempt to perform arithmetic on a nil value",
			["time"] = "2021/10/19 12:23:54",
			["locals"] = "MSQ = <table> {\n AddSpellAlert = <function> defined @Interface\\AddOns\\Masque\\Core\\Regions\\SpellAlert.lua:100\n Register = <function> defined @Interface\\AddOns\\Masque\\Core\\Callback.lua:66\n GetSpellAlert = <function> defined @Interface\\AddOns\\Masque\\Core\\Regions\\SpellAlert.lua:122\n GetSkins = <function> defined @Interface\\AddOns\\Masque\\Skins\\Skins.lua:164\n Group = <function> defined @Interface\\AddOns\\Masque\\Core\\Groups.lua:118\n GetShadow = <function> defined @Interface\\AddOns\\Masque\\Core\\Regions\\Shadow.lua:118\n GetDefaultSkin = <function> defined @Interface\\AddOns\\Masque\\Skins\\Skins.lua:154\n UpdateCharge = <function> defined @Interface\\AddOns\\Masque\\Core\\Regions\\Frame.lua:213\n UpdateSpellAlert = <function> defined @Interface\\AddOns\\Masque\\Core\\Regions\\SpellAlert.lua:91\n SetEmpty = <function> defined @Interface\\AddOns\\Masque\\Core\\Regions\\Icon.lua:129\n GetBackdrop = <function> defined @Interface\\AddOns\\Masque\\Core\\Regions\\Backdrop.lua:154\n GetSkin = <function> defined @Interface\\AddOns\\Masque\\Skins\\Skins.lua:159\n GetNormal = <function> defined @Interface\\AddOns\\Masque\\Core\\Regions\\Normal.lua:213\n AddType = <function> defined @Interface\\AddOns\\Masque\\Skins\\Regions.lua:470\n GetGloss = <function> defined @Interface\\AddOns\\Masque\\Core\\Regions\\Gloss.lua:118\n AddSkin = <function> defined @Interface\\AddOns\\Masque\\Skins\\Skins.lua:111\n}\nResolution = \"auto\"\nWindowed = false\n(*temporary) = nil\n(*temporary) = \"auto\"\n(*temporary) = \"%d+x(%d+)\"\n(*temporary) = nil\n(*temporary) = \"gxFullscreenResolution\"\n(*temporary) = \"auto\"\n(*temporary) = 2\n(*temporary) = Display_DisplayModeDropDown {\n 0 = <userdata>\n description = \"让游戏在全屏模式或窗口模式运行。\"\n RefreshValue = <function> defined @Interface\\SharedXML\\VideoOptionsPanels.lua:670\n Right = Display_DisplayModeDropDownRight {\n }\n data = <table> {\n }\n GetSafeValue = <function> defined @Interface\\SharedXML\\GraphicsQualityLevels.lua:172\n selectedID = 2\n windowUpdate = true\n key = Display_DisplayModeDropDown {\n }\n Button = Display_DisplayModeDropDownButton {\n }\n noResize = 1\n Icon = Display_DisplayModeDropDownIcon {\n }\n width = 110\n fullscreenmode = <function> defined @Interface\\SharedXML\\GraphicsQualityLevels.lua:181\n warning = Display_DisplayModeDropDownWarning {\n }\n type = 2\n windowedmode = <function> defined @Interface\\SharedXML\\GraphicsQualityLevels.lua:177\n GetNewValueString = <function> defined @Interface\\SharedXML\\VideoOptionsPanels.lua:869\n Text = Display_DisplayModeDropDownText {\n }\n GetValue = <function> defined @Interface\\SharedXML\\VideoOptionsPanels.lua:859\n tablerefresh = true\n SetValue = <function> defined @Interface\\SharedXML\\VideoOptionsPanels.lua:393\n needrefresh = false\n name = \"显示模式\"\n initialize = <function> defined @Interface\\SharedXML\\VideoOptionsPanels.lua:799\n Middle = Display_DisplayModeDropDownMiddle {\n }\n dependent = <table> {\n }\n Left = Display_DisplayModeDropDownLeft {\n }\n lookup = <function> defined @Interface\\SharedXML\\VideoOptionsPanels.lua:493\n}\n(*temporary) = <table> {\n gxMaximize = 1\n}\n(*temporary) = <function> defined =[C]:-1\n(*temporary) = <table> {\n 1 = <table> {\n }\n 2 = <table> {\n }\n}\n(*temporary) = 2\n(*temporary) = \"attempt to perform arithmetic on a nil value\"\n",
			["stack"] = "[string \"@Interface\\AddOns\\Masque_Epix\\Masque_Epix-1.0.lua\"]:9: in main chunk",
			["session"] = 170,
			["counter"] = 5,
		}, -- [45]
		{
			["message"] = "(null)",
			["time"] = "2021/07/26 15:28:18",
			["session"] = 170,
			["counter"] = 18,
		}, -- [46]
		{
			["message"] = "Couldn't open Interface\\AddOns\\alaTalentEmu\\TalentEmu.xml",
			["session"] = 183,
			["time"] = "2021/12/06 23:37:48",
			["counter"] = 3,
		}, -- [47]
		{
			["message"] = "...erQuestTracker\\QuestWatchHelper\\QuestWatchHelper.lua:164: attempt to index upvalue 'BlizzardTrackerFrame' (a nil value)",
			["time"] = "2021/05/25 15:30:10",
			["stack"] = "[string \"@Interface\\AddOns\\ButterQuestTracker\\QuestWatchHelper\\QuestWatchHelper.lua\"]:164: in function `KeepHidden'\n[string \"@Interface\\AddOns\\ButterQuestTracker\\ButterQuestTracker-1.9.27.lua\"]:58: in function <...ace\\AddOns\\ButterQuestTracker\\ButterQuestTracker.lua:43>\n[string \"=[C]\"]: ?\n[string \"@Interface\\AddOns\\BlizzMove\\Libs\\AceAddon-3.0\\AceAddon-3.0-13.lua\"]:70: in function <...\\AddOns\\BlizzMove\\Libs\\AceAddon-3.0\\AceAddon-3.0.lua:65>\n[string \"@Interface\\AddOns\\BlizzMove\\Libs\\AceAddon-3.0\\AceAddon-3.0-13.lua\"]:527: in function `EnableAddon'\n[string \"@Interface\\AddOns\\BlizzMove\\Libs\\AceAddon-3.0\\AceAddon-3.0-13.lua\"]:630: in function <...\\AddOns\\BlizzMove\\Libs\\AceAddon-3.0\\AceAddon-3.0.lua:615>",
			["session"] = 184,
			["counter"] = 55,
		}, -- [48]
	},
}
