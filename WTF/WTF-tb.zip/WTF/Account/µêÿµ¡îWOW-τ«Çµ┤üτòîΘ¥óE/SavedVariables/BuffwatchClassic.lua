
BuffwatchConfig = {
	["CooldownTextScale"] = 0.449999988079071,
	["ExpiredSound"] = false,
	["debug"] = false,
	["Version"] = "2.01",
	["Spirals"] = true,
	["ExpiredWarning"] = true,
	["Alpha"] = 0.5,
	["HideCooldownText"] = true,
}
