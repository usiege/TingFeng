
BugSackDB = {
	["soundMedia"] = "BugSack: Fatality",
	["fontSize"] = "GameFontHighlight",
	["useMaster"] = false,
	["altwipe"] = false,
	["mute"] = true,
	["auto"] = false,
	["chatframe"] = false,
}
BugSackLDBIconDB = {
}
