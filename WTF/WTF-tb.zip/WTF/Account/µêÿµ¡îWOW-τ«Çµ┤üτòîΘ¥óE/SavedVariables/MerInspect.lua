
MerInspectDB = {
	["ShowOwnFrameWhenInspecting"] = false,
	["ShowCharacterItemStats"] = true,
	["ShowInspectAngularBorder"] = false,
	["ShowCharacterItemSheet"] = true,
	["ShowInspectItemSheet"] = true,
	["version"] = 1,
	["ShowItemSlotString"] = true,
	["ShowItemStats"] = true,
	["ShowInspectColoredLabel"] = true,
	["ShowItemBorder"] = true,
}
