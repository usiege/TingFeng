
WhisperPopDB = {
	["listWidth"] = 200,
	["listHeight"] = 320,
	["keepDatas"] = {
	},
	["notifyButton"] = 1,
	["time"] = 1,
	["save"] = 1,
	["history"] = {
	},
	["help"] = 1,
	["buttonScale"] = 100,
	["keep"] = 1,
	["listScale"] = 100,
	["version"] = 4.12,
	["foreignOnly"] = 1,
	["applyFilters"] = 1,
	["sound"] = 1,
	["ignoreTags"] = 1,
}
