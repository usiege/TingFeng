
GatherMate2DB = {
	["profileKeys"] = {
		["猎猎思密达 - 阿什坎迪"] = "Default",
		["暗黑界面 - 阿什坎迪"] = "Default",
		["简洁界面 - 阿什坎迪"] = "Default",
	},
	["global"] = {
		["data_version"] = 5,
	},
	["profiles"] = {
		["Default"] = {
		},
	},
}
GatherMate2HerbDB = {
}
GatherMate2MineDB = {
}
GatherMate2FishDB = {
}
GatherMate2GasDB = {
}
GatherMate2TreasureDB = {
}
