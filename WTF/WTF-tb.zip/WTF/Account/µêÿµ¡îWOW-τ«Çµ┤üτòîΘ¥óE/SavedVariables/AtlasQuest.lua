
AtlasQuest_Options = {
	["Version"] = "4.12.83",
	["暗黑界面"] = {
		["ShownSide"] = "Left",
		["AtlasAutoShow"] = 1,
	},
	["虎狼之词"] = {
		["ShownSide"] = "Left",
		["AtlasAutoShow"] = 1,
	},
	["简洁界面"] = {
		["ShownSide"] = "Left",
		["AtlasAutoShow"] = 1,
	},
	["猎猎思密达"] = {
		["ShownSide"] = "Left",
		["AtlasAutoShow"] = 1,
	},
}
