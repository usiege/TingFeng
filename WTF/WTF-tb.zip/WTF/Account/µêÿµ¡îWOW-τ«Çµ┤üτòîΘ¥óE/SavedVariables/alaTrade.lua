
alaTradeSV = {
	["config"] = {
		["show_DBIcon"] = true,
		["searchNameOnly"] = true,
		["show_disenchant_price"] = true,
		["show_vendor_price"] = true,
		["show_ah_price_multi"] = true,
		["sort_method_seq"] = -1,
		["cache_history"] = true,
		["regular_exp"] = false,
		["show_vendor_price_multi"] = true,
		["prev_cache_all"] = 1625219212,
		["data_valid_time"] = 3600,
		["avoid_stuck_cost"] = 100,
		["auto_clean_time"] = 0,
		["avoid_stuck"] = true,
		["show_disenchant_detail"] = true,
		["show_ah_price"] = true,
		["sort_method"] = 1,
		["minimapPos"] = 165,
		["showEmpty"] = false,
		["BaudAuctionFrame"] = true,
	},
	["cache"] = {
		["阿什坎迪"] = {
		},
	},
	["cache3"] = {
	},
	["_version"] = 200525,
	["cache2"] = {
	},
}
