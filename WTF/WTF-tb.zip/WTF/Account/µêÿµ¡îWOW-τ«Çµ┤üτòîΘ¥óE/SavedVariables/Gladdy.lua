
GladdyXZ = {
	["profileKeys"] = {
		["猎猎思密达 - 阿什坎迪"] = "简洁界面 - 阿什坎迪",
		["暗黑界面 - 阿什坎迪"] = "Default",
		["简洁界面 - 阿什坎迪"] = "简洁界面 - 阿什坎迪",
	},
	["profiles"] = {
		["Default"] = {
			["auraFontSizeScale"] = 0.9,
			["rangeCheckTrinket"] = true,
			["npTotemPlatesSize"] = 30,
			["shadowsightTimerX"] = 406.3031616210938,
			["ciYOffset"] = -21.19999999999999,
			["classIconSize"] = 80,
			["rangeCheckClassIcon"] = true,
			["y"] = 592.9090665288386,
			["shadowsightTimerY"] = -144.712158203125,
			["shadowsightTimerRelPoint2"] = "TOP",
			["racialSize"] = 80,
			["rangeCheckRacial"] = true,
			["x"] = 1012.241055847844,
			["cooldownSize"] = 38,
			["cooldownFontScale"] = 0.7000000000000001,
			["announcements"] = {
				["health"] = true,
			},
			["frameScale"] = 0.6,
			["shadowsightTimerRelPoint1"] = "TOP",
			["barWidth"] = 200,
		},
		["简洁界面 - 阿什坎迪"] = {
			["frameScale"] = 0.7000000000000001,
			["locked"] = true,
			["x"] = 967.7646330264834,
			["y"] = 549.4666429643403,
		},
	},
}
