
alaGearManSV = {
	["quickStyle"] = "C",
	["num_per_line"] = 6,
	["sets"] = {
		["Player-4792-00BAD688"] = {
		},
		["Player-4792-025EAE5E"] = {
		},
		["Player-4792-03A26BE8"] = {
		},
		["Player-4792-026E8FC2"] = {
		},
	},
	["useBar"] = true,
	["takeoffAll_pos"] = "RIGHT",
	["quickPos"] = {
		"LEFT", -- [1]
		nil, -- [2]
		"LEFT", -- [3]
		404.1111450195313, -- [4]
		-194.5555419921875, -- [5]
	},
	["takeoffAll_include_neck_finger_and_trinket"] = false,
	["_version"] = 200610,
	["show_outfit_in_tooltip"] = true,
	["multi_lines"] = false,
	["quickPosChar"] = {
	},
	["quickSize"] = 18,
}
