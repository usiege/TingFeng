
settings = {
	["followCheck"] = true,
	["followNameCheck"] = false,
	["followName"] = "这里输入队伍中要跟随的人",
	["command1"] = "11",
	["followLeaderCheck"] = true,
	["command2"] = "22",
	["greyCheck"] = true,
	["stopCheck"] = true,
	["greenCheck"] = false,
	["followPartyCheck"] = false,
	["tradeCheck"] = false,
	["repoCheck"] = true,
	["blueCheck"] = false,
}
