
alaTradeSkillSV = {
	["cmm"] = {
		[4792] = {
		},
	},
	["_GLOBAL"] = {
		["AuctionMaster"] = {
		},
		["CloudyTradeSkill"] = {
		},
		["Leatrix_Plus"] = {
		},
		["alaTrade"] = {
			["__ala_meta__"] = 1,
		},
		["db"] = {
		},
		["Auctioneer"] = {
		},
		["aux-addon"] = {
		},
		["AuctionBase"] = {
			["CreateFrame"] = 9,
		},
		["ui"] = {
			["ALADROP"] = 540,
			["ALASCR"] = 27,
			["ALA_HOOK_ChatEdit_InsertLink"] = 9,
			["ALA_HOOK_ChatEdit_InsertName"] = 9,
			["UISpecialFrames"] = 18,
			["UIParent"] = 27,
		},
		["tooltip"] = {
		},
		["MissingTradeSkillsList"] = {
		},
		["AuctionFaster"] = {
		},
		["AuctionDB"] = {
		},
		["Auctionator"] = {
			["Auctionator"] = 30,
		},
		["communication"] = {
		},
		["TradeSkillMaster"] = {
		},
		["Auctipus"] = {
		},
		["cooldown"] = {
		},
		["main"] = {
			["EnableAddOn"] = 9,
			["alaTradeSkillSV"] = 77,
			["LibStub"] = 18,
			["LoadAddOn"] = 9,
		},
	},
	["set"] = {
		["show_tradeskill_tip_craft_spell_price"] = true,
		["show_DBIcon"] = true,
		["first_auction_mod"] = "*",
		["show_tab"] = true,
		["show_board"] = false,
		["expand"] = false,
		["show_tradeskill_tip_recipe_price"] = true,
		["show_tradeskill_tip_craft_item_price"] = true,
		["show_tradeskill_frame_rank_info"] = true,
		["regular_exp"] = false,
		["blz_style"] = false,
		["minimapPos"] = 0,
		["lock_board"] = false,
		["show_tradeskill_tip_recipe_account_learned"] = true,
		["board_pos"] = {
			"TOP", -- [1]
			"UIParent", -- [2]
			"BOTTOM", -- [3]
			260, -- [4]
			190, -- [5]
		},
		["show_tradeskill_tip_material_craft_info"] = true,
		["show_tradeskill_frame_price_info"] = true,
		["default_skill_button_tip"] = true,
		["bg_color"] = {
			0, -- [1]
			0, -- [2]
			0, -- [3]
			0.75, -- [4]
		},
		["colored_rank_for_unknown"] = false,
		["char_list"] = {
			"Player-4792-026E8FC2", -- [1]
			"Player-4792-03A26BE8", -- [2]
		},
		["show_call"] = true,
		["portrait_button"] = true,
		["hide_mtsl"] = false,
		["explorer"] = {
			["searchText"] = "",
			["showItemInsteadOfSpell"] = false,
			["showProfit"] = false,
			["showRank"] = true,
			["update"] = true,
			["phase"] = 2,
			["filter"] = {
			},
			["showSet"] = true,
			["showUnkown"] = false,
			["showHighRank"] = false,
			["showKnown"] = true,
		},
	},
	["fav"] = {
	},
	["_version"] = 210605.1,
	["var"] = {
		["Player-4792-03A26BE8"] = {
			["realm_id"] = 4792,
			["supreme_list"] = {
			},
			["realm_name"] = "阿什坎迪",
		},
		["Player-4792-026E8FC2"] = {
			["realm_id"] = 4792,
			["supreme_list"] = {
			},
			["realm_name"] = "阿什坎迪",
		},
	},
}
