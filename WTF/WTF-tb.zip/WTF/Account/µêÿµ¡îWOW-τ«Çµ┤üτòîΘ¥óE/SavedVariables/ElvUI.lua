
ElvDB = {
	["LuaErrorDisabledAddOns"] = {
	},
	["gold"] = {
		["阿什坎迪"] = {
			["简洁界面"] = 4,
			["今晚就动手"] = 44,
		},
	},
	["global"] = {
		["nameplate"] = {
			["filters"] = {
				["ElvUI_Boss"] = {
				},
				["ElvUI_NonTarget"] = {
				},
				["ElvUI_TankNonTarget"] = {
				},
				["ElvUI_Target"] = {
				},
				["ElvUI_TankTarget"] = {
				},
			},
		},
		["general"] = {
			["AceGUI"] = {
				["height"] = 767.76,
				["width"] = 1017.21,
			},
			["smallerWorldMapScale"] = 0.8500000000000001,
			["UIScale"] = 0.8,
		},
	},
	["DisabledAddOns"] = {
	},
	["profileKeys"] = {
		["猎猎思密达 - 阿什坎迪"] = "Default",
		["简洁界面 - 阿什坎迪"] = "Default",
		["今晚就动手 - 阿什坎迪"] = "Default",
	},
	["class"] = {
		["阿什坎迪"] = {
			["简洁界面"] = "WARRIOR",
			["今晚就动手"] = "ROGUE",
		},
	},
	["faction"] = {
		["阿什坎迪"] = {
			["简洁界面"] = "Alliance",
			["今晚就动手"] = "Alliance",
		},
	},
	["profiles"] = {
		["简洁2"] = {
			["databars"] = {
				["reputation"] = {
					["enable"] = true,
					["height"] = 6,
					["width"] = 393,
				},
				["threat"] = {
					["enable"] = false,
					["height"] = 24,
					["width"] = 472,
				},
				["experience"] = {
					["height"] = 8,
					["textFormat"] = "PERCENT",
					["width"] = 393,
				},
				["petExperience"] = {
					["width"] = 65,
				},
			},
			["currentTutorial"] = 3,
			["general"] = {
				["loginmessage"] = false,
				["fontSize"] = 14,
				["itemLevel"] = {
					["displayCharacterInfo"] = false,
					["itemLevelFontSize"] = 10,
				},
				["autoTrackReputation"] = true,
				["afk"] = false,
				["totems"] = {
					["size"] = 30,
					["growthDirection"] = "HORIZONTAL",
					["spacing"] = 8,
				},
				["minimap"] = {
					["icons"] = {
						["tracking"] = {
							["xOffset"] = -12,
							["scale"] = 0.6,
							["position"] = "TOPLEFT",
						},
					},
					["locationText"] = "SHOW",
					["size"] = 140,
				},
				["interruptAnnounce"] = "RAID",
				["altPowerBar"] = {
					["statusBar"] = "Melli",
				},
				["bottomPanel"] = false,
				["backdropfadecolor"] = {
					["a"] = 0.85700567066669,
					["r"] = 0.058823529411765,
					["g"] = 0.058823529411765,
					["b"] = 0.058823529411765,
				},
				["objectiveFrameHeight"] = 550,
				["valuecolor"] = {
					["r"] = 0.999997794628143,
					["g"] = 0.956860661506653,
					["b"] = 0.407842248678207,
				},
				["bonusObjectivePosition"] = "AUTO",
				["numberPrefixStyle"] = "CHINESE",
			},
			["movers"] = {
				["ElvUF_FocusCastbarMover"] = "TOPLEFT,ElvUF_Focus,BOTTOMLEFT,0,-1",
				["ElvUF_FocusTargetMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,361,-92",
				["BuffsMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-161,-5",
				["BossButton"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-441,346",
				["LootFrameMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,423,-416",
				["ZoneAbility"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,422,323",
				["DurabilityFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-76,-324",
				["ElvUF_PetCastbarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,423,121",
				["VehicleSeatMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-66,-261",
				["ElvUF_TargetTargetMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-416,256",
				["EuiExecuteMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,634,-367",
				["LossControlMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-407,101",
				["WTCombatAlertFrameMover"] = "TOP,ElvUIParent,TOP,0,-276",
				["MirrorTimer1Mover"] = "TOP,ElvUIParent,TOP,0,-140",
				["ElvAB_4"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-525,10",
				["AltPowerBarMover"] = "TOP,ElvUIParent,TOP,0,-196",
				["ReputationBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,0",
				["ObjectiveFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-83,-236",
				["MirrorTimer2Mover"] = "TOP,MirrorTimer1,BOTTOM,0,0",
				["ShiftAB"] = "BOTTOM,ElvUIParent,BOTTOM,-175,104",
				["ElvUF_TargetCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,253,245",
				["ElvUF_PlayerMover"] = "BOTTOM,ElvUIParent,BOTTOM,-253,256",
				["RightChatMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-4,4",
				["RaidCDAnchorMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,366,-300",
				["AutoButtonAnchor3Mover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-208,214",
				["ElvUF_AssistMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,123,-43",
				["WTRaidMarkersBarAnchor"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,310",
				["TopCenterContainerMover"] = "TOP,ElvUIParent,TOP,0,-51",
				["ThreatBarMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-4,4",
				["PetAB"] = "BOTTOM,ElvUIParent,BOTTOM,46,103",
				["ElvUF_RaidMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,0,-116",
				["LeftChatMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,27",
				["GMMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,315",
				["BagsMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-4,33",
				["WTChatBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,288",
				["WTMinimapButtonBarAnchor"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-4,-4",
				["ElvUF_FocusMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,222,-81",
				["AutoButtonAnchorMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-66,214",
				["ClassBarMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,475,-31",
				["MicrobarMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-20,4",
				["PetExperienceBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,423,176",
				["PowerBarContainerMover"] = "TOP,ElvUIParent,TOP,0,-55",
				["WTCustomEmoteFrameMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,324,56",
				["ExperienceBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,6",
				["ArenaHeaderMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-156,-264",
				["ElvUF_TargetMover"] = "BOTTOM,ElvUIParent,BOTTOM,253,256",
				["WTSwitchButtonBarMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-60,-196",
				["ElvUF_PetMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,423,139",
				["ElvUF_Raid40Mover"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-235",
				["WTParagonReputationToastFrameMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-49",
				["QuestTimerFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,0,-171",
				["ElvAB_1"] = "BOTTOM,ElvUIParent,BOTTOM,0,13",
				["ElvAB_2"] = "BOTTOM,ElvUIParent,BOTTOM,164,436",
				["BelowMinimapContainerMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-4,-166",
				["TalkingHeadFrameMover"] = "BOTTOM,ElvUIParent,BOTTOM,-2,144",
				["WTGameBarAnchor"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-4",
				["EUIMinimapButtonMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-138,-75",
				["ElvUIBankMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,191,289",
				["ElvAB_3"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,525,10",
				["ElvAB_5"] = "BOTTOM,ElvUIParent,BOTTOM,0,43",
				["VehicleLeaveButton"] = "BOTTOM,ElvUIParent,BOTTOM,206,131",
				["MirrorTimer3Mover"] = "TOP,MirrorTimer2,BOTTOM,0,0",
				["LevelUpBossBannerMover"] = "TOP,ElvUIParent,TOP,0,-107",
				["ElvUF_PlayerCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,131",
				["ExAE_FrameMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,360,276",
				["VOICECHAT"] = "TOP,ElvUIParent,TOP,-251,-3",
				["ElvUIBagMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-420,-249",
				["HonorBarMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-2,-251",
				["ElvAB_6"] = "BOTTOM,ElvUIParent,BOTTOM,0,73",
				["TooltipMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-78,323",
				["ElvUF_TankMover"] = "TOPLEFT,UIParent,TOPLEFT,4,-71",
				["BossHeaderMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-158,-262",
				["TotemBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,371,255",
				["BNETMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,315",
				["ElvUF_PartyMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,121,-291",
				["AlertFrameMover"] = "BOTTOM,ElvUIParent,BOTTOM,-3,417",
				["DebuffsMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-160,-133",
				["MinimapMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-4,-4",
			},
			["convertPages"] = true,
			["bags"] = {
				["bagWidth"] = 550,
				["split"] = {
					["bagSpacing"] = 7,
					["bag4"] = true,
					["bag1"] = true,
					["bag2"] = true,
					["bag3"] = true,
				},
				["vendorGrays"] = {
					["enable"] = true,
				},
				["bagSize"] = 40,
				["bankWidth"] = 550,
				["bagBar"] = {
					["size"] = 25,
					["growthDirection"] = "HORIZONTAL",
				},
				["itemLevelCustomColorEnable"] = true,
				["scrapIcon"] = true,
				["bankSize"] = 40,
			},
			["chat"] = {
				["customTimeColor"] = {
					["b"] = 0.70196078431373,
					["g"] = 0.70196078431373,
					["r"] = 0.70196078431373,
				},
				["emotionIcons"] = false,
				["panelColor"] = {
					["a"] = 0.215930461883545,
					["r"] = 0.0588235294117647,
					["g"] = 0.0588235294117647,
					["b"] = 0.0588235294117647,
				},
				["panelBackdrop"] = "LEFT",
				["maxLines"] = 353,
				["copyChatLines"] = true,
				["tabSelectorColor"] = {
					["r"] = 0.999997794628143,
					["g"] = 0.956860661506653,
					["b"] = 0.407842248678207,
				},
				["scrollDownInterval"] = 30,
				["panelHeight"] = 260,
				["tabSelector"] = "NONE",
				["panelWidthRight"] = 300,
				["editBoxPosition"] = "ABOVE_CHAT",
				["panelWidth"] = 350,
			},
			["auras"] = {
				["debuffs"] = {
					["timeFontOutline"] = "OUTLINE",
					["countFont"] = "傷害數字",
					["timeFont"] = "傷害數字",
					["countFontOutline"] = "OUTLINE",
					["size"] = 26,
				},
				["buffs"] = {
					["timeFontSize"] = 11,
					["countFont"] = "傷害數字",
					["countFontOutline"] = "OUTLINE",
					["timeFont"] = "EUI",
					["timeFontOutline"] = "OUTLINE",
					["size"] = 26,
				},
			},
			["unitframe"] = {
				["statusbar"] = "ElvUI Blank",
				["font"] = "聊天",
				["colors"] = {
					["auraBarBuff"] = {
						["r"] = 0.999997794628143,
						["g"] = 0.486273437738419,
						["b"] = 0.0392156019806862,
					},
					["castClassColor"] = true,
					["healthclass"] = true,
				},
				["smartRaidFilter"] = false,
				["smoothbars"] = true,
				["fontOutline"] = "THICKOUTLINE",
				["cooldown"] = {
					["fonts"] = {
						["enable"] = true,
						["fontSize"] = 15,
					},
				},
				["units"] = {
					["tank"] = {
						["verticalSpacing"] = 2,
						["width"] = 85,
					},
					["focustarget"] = {
						["castbar"] = {
							["width"] = 80,
						},
						["width"] = 80,
						["power"] = {
							["enable"] = false,
						},
					},
					["pet"] = {
						["infoPanel"] = {
							["height"] = 14,
						},
						["debuffs"] = {
							["enable"] = true,
						},
						["disableTargetGlow"] = false,
						["castbar"] = {
							["iconSize"] = 32,
							["width"] = 65,
						},
						["customTexts"] = {
							["名字"] = {
								["attachTextTo"] = "Health",
								["xOffset"] = 0,
								["text_format"] = "[namecolor][name:medium]",
								["yOffset"] = 0,
								["font"] = "聊天",
								["justifyH"] = "CENTER",
								["fontOutline"] = "OUTLINE",
								["enable"] = true,
								["size"] = 10,
							},
						},
						["power"] = {
							["height"] = 4,
						},
						["name"] = {
							["text_format"] = "[happiness:full]",
							["yOffset"] = 10,
						},
						["width"] = 65,
					},
					["targettarget"] = {
						["raidicon"] = {
							["attachTo"] = "LEFT",
							["xOffset"] = 2,
							["enable"] = false,
							["yOffset"] = 0,
						},
						["debuffs"] = {
							["enable"] = false,
							["anchorPoint"] = "TOPRIGHT",
						},
						["threatStyle"] = "GLOW",
						["power"] = {
							["enable"] = false,
						},
						["height"] = 35,
						["name"] = {
							["text_format"] = "[name:medium]",
						},
						["disableMouseoverGlow"] = true,
						["width"] = 100,
					},
					["target"] = {
						["debuffs"] = {
							["countFontSize"] = 5,
							["perrow"] = 7,
							["attachTo"] = "FRAME",
							["priority"] = "Blacklist,Personal,nonPersonal",
							["numrows"] = 2,
							["yOffset"] = 16,
						},
						["portrait"] = {
							["overlay"] = true,
							["overlayAlpha"] = 0.8,
							["camDistanceScale"] = 4,
							["enable"] = true,
						},
						["power"] = {
							["attachTextTo"] = "Power",
							["xOffset"] = -2,
							["text_format"] = "[powercolor][  >power:current]",
							["position"] = "RIGHT",
						},
						["customTexts"] = {
							["精英"] = {
								["attachTextTo"] = "Health",
								["xOffset"] = -80,
								["text_format"] = "[classification:icon][range]",
								["yOffset"] = 25,
								["font"] = "聊天",
								["justifyH"] = "CENTER",
								["fontOutline"] = "OUTLINE",
								["enable"] = true,
								["size"] = 10,
							},
						},
						["castbar"] = {
							["height"] = 10,
							["width"] = 160,
							["insideInfoPanel"] = false,
						},
						["disableMouseoverGlow"] = true,
						["width"] = 160,
						["health"] = {
							["attachTextTo"] = "InfoPanel",
							["xOffset"] = 0,
							["text_format"] = "[health:current:shortvalue]  -  [perhp]%",
							["yOffset"] = 3,
						},
						["name"] = {
							["yOffset"] = 16,
							["text_format"] = "[level]   [name]",
							["position"] = "TOPRIGHT",
						},
						["fader"] = {
							["range"] = false,
						},
						["height"] = 45,
						["orientation"] = "LEFT",
						["buffs"] = {
							["countFontSize"] = 5,
							["perrow"] = 7,
							["attachTo"] = "DEBUFFS",
							["growthX"] = "RIGHT",
							["numrows"] = 2,
							["priority"] = "Blacklist,Dispellable,Personal,nonPersonal,PlayerBuffs,Whitelist",
							["anchorPoint"] = "BOTTOMLEFT",
							["yOffset"] = -73,
						},
						["CombatIcon"] = {
							["xOffset"] = 81,
							["yOffset"] = 27,
						},
						["aurabar"] = {
							["height"] = 18,
							["enable"] = false,
						},
					},
					["player"] = {
						["RestIcon"] = {
							["size"] = 20,
						},
						["debuffs"] = {
							["countFontSize"] = 10,
							["sizeOverride"] = 25,
							["perrow"] = 6,
							["numrows"] = 2,
							["anchorPoint"] = "BOTTOMLEFT",
							["yOffset"] = -30,
						},
						["portrait"] = {
							["overlay"] = true,
							["overlayAlpha"] = 0.8,
							["camDistanceScale"] = 4,
							["enable"] = true,
						},
						["power"] = {
							["attachTextTo"] = "Power",
							["text_format"] = "[powercolor][curpp]",
						},
						["disableMouseoverGlow"] = true,
						["width"] = 160,
						["health"] = {
							["xOffset"] = 0,
							["text_format"] = "[health:current:shortvalue]                   [perhp]%",
							["position"] = "RIGHT",
						},
						["classbar"] = {
							["detachedWidth"] = 360,
							["autoHide"] = true,
						},
						["name"] = {
							["yOffset"] = 16,
							["text_format"] = "[name]   [level]",
							["position"] = "TOPLEFT",
						},
						["castbar"] = {
							["height"] = 20,
							["width"] = 214,
							["insideInfoPanel"] = false,
						},
						["height"] = 45,
						["buffs"] = {
							["countFontSize"] = 10,
							["perrow"] = 6,
							["attachTo"] = "FRAME",
							["numrows"] = 2,
							["durationPosition"] = "BOTTOM",
							["yOffset"] = 15,
						},
						["CombatIcon"] = {
							["xOffset"] = -81,
							["yOffset"] = 28,
						},
						["aurabar"] = {
							["height"] = 10,
							["enable"] = false,
						},
					},
					["raid40"] = {
						["health"] = {
							["text_format"] = "[health:deficit]",
						},
						["power"] = {
							["enable"] = true,
						},
						["height"] = 40,
						["healPrediction"] = {
							["enable"] = true,
						},
						["enable"] = false,
					},
					["focus"] = {
						["enable"] = false,
						["castbar"] = {
							["width"] = 120,
						},
						["health"] = {
							["xOffset"] = -37,
							["text_format"] = " [perhp]%",
							["yOffset"] = -18,
						},
						["width"] = 120,
					},
					["assist"] = {
						["enable"] = false,
					},
					["raid"] = {
						["debuffs"] = {
							["enable"] = true,
							["anchorPoint"] = "CENTER",
						},
						["height"] = 45,
						["healPrediction"] = {
							["enable"] = true,
						},
						["enable"] = false,
						["buffs"] = {
							["enable"] = true,
							["anchorPoint"] = "CENTER",
						},
					},
					["arena"] = {
						["enable"] = false,
					},
					["party"] = {
						["debuffs"] = {
							["countFontSize"] = 8,
							["sizeOverride"] = 22,
							["priority"] = "",
							["numrows"] = 2,
							["yOffset"] = 11,
						},
						["power"] = {
							["text_format"] = "",
							["height"] = 4,
						},
						["healPrediction"] = {
							["enable"] = true,
						},
						["width"] = 120,
						["name"] = {
							["text_format"] = "[namecolor][name:medium] [difficultycolor][level]",
						},
						["health"] = {
							["text_format"] = "",
						},
						["buffs"] = {
							["countFontSize"] = 8,
							["sizeOverride"] = 22,
							["perrow"] = 5,
							["enable"] = true,
							["priority"] = "",
							["numrows"] = 2,
							["yOffset"] = 11,
						},
						["height"] = 44,
						["verticalSpacing"] = 6,
						["visibility"] = "[@raid2,exists][@party1,noexists] hide;show",
						["rdebuffs"] = {
							["font"] = "PT Sans Narrow",
							["size"] = 20,
							["yOffset"] = 12,
						},
					},
				},
			},
			["dbConverted"] = 2.3,
			["datatexts"] = {
				["fontSize"] = 10,
				["panels"] = {
					["MinimapPanel"] = {
						["backdrop"] = false,
						["border"] = false,
					},
					["RightChatDataPanel"] = {
						"Gold", -- [1]
						"MeetingStone", -- [2]
						"System", -- [3]
						["enable"] = false,
						["backdrop"] = false,
					},
					["LeftChatDataPanel"] = {
						"WeakAuras", -- [1]
						"ElvUI", -- [2]
						"Durability", -- [3]
						["enable"] = false,
						["backdrop"] = false,
						["panelTransparency"] = true,
					},
				},
				["fontOutline"] = "OUTLINE",
			},
			["actionbar"] = {
				["bar3"] = {
					["point"] = "TOPLEFT",
					["buttons"] = 12,
					["macrotext"] = true,
					["buttonsPerRow"] = 4,
					["visibility"] = "[petbattle] hide; show",
					["buttonSize"] = 31,
				},
				["bar6"] = {
					["enabled"] = true,
					["macrotext"] = true,
					["point"] = "TOPLEFT",
					["buttonSize"] = 31,
				},
				["bar2"] = {
					["macrotext"] = true,
					["visibility"] = "[petbattle] hide; show",
					["buttonSize"] = 31,
				},
				["bar10"] = {
					["macrotext"] = true,
				},
				["bar8"] = {
					["macrotext"] = true,
				},
				["bar5"] = {
					["buttonSize"] = 31,
					["macrotext"] = true,
					["buttonsPerRow"] = 12,
					["visibility"] = "[petbattle] hide; show",
					["buttons"] = 12,
				},
				["barPet"] = {
					["point"] = "TOPLEFT",
					["buttonsPerRow"] = 10,
					["backdrop"] = false,
					["buttonSize"] = 28,
				},
				["microbar"] = {
					["buttons"] = 7,
					["buttonSize"] = 23,
				},
				["font"] = "傷害數字",
				["bar7"] = {
					["macrotext"] = true,
				},
				["bar1"] = {
					["macrotext"] = true,
					["buttonSize"] = 31,
				},
				["bar9"] = {
					["macrotext"] = true,
				},
				["stanceBar"] = {
					["style"] = "classic",
					["buttonSpacing"] = 1,
					["buttonSize"] = 25,
				},
				["cooldown"] = {
					["fonts"] = {
						["enable"] = true,
					},
					["override"] = false,
				},
				["bar4"] = {
					["point"] = "TOPLEFT",
					["buttonSize"] = 31,
					["macrotext"] = true,
					["buttonsPerRow"] = 4,
					["visibility"] = "[petbattle] hide; show",
					["backdrop"] = false,
				},
			},
			["nameplates"] = {
				["clampToScreen"] = true,
				["statusbar"] = "Melli",
				["units"] = {
					["ENEMY_NPC"] = {
						["debuffs"] = {
							["size"] = 20,
							["yOffset"] = 15,
						},
						["health"] = {
							["text"] = {
								["format"] = "[perhp]%",
							},
						},
						["buffs"] = {
							["enable"] = false,
							["size"] = 20,
						},
					},
					["TARGET"] = {
						["classpower"] = {
							["enable"] = true,
							["width"] = 60,
							["yOffset"] = -11,
						},
					},
					["FRIENDLY_NPC"] = {
						["debuffs"] = {
							["enable"] = false,
							["size"] = 20,
						},
						["health"] = {
							["text"] = {
								["format"] = "[perhp]%",
							},
						},
						["buffs"] = {
							["enable"] = false,
							["size"] = 20,
						},
					},
					["ENEMY_PLAYER"] = {
						["debuffs"] = {
							["size"] = 20,
							["yOffset"] = 15,
						},
						["health"] = {
							["text"] = {
								["format"] = "[health:current:shortvalue]  -  [perhp]%",
							},
						},
						["buffs"] = {
							["size"] = 20,
						},
					},
					["FRIENDLY_PLAYER"] = {
						["debuffs"] = {
							["size"] = 20,
							["yOffset"] = 15,
						},
						["nameOnly"] = true,
						["health"] = {
							["text"] = {
								["format"] = "[perhp]%",
							},
						},
						["buffs"] = {
							["enable"] = false,
							["size"] = 20,
						},
					},
				},
			},
			["v11NamePlateReset"] = true,
			["cooldown"] = {
				["fonts"] = {
					["enable"] = true,
				},
				["hideBlizzard"] = true,
			},
			["tooltip"] = {
				["itemCount"] = "NONE",
				["healthBar"] = {
					["height"] = 12,
					["font"] = "PT Sans Narrow",
					["fontSize"] = 12,
					["fontOutline"] = "NONE",
				},
				["showMount"] = false,
				["cursorAnchorType"] = "ANCHOR_CURSOR_RIGHT",
				["alwaysShowRealm"] = true,
				["modifierID"] = "SHIFT",
				["guildRanks"] = false,
			},
		},
		["简洁2-纯血条头像"] = {
			["databars"] = {
				["reputation"] = {
					["enable"] = true,
					["height"] = 6,
					["width"] = 393,
				},
				["threat"] = {
					["enable"] = false,
					["height"] = 24,
					["width"] = 472,
				},
				["experience"] = {
					["height"] = 8,
					["textFormat"] = "PERCENT",
					["width"] = 393,
				},
				["petExperience"] = {
					["width"] = 65,
				},
			},
			["currentTutorial"] = 3,
			["general"] = {
				["loginmessage"] = false,
				["fontSize"] = 14,
				["itemLevel"] = {
					["itemLevelFontSize"] = 10,
					["displayCharacterInfo"] = false,
				},
				["autoTrackReputation"] = true,
				["afk"] = false,
				["totems"] = {
					["growthDirection"] = "HORIZONTAL",
					["size"] = 30,
					["spacing"] = 8,
				},
				["minimap"] = {
					["icons"] = {
						["tracking"] = {
							["xOffset"] = -12,
							["scale"] = 0.6,
							["position"] = "TOPLEFT",
						},
					},
					["locationText"] = "SHOW",
					["size"] = 140,
				},
				["interruptAnnounce"] = "RAID",
				["altPowerBar"] = {
					["statusBar"] = "Melli",
				},
				["bottomPanel"] = false,
				["backdropfadecolor"] = {
					["a"] = 0.85700567066669,
					["r"] = 0.058823529411765,
					["g"] = 0.058823529411765,
					["b"] = 0.058823529411765,
				},
				["objectiveFrameHeight"] = 550,
				["valuecolor"] = {
					["r"] = 0.999997794628143,
					["g"] = 0.956860661506653,
					["b"] = 0.407842248678207,
				},
				["bonusObjectivePosition"] = "AUTO",
				["numberPrefixStyle"] = "CHINESE",
			},
			["movers"] = {
				["ElvUF_FocusCastbarMover"] = "TOPLEFT,ElvUF_Focus,BOTTOMLEFT,0,-1",
				["ElvUF_FocusTargetMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,361,-92",
				["BuffsMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-161,-5",
				["BossButton"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-441,346",
				["LootFrameMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,423,-416",
				["ZoneAbility"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,422,323",
				["PowerBarContainerMover"] = "TOP,ElvUIParent,TOP,0,-55",
				["ElvUF_PetCastbarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,423,121",
				["VehicleSeatMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-66,-261",
				["ElvUF_TargetTargetMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-405,256",
				["EuiExecuteMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,634,-367",
				["LossControlMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-407,101",
				["WTCombatAlertFrameMover"] = "TOP,ElvUIParent,TOP,0,-276",
				["MirrorTimer1Mover"] = "TOP,ElvUIParent,TOP,0,-140",
				["ElvAB_4"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-525,10",
				["AltPowerBarMover"] = "TOP,ElvUIParent,TOP,0,-196",
				["ReputationBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,0",
				["ObjectiveFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-83,-236",
				["MirrorTimer2Mover"] = "TOP,MirrorTimer1,BOTTOM,0,0",
				["ShiftAB"] = "BOTTOM,ElvUIParent,BOTTOM,-175,104",
				["ElvUF_TargetCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,253,245",
				["ElvUF_PlayerMover"] = "BOTTOM,ElvUIParent,BOTTOM,-253,256",
				["RightChatMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-4,4",
				["RaidCDAnchorMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,366,-300",
				["AutoButtonAnchor3Mover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-208,214",
				["ElvUF_AssistMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,123,-43",
				["WTRaidMarkersBarAnchor"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,310",
				["TopCenterContainerMover"] = "TOP,ElvUIParent,TOP,0,-51",
				["ThreatBarMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-4,4",
				["PetAB"] = "BOTTOM,ElvUIParent,BOTTOM,46,103",
				["ElvUF_RaidMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,0,-116",
				["LeftChatMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,27",
				["GMMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,315",
				["BagsMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-4,33",
				["WTChatBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,288",
				["WTMinimapButtonBarAnchor"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-4,-4",
				["ElvUF_FocusMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,222,-81",
				["AutoButtonAnchorMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-66,214",
				["EUIMinimapButtonMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-138,-75",
				["MicrobarMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-20,4",
				["PetExperienceBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,423,176",
				["WTCustomEmoteFrameMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,324,56",
				["ArenaHeaderMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-156,-264",
				["ExperienceBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,6",
				["BNETMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,315",
				["ElvUF_TargetMover"] = "BOTTOM,ElvUIParent,BOTTOM,253,256",
				["WTParagonReputationToastFrameMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-49",
				["TotemBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,371,255",
				["ElvUF_Raid40Mover"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-235",
				["TalkingHeadFrameMover"] = "BOTTOM,ElvUIParent,BOTTOM,-2,144",
				["DurabilityFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-76,-324",
				["ElvAB_1"] = "BOTTOM,ElvUIParent,BOTTOM,0,13",
				["ElvAB_2"] = "BOTTOM,ElvUIParent,BOTTOM,164,436",
				["BelowMinimapContainerMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-4,-166",
				["ClassBarMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,475,-31",
				["WTGameBarAnchor"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-4",
				["ElvUIBankMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,191,289",
				["WTSwitchButtonBarMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-60,-196",
				["ElvAB_3"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,525,10",
				["ElvAB_5"] = "BOTTOM,ElvUIParent,BOTTOM,0,43",
				["VehicleLeaveButton"] = "BOTTOM,ElvUIParent,BOTTOM,206,131",
				["LevelUpBossBannerMover"] = "TOP,ElvUIParent,TOP,0,-107",
				["MirrorTimer3Mover"] = "TOP,MirrorTimer2,BOTTOM,0,0",
				["ElvUF_PlayerCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,131",
				["ExAE_FrameMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,360,276",
				["VOICECHAT"] = "TOP,ElvUIParent,TOP,-251,-3",
				["ElvUIBagMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-420,-249",
				["HonorBarMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-2,-251",
				["ElvAB_6"] = "BOTTOM,ElvUIParent,BOTTOM,0,73",
				["TooltipMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-78,323",
				["ElvUF_TankMover"] = "TOPLEFT,UIParent,TOPLEFT,4,-74",
				["BossHeaderMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-158,-262",
				["ElvUF_PetMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,423,139",
				["QuestTimerFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,0,-171",
				["ElvUF_PartyMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,121,-291",
				["AlertFrameMover"] = "BOTTOM,ElvUIParent,BOTTOM,-3,417",
				["DebuffsMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-160,-133",
				["MinimapMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-4,-4",
			},
			["convertPages"] = true,
			["v11NamePlateReset"] = true,
			["auras"] = {
				["debuffs"] = {
					["timeFontOutline"] = "OUTLINE",
					["countFont"] = "傷害數字",
					["timeFont"] = "傷害數字",
					["countFontOutline"] = "OUTLINE",
					["size"] = 26,
				},
				["buffs"] = {
					["timeFontOutline"] = "OUTLINE",
					["countFont"] = "傷害數字",
					["countFontOutline"] = "OUTLINE",
					["timeFont"] = "EUI",
					["timeFontSize"] = 11,
					["size"] = 26,
				},
			},
			["chat"] = {
				["tabSelector"] = "NONE",
				["emotionIcons"] = false,
				["panelColor"] = {
					["a"] = 0.215930461883545,
					["r"] = 0.0588235294117647,
					["g"] = 0.0588235294117647,
					["b"] = 0.0588235294117647,
				},
				["panelBackdrop"] = "LEFT",
				["maxLines"] = 353,
				["copyChatLines"] = true,
				["tabSelectorColor"] = {
					["r"] = 0.999997794628143,
					["g"] = 0.956860661506653,
					["b"] = 0.407842248678207,
				},
				["scrollDownInterval"] = 30,
				["panelHeight"] = 260,
				["customTimeColor"] = {
					["r"] = 0.70196078431373,
					["g"] = 0.70196078431373,
					["b"] = 0.70196078431373,
				},
				["panelWidthRight"] = 300,
				["editBoxPosition"] = "ABOVE_CHAT",
				["panelWidth"] = 350,
			},
			["unitframe"] = {
				["font"] = "聊天",
				["statusbar"] = "ElvUI Blank",
				["colors"] = {
					["auraBarBuff"] = {
						["r"] = 0.999997794628143,
						["g"] = 0.486273437738419,
						["b"] = 0.0392156019806862,
					},
					["castClassColor"] = true,
					["healthclass"] = true,
				},
				["smartRaidFilter"] = false,
				["smoothbars"] = true,
				["fontOutline"] = "THICKOUTLINE",
				["cooldown"] = {
					["fonts"] = {
						["enable"] = true,
						["fontSize"] = 15,
					},
				},
				["units"] = {
					["tank"] = {
						["verticalSpacing"] = 2,
						["width"] = 85,
					},
					["focustarget"] = {
						["power"] = {
							["enable"] = false,
						},
						["width"] = 80,
						["castbar"] = {
							["width"] = 80,
						},
					},
					["pet"] = {
						["infoPanel"] = {
							["height"] = 14,
						},
						["debuffs"] = {
							["enable"] = true,
						},
						["disableTargetGlow"] = false,
						["power"] = {
							["height"] = 4,
						},
						["customTexts"] = {
							["名字"] = {
								["attachTextTo"] = "Health",
								["enable"] = true,
								["text_format"] = "[namecolor][name:medium]",
								["yOffset"] = 0,
								["font"] = "聊天",
								["justifyH"] = "CENTER",
								["fontOutline"] = "OUTLINE",
								["xOffset"] = 0,
								["size"] = 10,
							},
						},
						["castbar"] = {
							["iconSize"] = 32,
							["width"] = 65,
						},
						["name"] = {
							["text_format"] = "[happiness:full]",
							["yOffset"] = 10,
						},
						["width"] = 65,
					},
					["party"] = {
						["debuffs"] = {
							["countFontSize"] = 8,
							["sizeOverride"] = 22,
							["priority"] = "",
							["numrows"] = 2,
							["yOffset"] = 11,
						},
						["power"] = {
							["text_format"] = "",
							["height"] = 4,
						},
						["healPrediction"] = {
							["enable"] = true,
						},
						["width"] = 120,
						["name"] = {
							["text_format"] = "[namecolor][name:medium] [difficultycolor][level]",
						},
						["health"] = {
							["text_format"] = "",
						},
						["verticalSpacing"] = 6,
						["height"] = 44,
						["buffs"] = {
							["countFontSize"] = 8,
							["sizeOverride"] = 22,
							["perrow"] = 5,
							["enable"] = true,
							["priority"] = "",
							["numrows"] = 2,
							["yOffset"] = 11,
						},
						["visibility"] = "[@raid2,exists][@party1,noexists] hide;show",
						["rdebuffs"] = {
							["font"] = "PT Sans Narrow",
							["size"] = 20,
							["yOffset"] = 12,
						},
					},
					["assist"] = {
						["enable"] = false,
					},
					["player"] = {
						["RestIcon"] = {
							["size"] = 20,
						},
						["debuffs"] = {
							["countFontSize"] = 10,
							["sizeOverride"] = 25,
							["perrow"] = 6,
							["numrows"] = 2,
							["anchorPoint"] = "BOTTOMLEFT",
							["yOffset"] = -30,
						},
						["portrait"] = {
							["overlay"] = true,
							["overlayAlpha"] = 0.7,
							["fullOverlay"] = true,
						},
						["power"] = {
							["attachTextTo"] = "Power",
							["text_format"] = "[powercolor][curpp]",
						},
						["disableMouseoverGlow"] = true,
						["width"] = 180,
						["health"] = {
							["xOffset"] = 0,
							["text_format"] = "[health:current:shortvalue]                         [perhp]%",
							["position"] = "RIGHT",
						},
						["CombatIcon"] = {
							["xOffset"] = -81,
							["yOffset"] = 28,
						},
						["name"] = {
							["yOffset"] = 16,
							["text_format"] = "[name]   [level]",
							["position"] = "TOPLEFT",
						},
						["castbar"] = {
							["height"] = 20,
							["width"] = 214,
							["insideInfoPanel"] = false,
						},
						["height"] = 40,
						["buffs"] = {
							["countFontSize"] = 10,
							["perrow"] = 6,
							["attachTo"] = "FRAME",
							["numrows"] = 2,
							["durationPosition"] = "BOTTOM",
							["yOffset"] = 15,
						},
						["classbar"] = {
							["detachedWidth"] = 360,
							["autoHide"] = true,
						},
						["aurabar"] = {
							["height"] = 10,
							["enable"] = false,
						},
					},
					["raid40"] = {
						["health"] = {
							["text_format"] = "[health:deficit]",
						},
						["power"] = {
							["enable"] = true,
						},
						["height"] = 40,
						["healPrediction"] = {
							["enable"] = true,
						},
						["enable"] = false,
					},
					["focus"] = {
						["enable"] = false,
						["castbar"] = {
							["width"] = 120,
						},
						["health"] = {
							["xOffset"] = -37,
							["text_format"] = " [perhp]%",
							["yOffset"] = -18,
						},
						["width"] = 120,
					},
					["target"] = {
						["debuffs"] = {
							["countFontSize"] = 5,
							["perrow"] = 7,
							["attachTo"] = "FRAME",
							["priority"] = "Blacklist,Personal,nonPersonal",
							["numrows"] = 2,
							["yOffset"] = 16,
						},
						["portrait"] = {
							["overlay"] = true,
							["overlayAlpha"] = 0.65,
							["fullOverlay"] = true,
						},
						["power"] = {
							["attachTextTo"] = "Power",
							["xOffset"] = -2,
							["text_format"] = "[powercolor][  >power:current]",
							["position"] = "RIGHT",
						},
						["customTexts"] = {
							["精英"] = {
								["attachTextTo"] = "Health",
								["enable"] = true,
								["text_format"] = "[classification:icon][range]",
								["yOffset"] = 25,
								["font"] = "聊天",
								["justifyH"] = "CENTER",
								["fontOutline"] = "OUTLINE",
								["xOffset"] = -80,
								["size"] = 10,
							},
						},
						["castbar"] = {
							["height"] = 10,
							["width"] = 180,
							["insideInfoPanel"] = false,
						},
						["disableMouseoverGlow"] = true,
						["width"] = 180,
						["name"] = {
							["yOffset"] = 16,
							["text_format"] = "[level]   [name]",
							["position"] = "TOPRIGHT",
						},
						["fader"] = {
							["range"] = false,
						},
						["health"] = {
							["attachTextTo"] = "InfoPanel",
							["xOffset"] = 0,
							["text_format"] = "[health:current:shortvalue]  -  [perhp]%",
							["yOffset"] = 3,
						},
						["orientation"] = "LEFT",
						["height"] = 45,
						["buffs"] = {
							["countFontSize"] = 5,
							["perrow"] = 7,
							["attachTo"] = "DEBUFFS",
							["growthX"] = "RIGHT",
							["numrows"] = 2,
							["priority"] = "Blacklist,Dispellable,Personal,nonPersonal,PlayerBuffs,Whitelist",
							["anchorPoint"] = "BOTTOMLEFT",
							["yOffset"] = -73,
						},
						["CombatIcon"] = {
							["xOffset"] = 81,
							["yOffset"] = 27,
						},
						["aurabar"] = {
							["height"] = 18,
							["enable"] = false,
						},
					},
					["arena"] = {
						["enable"] = false,
					},
					["raid"] = {
						["debuffs"] = {
							["enable"] = true,
							["anchorPoint"] = "CENTER",
						},
						["height"] = 45,
						["healPrediction"] = {
							["enable"] = true,
						},
						["enable"] = false,
						["buffs"] = {
							["enable"] = true,
							["anchorPoint"] = "CENTER",
						},
					},
					["targettarget"] = {
						["raidicon"] = {
							["attachTo"] = "LEFT",
							["xOffset"] = 2,
							["enable"] = false,
							["yOffset"] = 0,
						},
						["debuffs"] = {
							["enable"] = false,
							["anchorPoint"] = "TOPRIGHT",
						},
						["threatStyle"] = "GLOW",
						["power"] = {
							["enable"] = false,
						},
						["height"] = 35,
						["name"] = {
							["text_format"] = "[name:medium]",
						},
						["disableMouseoverGlow"] = true,
						["width"] = 100,
					},
				},
			},
			["dbConverted"] = 2.3,
			["datatexts"] = {
				["fontSize"] = 10,
				["panels"] = {
					["MinimapPanel"] = {
						["border"] = false,
						["backdrop"] = false,
					},
					["RightChatDataPanel"] = {
						"Gold", -- [1]
						"MeetingStone", -- [2]
						"System", -- [3]
						["enable"] = false,
						["backdrop"] = false,
					},
					["LeftChatDataPanel"] = {
						"WeakAuras", -- [1]
						"ElvUI", -- [2]
						"Durability", -- [3]
						["enable"] = false,
						["backdrop"] = false,
						["panelTransparency"] = true,
					},
				},
				["fontOutline"] = "OUTLINE",
			},
			["actionbar"] = {
				["bar3"] = {
					["point"] = "TOPLEFT",
					["buttonSize"] = 31,
					["macrotext"] = true,
					["buttonsPerRow"] = 4,
					["visibility"] = "[petbattle] hide; show",
					["buttons"] = 12,
				},
				["bar6"] = {
					["enabled"] = true,
					["macrotext"] = true,
					["point"] = "TOPLEFT",
					["buttonSize"] = 31,
				},
				["bar2"] = {
					["macrotext"] = true,
					["visibility"] = "[petbattle] hide; show",
					["buttonSize"] = 31,
				},
				["bar10"] = {
					["macrotext"] = true,
				},
				["bar8"] = {
					["macrotext"] = true,
				},
				["bar5"] = {
					["buttons"] = 12,
					["macrotext"] = true,
					["buttonsPerRow"] = 12,
					["visibility"] = "[petbattle] hide; show",
					["buttonSize"] = 31,
				},
				["barPet"] = {
					["point"] = "TOPLEFT",
					["buttonsPerRow"] = 10,
					["backdrop"] = false,
					["buttonSize"] = 28,
				},
				["microbar"] = {
					["buttons"] = 7,
					["buttonSize"] = 23,
				},
				["font"] = "傷害數字",
				["bar7"] = {
					["macrotext"] = true,
				},
				["bar1"] = {
					["macrotext"] = true,
					["buttonSize"] = 31,
				},
				["bar9"] = {
					["macrotext"] = true,
				},
				["stanceBar"] = {
					["style"] = "classic",
					["buttonSpacing"] = 1,
					["buttonSize"] = 25,
				},
				["cooldown"] = {
					["fonts"] = {
						["enable"] = true,
					},
					["override"] = false,
				},
				["bar4"] = {
					["point"] = "TOPLEFT",
					["buttonSize"] = 31,
					["macrotext"] = true,
					["buttonsPerRow"] = 4,
					["visibility"] = "[petbattle] hide; show",
					["backdrop"] = false,
				},
			},
			["nameplates"] = {
				["clampToScreen"] = true,
				["statusbar"] = "Melli",
				["units"] = {
					["ENEMY_NPC"] = {
						["debuffs"] = {
							["size"] = 20,
							["yOffset"] = 15,
						},
						["health"] = {
							["text"] = {
								["format"] = "[perhp]%",
							},
						},
						["buffs"] = {
							["enable"] = false,
							["size"] = 20,
						},
					},
					["TARGET"] = {
						["classpower"] = {
							["enable"] = true,
							["width"] = 60,
							["yOffset"] = -11,
						},
					},
					["FRIENDLY_NPC"] = {
						["debuffs"] = {
							["enable"] = false,
							["size"] = 20,
						},
						["health"] = {
							["text"] = {
								["format"] = "[perhp]%",
							},
						},
						["buffs"] = {
							["enable"] = false,
							["size"] = 20,
						},
					},
					["ENEMY_PLAYER"] = {
						["debuffs"] = {
							["size"] = 20,
							["yOffset"] = 15,
						},
						["health"] = {
							["text"] = {
								["format"] = "[health:current:shortvalue]  -  [perhp]%",
							},
						},
						["buffs"] = {
							["size"] = 20,
						},
					},
					["FRIENDLY_PLAYER"] = {
						["debuffs"] = {
							["size"] = 20,
							["yOffset"] = 15,
						},
						["nameOnly"] = true,
						["health"] = {
							["text"] = {
								["format"] = "[perhp]%",
							},
						},
						["buffs"] = {
							["enable"] = false,
							["size"] = 20,
						},
					},
				},
			},
			["bags"] = {
				["scrapIcon"] = true,
				["split"] = {
					["bagSpacing"] = 7,
					["bag4"] = true,
					["bag1"] = true,
					["bag2"] = true,
					["bag3"] = true,
				},
				["vendorGrays"] = {
					["enable"] = true,
				},
				["bagSize"] = 40,
				["bankWidth"] = 550,
				["bagBar"] = {
					["size"] = 25,
					["growthDirection"] = "HORIZONTAL",
				},
				["itemLevelCustomColorEnable"] = true,
				["bagWidth"] = 550,
				["bankSize"] = 40,
			},
			["cooldown"] = {
				["fonts"] = {
					["enable"] = true,
				},
				["hideBlizzard"] = true,
			},
			["tooltip"] = {
				["itemCount"] = "NONE",
				["healthBar"] = {
					["height"] = 12,
					["fontSize"] = 12,
					["font"] = "PT Sans Narrow",
					["fontOutline"] = "NONE",
				},
				["showMount"] = false,
				["cursorAnchorType"] = "ANCHOR_CURSOR_RIGHT",
				["alwaysShowRealm"] = true,
				["modifierID"] = "SHIFT",
				["guildRanks"] = false,
			},
		},
		["Default"] = {
			["databars"] = {
				["threat"] = {
					["enable"] = false,
					["width"] = 472,
					["height"] = 24,
				},
				["honor"] = {
					["enable"] = false,
				},
				["reputation"] = {
					["enable"] = true,
					["width"] = 409,
					["height"] = 6,
				},
				["petExperience"] = {
					["width"] = 65,
				},
				["experience"] = {
					["fontSize"] = 10,
					["textFormat"] = "PERCENT",
					["width"] = 409,
					["height"] = 8,
					["showBubbles"] = true,
				},
				["azerite"] = {
					["enable"] = false,
				},
			},
			["currentTutorial"] = 6,
			["general"] = {
				["interruptAnnounce"] = "RAID",
				["backdropfadecolor"] = {
					["a"] = 0.85700567066669,
					["r"] = 0.058823529411765,
					["g"] = 0.058823529411765,
					["b"] = 0.058823529411765,
				},
				["valuecolor"] = {
					["r"] = 0.999997794628143,
					["g"] = 0.956860661506653,
					["b"] = 0.407842248678207,
				},
				["loginmessage"] = false,
				["vehicleSeatIndicatorSize"] = 80,
				["altPowerBar"] = {
					["statusBar"] = "Melli",
				},
				["objectiveFrameHeight"] = 550,
				["afk"] = false,
				["autoRepair"] = true,
				["minimap"] = {
					["locationText"] = "SHOW",
					["icons"] = {
						["lfgEye"] = {
							["yOffset"] = -26,
							["position"] = "BOTTOM",
						},
						["classHall"] = {
							["xOffset"] = -36,
							["yOffset"] = -45,
						},
						["tracking"] = {
							["xOffset"] = -12,
							["scale"] = 0.6,
							["position"] = "TOPLEFT",
						},
					},
					["size"] = 140,
				},
				["bottomPanel"] = false,
				["autoTrackReputation"] = true,
				["numberPrefixStyle"] = "CHINESE",
				["talkingHeadFrameScale"] = 0.7,
				["totems"] = {
					["spacing"] = 8,
					["size"] = 30,
					["growthDirection"] = "HORIZONTAL",
				},
				["fontSize"] = 14,
				["bonusObjectivePosition"] = "AUTO",
				["itemLevel"] = {
					["displayCharacterInfo"] = false,
					["itemLevelFontSize"] = 10,
				},
			},
			["v11NamePlateReset"] = true,
			["chat"] = {
				["tabSelectorColor"] = {
					["r"] = 0.999997794628143,
					["g"] = 0.956860661506653,
					["b"] = 0.407842248678207,
				},
				["tabSelector"] = "NONE",
				["panelHeightRight"] = 60,
				["scrollDownInterval"] = 30,
				["panelWidth"] = 350,
				["panelHeight"] = 260,
				["panelWidthRight"] = 50,
				["panelBackdrop"] = "LEFT",
				["panelColor"] = {
					["a"] = 0.1851545572280884,
					["r"] = 0.05882352941176471,
					["g"] = 0.05882352941176471,
					["b"] = 0.05882352941176471,
				},
				["separateSizes"] = true,
				["panelSnapLeftID"] = 1,
				["editBoxPosition"] = "ABOVE_CHAT",
				["maxLines"] = 353,
				["customTimeColor"] = {
					["b"] = 0.70196078431373,
					["g"] = 0.70196078431373,
					["r"] = 0.70196078431373,
				},
				["copyChatLines"] = true,
			},
			["dbConverted"] = 2.31,
			["euiscript"] = {
				["autobutton"] = {
					["enable"] = false,
					["questSize"] = 30,
					["slotSize"] = 30,
				},
				["raidcd_width"] = 150,
				["raidcd"] = false,
			},
			["movers"] = {
				["ElvUF_FocusCastbarMover"] = "TOPLEFT,ElvUF_Focus,BOTTOMLEFT,0,-1",
				["ElvUF_FocusTargetMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,503,-116",
				["BuffsMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-161,-5",
				["BossButton"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-441,346",
				["LootFrameMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,423,-416",
				["ZoneAbility"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,422,323",
				["DurabilityFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-76,-324",
				["ElvUF_PetCastbarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,423,121",
				["VehicleSeatMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-66,-261",
				["ElvUIBankMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,256,344",
				["WTSwitchButtonBarMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-60,-196",
				["LossControlMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-407,101",
				["WTCombatAlertFrameMover"] = "TOP,ElvUIParent,TOP,0,-276",
				["MirrorTimer1Mover"] = "TOP,ElvUIParent,TOP,0,-140",
				["ElvAB_4"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-38,240",
				["AltPowerBarMover"] = "TOP,ElvUIParent,TOP,0,-196",
				["ReputationBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,0",
				["ObjectiveFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-83,-236",
				["MirrorTimer2Mover"] = "TOP,MirrorTimer1,BOTTOM,0,0",
				["ShiftAB"] = "BOTTOM,ElvUIParent,BOTTOM,-175,109",
				["ArenaHeaderMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-156,-264",
				["ElvUF_PlayerMover"] = "BOTTOM,ElvUIParent,BOTTOM,-231,270",
				["RightChatMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-4,4",
				["RaidCDAnchorMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,366,-300",
				["AutoButtonAnchor3Mover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-208,214",
				["ElvUF_AssistMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,123,-43",
				["WTRaidMarkersBarAnchor"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,310",
				["TopCenterContainerMover"] = "TOP,ElvUIParent,TOP,0,-51",
				["ThreatBarMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-4,4",
				["ElvUF_PlayerCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,132",
				["ElvUF_RaidMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,0,-116",
				["LeftChatMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,29",
				["GMMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,320",
				["MirrorTimer3Mover"] = "TOP,MirrorTimer2,BOTTOM,0,0",
				["WTChatBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,288",
				["WTMinimapButtonBarAnchor"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-4,-4",
				["ElvUF_FocusMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,397,-106",
				["AutoButtonAnchorMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-66,214",
				["ClassBarMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,475,-31",
				["MicrobarMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-15,4",
				["PetExperienceBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,423,176",
				["PowerBarContainerMover"] = "TOP,ElvUIParent,TOP,0,-54",
				["QuestTimerFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,0,-171",
				["ExperienceBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,6",
				["ExAE_FrameMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,360,276",
				["ElvUF_TargetMover"] = "BOTTOM,ElvUIParent,BOTTOM,232,270",
				["WTParagonReputationToastFrameMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-49",
				["ElvUF_PetMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,423,139",
				["ElvUF_Raid40Mover"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-202",
				["ElvUF_TargetCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,232,259",
				["TalkingHeadFrameMover"] = "BOTTOM,ElvUIParent,BOTTOM,-2,144",
				["ElvAB_1"] = "BOTTOM,ElvUIParent,BOTTOM,0,13",
				["ElvAB_2"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-235,4",
				["BelowMinimapContainerMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-4,-166",
				["ElvUF_TargetTargetMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-417,277",
				["WTGameBarAnchor"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-4",
				["BNETMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,315",
				["EUIMinimapButtonMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-138,-75",
				["ElvAB_3"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-3,240",
				["ElvAB_5"] = "BOTTOM,ElvUIParent,BOTTOM,0,44",
				["VehicleLeaveButton"] = "BOTTOM,ElvUIParent,BOTTOM,238,130",
				["PetAB"] = "BOTTOM,ElvUIParent,BOTTOM,77,108",
				["ElvUIBagMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-409,-250",
				["BagsMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-237,4",
				["LevelUpBossBannerMover"] = "TOP,ElvUIParent,TOP,0,-107",
				["VOICECHAT"] = "TOPLEFT,UIParent,TOPLEFT,127,-4",
				["EuiExecuteMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,634,-367",
				["HonorBarMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-2,-251",
				["ElvAB_6"] = "BOTTOM,ElvUIParent,BOTTOM,0,76",
				["TooltipMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-78,323",
				["ElvUF_TankMover"] = "TOPLEFT,UIParent,TOPLEFT,4,-80",
				["BossHeaderMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-158,-262",
				["TotemBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,326,253",
				["WTCustomEmoteFrameMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,324,56",
				["ElvUF_PartyMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,121,-291",
				["AlertFrameMover"] = "BOTTOM,ElvUIParent,BOTTOM,-3,417",
				["DebuffsMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-160,-133",
				["MinimapMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-4,-4",
			},
			["convertPages"] = true,
			["tooltip"] = {
				["itemCount"] = "NONE",
				["showMount"] = false,
				["cursorAnchorType"] = "ANCHOR_CURSOR_RIGHT",
				["modifierID"] = "SHIFT",
				["healthBar"] = {
					["font"] = "PT Sans Narrow",
					["fontOutline"] = "NONE",
					["height"] = 12,
					["fontSize"] = 12,
				},
				["alwaysShowRealm"] = true,
				["guildRanks"] = false,
			},
			["bags"] = {
				["bagSize"] = 40,
				["itemLevelCustomColorEnable"] = true,
				["scrapIcon"] = true,
				["bankSize"] = 40,
				["split"] = {
					["bag1"] = true,
					["bag3"] = true,
					["bagSpacing"] = 7,
					["bag4"] = true,
					["bag2"] = true,
				},
				["bagWidth"] = 550,
				["vendorGrays"] = {
					["enable"] = true,
				},
				["bagBar"] = {
					["growthDirection"] = "HORIZONTAL",
					["spacing"] = 2,
					["backdropSpacing"] = 2,
					["size"] = 25,
				},
				["bankWidth"] = 550,
			},
			["actionbar"] = {
				["bar3"] = {
					["buttonsPerRow"] = 1,
					["visibility"] = "[petbattle] hide; show",
					["point"] = "TOPLEFT",
					["buttons"] = 12,
					["macrotext"] = true,
				},
				["bar8"] = {
					["macrotext"] = true,
				},
				["bar9"] = {
					["macrotext"] = true,
				},
				["font"] = "傷害數字",
				["bar7"] = {
					["macrotext"] = true,
				},
				["barPet"] = {
					["backdrop"] = false,
					["buttonsPerRow"] = 10,
					["point"] = "TOPLEFT",
					["buttonSize"] = 24,
				},
				["bar6"] = {
					["enabled"] = true,
					["macrotext"] = true,
				},
				["bar10"] = {
					["macrotext"] = true,
				},
				["microbar"] = {
					["buttons"] = 7,
					["buttonSize"] = 23,
				},
				["bar2"] = {
					["visibility"] = "[petbattle] hide; show",
					["macrotext"] = true,
				},
				["bar5"] = {
					["visibility"] = "[petbattle] hide; show",
					["buttons"] = 12,
					["macrotext"] = true,
					["buttonsPerRow"] = 12,
				},
				["bar1"] = {
					["macrotext"] = true,
				},
				["stanceBar"] = {
					["buttonSpacing"] = 1,
					["buttonSize"] = 25,
					["style"] = "classic",
				},
				["cooldown"] = {
					["fonts"] = {
						["enable"] = true,
					},
					["override"] = false,
				},
				["bar4"] = {
					["visibility"] = "[petbattle] hide; show",
					["point"] = "TOPLEFT",
					["macrotext"] = true,
					["backdrop"] = false,
				},
			},
			["unitframe"] = {
				["number"] = "CNW",
				["fontSize"] = 11,
				["smartRaidFilter"] = false,
				["units"] = {
					["tank"] = {
						["width"] = 85,
						["height"] = 30,
						["verticalSpacing"] = 2,
					},
					["boss"] = {
						["debuffs"] = {
							["sizeOverride"] = 27,
							["yOffset"] = -16,
							["maxDuration"] = 300,
						},
						["name"] = {
							["yOffset"] = 33,
						},
						["castbar"] = {
							["width"] = 230,
						},
						["width"] = 230,
						["infoPanel"] = {
							["height"] = 17,
						},
						["health"] = {
							["xOffset"] = 0,
							["text_format"] = "[healthcolor][health:current]（[health:percent]）",
						},
						["height"] = 40,
						["buffs"] = {
							["sizeOverride"] = 27,
							["yOffset"] = 16,
							["maxDuration"] = 300,
						},
					},
					["focustarget"] = {
						["castbar"] = {
							["width"] = 80,
						},
						["width"] = 80,
						["power"] = {
							["enable"] = false,
						},
					},
					["pet"] = {
						["debuffs"] = {
							["enable"] = true,
						},
						["disableTargetGlow"] = false,
						["castbar"] = {
							["iconSize"] = 32,
							["width"] = 65,
						},
						["customTexts"] = {
							["名字"] = {
								["attachTextTo"] = "Health",
								["xOffset"] = 0,
								["text_format"] = "[namecolor][name:medium]",
								["yOffset"] = 0,
								["font"] = "聊天",
								["justifyH"] = "CENTER",
								["fontOutline"] = "OUTLINE",
								["enable"] = true,
								["size"] = 10,
							},
						},
						["width"] = 65,
						["infoPanel"] = {
							["height"] = 14,
						},
						["name"] = {
							["text_format"] = "[happiness:full]",
							["yOffset"] = 10,
						},
						["power"] = {
							["height"] = 4,
						},
					},
					["target"] = {
						["castbar"] = {
							["customTimeFont"] = {
								["enable"] = true,
							},
							["insideInfoPanel"] = false,
							["customTextFont"] = {
								["enable"] = true,
								["font"] = "傷害數字",
							},
							["width"] = 160,
							["height"] = 10,
						},
						["debuffs"] = {
							["countFontSize"] = 5,
							["yOffset"] = 16,
							["priority"] = "Blacklist,Personal,nonPersonal",
							["numrows"] = 2,
							["perrow"] = 7,
							["attachTo"] = "FRAME",
						},
						["portrait"] = {
							["overlay"] = true,
							["enable"] = true,
							["camDistanceScale"] = 4,
							["overlayAlpha"] = 0.8,
						},
						["DragonOverlayStyle"] = "classic",
						["CombatIcon"] = {
							["xOffset"] = 81,
							["yOffset"] = 27,
						},
						["aurabar"] = {
							["enable"] = false,
							["height"] = 18,
						},
						["power"] = {
							["attachTextTo"] = "Power",
							["text_format"] = "[powercolor][  >power:current]",
							["position"] = "RIGHT",
							["xOffset"] = -2,
						},
						["customTexts"] = {
							["精英"] = {
								["attachTextTo"] = "Health",
								["xOffset"] = -80,
								["text_format"] = "[classification:icon][range]",
								["yOffset"] = 25,
								["font"] = "聊天",
								["justifyH"] = "CENTER",
								["fontOutline"] = "OUTLINE",
								["enable"] = true,
								["size"] = 10,
							},
						},
						["healPrediction"] = {
							["absorbStyle"] = "NORMAL",
						},
						["disableMouseoverGlow"] = true,
						["width"] = 160,
						["fader"] = {
							["range"] = false,
						},
						["health"] = {
							["attachTextTo"] = "InfoPanel",
							["xOffset"] = 0,
							["text_format"] = "[health:current:shortvalue]  -  [perhp]%",
							["yOffset"] = 3,
						},
						["orientation"] = "LEFT",
						["height"] = 45,
						["buffs"] = {
							["countFontSize"] = 5,
							["growthX"] = "RIGHT",
							["yOffset"] = -73,
							["anchorPoint"] = "BOTTOMLEFT",
							["priority"] = "Blacklist,Dispellable,Personal,nonPersonal,PlayerBuffs,Whitelist",
							["numrows"] = 2,
							["perrow"] = 7,
							["attachTo"] = "DEBUFFS",
						},
						["name"] = {
							["position"] = "TOPRIGHT",
							["text_format"] = "[level]   [name]",
							["yOffset"] = 16,
						},
					},
					["arena"] = {
						["enable"] = false,
						["width"] = 230,
						["height"] = 40,
					},
					["player"] = {
						["debuffs"] = {
							["countFontSize"] = 10,
							["sizeOverride"] = 25,
							["yOffset"] = -30,
							["anchorPoint"] = "BOTTOMLEFT",
							["numrows"] = 2,
							["perrow"] = 6,
						},
						["classbar"] = {
							["autoHide"] = true,
							["detachedWidth"] = 360,
						},
						["customTexts"] = {
						},
						["healPrediction"] = {
							["absorbStyle"] = "NORMAL",
						},
						["disableMouseoverGlow"] = true,
						["name"] = {
							["position"] = "TOPLEFT",
							["text_format"] = "[name]   [level]",
							["yOffset"] = 15,
						},
						["height"] = 45,
						["buffs"] = {
							["countFontSize"] = 10,
							["yOffset"] = 15,
							["durationPosition"] = "BOTTOM",
							["numrows"] = 2,
							["perrow"] = 6,
							["attachTo"] = "FRAME",
						},
						["castbar"] = {
							["customTimeFont"] = {
								["enable"] = true,
							},
							["insideInfoPanel"] = false,
							["customTextFont"] = {
								["enable"] = true,
								["font"] = "傷害數字",
							},
							["width"] = 214,
							["height"] = 20,
						},
						["aurabar"] = {
							["enable"] = false,
							["height"] = 10,
						},
						["RestIcon"] = {
							["size"] = 20,
						},
						["power"] = {
							["attachTextTo"] = "Power",
							["text_format"] = "[powercolor][curpp]",
						},
						["portrait"] = {
							["overlay"] = true,
							["enable"] = true,
							["camDistanceScale"] = 4,
							["overlayAlpha"] = 0.8,
						},
						["width"] = 160,
						["health"] = {
							["position"] = "RIGHT",
							["xOffset"] = 0,
							["text_format"] = "[health:current:shortvalue]                 [perhp]%",
						},
						["CombatIcon"] = {
							["xOffset"] = -81,
							["yOffset"] = 28,
						},
					},
					["raid40"] = {
						["healPrediction"] = {
							["enable"] = true,
						},
						["name"] = {
							["text_format"] = "[name:short]",
						},
						["height"] = 40,
						["power"] = {
							["enable"] = true,
						},
						["health"] = {
							["text_format"] = "[health:deficit]",
						},
						["enable"] = false,
					},
					["focus"] = {
						["debuffs"] = {
							["sizeOverride"] = 30,
							["priority"] = "Blacklist,Personal,nonPersonal,Boss,RaidDebuffs,Dispellable,Whitelist",
							["attachTo"] = "HEALTH",
						},
						["enable"] = false,
						["health"] = {
							["xOffset"] = -25,
							["text_format"] = "[perhp]%",
							["yOffset"] = -12,
						},
						["CombatIcon"] = {
							["enable"] = false,
						},
						["castbar"] = {
							["width"] = 100,
						},
						["power"] = {
							["height"] = 3,
						},
						["width"] = 100,
						["height"] = 40,
						["name"] = {
							["yOffset"] = 7,
						},
					},
					["assist"] = {
						["enable"] = false,
					},
					["raid"] = {
						["healPrediction"] = {
							["enable"] = true,
						},
						["height"] = 45,
						["buffs"] = {
							["enable"] = true,
							["anchorPoint"] = "CENTER",
						},
						["enable"] = false,
						["debuffs"] = {
							["enable"] = true,
							["anchorPoint"] = "CENTER",
						},
					},
					["party"] = {
						["buffs"] = {
							["countFontSize"] = 8,
							["sizeOverride"] = 22,
							["enable"] = true,
							["yOffset"] = 11,
							["priority"] = "",
							["numrows"] = 2,
							["perrow"] = 5,
						},
						["classbar"] = {
							["height"] = 5,
						},
						["healPrediction"] = {
							["enable"] = true,
						},
						["name"] = {
							["xOffset"] = -5,
							["text_format"] = "[level][name:medium] [difficultycolor]",
							["yOffset"] = 3,
						},
						["height"] = 44,
						["verticalSpacing"] = 6,
						["visibility"] = "[@raid2,exists][@party1,noexists] hide;show",
						["rdebuffs"] = {
							["yOffset"] = 12,
							["font"] = "PT Sans Narrow",
							["size"] = 20,
						},
						["power"] = {
							["text_format"] = "",
							["height"] = 4,
						},
						["width"] = 120,
						["debuffs"] = {
							["countFontSize"] = 8,
							["sizeOverride"] = 22,
							["yOffset"] = 11,
							["priority"] = "",
							["numrows"] = 2,
						},
						["health"] = {
							["position"] = "RIGHT",
							["text_format"] = " [perhp]%",
							["yOffset"] = -10,
						},
					},
					["targettarget"] = {
						["debuffs"] = {
							["enable"] = false,
							["anchorPoint"] = "TOPRIGHT",
						},
						["threatStyle"] = "GLOW",
						["power"] = {
							["enable"] = false,
						},
						["disableMouseoverGlow"] = true,
						["width"] = 100,
						["name"] = {
							["xOffset"] = -18,
							["text_format"] = "[name:medium]",
							["yOffset"] = 5,
						},
						["height"] = 35,
						["health"] = {
							["xOffset"] = 0,
							["text_format"] = "[perhp]%",
							["yOffset"] = -10,
						},
						["raidicon"] = {
							["attachTo"] = "LEFT",
							["xOffset"] = 2,
							["enable"] = false,
							["yOffset"] = 0,
						},
					},
				},
				["statusbar"] = "ElvUI Blank",
				["colors"] = {
					["healthclass"] = true,
					["castClassColor"] = true,
					["auraBarBuff"] = {
						["r"] = 0.999997794628143,
						["g"] = 0.486273437738419,
						["b"] = 0.0392156019806862,
					},
				},
				["fontOutline"] = "THICKOUTLINE",
				["font"] = "默认",
				["smoothbars"] = true,
				["cooldown"] = {
					["fonts"] = {
						["enable"] = true,
						["fontSize"] = 15,
					},
				},
			},
			["datatexts"] = {
				["fontSize"] = 10,
				["fontOutline"] = "OUTLINE",
				["panels"] = {
					["MinimapPanel"] = {
						["backdrop"] = false,
						["border"] = false,
					},
					["RightChatDataPanel"] = {
						"Gold", -- [1]
						"MeetingStone", -- [2]
						"System", -- [3]
						["enable"] = false,
						["backdrop"] = false,
					},
					["LeftChatDataPanel"] = {
						"WeakAuras", -- [1]
						"ElvUI", -- [2]
						"Durability", -- [3]
						["enable"] = false,
						["backdrop"] = false,
						["panelTransparency"] = true,
					},
				},
			},
			["nameplates_v1"] = {
				["cooldown"] = {
					["fonts"] = {
						["enable"] = true,
					},
				},
				["classbar"] = {
					["position"] = "BELOW",
				},
				["units"] = {
					["ENEMY_PLAYER"] = {
						["buffs"] = {
							["baseHeight"] = 20,
						},
						["debuffs"] = {
							["baseHeight"] = 20,
						},
					},
					["FRIENDLY_NPC"] = {
						["healthbar"] = {
							["text"] = {
								["enable"] = false,
							},
						},
					},
				},
			},
			["nameplates"] = {
				["units"] = {
					["ENEMY_NPC"] = {
						["debuffs"] = {
							["yOffset"] = 15,
							["size"] = 20,
						},
						["buffs"] = {
							["enable"] = false,
							["size"] = 20,
						},
						["health"] = {
							["text"] = {
								["fontSize"] = 10,
								["format"] = "[perhp]%",
							},
						},
					},
					["TARGET"] = {
						["classpower"] = {
							["enable"] = true,
							["width"] = 60,
							["yOffset"] = -11,
						},
					},
					["FRIENDLY_NPC"] = {
						["debuffs"] = {
							["enable"] = false,
							["yOffset"] = 15,
							["size"] = 20,
						},
						["buffs"] = {
							["enable"] = false,
							["size"] = 20,
						},
						["health"] = {
							["text"] = {
								["fontSize"] = 10,
								["format"] = "[perhp]%",
							},
						},
					},
					["ENEMY_PLAYER"] = {
						["debuffs"] = {
							["yOffset"] = 20,
							["size"] = 20,
						},
						["buffs"] = {
							["size"] = 20,
						},
						["health"] = {
							["text"] = {
								["fontSize"] = 10,
								["format"] = "[health:current:shortvalue]  -  [perhp]%",
							},
						},
					},
					["FRIENDLY_PLAYER"] = {
						["debuffs"] = {
							["yOffset"] = 15,
							["size"] = 20,
						},
						["health"] = {
							["text"] = {
								["fontSize"] = 10,
								["format"] = "[perhp]%",
							},
						},
						["nameOnly"] = true,
						["buffs"] = {
							["enable"] = false,
							["size"] = 20,
						},
					},
				},
				["clampToScreen"] = true,
				["statusbar"] = "Melli",
			},
			["auras"] = {
				["debuffs"] = {
					["size"] = 26,
					["countFont"] = "傷害數字",
					["timeFont"] = "傷害數字",
					["countFontOutline"] = "OUTLINE",
					["timeFontOutline"] = "OUTLINE",
				},
				["buffs"] = {
					["size"] = 26,
					["countFont"] = "傷害數字",
					["timeFont"] = "EUI",
					["countFontOutline"] = "OUTLINE",
					["timeFontOutline"] = "OUTLINE",
					["timeFontSize"] = 11,
				},
			},
			["cooldown"] = {
				["hideBlizzard"] = true,
				["fonts"] = {
					["enable"] = true,
				},
			},
			["AuraWatch"] = {
				["loadDefault"] = true,
				["myclass"] = "ROGUE",
			},
		},
		["界面1"] = {
			["databars"] = {
				["petExperience"] = {
					["width"] = 65,
				},
				["threat"] = {
					["enable"] = false,
					["height"] = 24,
					["width"] = 472,
				},
				["experience"] = {
					["fontSize"] = 10,
					["height"] = 8,
					["textFormat"] = "PERCENT",
					["showBubbles"] = true,
					["width"] = 409,
				},
				["honor"] = {
					["enable"] = false,
				},
				["reputation"] = {
					["enable"] = true,
					["height"] = 6,
					["width"] = 409,
				},
				["azerite"] = {
					["enable"] = false,
				},
			},
			["currentTutorial"] = 6,
			["general"] = {
				["totems"] = {
					["size"] = 30,
					["growthDirection"] = "HORIZONTAL",
					["spacing"] = 8,
				},
				["fontSize"] = 14,
				["interruptAnnounce"] = "RAID",
				["afk"] = false,
				["autoRepair"] = true,
				["minimap"] = {
					["icons"] = {
						["lfgEye"] = {
							["yOffset"] = -26,
							["position"] = "BOTTOM",
						},
						["classHall"] = {
							["xOffset"] = -36,
							["yOffset"] = -45,
						},
						["tracking"] = {
							["scale"] = 0.6,
							["xOffset"] = -12,
							["position"] = "TOPLEFT",
						},
					},
					["locationText"] = "SHOW",
					["size"] = 140,
				},
				["bottomPanel"] = false,
				["backdropfadecolor"] = {
					["a"] = 0.85700567066669,
					["b"] = 0.058823529411765,
					["g"] = 0.058823529411765,
					["r"] = 0.058823529411765,
				},
				["valuecolor"] = {
					["b"] = 0.407842248678207,
					["g"] = 0.956860661506653,
					["r"] = 0.999997794628143,
				},
				["loginmessage"] = false,
				["itemLevel"] = {
					["displayCharacterInfo"] = false,
					["itemLevelFontSize"] = 10,
				},
				["talkingHeadFrameScale"] = 0.7,
				["altPowerBar"] = {
					["statusBar"] = "Melli",
				},
				["bonusObjectivePosition"] = "AUTO",
				["vehicleSeatIndicatorSize"] = 80,
				["numberPrefixStyle"] = "CHINESE",
				["objectiveFrameHeight"] = 550,
				["autoTrackReputation"] = true,
			},
			["v11NamePlateReset"] = true,
			["chat"] = {
				["customTimeColor"] = {
					["b"] = 0.70196078431373,
					["g"] = 0.70196078431373,
					["r"] = 0.70196078431373,
				},
				["panelBackdrop"] = "LEFT",
				["tabSelector"] = "NONE",
				["scrollDownInterval"] = 30,
				["panelColor"] = {
					["a"] = 0.1851545572280884,
					["b"] = 0.05882352941176471,
					["g"] = 0.05882352941176471,
					["r"] = 0.05882352941176471,
				},
				["panelSnapLeftID"] = 1,
				["tabSelectorColor"] = {
					["b"] = 0.407842248678207,
					["g"] = 0.956860661506653,
					["r"] = 0.999997794628143,
				},
				["panelHeightRight"] = 60,
				["editBoxPosition"] = "ABOVE_CHAT",
				["separateSizes"] = true,
				["panelHeight"] = 260,
				["copyChatLines"] = true,
				["panelWidthRight"] = 50,
				["maxLines"] = 353,
				["panelWidth"] = 350,
			},
			["dbConverted"] = 2.3,
			["euiscript"] = {
				["autobutton"] = {
					["enable"] = false,
					["questSize"] = 30,
					["slotSize"] = 30,
				},
				["raidcd_width"] = 150,
				["raidcd"] = false,
			},
			["movers"] = {
				["ElvUF_FocusCastbarMover"] = "TOPLEFT,ElvUF_Focus,BOTTOMLEFT,0,-1",
				["ElvUF_FocusTargetMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,503,-116",
				["BuffsMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-161,-5",
				["BossButton"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-441,346",
				["LootFrameMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,423,-416",
				["ZoneAbility"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,422,323",
				["PowerBarContainerMover"] = "TOP,ElvUIParent,TOP,0,-54",
				["ElvUF_PetCastbarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,423,121",
				["VehicleSeatMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-66,-261",
				["ElvUIBankMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,256,344",
				["WTSwitchButtonBarMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-60,-196",
				["LossControlMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-407,101",
				["WTCombatAlertFrameMover"] = "TOP,ElvUIParent,TOP,0,-276",
				["MirrorTimer1Mover"] = "TOP,ElvUIParent,TOP,0,-140",
				["QuestTimerFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,0,-171",
				["PetExperienceBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,423,176",
				["ReputationBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,0",
				["ObjectiveFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-83,-236",
				["MirrorTimer2Mover"] = "TOP,MirrorTimer1,BOTTOM,0,0",
				["ShiftAB"] = "BOTTOM,ElvUIParent,BOTTOM,-175,109",
				["ArenaHeaderMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-156,-264",
				["ElvUF_PlayerMover"] = "BOTTOM,ElvUIParent,BOTTOM,-231,270",
				["RightChatMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-4,4",
				["RaidCDAnchorMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,366,-300",
				["AutoButtonAnchor3Mover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-208,214",
				["ElvUF_AssistMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,123,-43",
				["WTRaidMarkersBarAnchor"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,310",
				["TopCenterContainerMover"] = "TOP,ElvUIParent,TOP,0,-51",
				["ThreatBarMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-4,4",
				["ElvUF_PlayerCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,132",
				["ElvUF_RaidMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,0,-116",
				["LeftChatMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,29",
				["GMMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,320",
				["MirrorTimer3Mover"] = "TOP,MirrorTimer2,BOTTOM,0,0",
				["ExAE_FrameMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,360,276",
				["WTMinimapButtonBarAnchor"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-4,-4",
				["ElvUF_FocusMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,397,-106",
				["AutoButtonAnchorMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-66,214",
				["ClassBarMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,475,-31",
				["MicrobarMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-15,4",
				["AltPowerBarMover"] = "TOP,ElvUIParent,TOP,0,-196",
				["ElvAB_4"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-38,240",
				["TalkingHeadFrameMover"] = "BOTTOM,ElvUIParent,BOTTOM,-2,144",
				["ExperienceBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,6",
				["ElvUF_TargetTargetMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-417,277",
				["ElvUF_TargetMover"] = "BOTTOM,ElvUIParent,BOTTOM,232,270",
				["DurabilityFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-76,-324",
				["TotemBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,326,253",
				["ElvUF_Raid40Mover"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-202",
				["BNETMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,315",
				["EUIMinimapButtonMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-138,-75",
				["ElvAB_1"] = "BOTTOM,ElvUIParent,BOTTOM,0,13",
				["ElvAB_2"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-235,4",
				["BelowMinimapContainerMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-4,-166",
				["ElvUF_TargetCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,232,259",
				["WTGameBarAnchor"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-4",
				["WTCustomEmoteFrameMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,324,56",
				["WTChatBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,288",
				["ElvAB_3"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-3,240",
				["ElvAB_5"] = "BOTTOM,ElvUIParent,BOTTOM,0,44",
				["VehicleLeaveButton"] = "BOTTOM,ElvUIParent,BOTTOM,238,130",
				["EuiExecuteMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,634,-367",
				["ElvUIBagMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-409,-250",
				["LevelUpBossBannerMover"] = "TOP,ElvUIParent,TOP,0,-107",
				["BagsMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-237,4",
				["VOICECHAT"] = "TOPLEFT,UIParent,TOPLEFT,127,-4",
				["PetAB"] = "BOTTOM,ElvUIParent,BOTTOM,77,108",
				["HonorBarMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-2,-251",
				["ElvAB_6"] = "BOTTOM,ElvUIParent,BOTTOM,0,76",
				["TooltipMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-78,323",
				["ElvUF_TankMover"] = "TOPLEFT,UIParent,TOPLEFT,4,-80",
				["BossHeaderMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-158,-262",
				["ElvUF_PetMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,423,139",
				["WTParagonReputationToastFrameMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-49",
				["ElvUF_PartyMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,121,-291",
				["AlertFrameMover"] = "BOTTOM,ElvUIParent,BOTTOM,-3,417",
				["DebuffsMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-160,-133",
				["MinimapMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-4,-4",
			},
			["convertPages"] = true,
			["AuraWatch"] = {
				["loadDefault"] = true,
				["myclass"] = "ROGUE",
			},
			["bags"] = {
				["scrapIcon"] = true,
				["split"] = {
					["bagSpacing"] = 7,
					["bag4"] = true,
					["bag1"] = true,
					["bag2"] = true,
					["bag3"] = true,
				},
				["vendorGrays"] = {
					["enable"] = true,
				},
				["bagSize"] = 40,
				["bankWidth"] = 550,
				["bagBar"] = {
					["size"] = 25,
					["spacing"] = 2,
					["backdropSpacing"] = 2,
					["growthDirection"] = "HORIZONTAL",
				},
				["itemLevelCustomColorEnable"] = true,
				["bagWidth"] = 550,
				["bankSize"] = 40,
			},
			["auras"] = {
				["debuffs"] = {
					["timeFontOutline"] = "OUTLINE",
					["countFont"] = "傷害數字",
					["timeFont"] = "傷害數字",
					["countFontOutline"] = "OUTLINE",
					["size"] = 26,
				},
				["buffs"] = {
					["timeFontSize"] = 11,
					["countFont"] = "傷害數字",
					["countFontOutline"] = "OUTLINE",
					["timeFont"] = "EUI",
					["timeFontOutline"] = "OUTLINE",
					["size"] = 26,
				},
			},
			["unitframe"] = {
				["number"] = "CNW",
				["fontSize"] = 11,
				["units"] = {
					["tank"] = {
						["height"] = 30,
						["verticalSpacing"] = 2,
						["width"] = 85,
					},
					["boss"] = {
						["infoPanel"] = {
							["height"] = 17,
						},
						["debuffs"] = {
							["maxDuration"] = 300,
							["sizeOverride"] = 27,
							["yOffset"] = -16,
						},
						["health"] = {
							["xOffset"] = 0,
							["text_format"] = "[healthcolor][health:current]（[health:percent]）",
						},
						["castbar"] = {
							["width"] = 230,
						},
						["height"] = 40,
						["buffs"] = {
							["maxDuration"] = 300,
							["sizeOverride"] = 27,
							["yOffset"] = 16,
						},
						["name"] = {
							["yOffset"] = 33,
						},
						["width"] = 230,
					},
					["focustarget"] = {
						["power"] = {
							["enable"] = false,
						},
						["width"] = 80,
						["castbar"] = {
							["width"] = 80,
						},
					},
					["targettarget"] = {
						["debuffs"] = {
							["enable"] = false,
							["anchorPoint"] = "TOPRIGHT",
						},
						["threatStyle"] = "GLOW",
						["power"] = {
							["enable"] = false,
						},
						["disableMouseoverGlow"] = true,
						["width"] = 100,
						["health"] = {
							["xOffset"] = 0,
							["text_format"] = "[perhp]%",
							["yOffset"] = -10,
						},
						["height"] = 35,
						["name"] = {
							["xOffset"] = -18,
							["text_format"] = "[name:medium]",
							["yOffset"] = 5,
						},
						["raidicon"] = {
							["attachTo"] = "LEFT",
							["xOffset"] = 2,
							["enable"] = false,
							["yOffset"] = 0,
						},
					},
					["target"] = {
						["debuffs"] = {
							["countFontSize"] = 5,
							["perrow"] = 7,
							["attachTo"] = "FRAME",
							["priority"] = "Blacklist,Personal,nonPersonal",
							["numrows"] = 2,
							["yOffset"] = 16,
						},
						["portrait"] = {
							["overlay"] = true,
							["overlayAlpha"] = 0.8,
							["camDistanceScale"] = 4,
							["enable"] = true,
						},
						["DragonOverlayStyle"] = "classic",
						["CombatIcon"] = {
							["xOffset"] = 81,
							["yOffset"] = 27,
						},
						["aurabar"] = {
							["enable"] = false,
							["height"] = 18,
						},
						["power"] = {
							["attachTextTo"] = "Power",
							["xOffset"] = -2,
							["text_format"] = "[powercolor][  >power:current]",
							["position"] = "RIGHT",
						},
						["customTexts"] = {
							["精英"] = {
								["attachTextTo"] = "Health",
								["enable"] = true,
								["text_format"] = "[classification:icon][range]",
								["yOffset"] = 25,
								["font"] = "聊天",
								["justifyH"] = "CENTER",
								["fontOutline"] = "OUTLINE",
								["xOffset"] = -80,
								["size"] = 10,
							},
						},
						["healPrediction"] = {
							["absorbStyle"] = "NORMAL",
						},
						["disableMouseoverGlow"] = true,
						["width"] = 160,
						["castbar"] = {
							["customTimeFont"] = {
								["enable"] = true,
							},
							["insideInfoPanel"] = false,
							["height"] = 10,
							["customTextFont"] = {
								["enable"] = true,
								["font"] = "傷害數字",
							},
							["width"] = 160,
						},
						["fader"] = {
							["range"] = false,
						},
						["height"] = 45,
						["orientation"] = "LEFT",
						["buffs"] = {
							["countFontSize"] = 5,
							["perrow"] = 7,
							["attachTo"] = "DEBUFFS",
							["growthX"] = "RIGHT",
							["numrows"] = 2,
							["priority"] = "Blacklist,Dispellable,Personal,nonPersonal,PlayerBuffs,Whitelist",
							["anchorPoint"] = "BOTTOMLEFT",
							["yOffset"] = -73,
						},
						["name"] = {
							["yOffset"] = 16,
							["text_format"] = "[level]   [name]",
							["position"] = "TOPRIGHT",
						},
						["health"] = {
							["attachTextTo"] = "InfoPanel",
							["xOffset"] = 0,
							["text_format"] = "[health:current:shortvalue]  -  [perhp]%",
							["yOffset"] = 3,
						},
					},
					["raid"] = {
						["debuffs"] = {
							["enable"] = true,
							["anchorPoint"] = "CENTER",
						},
						["enable"] = false,
						["buffs"] = {
							["enable"] = true,
							["anchorPoint"] = "CENTER",
						},
						["height"] = 45,
						["healPrediction"] = {
							["enable"] = true,
						},
					},
					["party"] = {
						["debuffs"] = {
							["countFontSize"] = 8,
							["sizeOverride"] = 22,
							["priority"] = "",
							["numrows"] = 2,
							["yOffset"] = 11,
						},
						["power"] = {
							["text_format"] = "",
							["height"] = 4,
						},
						["healPrediction"] = {
							["enable"] = true,
						},
						["width"] = 120,
						["rdebuffs"] = {
							["font"] = "PT Sans Narrow",
							["size"] = 20,
							["yOffset"] = 12,
						},
						["visibility"] = "[@raid2,exists][@party1,noexists] hide;show",
						["health"] = {
							["yOffset"] = -10,
							["text_format"] = " [perhp]%",
							["position"] = "RIGHT",
						},
						["buffs"] = {
							["countFontSize"] = 8,
							["sizeOverride"] = 22,
							["perrow"] = 5,
							["enable"] = true,
							["priority"] = "",
							["numrows"] = 2,
							["yOffset"] = 11,
						},
						["height"] = 44,
						["verticalSpacing"] = 6,
						["classbar"] = {
							["height"] = 5,
						},
						["name"] = {
							["xOffset"] = -5,
							["text_format"] = "[level][name:medium] [difficultycolor]",
							["yOffset"] = 3,
						},
					},
					["raid40"] = {
						["name"] = {
							["text_format"] = "[name:short]",
						},
						["power"] = {
							["enable"] = true,
						},
						["height"] = 40,
						["healPrediction"] = {
							["enable"] = true,
						},
						["health"] = {
							["text_format"] = "[health:deficit]",
						},
						["enable"] = false,
					},
					["focus"] = {
						["debuffs"] = {
							["attachTo"] = "HEALTH",
							["sizeOverride"] = 30,
							["priority"] = "Blacklist,Personal,nonPersonal,Boss,RaidDebuffs,Dispellable,Whitelist",
						},
						["power"] = {
							["height"] = 3,
						},
						["enable"] = false,
						["width"] = 100,
						["name"] = {
							["yOffset"] = 7,
						},
						["height"] = 40,
						["health"] = {
							["xOffset"] = -25,
							["text_format"] = "[perhp]%",
							["yOffset"] = -12,
						},
						["CombatIcon"] = {
							["enable"] = false,
						},
						["castbar"] = {
							["width"] = 100,
						},
					},
					["assist"] = {
						["enable"] = false,
					},
					["arena"] = {
						["enable"] = false,
						["height"] = 40,
						["width"] = 230,
					},
					["player"] = {
						["RestIcon"] = {
							["size"] = 20,
						},
						["debuffs"] = {
							["countFontSize"] = 10,
							["sizeOverride"] = 25,
							["perrow"] = 6,
							["numrows"] = 2,
							["anchorPoint"] = "BOTTOMLEFT",
							["yOffset"] = -30,
						},
						["portrait"] = {
							["overlay"] = true,
							["overlayAlpha"] = 0.8,
							["camDistanceScale"] = 4,
							["enable"] = true,
						},
						["power"] = {
							["attachTextTo"] = "Power",
							["text_format"] = "[powercolor][curpp]",
						},
						["customTexts"] = {
						},
						["healPrediction"] = {
							["absorbStyle"] = "NORMAL",
						},
						["disableMouseoverGlow"] = true,
						["width"] = 160,
						["castbar"] = {
							["customTimeFont"] = {
								["enable"] = true,
							},
							["insideInfoPanel"] = false,
							["height"] = 20,
							["customTextFont"] = {
								["enable"] = true,
								["font"] = "傷害數字",
							},
							["width"] = 214,
						},
						["classbar"] = {
							["detachedWidth"] = 360,
							["autoHide"] = true,
						},
						["health"] = {
							["xOffset"] = 0,
							["text_format"] = "[health:current:shortvalue]                 [perhp]%",
							["position"] = "RIGHT",
						},
						["name"] = {
							["yOffset"] = 15,
							["text_format"] = "[name]   [level]",
							["position"] = "TOPLEFT",
						},
						["height"] = 45,
						["buffs"] = {
							["countFontSize"] = 10,
							["perrow"] = 6,
							["attachTo"] = "FRAME",
							["numrows"] = 2,
							["durationPosition"] = "BOTTOM",
							["yOffset"] = 15,
						},
						["CombatIcon"] = {
							["xOffset"] = -81,
							["yOffset"] = 28,
						},
						["aurabar"] = {
							["enable"] = false,
							["height"] = 10,
						},
					},
					["pet"] = {
						["infoPanel"] = {
							["height"] = 14,
						},
						["debuffs"] = {
							["enable"] = true,
						},
						["name"] = {
							["text_format"] = "[happiness:full]",
							["yOffset"] = 10,
						},
						["power"] = {
							["height"] = 4,
						},
						["customTexts"] = {
							["名字"] = {
								["attachTextTo"] = "Health",
								["enable"] = true,
								["text_format"] = "[namecolor][name:medium]",
								["yOffset"] = 0,
								["font"] = "聊天",
								["justifyH"] = "CENTER",
								["fontOutline"] = "OUTLINE",
								["xOffset"] = 0,
								["size"] = 10,
							},
						},
						["disableTargetGlow"] = false,
						["castbar"] = {
							["iconSize"] = 32,
							["width"] = 65,
						},
						["width"] = 65,
					},
				},
				["font"] = "默认",
				["colors"] = {
					["auraBarBuff"] = {
						["b"] = 0.0392156019806862,
						["g"] = 0.486273437738419,
						["r"] = 0.999997794628143,
					},
					["castClassColor"] = true,
					["healthclass"] = true,
				},
				["smartRaidFilter"] = false,
				["fontOutline"] = "THICKOUTLINE",
				["smoothbars"] = true,
				["cooldown"] = {
					["fonts"] = {
						["enable"] = true,
						["fontSize"] = 15,
					},
				},
				["statusbar"] = "ElvUI Blank",
			},
			["datatexts"] = {
				["fontSize"] = 10,
				["panels"] = {
					["MinimapPanel"] = {
						["border"] = false,
						["backdrop"] = false,
					},
					["RightChatDataPanel"] = {
						"Gold", -- [1]
						"MeetingStone", -- [2]
						"System", -- [3]
						["backdrop"] = false,
						["enable"] = false,
					},
					["LeftChatDataPanel"] = {
						"WeakAuras", -- [1]
						"ElvUI", -- [2]
						"Durability", -- [3]
						["panelTransparency"] = true,
						["backdrop"] = false,
						["enable"] = false,
					},
				},
				["fontOutline"] = "OUTLINE",
			},
			["actionbar"] = {
				["bar3"] = {
					["point"] = "TOPLEFT",
					["buttons"] = 12,
					["macrotext"] = true,
					["buttonsPerRow"] = 1,
					["visibility"] = "[petbattle] hide; show",
				},
				["bar6"] = {
					["enabled"] = true,
					["macrotext"] = true,
				},
				["bar2"] = {
					["visibility"] = "[petbattle] hide; show",
					["macrotext"] = true,
				},
				["bar10"] = {
					["macrotext"] = true,
				},
				["bar8"] = {
					["macrotext"] = true,
				},
				["bar5"] = {
					["macrotext"] = true,
					["buttonsPerRow"] = 12,
					["visibility"] = "[petbattle] hide; show",
					["buttons"] = 12,
				},
				["barPet"] = {
					["point"] = "TOPLEFT",
					["buttonsPerRow"] = 10,
					["backdrop"] = false,
					["buttonSize"] = 24,
				},
				["microbar"] = {
					["buttons"] = 7,
					["buttonSize"] = 23,
				},
				["font"] = "傷害數字",
				["bar7"] = {
					["macrotext"] = true,
				},
				["bar1"] = {
					["macrotext"] = true,
				},
				["bar9"] = {
					["macrotext"] = true,
				},
				["stanceBar"] = {
					["style"] = "classic",
					["buttonSpacing"] = 1,
					["buttonSize"] = 25,
				},
				["cooldown"] = {
					["fonts"] = {
						["enable"] = true,
					},
					["override"] = false,
				},
				["bar4"] = {
					["macrotext"] = true,
					["backdrop"] = false,
					["visibility"] = "[petbattle] hide; show",
					["point"] = "TOPLEFT",
				},
			},
			["nameplates"] = {
				["statusbar"] = "Melli",
				["clampToScreen"] = true,
				["units"] = {
					["ENEMY_NPC"] = {
						["debuffs"] = {
							["size"] = 20,
							["yOffset"] = 15,
						},
						["health"] = {
							["text"] = {
								["format"] = "[perhp]%",
								["fontSize"] = 10,
							},
						},
						["buffs"] = {
							["enable"] = false,
							["size"] = 20,
						},
					},
					["TARGET"] = {
						["classpower"] = {
							["enable"] = true,
							["yOffset"] = -11,
							["width"] = 60,
						},
					},
					["FRIENDLY_NPC"] = {
						["debuffs"] = {
							["enable"] = false,
							["size"] = 20,
							["yOffset"] = 15,
						},
						["health"] = {
							["text"] = {
								["format"] = "[perhp]%",
								["fontSize"] = 10,
							},
						},
						["buffs"] = {
							["enable"] = false,
							["size"] = 20,
						},
					},
					["ENEMY_PLAYER"] = {
						["debuffs"] = {
							["size"] = 20,
							["yOffset"] = 20,
						},
						["health"] = {
							["text"] = {
								["format"] = "[health:current:shortvalue]  -  [perhp]%",
								["fontSize"] = 10,
							},
						},
						["buffs"] = {
							["size"] = 20,
						},
					},
					["FRIENDLY_PLAYER"] = {
						["debuffs"] = {
							["size"] = 20,
							["yOffset"] = 15,
						},
						["nameOnly"] = true,
						["health"] = {
							["text"] = {
								["format"] = "[perhp]%",
								["fontSize"] = 10,
							},
						},
						["buffs"] = {
							["enable"] = false,
							["size"] = 20,
						},
					},
				},
			},
			["nameplates_v1"] = {
				["cooldown"] = {
					["fonts"] = {
						["enable"] = true,
					},
				},
				["classbar"] = {
					["position"] = "BELOW",
				},
				["units"] = {
					["ENEMY_PLAYER"] = {
						["debuffs"] = {
							["baseHeight"] = 20,
						},
						["buffs"] = {
							["baseHeight"] = 20,
						},
					},
					["FRIENDLY_NPC"] = {
						["healthbar"] = {
							["text"] = {
								["enable"] = false,
							},
						},
					},
				},
			},
			["cooldown"] = {
				["fonts"] = {
					["enable"] = true,
				},
				["hideBlizzard"] = true,
			},
			["tooltip"] = {
				["showMount"] = false,
				["healthBar"] = {
					["height"] = 12,
					["font"] = "PT Sans Narrow",
					["fontSize"] = 12,
					["fontOutline"] = "NONE",
				},
				["itemCount"] = "NONE",
				["cursorAnchorType"] = "ANCHOR_CURSOR_RIGHT",
				["alwaysShowRealm"] = true,
				["modifierID"] = "SHIFT",
				["guildRanks"] = false,
			},
		},
		["简洁2-独立头像"] = {
			["databars"] = {
				["reputation"] = {
					["enable"] = true,
					["height"] = 6,
					["width"] = 393,
				},
				["threat"] = {
					["enable"] = false,
					["height"] = 24,
					["width"] = 472,
				},
				["experience"] = {
					["height"] = 8,
					["textFormat"] = "PERCENT",
					["width"] = 393,
				},
				["petExperience"] = {
					["width"] = 65,
				},
			},
			["currentTutorial"] = 3,
			["general"] = {
				["loginmessage"] = false,
				["fontSize"] = 14,
				["itemLevel"] = {
					["itemLevelFontSize"] = 10,
					["displayCharacterInfo"] = false,
				},
				["autoTrackReputation"] = true,
				["afk"] = false,
				["totems"] = {
					["growthDirection"] = "HORIZONTAL",
					["size"] = 30,
					["spacing"] = 8,
				},
				["minimap"] = {
					["icons"] = {
						["tracking"] = {
							["xOffset"] = -12,
							["scale"] = 0.6,
							["position"] = "TOPLEFT",
						},
					},
					["locationText"] = "SHOW",
					["size"] = 140,
				},
				["interruptAnnounce"] = "RAID",
				["altPowerBar"] = {
					["statusBar"] = "Melli",
				},
				["bottomPanel"] = false,
				["backdropfadecolor"] = {
					["a"] = 0.85700567066669,
					["r"] = 0.058823529411765,
					["g"] = 0.058823529411765,
					["b"] = 0.058823529411765,
				},
				["objectiveFrameHeight"] = 550,
				["valuecolor"] = {
					["r"] = 0.999997794628143,
					["g"] = 0.956860661506653,
					["b"] = 0.407842248678207,
				},
				["bonusObjectivePosition"] = "AUTO",
				["numberPrefixStyle"] = "CHINESE",
			},
			["movers"] = {
				["ElvUF_FocusCastbarMover"] = "TOPLEFT,ElvUF_Focus,BOTTOMLEFT,0,-1",
				["ElvUF_FocusTargetMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,361,-92",
				["BuffsMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-161,-5",
				["BossButton"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-441,346",
				["LootFrameMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,423,-416",
				["ZoneAbility"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,422,323",
				["DurabilityFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-76,-324",
				["ElvUF_PetCastbarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,423,121",
				["VehicleSeatMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-66,-261",
				["ElvUF_TargetTargetMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-405,256",
				["EuiExecuteMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,634,-367",
				["LossControlMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-407,101",
				["WTCombatAlertFrameMover"] = "TOP,ElvUIParent,TOP,0,-276",
				["MirrorTimer1Mover"] = "TOP,ElvUIParent,TOP,0,-140",
				["QuestTimerFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,0,-171",
				["AltPowerBarMover"] = "TOP,ElvUIParent,TOP,0,-196",
				["ReputationBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,0",
				["ObjectiveFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-83,-236",
				["BNETMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,315",
				["ShiftAB"] = "BOTTOM,ElvUIParent,BOTTOM,-175,104",
				["ElvUF_TargetCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,253,245",
				["ElvUF_PlayerMover"] = "BOTTOM,ElvUIParent,BOTTOM,-253,256",
				["RightChatMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-4,4",
				["RaidCDAnchorMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,366,-300",
				["AutoButtonAnchor3Mover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-208,214",
				["ElvUF_AssistMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,123,-43",
				["WTRaidMarkersBarAnchor"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,310",
				["TopCenterContainerMover"] = "TOP,ElvUIParent,TOP,0,-51",
				["ThreatBarMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-4,4",
				["PetAB"] = "BOTTOM,ElvUIParent,BOTTOM,46,103",
				["ElvUF_RaidMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,0,-116",
				["LeftChatMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,27",
				["GMMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,315",
				["BagsMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-4,33",
				["WTChatBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,288",
				["WTMinimapButtonBarAnchor"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-4,-4",
				["ElvUF_FocusMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,222,-81",
				["AutoButtonAnchorMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-66,214",
				["ClassBarMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,475,-31",
				["MicrobarMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-20,4",
				["PetExperienceBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,423,176",
				["WTCustomEmoteFrameMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,324,56",
				["ArenaHeaderMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-156,-264",
				["ExperienceBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,6",
				["MirrorTimer2Mover"] = "TOP,MirrorTimer1,BOTTOM,0,0",
				["ElvUF_TargetMover"] = "BOTTOM,ElvUIParent,BOTTOM,253,256",
				["TalkingHeadFrameMover"] = "BOTTOM,ElvUIParent,BOTTOM,-2,144",
				["ElvUF_PetMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,423,139",
				["ElvUF_Raid40Mover"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-235",
				["ElvUIBankMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,191,289",
				["PowerBarContainerMover"] = "TOP,ElvUIParent,TOP,0,-55",
				["ElvAB_1"] = "BOTTOM,ElvUIParent,BOTTOM,0,13",
				["ElvAB_2"] = "BOTTOM,ElvUIParent,BOTTOM,164,436",
				["BelowMinimapContainerMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-4,-166",
				["EUIMinimapButtonMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-138,-75",
				["WTGameBarAnchor"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-4",
				["WTSwitchButtonBarMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-60,-196",
				["WTParagonReputationToastFrameMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-49",
				["ElvAB_3"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,525,10",
				["ElvAB_5"] = "BOTTOM,ElvUIParent,BOTTOM,0,43",
				["VehicleLeaveButton"] = "BOTTOM,ElvUIParent,BOTTOM,206,131",
				["MirrorTimer3Mover"] = "TOP,MirrorTimer2,BOTTOM,0,0",
				["LevelUpBossBannerMover"] = "TOP,ElvUIParent,TOP,0,-107",
				["ElvUF_PlayerCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,131",
				["ExAE_FrameMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,360,276",
				["VOICECHAT"] = "TOP,ElvUIParent,TOP,-251,-3",
				["ElvUIBagMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-420,-249",
				["HonorBarMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-2,-251",
				["ElvAB_6"] = "BOTTOM,ElvUIParent,BOTTOM,0,73",
				["TooltipMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-78,323",
				["ElvUF_TankMover"] = "TOPLEFT,UIParent,TOPLEFT,4,-67",
				["BossHeaderMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-158,-262",
				["TotemBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,371,255",
				["ElvAB_4"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-525,10",
				["ElvUF_PartyMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,121,-291",
				["AlertFrameMover"] = "BOTTOM,ElvUIParent,BOTTOM,-3,417",
				["DebuffsMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-160,-133",
				["MinimapMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-4,-4",
			},
			["convertPages"] = true,
			["v11NamePlateReset"] = true,
			["auras"] = {
				["debuffs"] = {
					["timeFontOutline"] = "OUTLINE",
					["countFont"] = "傷害數字",
					["timeFont"] = "傷害數字",
					["countFontOutline"] = "OUTLINE",
					["size"] = 26,
				},
				["buffs"] = {
					["timeFontOutline"] = "OUTLINE",
					["countFont"] = "傷害數字",
					["countFontOutline"] = "OUTLINE",
					["timeFont"] = "EUI",
					["timeFontSize"] = 11,
					["size"] = 26,
				},
			},
			["chat"] = {
				["customTimeColor"] = {
					["r"] = 0.70196078431373,
					["g"] = 0.70196078431373,
					["b"] = 0.70196078431373,
				},
				["emotionIcons"] = false,
				["panelColor"] = {
					["a"] = 0.215930461883545,
					["r"] = 0.0588235294117647,
					["g"] = 0.0588235294117647,
					["b"] = 0.0588235294117647,
				},
				["panelBackdrop"] = "LEFT",
				["maxLines"] = 353,
				["copyChatLines"] = true,
				["tabSelectorColor"] = {
					["r"] = 0.999997794628143,
					["g"] = 0.956860661506653,
					["b"] = 0.407842248678207,
				},
				["scrollDownInterval"] = 30,
				["panelHeight"] = 260,
				["tabSelector"] = "NONE",
				["panelWidthRight"] = 300,
				["editBoxPosition"] = "ABOVE_CHAT",
				["panelWidth"] = 350,
			},
			["unitframe"] = {
				["font"] = "聊天",
				["statusbar"] = "ElvUI Blank",
				["colors"] = {
					["auraBarBuff"] = {
						["r"] = 0.999997794628143,
						["g"] = 0.486273437738419,
						["b"] = 0.0392156019806862,
					},
					["castClassColor"] = true,
					["healthclass"] = true,
				},
				["fontOutline"] = "THICKOUTLINE",
				["smoothbars"] = true,
				["smartRaidFilter"] = false,
				["cooldown"] = {
					["fonts"] = {
						["enable"] = true,
						["fontSize"] = 15,
					},
				},
				["units"] = {
					["tank"] = {
						["verticalSpacing"] = 2,
						["width"] = 85,
					},
					["focustarget"] = {
						["power"] = {
							["enable"] = false,
						},
						["width"] = 80,
						["castbar"] = {
							["width"] = 80,
						},
					},
					["pet"] = {
						["infoPanel"] = {
							["height"] = 14,
						},
						["debuffs"] = {
							["enable"] = true,
						},
						["disableTargetGlow"] = false,
						["power"] = {
							["height"] = 4,
						},
						["customTexts"] = {
							["名字"] = {
								["attachTextTo"] = "Health",
								["xOffset"] = 0,
								["text_format"] = "[namecolor][name:medium]",
								["yOffset"] = 0,
								["font"] = "聊天",
								["justifyH"] = "CENTER",
								["fontOutline"] = "OUTLINE",
								["enable"] = true,
								["size"] = 10,
							},
						},
						["castbar"] = {
							["iconSize"] = 32,
							["width"] = 65,
						},
						["name"] = {
							["text_format"] = "[happiness:full]",
							["yOffset"] = 10,
						},
						["width"] = 65,
					},
					["targettarget"] = {
						["raidicon"] = {
							["attachTo"] = "LEFT",
							["xOffset"] = 2,
							["enable"] = false,
							["yOffset"] = 0,
						},
						["debuffs"] = {
							["enable"] = false,
							["anchorPoint"] = "TOPRIGHT",
						},
						["threatStyle"] = "GLOW",
						["power"] = {
							["enable"] = false,
						},
						["height"] = 35,
						["name"] = {
							["text_format"] = "[name:medium]",
						},
						["disableMouseoverGlow"] = true,
						["width"] = 100,
					},
					["player"] = {
						["RestIcon"] = {
							["size"] = 20,
						},
						["debuffs"] = {
							["countFontSize"] = 10,
							["sizeOverride"] = 25,
							["perrow"] = 6,
							["numrows"] = 2,
							["anchorPoint"] = "BOTTOMLEFT",
							["yOffset"] = -30,
						},
						["portrait"] = {
							["enable"] = true,
							["camDistanceScale"] = 1,
							["overlayAlpha"] = 0.7,
						},
						["power"] = {
							["attachTextTo"] = "Power",
							["text_format"] = "[powercolor][curpp]",
						},
						["disableMouseoverGlow"] = true,
						["width"] = 180,
						["health"] = {
							["xOffset"] = 0,
							["text_format"] = "[health:current:shortvalue]               [perhp]%",
							["position"] = "RIGHT",
						},
						["CombatIcon"] = {
							["xOffset"] = -81,
							["yOffset"] = 28,
						},
						["name"] = {
							["yOffset"] = 16,
							["text_format"] = "[name]   [level]",
							["position"] = "TOPLEFT",
						},
						["castbar"] = {
							["height"] = 20,
							["width"] = 214,
							["insideInfoPanel"] = false,
						},
						["height"] = 45,
						["buffs"] = {
							["countFontSize"] = 10,
							["perrow"] = 6,
							["attachTo"] = "FRAME",
							["numrows"] = 2,
							["durationPosition"] = "BOTTOM",
							["yOffset"] = 15,
						},
						["classbar"] = {
							["detachedWidth"] = 360,
							["autoHide"] = true,
						},
						["aurabar"] = {
							["enable"] = false,
							["height"] = 10,
						},
					},
					["party"] = {
						["debuffs"] = {
							["countFontSize"] = 8,
							["sizeOverride"] = 22,
							["priority"] = "",
							["numrows"] = 2,
							["yOffset"] = 11,
						},
						["power"] = {
							["text_format"] = "",
							["height"] = 4,
						},
						["healPrediction"] = {
							["enable"] = true,
						},
						["width"] = 120,
						["name"] = {
							["text_format"] = "[namecolor][name:medium] [difficultycolor][level]",
						},
						["health"] = {
							["text_format"] = "",
						},
						["verticalSpacing"] = 6,
						["height"] = 44,
						["buffs"] = {
							["countFontSize"] = 8,
							["sizeOverride"] = 22,
							["perrow"] = 5,
							["enable"] = true,
							["priority"] = "",
							["numrows"] = 2,
							["yOffset"] = 11,
						},
						["visibility"] = "[@raid2,exists][@party1,noexists] hide;show",
						["rdebuffs"] = {
							["font"] = "PT Sans Narrow",
							["size"] = 20,
							["yOffset"] = 12,
						},
					},
					["raid40"] = {
						["health"] = {
							["text_format"] = "[health:deficit]",
						},
						["power"] = {
							["enable"] = true,
						},
						["height"] = 40,
						["healPrediction"] = {
							["enable"] = true,
						},
						["enable"] = false,
					},
					["focus"] = {
						["enable"] = false,
						["castbar"] = {
							["width"] = 120,
						},
						["health"] = {
							["xOffset"] = -37,
							["text_format"] = " [perhp]%",
							["yOffset"] = -18,
						},
						["width"] = 120,
					},
					["assist"] = {
						["enable"] = false,
					},
					["raid"] = {
						["debuffs"] = {
							["enable"] = true,
							["anchorPoint"] = "CENTER",
						},
						["height"] = 45,
						["healPrediction"] = {
							["enable"] = true,
						},
						["enable"] = false,
						["buffs"] = {
							["enable"] = true,
							["anchorPoint"] = "CENTER",
						},
					},
					["arena"] = {
						["enable"] = false,
					},
					["target"] = {
						["debuffs"] = {
							["countFontSize"] = 5,
							["perrow"] = 7,
							["attachTo"] = "FRAME",
							["priority"] = "Blacklist,Personal,nonPersonal",
							["numrows"] = 2,
							["yOffset"] = 16,
						},
						["portrait"] = {
							["enable"] = true,
							["camDistanceScale"] = 1,
							["overlayAlpha"] = 0.65,
						},
						["power"] = {
							["attachTextTo"] = "Power",
							["xOffset"] = -2,
							["text_format"] = "[powercolor][  >power:current]",
							["position"] = "RIGHT",
						},
						["customTexts"] = {
							["精英"] = {
								["attachTextTo"] = "Health",
								["xOffset"] = -80,
								["text_format"] = "[classification:icon][range]",
								["yOffset"] = 25,
								["font"] = "聊天",
								["justifyH"] = "CENTER",
								["fontOutline"] = "OUTLINE",
								["enable"] = true,
								["size"] = 10,
							},
						},
						["disableMouseoverGlow"] = true,
						["width"] = 180,
						["name"] = {
							["yOffset"] = 16,
							["text_format"] = "[level]   [name]",
							["position"] = "TOPRIGHT",
						},
						["fader"] = {
							["range"] = false,
						},
						["health"] = {
							["attachTextTo"] = "InfoPanel",
							["position"] = "LEFT",
							["xOffset"] = 0,
							["text_format"] = " [health:current:shortvalue]  -  [perhp]%",
							["yOffset"] = 3,
						},
						["castbar"] = {
							["height"] = 10,
							["width"] = 180,
							["insideInfoPanel"] = false,
						},
						["height"] = 45,
						["buffs"] = {
							["countFontSize"] = 5,
							["perrow"] = 7,
							["attachTo"] = "DEBUFFS",
							["growthX"] = "RIGHT",
							["numrows"] = 2,
							["priority"] = "Blacklist,Dispellable,Personal,nonPersonal,PlayerBuffs,Whitelist",
							["anchorPoint"] = "BOTTOMLEFT",
							["yOffset"] = -73,
						},
						["CombatIcon"] = {
							["xOffset"] = 81,
							["yOffset"] = 27,
						},
						["aurabar"] = {
							["enable"] = false,
							["height"] = 18,
						},
					},
				},
			},
			["dbConverted"] = 2.3,
			["datatexts"] = {
				["fontSize"] = 10,
				["panels"] = {
					["MinimapPanel"] = {
						["border"] = false,
						["backdrop"] = false,
					},
					["RightChatDataPanel"] = {
						"Gold", -- [1]
						"MeetingStone", -- [2]
						"System", -- [3]
						["enable"] = false,
						["backdrop"] = false,
					},
					["LeftChatDataPanel"] = {
						"WeakAuras", -- [1]
						"ElvUI", -- [2]
						"Durability", -- [3]
						["enable"] = false,
						["backdrop"] = false,
						["panelTransparency"] = true,
					},
				},
				["fontOutline"] = "OUTLINE",
			},
			["actionbar"] = {
				["bar3"] = {
					["point"] = "TOPLEFT",
					["buttonSize"] = 31,
					["macrotext"] = true,
					["buttonsPerRow"] = 4,
					["visibility"] = "[petbattle] hide; show",
					["buttons"] = 12,
				},
				["bar6"] = {
					["enabled"] = true,
					["macrotext"] = true,
					["point"] = "TOPLEFT",
					["buttonSize"] = 31,
				},
				["bar2"] = {
					["macrotext"] = true,
					["visibility"] = "[petbattle] hide; show",
					["buttonSize"] = 31,
				},
				["bar10"] = {
					["macrotext"] = true,
				},
				["bar8"] = {
					["macrotext"] = true,
				},
				["bar5"] = {
					["buttons"] = 12,
					["macrotext"] = true,
					["buttonsPerRow"] = 12,
					["visibility"] = "[petbattle] hide; show",
					["buttonSize"] = 31,
				},
				["barPet"] = {
					["point"] = "TOPLEFT",
					["buttonsPerRow"] = 10,
					["backdrop"] = false,
					["buttonSize"] = 28,
				},
				["microbar"] = {
					["buttons"] = 7,
					["buttonSize"] = 23,
				},
				["font"] = "傷害數字",
				["bar7"] = {
					["macrotext"] = true,
				},
				["bar1"] = {
					["macrotext"] = true,
					["buttonSize"] = 31,
				},
				["bar9"] = {
					["macrotext"] = true,
				},
				["stanceBar"] = {
					["style"] = "classic",
					["buttonSpacing"] = 1,
					["buttonSize"] = 25,
				},
				["cooldown"] = {
					["fonts"] = {
						["enable"] = true,
					},
					["override"] = false,
				},
				["bar4"] = {
					["point"] = "TOPLEFT",
					["buttonSize"] = 31,
					["macrotext"] = true,
					["buttonsPerRow"] = 4,
					["visibility"] = "[petbattle] hide; show",
					["backdrop"] = false,
				},
			},
			["nameplates"] = {
				["clampToScreen"] = true,
				["statusbar"] = "Melli",
				["units"] = {
					["ENEMY_NPC"] = {
						["debuffs"] = {
							["size"] = 20,
							["yOffset"] = 15,
						},
						["health"] = {
							["text"] = {
								["format"] = "[perhp]%",
							},
						},
						["buffs"] = {
							["enable"] = false,
							["size"] = 20,
						},
					},
					["TARGET"] = {
						["classpower"] = {
							["enable"] = true,
							["width"] = 60,
							["yOffset"] = -11,
						},
					},
					["FRIENDLY_NPC"] = {
						["debuffs"] = {
							["enable"] = false,
							["size"] = 20,
						},
						["health"] = {
							["text"] = {
								["format"] = "[perhp]%",
							},
						},
						["buffs"] = {
							["enable"] = false,
							["size"] = 20,
						},
					},
					["ENEMY_PLAYER"] = {
						["debuffs"] = {
							["size"] = 20,
							["yOffset"] = 15,
						},
						["health"] = {
							["text"] = {
								["format"] = "[health:current:shortvalue]  -  [perhp]%",
							},
						},
						["buffs"] = {
							["size"] = 20,
						},
					},
					["FRIENDLY_PLAYER"] = {
						["debuffs"] = {
							["size"] = 20,
							["yOffset"] = 15,
						},
						["nameOnly"] = true,
						["health"] = {
							["text"] = {
								["format"] = "[perhp]%",
							},
						},
						["buffs"] = {
							["enable"] = false,
							["size"] = 20,
						},
					},
				},
			},
			["bags"] = {
				["bagWidth"] = 550,
				["split"] = {
					["bagSpacing"] = 7,
					["bag4"] = true,
					["bag1"] = true,
					["bag2"] = true,
					["bag3"] = true,
				},
				["vendorGrays"] = {
					["enable"] = true,
				},
				["bagSize"] = 40,
				["bankWidth"] = 550,
				["bagBar"] = {
					["size"] = 25,
					["growthDirection"] = "HORIZONTAL",
				},
				["itemLevelCustomColorEnable"] = true,
				["scrapIcon"] = true,
				["bankSize"] = 40,
			},
			["cooldown"] = {
				["fonts"] = {
					["enable"] = true,
				},
				["hideBlizzard"] = true,
			},
			["tooltip"] = {
				["itemCount"] = "NONE",
				["healthBar"] = {
					["height"] = 12,
					["fontSize"] = 12,
					["font"] = "PT Sans Narrow",
					["fontOutline"] = "NONE",
				},
				["showMount"] = false,
				["cursorAnchorType"] = "ANCHOR_CURSOR_RIGHT",
				["alwaysShowRealm"] = true,
				["modifierID"] = "SHIFT",
				["guildRanks"] = false,
			},
		},
		["简洁1-独立头像"] = {
			["databars"] = {
				["petExperience"] = {
					["width"] = 65,
				},
				["threat"] = {
					["enable"] = false,
					["height"] = 24,
					["width"] = 472,
				},
				["experience"] = {
					["fontSize"] = 10,
					["height"] = 8,
					["textFormat"] = "PERCENT",
					["showBubbles"] = true,
					["width"] = 409,
				},
				["honor"] = {
					["enable"] = false,
				},
				["reputation"] = {
					["enable"] = true,
					["height"] = 6,
					["width"] = 409,
				},
				["azerite"] = {
					["enable"] = false,
				},
			},
			["currentTutorial"] = 6,
			["general"] = {
				["totems"] = {
					["growthDirection"] = "HORIZONTAL",
					["size"] = 30,
					["spacing"] = 8,
				},
				["fontSize"] = 14,
				["autoTrackReputation"] = true,
				["afk"] = false,
				["autoRepair"] = true,
				["minimap"] = {
					["icons"] = {
						["lfgEye"] = {
							["position"] = "BOTTOM",
							["yOffset"] = -26,
						},
						["classHall"] = {
							["xOffset"] = -36,
							["yOffset"] = -45,
						},
						["tracking"] = {
							["scale"] = 0.6,
							["xOffset"] = -12,
							["position"] = "TOPLEFT",
						},
					},
					["locationText"] = "SHOW",
					["size"] = 140,
				},
				["bottomPanel"] = false,
				["backdropfadecolor"] = {
					["a"] = 0.85700567066669,
					["r"] = 0.058823529411765,
					["g"] = 0.058823529411765,
					["b"] = 0.058823529411765,
				},
				["valuecolor"] = {
					["r"] = 0.999997794628143,
					["g"] = 0.956860661506653,
					["b"] = 0.407842248678207,
				},
				["loginmessage"] = false,
				["itemLevel"] = {
					["displayCharacterInfo"] = false,
					["itemLevelFontSize"] = 10,
				},
				["talkingHeadFrameScale"] = 0.7,
				["altPowerBar"] = {
					["statusBar"] = "Melli",
				},
				["numberPrefixStyle"] = "CHINESE",
				["vehicleSeatIndicatorSize"] = 80,
				["bonusObjectivePosition"] = "AUTO",
				["objectiveFrameHeight"] = 550,
				["interruptAnnounce"] = "RAID",
			},
			["bags"] = {
				["scrapIcon"] = true,
				["split"] = {
					["bagSpacing"] = 7,
					["bag4"] = true,
					["bag1"] = true,
					["bag2"] = true,
					["bag3"] = true,
				},
				["vendorGrays"] = {
					["enable"] = true,
				},
				["bagSize"] = 40,
				["bankWidth"] = 550,
				["bagWidth"] = 550,
				["itemLevelCustomColorEnable"] = true,
				["bagBar"] = {
					["size"] = 25,
					["spacing"] = 2,
					["backdropSpacing"] = 2,
					["growthDirection"] = "HORIZONTAL",
				},
				["bankSize"] = 40,
			},
			["chat"] = {
				["customTimeColor"] = {
					["r"] = 0.70196078431373,
					["g"] = 0.70196078431373,
					["b"] = 0.70196078431373,
				},
				["panelBackdrop"] = "LEFT",
				["tabSelector"] = "NONE",
				["panelColor"] = {
					["a"] = 0.1851545572280884,
					["r"] = 0.05882352941176471,
					["g"] = 0.05882352941176471,
					["b"] = 0.05882352941176471,
				},
				["scrollDownInterval"] = 30,
				["tabSelectorColor"] = {
					["r"] = 0.999997794628143,
					["g"] = 0.956860661506653,
					["b"] = 0.407842248678207,
				},
				["panelHeightRight"] = 60,
				["editBoxPosition"] = "ABOVE_CHAT",
				["separateSizes"] = true,
				["panelHeight"] = 260,
				["copyChatLines"] = true,
				["panelWidthRight"] = 50,
				["maxLines"] = 353,
				["panelWidth"] = 350,
			},
			["dbConverted"] = 2.3,
			["euiscript"] = {
				["autobutton"] = {
					["enable"] = false,
					["questSize"] = 30,
					["slotSize"] = 30,
				},
				["raidcd_width"] = 150,
				["raidcd"] = false,
			},
			["movers"] = {
				["ElvUF_FocusCastbarMover"] = "TOPLEFT,ElvUF_Focus,BOTTOMLEFT,0,-1",
				["ElvUF_FocusTargetMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,503,-116",
				["BuffsMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-161,-5",
				["BossButton"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-441,346",
				["LootFrameMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,423,-416",
				["ZoneAbility"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,422,323",
				["PowerBarContainerMover"] = "TOP,ElvUIParent,TOP,0,-54",
				["ElvUF_PetCastbarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,423,121",
				["VehicleSeatMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-66,-261",
				["ElvUF_TargetTargetMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-417,277",
				["WTSwitchButtonBarMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-60,-196",
				["LossControlMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-407,101",
				["WTCombatAlertFrameMover"] = "TOP,ElvUIParent,TOP,0,-276",
				["MirrorTimer1Mover"] = "TOP,ElvUIParent,TOP,0,-140",
				["TalkingHeadFrameMover"] = "BOTTOM,ElvUIParent,BOTTOM,-2,144",
				["AltPowerBarMover"] = "TOP,ElvUIParent,TOP,0,-196",
				["ReputationBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,0",
				["ObjectiveFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-83,-236",
				["MirrorTimer2Mover"] = "TOP,MirrorTimer1,BOTTOM,0,0",
				["ShiftAB"] = "BOTTOM,ElvUIParent,BOTTOM,-176,109",
				["ArenaHeaderMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-156,-264",
				["ElvUF_PlayerMover"] = "BOTTOM,ElvUIParent,BOTTOM,-231,270",
				["RightChatMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-4,4",
				["RaidCDAnchorMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,366,-300",
				["AutoButtonAnchor3Mover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-208,214",
				["ElvUF_AssistMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,123,-43",
				["WTRaidMarkersBarAnchor"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,310",
				["TopCenterContainerMover"] = "TOP,UIParent,TOP,0,-51",
				["ThreatBarMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-4,4",
				["PetAB"] = "BOTTOM,ElvUIParent,BOTTOM,77,108",
				["ElvUF_RaidMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,0,-116",
				["LeftChatMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,29",
				["GMMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,320",
				["MirrorTimer3Mover"] = "TOP,MirrorTimer2,BOTTOM,0,0",
				["ExAE_FrameMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,360,276",
				["WTMinimapButtonBarAnchor"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-4,-4",
				["ElvUF_FocusMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,397,-106",
				["AutoButtonAnchorMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-66,214",
				["ClassBarMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,475,-31",
				["MicrobarMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-15,4",
				["PetExperienceBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,423,176",
				["WTCustomEmoteFrameMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,324,56",
				["QuestTimerFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,0,-171",
				["ExperienceBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,6",
				["ElvAB_4"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-38,240",
				["ElvUF_TargetMover"] = "BOTTOM,ElvUIParent,BOTTOM,233,270",
				["WTParagonReputationToastFrameMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-49",
				["TotemBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,326,253",
				["ElvUF_Raid40Mover"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-202",
				["EuiExecuteMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,634,-367",
				["DurabilityFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-76,-324",
				["ElvAB_1"] = "BOTTOM,ElvUIParent,BOTTOM,0,13",
				["ElvAB_2"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-235,4",
				["BelowMinimapContainerMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-4,-166",
				["EUIMinimapButtonMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-138,-75",
				["WTGameBarAnchor"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-4",
				["ElvUF_TargetCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,233,259",
				["BNETMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,315",
				["ElvAB_3"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-3,240",
				["ElvAB_5"] = "BOTTOM,ElvUIParent,BOTTOM,0,44",
				["VehicleLeaveButton"] = "BOTTOM,ElvUIParent,BOTTOM,238,130",
				["ElvUIBagMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-409,-250",
				["LevelUpBossBannerMover"] = "TOP,ElvUIParent,TOP,0,-107",
				["BagsMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-237,4",
				["ElvUF_PlayerCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,132",
				["VOICECHAT"] = "TOPLEFT,UIParent,TOPLEFT,131,-4",
				["WTChatBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,288",
				["HonorBarMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-2,-251",
				["ElvAB_6"] = "BOTTOM,ElvUIParent,BOTTOM,0,76",
				["TooltipMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-78,323",
				["ElvUF_TankMover"] = "TOPLEFT,UIParent,TOPLEFT,4,-60",
				["BossHeaderMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-158,-262",
				["ElvUF_PetMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,423,139",
				["ElvUIBankMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,256,344",
				["ElvUF_PartyMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,121,-291",
				["AlertFrameMover"] = "BOTTOM,ElvUIParent,BOTTOM,-3,417",
				["DebuffsMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-160,-133",
				["MinimapMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-4,-4",
			},
			["convertPages"] = true,
			["tooltip"] = {
				["showMount"] = false,
				["healthBar"] = {
					["height"] = 12,
					["fontSize"] = 12,
					["font"] = "PT Sans Narrow",
					["fontOutline"] = "NONE",
				},
				["itemCount"] = "NONE",
				["cursorAnchorType"] = "ANCHOR_CURSOR_RIGHT",
				["alwaysShowRealm"] = true,
				["modifierID"] = "SHIFT",
				["guildRanks"] = false,
			},
			["v11NamePlateReset"] = true,
			["AuraWatch"] = {
				["loadDefault"] = true,
				["myclass"] = "ROGUE",
			},
			["unitframe"] = {
				["number"] = "CNW",
				["units"] = {
					["tank"] = {
						["height"] = 30,
						["verticalSpacing"] = 2,
						["width"] = 85,
					},
					["party"] = {
						["debuffs"] = {
							["countFontSize"] = 8,
							["sizeOverride"] = 22,
							["priority"] = "",
							["numrows"] = 2,
							["yOffset"] = 11,
						},
						["power"] = {
							["text_format"] = "",
							["height"] = 4,
						},
						["healPrediction"] = {
							["enable"] = true,
						},
						["width"] = 120,
						["rdebuffs"] = {
							["font"] = "PT Sans Narrow",
							["size"] = 20,
							["yOffset"] = 12,
						},
						["visibility"] = "[@raid2,exists][@party1,noexists] hide;show",
						["health"] = {
							["yOffset"] = -10,
							["text_format"] = " [perhp]%",
							["position"] = "RIGHT",
						},
						["buffs"] = {
							["countFontSize"] = 8,
							["sizeOverride"] = 22,
							["perrow"] = 5,
							["enable"] = true,
							["priority"] = "",
							["numrows"] = 2,
							["yOffset"] = 11,
						},
						["height"] = 44,
						["verticalSpacing"] = 6,
						["classbar"] = {
							["height"] = 5,
						},
						["name"] = {
							["xOffset"] = -5,
							["text_format"] = "[level][name:medium] [difficultycolor]",
							["yOffset"] = 3,
						},
					},
					["focustarget"] = {
						["power"] = {
							["enable"] = false,
						},
						["width"] = 80,
						["castbar"] = {
							["width"] = 80,
						},
					},
					["pet"] = {
						["infoPanel"] = {
							["height"] = 14,
						},
						["debuffs"] = {
							["enable"] = true,
						},
						["disableTargetGlow"] = false,
						["power"] = {
							["height"] = 4,
						},
						["customTexts"] = {
							["名字"] = {
								["attachTextTo"] = "Health",
								["enable"] = true,
								["text_format"] = "[namecolor][name:medium]",
								["yOffset"] = 0,
								["font"] = "聊天",
								["justifyH"] = "CENTER",
								["fontOutline"] = "OUTLINE",
								["xOffset"] = 0,
								["size"] = 10,
							},
						},
						["castbar"] = {
							["iconSize"] = 32,
							["width"] = 65,
						},
						["name"] = {
							["text_format"] = "[happiness:full]",
							["yOffset"] = 10,
						},
						["width"] = 65,
					},
					["target"] = {
						["power"] = {
							["attachTextTo"] = "Power",
							["xOffset"] = -2,
							["text_format"] = "[powercolor][  >power:current]",
							["position"] = "RIGHT",
						},
						["debuffs"] = {
							["countFontSize"] = 5,
							["perrow"] = 7,
							["attachTo"] = "FRAME",
							["priority"] = "Blacklist,Personal,nonPersonal",
							["numrows"] = 2,
							["yOffset"] = 16,
						},
						["portrait"] = {
							["enable"] = true,
							["camDistanceScale"] = 1.1,
							["overlayAlpha"] = 0.7,
						},
						["castbar"] = {
							["customTimeFont"] = {
								["enable"] = true,
							},
							["insideInfoPanel"] = false,
							["height"] = 10,
							["customTextFont"] = {
								["enable"] = true,
								["font"] = "傷害數字",
							},
							["width"] = 190,
						},
						["customTexts"] = {
							["精英"] = {
								["attachTextTo"] = "Health",
								["enable"] = true,
								["text_format"] = "[classification:icon][range]",
								["yOffset"] = 25,
								["font"] = "聊天",
								["justifyH"] = "CENTER",
								["fontOutline"] = "OUTLINE",
								["xOffset"] = -80,
								["size"] = 10,
							},
						},
						["healPrediction"] = {
							["absorbStyle"] = "NORMAL",
						},
						["disableMouseoverGlow"] = true,
						["DragonOverlayStyle"] = "classic",
						["width"] = 190,
						["name"] = {
							["yOffset"] = 16,
							["text_format"] = "[level]   [name]",
							["position"] = "TOPRIGHT",
						},
						["health"] = {
							["attachTextTo"] = "InfoPanel",
							["position"] = "LEFT",
							["xOffset"] = 0,
							["text_format"] = " [health:current:shortvalue]  -  [perhp]%",
							["yOffset"] = 3,
						},
						["fader"] = {
							["range"] = false,
						},
						["height"] = 45,
						["buffs"] = {
							["countFontSize"] = 5,
							["perrow"] = 7,
							["attachTo"] = "DEBUFFS",
							["growthX"] = "RIGHT",
							["numrows"] = 2,
							["priority"] = "Blacklist,Dispellable,Personal,nonPersonal,PlayerBuffs,Whitelist",
							["anchorPoint"] = "BOTTOMLEFT",
							["yOffset"] = -73,
						},
						["CombatIcon"] = {
							["xOffset"] = 81,
							["yOffset"] = 27,
						},
						["aurabar"] = {
							["enable"] = false,
							["height"] = 18,
						},
					},
					["arena"] = {
						["enable"] = false,
						["height"] = 40,
						["width"] = 230,
					},
					["player"] = {
						["RestIcon"] = {
							["size"] = 20,
						},
						["debuffs"] = {
							["countFontSize"] = 10,
							["sizeOverride"] = 25,
							["perrow"] = 6,
							["numrows"] = 2,
							["anchorPoint"] = "BOTTOMLEFT",
							["yOffset"] = -30,
						},
						["portrait"] = {
							["enable"] = true,
							["camDistanceScale"] = 1.1,
							["overlayAlpha"] = 0.7,
						},
						["power"] = {
							["attachTextTo"] = "Power",
							["text_format"] = "[powercolor][curpp]",
						},
						["customTexts"] = {
						},
						["healPrediction"] = {
							["absorbStyle"] = "NORMAL",
						},
						["disableMouseoverGlow"] = true,
						["width"] = 190,
						["health"] = {
							["xOffset"] = 0,
							["text_format"] = "[health:current:shortvalue]               [perhp]%",
							["position"] = "RIGHT",
						},
						["CombatIcon"] = {
							["xOffset"] = -81,
							["yOffset"] = 28,
						},
						["name"] = {
							["yOffset"] = 15,
							["text_format"] = "[name]   [level]",
							["position"] = "TOPLEFT",
						},
						["castbar"] = {
							["customTimeFont"] = {
								["enable"] = true,
							},
							["insideInfoPanel"] = false,
							["height"] = 20,
							["customTextFont"] = {
								["enable"] = true,
								["font"] = "傷害數字",
							},
							["width"] = 214,
						},
						["height"] = 45,
						["buffs"] = {
							["countFontSize"] = 10,
							["perrow"] = 6,
							["attachTo"] = "FRAME",
							["numrows"] = 2,
							["durationPosition"] = "BOTTOM",
							["yOffset"] = 15,
						},
						["classbar"] = {
							["detachedWidth"] = 360,
							["autoHide"] = true,
						},
						["aurabar"] = {
							["enable"] = false,
							["height"] = 10,
						},
					},
					["raid40"] = {
						["name"] = {
							["text_format"] = "[name:short]",
						},
						["power"] = {
							["enable"] = true,
						},
						["height"] = 40,
						["healPrediction"] = {
							["enable"] = true,
						},
						["health"] = {
							["text_format"] = "[health:deficit]",
						},
						["enable"] = false,
					},
					["focus"] = {
						["debuffs"] = {
							["attachTo"] = "HEALTH",
							["sizeOverride"] = 30,
							["priority"] = "Blacklist,Personal,nonPersonal,Boss,RaidDebuffs,Dispellable,Whitelist",
						},
						["castbar"] = {
							["width"] = 100,
						},
						["enable"] = false,
						["width"] = 100,
						["name"] = {
							["yOffset"] = 7,
						},
						["height"] = 40,
						["health"] = {
							["xOffset"] = -25,
							["text_format"] = "[perhp]%",
							["yOffset"] = -12,
						},
						["CombatIcon"] = {
							["enable"] = false,
						},
						["power"] = {
							["height"] = 3,
						},
					},
					["assist"] = {
						["enable"] = false,
					},
					["raid"] = {
						["debuffs"] = {
							["enable"] = true,
							["anchorPoint"] = "CENTER",
						},
						["height"] = 45,
						["healPrediction"] = {
							["enable"] = true,
						},
						["enable"] = false,
						["buffs"] = {
							["enable"] = true,
							["anchorPoint"] = "CENTER",
						},
					},
					["boss"] = {
						["infoPanel"] = {
							["height"] = 17,
						},
						["debuffs"] = {
							["maxDuration"] = 300,
							["sizeOverride"] = 27,
							["yOffset"] = -16,
						},
						["name"] = {
							["yOffset"] = 33,
						},
						["castbar"] = {
							["width"] = 230,
						},
						["height"] = 40,
						["buffs"] = {
							["maxDuration"] = 300,
							["sizeOverride"] = 27,
							["yOffset"] = 16,
						},
						["health"] = {
							["xOffset"] = 0,
							["text_format"] = "[healthcolor][health:current]（[health:percent]）",
						},
						["width"] = 230,
					},
					["targettarget"] = {
						["debuffs"] = {
							["anchorPoint"] = "TOPRIGHT",
							["enable"] = false,
						},
						["threatStyle"] = "GLOW",
						["power"] = {
							["enable"] = false,
						},
						["disableMouseoverGlow"] = true,
						["width"] = 100,
						["name"] = {
							["xOffset"] = -18,
							["text_format"] = "[name:medium]",
							["yOffset"] = 5,
						},
						["height"] = 35,
						["health"] = {
							["xOffset"] = 0,
							["text_format"] = "[perhp]%",
							["yOffset"] = -10,
						},
						["raidicon"] = {
							["attachTo"] = "LEFT",
							["xOffset"] = 2,
							["enable"] = false,
							["yOffset"] = 0,
						},
					},
				},
				["font"] = "默认",
				["colors"] = {
					["auraBarBuff"] = {
						["r"] = 0.999997794628143,
						["g"] = 0.486273437738419,
						["b"] = 0.0392156019806862,
					},
					["castClassColor"] = true,
					["healthclass"] = true,
				},
				["fontOutline"] = "THICKOUTLINE",
				["smartRaidFilter"] = false,
				["smoothbars"] = true,
				["cooldown"] = {
					["fonts"] = {
						["enable"] = true,
						["fontSize"] = 15,
					},
				},
				["statusbar"] = "ElvUI Blank",
			},
			["datatexts"] = {
				["fontSize"] = 10,
				["panels"] = {
					["MinimapPanel"] = {
						["backdrop"] = false,
						["border"] = false,
					},
					["RightChatDataPanel"] = {
						"Gold", -- [1]
						"MeetingStone", -- [2]
						"System", -- [3]
						["enable"] = false,
						["backdrop"] = false,
					},
					["LeftChatDataPanel"] = {
						"WeakAuras", -- [1]
						"ElvUI", -- [2]
						"Durability", -- [3]
						["enable"] = false,
						["backdrop"] = false,
						["panelTransparency"] = true,
					},
				},
				["fontOutline"] = "OUTLINE",
			},
			["actionbar"] = {
				["bar3"] = {
					["point"] = "TOPLEFT",
					["buttons"] = 12,
					["macrotext"] = true,
					["buttonsPerRow"] = 1,
					["visibility"] = "[petbattle] hide; show",
				},
				["bar6"] = {
					["enabled"] = true,
					["macrotext"] = true,
				},
				["bar2"] = {
					["visibility"] = "[petbattle] hide; show",
					["macrotext"] = true,
				},
				["bar10"] = {
					["macrotext"] = true,
				},
				["bar8"] = {
					["macrotext"] = true,
				},
				["bar5"] = {
					["macrotext"] = true,
					["buttonsPerRow"] = 12,
					["visibility"] = "[petbattle] hide; show",
					["buttons"] = 12,
				},
				["barPet"] = {
					["point"] = "TOPLEFT",
					["buttonsPerRow"] = 10,
					["backdrop"] = false,
					["buttonSize"] = 24,
				},
				["microbar"] = {
					["buttons"] = 7,
					["buttonSize"] = 23,
				},
				["font"] = "傷害數字",
				["bar7"] = {
					["macrotext"] = true,
				},
				["bar1"] = {
					["macrotext"] = true,
				},
				["bar9"] = {
					["macrotext"] = true,
				},
				["stanceBar"] = {
					["style"] = "classic",
					["buttonSpacing"] = 1,
					["buttonSize"] = 25,
				},
				["cooldown"] = {
					["fonts"] = {
						["enable"] = true,
					},
					["override"] = false,
				},
				["bar4"] = {
					["macrotext"] = true,
					["visibility"] = "[petbattle] hide; show",
					["point"] = "TOPLEFT",
					["backdrop"] = false,
				},
			},
			["nameplates"] = {
				["clampToScreen"] = true,
				["statusbar"] = "Melli",
				["units"] = {
					["ENEMY_NPC"] = {
						["debuffs"] = {
							["size"] = 20,
							["yOffset"] = 15,
						},
						["health"] = {
							["text"] = {
								["format"] = "[perhp]%",
								["fontSize"] = 10,
							},
						},
						["buffs"] = {
							["enable"] = false,
							["size"] = 20,
						},
					},
					["TARGET"] = {
						["classpower"] = {
							["enable"] = true,
							["width"] = 60,
							["yOffset"] = -11,
						},
					},
					["FRIENDLY_NPC"] = {
						["debuffs"] = {
							["enable"] = false,
							["size"] = 20,
							["yOffset"] = 15,
						},
						["health"] = {
							["text"] = {
								["format"] = "[perhp]%",
								["fontSize"] = 10,
							},
						},
						["buffs"] = {
							["enable"] = false,
							["size"] = 20,
						},
					},
					["ENEMY_PLAYER"] = {
						["debuffs"] = {
							["size"] = 20,
							["yOffset"] = 20,
						},
						["health"] = {
							["text"] = {
								["format"] = "[health:current:shortvalue]  -  [perhp]%",
								["fontSize"] = 10,
							},
						},
						["buffs"] = {
							["size"] = 20,
						},
					},
					["FRIENDLY_PLAYER"] = {
						["debuffs"] = {
							["size"] = 20,
							["yOffset"] = 15,
						},
						["nameOnly"] = true,
						["health"] = {
							["text"] = {
								["format"] = "[perhp]%",
								["fontSize"] = 10,
							},
						},
						["buffs"] = {
							["enable"] = false,
							["size"] = 20,
						},
					},
				},
			},
			["nameplates_v1"] = {
				["cooldown"] = {
					["fonts"] = {
						["enable"] = true,
					},
				},
				["classbar"] = {
					["position"] = "BELOW",
				},
				["units"] = {
					["ENEMY_PLAYER"] = {
						["debuffs"] = {
							["baseHeight"] = 20,
						},
						["buffs"] = {
							["baseHeight"] = 20,
						},
					},
					["FRIENDLY_NPC"] = {
						["healthbar"] = {
							["text"] = {
								["enable"] = false,
							},
						},
					},
				},
			},
			["cooldown"] = {
				["fonts"] = {
					["enable"] = true,
				},
				["hideBlizzard"] = true,
			},
			["auras"] = {
				["debuffs"] = {
					["timeFontOutline"] = "OUTLINE",
					["countFont"] = "傷害數字",
					["timeFont"] = "傷害數字",
					["countFontOutline"] = "OUTLINE",
					["size"] = 26,
				},
				["buffs"] = {
					["timeFontOutline"] = "OUTLINE",
					["countFont"] = "傷害數字",
					["countFontOutline"] = "OUTLINE",
					["timeFont"] = "EUI",
					["timeFontSize"] = 11,
					["size"] = 26,
				},
			},
		},
		["简洁1-纯血条头像"] = {
			["databars"] = {
				["petExperience"] = {
					["width"] = 65,
				},
				["threat"] = {
					["enable"] = false,
					["height"] = 24,
					["width"] = 472,
				},
				["experience"] = {
					["fontSize"] = 10,
					["height"] = 8,
					["textFormat"] = "PERCENT",
					["showBubbles"] = true,
					["width"] = 409,
				},
				["honor"] = {
					["enable"] = false,
				},
				["reputation"] = {
					["enable"] = true,
					["height"] = 6,
					["width"] = 409,
				},
				["azerite"] = {
					["enable"] = false,
				},
			},
			["currentTutorial"] = 6,
			["general"] = {
				["totems"] = {
					["growthDirection"] = "HORIZONTAL",
					["size"] = 30,
					["spacing"] = 8,
				},
				["fontSize"] = 14,
				["autoTrackReputation"] = true,
				["afk"] = false,
				["autoRepair"] = true,
				["minimap"] = {
					["icons"] = {
						["lfgEye"] = {
							["position"] = "BOTTOM",
							["yOffset"] = -26,
						},
						["classHall"] = {
							["xOffset"] = -36,
							["yOffset"] = -45,
						},
						["tracking"] = {
							["xOffset"] = -12,
							["scale"] = 0.6,
							["position"] = "TOPLEFT",
						},
					},
					["locationText"] = "SHOW",
					["size"] = 140,
				},
				["bottomPanel"] = false,
				["backdropfadecolor"] = {
					["a"] = 0.85700567066669,
					["r"] = 0.058823529411765,
					["g"] = 0.058823529411765,
					["b"] = 0.058823529411765,
				},
				["valuecolor"] = {
					["r"] = 0.999997794628143,
					["g"] = 0.956860661506653,
					["b"] = 0.407842248678207,
				},
				["loginmessage"] = false,
				["itemLevel"] = {
					["displayCharacterInfo"] = false,
					["itemLevelFontSize"] = 10,
				},
				["talkingHeadFrameScale"] = 0.7,
				["altPowerBar"] = {
					["statusBar"] = "Melli",
				},
				["numberPrefixStyle"] = "CHINESE",
				["vehicleSeatIndicatorSize"] = 80,
				["bonusObjectivePosition"] = "AUTO",
				["objectiveFrameHeight"] = 550,
				["interruptAnnounce"] = "RAID",
			},
			["bags"] = {
				["bagWidth"] = 550,
				["split"] = {
					["bagSpacing"] = 7,
					["bag4"] = true,
					["bag1"] = true,
					["bag2"] = true,
					["bag3"] = true,
				},
				["vendorGrays"] = {
					["enable"] = true,
				},
				["bagSize"] = 40,
				["bankWidth"] = 550,
				["bagBar"] = {
					["size"] = 25,
					["spacing"] = 2,
					["backdropSpacing"] = 2,
					["growthDirection"] = "HORIZONTAL",
				},
				["itemLevelCustomColorEnable"] = true,
				["scrapIcon"] = true,
				["bankSize"] = 40,
			},
			["auras"] = {
				["debuffs"] = {
					["timeFontOutline"] = "OUTLINE",
					["countFont"] = "傷害數字",
					["timeFont"] = "傷害數字",
					["countFontOutline"] = "OUTLINE",
					["size"] = 26,
				},
				["buffs"] = {
					["timeFontSize"] = 11,
					["countFont"] = "傷害數字",
					["countFontOutline"] = "OUTLINE",
					["timeFont"] = "EUI",
					["timeFontOutline"] = "OUTLINE",
					["size"] = 26,
				},
			},
			["dbConverted"] = 2.3,
			["euiscript"] = {
				["autobutton"] = {
					["enable"] = false,
					["questSize"] = 30,
					["slotSize"] = 30,
				},
				["raidcd_width"] = 150,
				["raidcd"] = false,
			},
			["movers"] = {
				["ElvUF_FocusCastbarMover"] = "TOPLEFT,ElvUF_Focus,BOTTOMLEFT,0,-1",
				["ElvUF_FocusTargetMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,503,-116",
				["BuffsMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-161,-5",
				["BossButton"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-441,346",
				["LootFrameMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,423,-416",
				["ZoneAbility"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,422,323",
				["DurabilityFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-76,-324",
				["ElvUF_PetCastbarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,423,121",
				["VehicleSeatMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-66,-261",
				["ElvUIBankMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,256,344",
				["WTSwitchButtonBarMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-60,-196",
				["LossControlMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-407,101",
				["WTCombatAlertFrameMover"] = "TOP,ElvUIParent,TOP,0,-276",
				["MirrorTimer1Mover"] = "TOP,ElvUIParent,TOP,0,-140",
				["ElvAB_4"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-38,240",
				["AltPowerBarMover"] = "TOP,ElvUIParent,TOP,0,-196",
				["ReputationBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,0",
				["ObjectiveFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-83,-236",
				["MirrorTimer2Mover"] = "TOP,MirrorTimer1,BOTTOM,0,0",
				["ShiftAB"] = "BOTTOM,ElvUIParent,BOTTOM,-175,108",
				["ArenaHeaderMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-156,-264",
				["ElvUF_PlayerMover"] = "BOTTOM,ElvUIParent,BOTTOM,-231,270",
				["RightChatMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-4,4",
				["RaidCDAnchorMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,366,-300",
				["AutoButtonAnchor3Mover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-208,214",
				["ElvUF_AssistMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,123,-43",
				["WTRaidMarkersBarAnchor"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,310",
				["TopCenterContainerMover"] = "TOP,ElvUIParent,TOP,0,-51",
				["ThreatBarMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-4,4",
				["ElvUF_PlayerCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,132",
				["ElvUF_RaidMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,0,-116",
				["LeftChatMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,29",
				["GMMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,320",
				["MirrorTimer3Mover"] = "TOP,MirrorTimer2,BOTTOM,0,0",
				["WTChatBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,288",
				["WTMinimapButtonBarAnchor"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-4,-4",
				["ElvUF_FocusMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,397,-106",
				["AutoButtonAnchorMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-66,214",
				["EUIMinimapButtonMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-138,-75",
				["MicrobarMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-15,4",
				["PetExperienceBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,423,176",
				["WTCustomEmoteFrameMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,324,56",
				["TalkingHeadFrameMover"] = "BOTTOM,ElvUIParent,BOTTOM,-2,144",
				["ExperienceBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,6",
				["QuestTimerFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,0,-171",
				["ElvUF_TargetMover"] = "BOTTOM,ElvUIParent,BOTTOM,233,270",
				["BNETMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,315",
				["ElvUF_PetMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,423,139",
				["ElvUF_Raid40Mover"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-202",
				["WTParagonReputationToastFrameMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-49",
				["PowerBarContainerMover"] = "TOP,ElvUIParent,TOP,0,-54",
				["ElvAB_1"] = "BOTTOM,ElvUIParent,BOTTOM,0,13",
				["ElvAB_2"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-235,4",
				["BelowMinimapContainerMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-4,-166",
				["ClassBarMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,475,-31",
				["WTGameBarAnchor"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-4",
				["EuiExecuteMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,634,-367",
				["ElvUF_TargetCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,233,259",
				["ElvAB_3"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-3,240",
				["ElvAB_5"] = "BOTTOM,ElvUIParent,BOTTOM,0,44",
				["VehicleLeaveButton"] = "BOTTOM,ElvUIParent,BOTTOM,238,130",
				["LevelUpBossBannerMover"] = "TOP,ElvUIParent,TOP,0,-107",
				["ElvUIBagMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-409,-250",
				["BagsMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-237,4",
				["PetAB"] = "BOTTOM,ElvUIParent,BOTTOM,77,108",
				["VOICECHAT"] = "TOPLEFT,UIParent,TOPLEFT,131,-4",
				["ExAE_FrameMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,360,276",
				["HonorBarMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-2,-251",
				["ElvAB_6"] = "BOTTOM,ElvUIParent,BOTTOM,0,76",
				["TooltipMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-78,323",
				["ElvUF_TankMover"] = "TOPLEFT,UIParent,TOPLEFT,4,-68",
				["BossHeaderMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-158,-262",
				["TotemBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,326,253",
				["ElvUF_TargetTargetMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-417,277",
				["ElvUF_PartyMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,121,-291",
				["AlertFrameMover"] = "BOTTOM,ElvUIParent,BOTTOM,-3,417",
				["DebuffsMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-160,-133",
				["MinimapMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-4,-4",
			},
			["convertPages"] = true,
			["tooltip"] = {
				["itemCount"] = "NONE",
				["healthBar"] = {
					["height"] = 12,
					["fontSize"] = 12,
					["font"] = "PT Sans Narrow",
					["fontOutline"] = "NONE",
				},
				["showMount"] = false,
				["cursorAnchorType"] = "ANCHOR_CURSOR_RIGHT",
				["alwaysShowRealm"] = true,
				["modifierID"] = "SHIFT",
				["guildRanks"] = false,
			},
			["AuraWatch"] = {
				["loadDefault"] = true,
				["myclass"] = "ROGUE",
			},
			["nameplates_v1"] = {
				["cooldown"] = {
					["fonts"] = {
						["enable"] = true,
					},
				},
				["classbar"] = {
					["position"] = "BELOW",
				},
				["units"] = {
					["ENEMY_PLAYER"] = {
						["buffs"] = {
							["baseHeight"] = 20,
						},
						["debuffs"] = {
							["baseHeight"] = 20,
						},
					},
					["FRIENDLY_NPC"] = {
						["healthbar"] = {
							["text"] = {
								["enable"] = false,
							},
						},
					},
				},
			},
			["unitframe"] = {
				["number"] = "CNW",
				["units"] = {
					["tank"] = {
						["height"] = 30,
						["verticalSpacing"] = 2,
						["width"] = 85,
					},
					["pet"] = {
						["infoPanel"] = {
							["height"] = 14,
						},
						["debuffs"] = {
							["enable"] = true,
						},
						["disableTargetGlow"] = false,
						["power"] = {
							["height"] = 4,
						},
						["customTexts"] = {
							["名字"] = {
								["attachTextTo"] = "Health",
								["xOffset"] = 0,
								["text_format"] = "[namecolor][name:medium]",
								["yOffset"] = 0,
								["font"] = "聊天",
								["justifyH"] = "CENTER",
								["fontOutline"] = "OUTLINE",
								["enable"] = true,
								["size"] = 10,
							},
						},
						["castbar"] = {
							["iconSize"] = 32,
							["width"] = 65,
						},
						["name"] = {
							["text_format"] = "[happiness:full]",
							["yOffset"] = 10,
						},
						["width"] = 65,
					},
					["focustarget"] = {
						["power"] = {
							["enable"] = false,
						},
						["width"] = 80,
						["castbar"] = {
							["width"] = 80,
						},
					},
					["targettarget"] = {
						["debuffs"] = {
							["enable"] = false,
							["anchorPoint"] = "TOPRIGHT",
						},
						["threatStyle"] = "GLOW",
						["power"] = {
							["enable"] = false,
						},
						["disableMouseoverGlow"] = true,
						["width"] = 100,
						["name"] = {
							["xOffset"] = -18,
							["text_format"] = "[name:medium]",
							["yOffset"] = 5,
						},
						["height"] = 35,
						["health"] = {
							["xOffset"] = 0,
							["text_format"] = "[perhp]%",
							["yOffset"] = -10,
						},
						["raidicon"] = {
							["attachTo"] = "LEFT",
							["xOffset"] = 2,
							["enable"] = false,
							["yOffset"] = 0,
						},
					},
					["party"] = {
						["debuffs"] = {
							["countFontSize"] = 8,
							["sizeOverride"] = 22,
							["priority"] = "",
							["numrows"] = 2,
							["yOffset"] = 11,
						},
						["power"] = {
							["text_format"] = "",
							["height"] = 4,
						},
						["healPrediction"] = {
							["enable"] = true,
						},
						["width"] = 120,
						["rdebuffs"] = {
							["font"] = "PT Sans Narrow",
							["size"] = 20,
							["yOffset"] = 12,
						},
						["visibility"] = "[@raid2,exists][@party1,noexists] hide;show",
						["health"] = {
							["yOffset"] = -10,
							["text_format"] = " [perhp]%",
							["position"] = "RIGHT",
						},
						["buffs"] = {
							["countFontSize"] = 8,
							["sizeOverride"] = 22,
							["perrow"] = 5,
							["enable"] = true,
							["priority"] = "",
							["numrows"] = 2,
							["yOffset"] = 11,
						},
						["height"] = 44,
						["verticalSpacing"] = 6,
						["classbar"] = {
							["height"] = 5,
						},
						["name"] = {
							["xOffset"] = -5,
							["text_format"] = "[level][name:medium] [difficultycolor]",
							["yOffset"] = 3,
						},
					},
					["raid"] = {
						["debuffs"] = {
							["enable"] = true,
							["anchorPoint"] = "CENTER",
						},
						["height"] = 45,
						["healPrediction"] = {
							["enable"] = true,
						},
						["enable"] = false,
						["buffs"] = {
							["enable"] = true,
							["anchorPoint"] = "CENTER",
						},
					},
					["boss"] = {
						["infoPanel"] = {
							["height"] = 17,
						},
						["debuffs"] = {
							["maxDuration"] = 300,
							["sizeOverride"] = 27,
							["yOffset"] = -16,
						},
						["name"] = {
							["yOffset"] = 33,
						},
						["castbar"] = {
							["width"] = 230,
						},
						["height"] = 40,
						["buffs"] = {
							["maxDuration"] = 300,
							["sizeOverride"] = 27,
							["yOffset"] = 16,
						},
						["health"] = {
							["xOffset"] = 0,
							["text_format"] = "[healthcolor][health:current]（[health:percent]）",
						},
						["width"] = 230,
					},
					["raid40"] = {
						["name"] = {
							["text_format"] = "[name:short]",
						},
						["power"] = {
							["enable"] = true,
						},
						["height"] = 40,
						["healPrediction"] = {
							["enable"] = true,
						},
						["enable"] = false,
						["health"] = {
							["text_format"] = "[health:deficit]",
						},
					},
					["focus"] = {
						["debuffs"] = {
							["attachTo"] = "HEALTH",
							["sizeOverride"] = 30,
							["priority"] = "Blacklist,Personal,nonPersonal,Boss,RaidDebuffs,Dispellable,Whitelist",
						},
						["power"] = {
							["height"] = 3,
						},
						["enable"] = false,
						["width"] = 100,
						["name"] = {
							["yOffset"] = 7,
						},
						["height"] = 40,
						["health"] = {
							["xOffset"] = -25,
							["text_format"] = "[perhp]%",
							["yOffset"] = -12,
						},
						["CombatIcon"] = {
							["enable"] = false,
						},
						["castbar"] = {
							["width"] = 100,
						},
					},
					["assist"] = {
						["enable"] = false,
					},
					["arena"] = {
						["enable"] = false,
						["height"] = 40,
						["width"] = 230,
					},
					["target"] = {
						["debuffs"] = {
							["countFontSize"] = 5,
							["perrow"] = 7,
							["attachTo"] = "FRAME",
							["priority"] = "Blacklist,Personal,nonPersonal",
							["numrows"] = 2,
							["yOffset"] = 16,
						},
						["portrait"] = {
							["overlay"] = true,
							["overlayAlpha"] = 0.7,
						},
						["DragonOverlayStyle"] = "classic",
						["CombatIcon"] = {
							["xOffset"] = 81,
							["yOffset"] = 27,
						},
						["aurabar"] = {
							["enable"] = false,
							["height"] = 18,
						},
						["power"] = {
							["attachTextTo"] = "Power",
							["xOffset"] = -2,
							["text_format"] = "[powercolor][  >power:current]",
							["position"] = "RIGHT",
						},
						["customTexts"] = {
							["精英"] = {
								["attachTextTo"] = "Health",
								["xOffset"] = -80,
								["text_format"] = "[classification:icon][range]",
								["yOffset"] = 25,
								["font"] = "聊天",
								["justifyH"] = "CENTER",
								["fontOutline"] = "OUTLINE",
								["enable"] = true,
								["size"] = 10,
							},
						},
						["healPrediction"] = {
							["absorbStyle"] = "NORMAL",
						},
						["disableMouseoverGlow"] = true,
						["width"] = 180,
						["health"] = {
							["attachTextTo"] = "InfoPanel",
							["xOffset"] = 0,
							["text_format"] = "[health:current:shortvalue]  -  [perhp]%",
							["yOffset"] = 3,
						},
						["name"] = {
							["yOffset"] = 16,
							["text_format"] = "[level]   [name]",
							["position"] = "TOPRIGHT",
						},
						["height"] = 45,
						["orientation"] = "LEFT",
						["buffs"] = {
							["countFontSize"] = 5,
							["perrow"] = 7,
							["attachTo"] = "DEBUFFS",
							["growthX"] = "RIGHT",
							["numrows"] = 2,
							["priority"] = "Blacklist,Dispellable,Personal,nonPersonal,PlayerBuffs,Whitelist",
							["anchorPoint"] = "BOTTOMLEFT",
							["yOffset"] = -73,
						},
						["fader"] = {
							["range"] = false,
						},
						["castbar"] = {
							["customTimeFont"] = {
								["enable"] = true,
							},
							["insideInfoPanel"] = false,
							["height"] = 10,
							["customTextFont"] = {
								["enable"] = true,
								["font"] = "傷害數字",
							},
							["width"] = 180,
						},
					},
					["player"] = {
						["RestIcon"] = {
							["size"] = 20,
						},
						["debuffs"] = {
							["countFontSize"] = 10,
							["sizeOverride"] = 25,
							["perrow"] = 6,
							["numrows"] = 2,
							["anchorPoint"] = "BOTTOMLEFT",
							["yOffset"] = -30,
						},
						["portrait"] = {
							["overlay"] = true,
							["overlayAlpha"] = 0.7,
						},
						["power"] = {
							["attachTextTo"] = "Power",
							["text_format"] = "[powercolor][curpp]",
						},
						["customTexts"] = {
						},
						["healPrediction"] = {
							["absorbStyle"] = "NORMAL",
						},
						["disableMouseoverGlow"] = true,
						["width"] = 180,
						["health"] = {
							["xOffset"] = 0,
							["text_format"] = "[health:current:shortvalue]                        [perhp]%",
							["position"] = "RIGHT",
						},
						["CombatIcon"] = {
							["xOffset"] = -81,
							["yOffset"] = 28,
						},
						["name"] = {
							["yOffset"] = 15,
							["text_format"] = "[name]   [level]",
							["position"] = "TOPLEFT",
						},
						["castbar"] = {
							["customTimeFont"] = {
								["enable"] = true,
							},
							["insideInfoPanel"] = false,
							["height"] = 20,
							["customTextFont"] = {
								["enable"] = true,
								["font"] = "傷害數字",
							},
							["width"] = 214,
						},
						["height"] = 45,
						["buffs"] = {
							["countFontSize"] = 10,
							["perrow"] = 6,
							["attachTo"] = "FRAME",
							["numrows"] = 2,
							["durationPosition"] = "BOTTOM",
							["yOffset"] = 15,
						},
						["classbar"] = {
							["detachedWidth"] = 360,
							["autoHide"] = true,
						},
						["aurabar"] = {
							["enable"] = false,
							["height"] = 10,
						},
					},
				},
				["smoothbars"] = true,
				["colors"] = {
					["auraBarBuff"] = {
						["r"] = 0.999997794628143,
						["g"] = 0.486273437738419,
						["b"] = 0.0392156019806862,
					},
					["castClassColor"] = true,
					["healthclass"] = true,
				},
				["fontOutline"] = "THICKOUTLINE",
				["font"] = "默认",
				["statusbar"] = "ElvUI Blank",
				["cooldown"] = {
					["fonts"] = {
						["enable"] = true,
						["fontSize"] = 15,
					},
				},
				["smartRaidFilter"] = false,
			},
			["datatexts"] = {
				["fontSize"] = 10,
				["panels"] = {
					["MinimapPanel"] = {
						["border"] = false,
						["backdrop"] = false,
					},
					["RightChatDataPanel"] = {
						"Gold", -- [1]
						"MeetingStone", -- [2]
						"System", -- [3]
						["enable"] = false,
						["backdrop"] = false,
					},
					["LeftChatDataPanel"] = {
						"WeakAuras", -- [1]
						"ElvUI", -- [2]
						"Durability", -- [3]
						["panelTransparency"] = true,
						["backdrop"] = false,
						["enable"] = false,
					},
				},
				["fontOutline"] = "OUTLINE",
			},
			["actionbar"] = {
				["bar3"] = {
					["point"] = "TOPLEFT",
					["buttons"] = 12,
					["macrotext"] = true,
					["buttonsPerRow"] = 1,
					["visibility"] = "[petbattle] hide; show",
				},
				["bar6"] = {
					["enabled"] = true,
					["macrotext"] = true,
				},
				["bar2"] = {
					["visibility"] = "[petbattle] hide; show",
					["macrotext"] = true,
				},
				["bar10"] = {
					["macrotext"] = true,
				},
				["bar8"] = {
					["macrotext"] = true,
				},
				["bar5"] = {
					["macrotext"] = true,
					["buttonsPerRow"] = 12,
					["visibility"] = "[petbattle] hide; show",
					["buttons"] = 12,
				},
				["barPet"] = {
					["point"] = "TOPLEFT",
					["buttonsPerRow"] = 10,
					["backdrop"] = false,
					["buttonSize"] = 24,
				},
				["microbar"] = {
					["buttons"] = 7,
					["buttonSize"] = 23,
				},
				["font"] = "傷害數字",
				["bar7"] = {
					["macrotext"] = true,
				},
				["bar1"] = {
					["macrotext"] = true,
				},
				["bar9"] = {
					["macrotext"] = true,
				},
				["stanceBar"] = {
					["style"] = "classic",
					["buttonSpacing"] = 1,
					["buttonSize"] = 25,
				},
				["cooldown"] = {
					["fonts"] = {
						["enable"] = true,
					},
					["override"] = false,
				},
				["bar4"] = {
					["macrotext"] = true,
					["visibility"] = "[petbattle] hide; show",
					["point"] = "TOPLEFT",
					["backdrop"] = false,
				},
			},
			["nameplates"] = {
				["clampToScreen"] = true,
				["statusbar"] = "Melli",
				["units"] = {
					["ENEMY_NPC"] = {
						["debuffs"] = {
							["size"] = 20,
							["yOffset"] = 15,
						},
						["health"] = {
							["text"] = {
								["format"] = "[perhp]%",
								["fontSize"] = 10,
							},
						},
						["buffs"] = {
							["enable"] = false,
							["size"] = 20,
						},
					},
					["TARGET"] = {
						["classpower"] = {
							["enable"] = true,
							["width"] = 60,
							["yOffset"] = -11,
						},
					},
					["FRIENDLY_NPC"] = {
						["debuffs"] = {
							["enable"] = false,
							["size"] = 20,
							["yOffset"] = 15,
						},
						["health"] = {
							["text"] = {
								["format"] = "[perhp]%",
								["fontSize"] = 10,
							},
						},
						["buffs"] = {
							["enable"] = false,
							["size"] = 20,
						},
					},
					["ENEMY_PLAYER"] = {
						["debuffs"] = {
							["size"] = 20,
							["yOffset"] = 20,
						},
						["health"] = {
							["text"] = {
								["format"] = "[health:current:shortvalue]  -  [perhp]%",
								["fontSize"] = 10,
							},
						},
						["buffs"] = {
							["size"] = 20,
						},
					},
					["FRIENDLY_PLAYER"] = {
						["debuffs"] = {
							["size"] = 20,
							["yOffset"] = 15,
						},
						["nameOnly"] = true,
						["health"] = {
							["text"] = {
								["format"] = "[perhp]%",
								["fontSize"] = 10,
							},
						},
						["buffs"] = {
							["enable"] = false,
							["size"] = 20,
						},
					},
				},
			},
			["chat"] = {
				["customTimeColor"] = {
					["r"] = 0.70196078431373,
					["g"] = 0.70196078431373,
					["b"] = 0.70196078431373,
				},
				["panelBackdrop"] = "LEFT",
				["tabSelector"] = "NONE",
				["panelColor"] = {
					["a"] = 0.1851545572280884,
					["r"] = 0.05882352941176471,
					["g"] = 0.05882352941176471,
					["b"] = 0.05882352941176471,
				},
				["scrollDownInterval"] = 30,
				["tabSelectorColor"] = {
					["r"] = 0.999997794628143,
					["g"] = 0.956860661506653,
					["b"] = 0.407842248678207,
				},
				["panelHeightRight"] = 60,
				["editBoxPosition"] = "ABOVE_CHAT",
				["separateSizes"] = true,
				["panelHeight"] = 260,
				["copyChatLines"] = true,
				["panelWidthRight"] = 50,
				["maxLines"] = 353,
				["panelWidth"] = 350,
			},
			["cooldown"] = {
				["fonts"] = {
					["enable"] = true,
				},
				["hideBlizzard"] = true,
			},
			["v11NamePlateReset"] = true,
		},
		["Minimalistic"] = {
			["currentTutorial"] = 2,
			["general"] = {
				["font"] = "Expressway",
				["bottomPanel"] = false,
				["backdropfadecolor"] = {
					["a"] = 0.80000001192093,
					["b"] = 0.058823529411765,
					["g"] = 0.058823529411765,
					["r"] = 0.058823529411765,
				},
				["reputation"] = {
					["orientation"] = "HORIZONTAL",
					["textFormat"] = "PERCENT",
					["height"] = 16,
					["width"] = 200,
				},
				["bordercolor"] = {
					["b"] = 0.30588235294118,
					["g"] = 0.30588235294118,
					["r"] = 0.30588235294118,
				},
				["fontSize"] = 11,
				["valuecolor"] = {
					["a"] = 1,
					["b"] = 1,
					["g"] = 1,
					["r"] = 1,
				},
			},
			["movers"] = {
				["PetAB"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-50,-428",
				["ElvUF_RaidMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,51,120",
				["LeftChatMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,50,50",
				["GMMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,250,-50",
				["BossButton"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-117,-298",
				["LootFrameMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,249,-216",
				["ElvUF_RaidpetMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,50,827",
				["MicrobarMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-52",
				["VehicleSeatMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,51,-87",
				["ElvUF_TargetTargetMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,143",
				["ElvUF_Raid40Mover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,392,1073",
				["ElvAB_1"] = "BOTTOM,ElvUIParent,BOTTOM,0,50",
				["ElvAB_2"] = "BOTTOM,ElvUIParent,BOTTOM,0,90",
				["ElvAB_4"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-50,-394",
				["AltPowerBarMover"] = "TOP,ElvUIParent,TOP,0,-186",
				["ElvAB_3"] = "BOTTOM,ElvUIParent,BOTTOM,305,50",
				["ElvAB_5"] = "BOTTOM,ElvUIParent,BOTTOM,-305,50",
				["ElvUF_AssistMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,51,937",
				["ReputationBarMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-50,-228",
				["ObjectiveFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-122,-393",
				["BNETMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,50,232",
				["ShiftAB"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,50,1150",
				["ElvUF_PlayerCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,133",
				["RightChatMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-50,50",
				["ElvAB_6"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-488,330",
				["TooltipMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-50,50",
				["ElvUF_TankMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,50,995",
				["TotemBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,463,50",
				["ElvUF_PetMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,200",
				["ElvUF_PlayerMover"] = "BOTTOM,ElvUIParent,BOTTOM,-230,140",
				["ElvUF_PartyMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,184,773",
				["AlertFrameMover"] = "TOP,ElvUIParent,TOP,0,-50",
				["ElvUF_TargetMover"] = "BOTTOM,ElvUIParent,BOTTOM,230,140",
				["MinimapMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-50,-50",
			},
			["bags"] = {
				["itemLevelFontSize"] = 9,
				["countFontSize"] = 9,
			},
			["hideTutorial"] = true,
			["auras"] = {
				["font"] = "Expressway",
				["debuffs"] = {
					["countFontSize"] = 11,
					["durationFontSize"] = 11,
				},
				["buffs"] = {
					["countFontSize"] = 11,
					["maxWraps"] = 2,
					["durationFontSize"] = 11,
				},
			},
			["unitframe"] = {
				["statusbar"] = "ElvUI Blank",
				["fontOutline"] = "THICKOUTLINE",
				["smoothbars"] = true,
				["fontSize"] = 9,
				["font"] = "Expressway",
				["units"] = {
					["tank"] = {
						["enable"] = false,
					},
					["targettarget"] = {
						["infoPanel"] = {
							["enable"] = true,
						},
						["debuffs"] = {
							["enable"] = false,
						},
						["name"] = {
							["attachTextTo"] = "InfoPanel",
							["position"] = "TOP",
							["yOffset"] = -2,
						},
						["height"] = 50,
						["width"] = 122,
					},
					["assist"] = {
						["enable"] = false,
					},
					["party"] = {
						["horizontalSpacing"] = 3,
						["debuffs"] = {
							["numrows"] = 4,
							["anchorPoint"] = "BOTTOM",
							["perrow"] = 1,
						},
						["power"] = {
							["text_format"] = "",
							["height"] = 5,
						},
						["enable"] = false,
						["rdebuffs"] = {
							["font"] = "Expressway",
						},
						["growthDirection"] = "RIGHT_DOWN",
						["infoPanel"] = {
							["enable"] = true,
						},
						["width"] = 110,
						["health"] = {
							["attachTextTo"] = "InfoPanel",
							["orientation"] = "VERTICAL",
							["text_format"] = "[healthcolor][health:current]",
							["position"] = "RIGHT",
						},
						["name"] = {
							["attachTextTo"] = "InfoPanel",
							["text_format"] = "[namecolor][name:short]",
							["position"] = "LEFT",
						},
						["height"] = 59,
						["verticalSpacing"] = 0,
						["healPrediction"] = true,
						["roleIcon"] = {
							["position"] = "TOPRIGHT",
						},
					},
					["arena"] = {
						["spacing"] = 26,
						["castbar"] = {
							["width"] = 246,
						},
					},
					["focus"] = {
						["infoPanel"] = {
							["height"] = 17,
							["enable"] = true,
						},
						["threatStyle"] = "NONE",
						["castbar"] = {
							["iconSize"] = 26,
							["width"] = 122,
						},
						["height"] = 56,
						["name"] = {
							["attachTextTo"] = "InfoPanel",
							["position"] = "LEFT",
						},
						["health"] = {
							["attachTextTo"] = "InfoPanel",
							["text_format"] = "[healthcolor][health:current]",
						},
						["width"] = 189,
					},
					["target"] = {
						["debuffs"] = {
							["perrow"] = 7,
						},
						["power"] = {
							["attachTextTo"] = "InfoPanel",
							["hideonnpc"] = false,
							["text_format"] = "[powercolor][power:current-max]",
							["height"] = 15,
						},
						["infoPanel"] = {
							["enable"] = true,
						},
						["name"] = {
							["attachTextTo"] = "InfoPanel",
							["text_format"] = "[namecolor][name]",
						},
						["health"] = {
							["attachTextTo"] = "InfoPanel",
							["text_format"] = "[healthcolor][health:current-max]",
						},
						["height"] = 80,
						["buffs"] = {
							["perrow"] = 7,
						},
						["smartAuraPosition"] = "DEBUFFS_ON_BUFFS",
						["castbar"] = {
							["iconSize"] = 54,
							["iconAttached"] = false,
						},
					},
					["raid"] = {
						["roleIcon"] = {
							["position"] = "RIGHT",
						},
						["debuffs"] = {
							["enable"] = true,
							["sizeOverride"] = 27,
							["perrow"] = 4,
						},
						["rdebuffs"] = {
							["enable"] = false,
							["font"] = "Expressway",
						},
						["growthDirection"] = "UP_RIGHT",
						["health"] = {
							["yOffset"] = -6,
						},
						["groupsPerRowCol"] = 5,
						["height"] = 28,
						["name"] = {
							["position"] = "LEFT",
						},
						["visibility"] = "[nogroup] hide;show",
						["width"] = 140,
					},
					["pet"] = {
						["infoPanel"] = {
							["enable"] = true,
							["height"] = 14,
						},
						["debuffs"] = {
							["enable"] = true,
						},
						["threatStyle"] = "NONE",
						["castbar"] = {
							["width"] = 122,
						},
						["height"] = 50,
						["portrait"] = {
							["camDistanceScale"] = 2,
						},
						["width"] = 122,
					},
					["player"] = {
						["infoPanel"] = {
							["enable"] = true,
						},
						["debuffs"] = {
							["perrow"] = 7,
						},
						["health"] = {
							["attachTextTo"] = "InfoPanel",
							["text_format"] = "[healthcolor][health:current-max]",
						},
						["power"] = {
							["attachTextTo"] = "InfoPanel",
							["text_format"] = "[powercolor][power:current-max]",
							["height"] = 15,
						},
						["height"] = 80,
						["name"] = {
							["attachTextTo"] = "InfoPanel",
							["text_format"] = "[namecolor][name]",
						},
						["classbar"] = {
							["height"] = 15,
							["autoHide"] = true,
						},
						["castbar"] = {
							["iconAttached"] = false,
							["iconSize"] = 54,
							["height"] = 35,
							["width"] = 478,
						},
					},
				},
			},
			["datatexts"] = {
				["minimapPanels"] = false,
				["fontSize"] = 11,
				["panelTransparency"] = true,
				["goldFormat"] = "SHORT",
				["leftChatPanel"] = false,
				["font"] = "Expressway",
				["panels"] = {
					["BottomMiniPanel"] = "Time",
					["RightMiniPanel"] = "",
					["RightChatDataPanel"] = {
						["right"] = "",
						["left"] = "",
						["middle"] = "",
					},
					["LeftMiniPanel"] = "",
					["LeftChatDataPanel"] = {
						["right"] = "",
						["left"] = "",
						["middle"] = "",
					},
				},
				["rightChatPanel"] = false,
			},
			["actionbar"] = {
				["bar3"] = {
					["inheritGlobalFade"] = true,
					["buttonsize"] = 38,
					["buttonsPerRow"] = 3,
				},
				["fontSize"] = 9,
				["bar2"] = {
					["enabled"] = true,
					["inheritGlobalFade"] = true,
					["buttonsize"] = 38,
				},
				["bar1"] = {
					["heightMult"] = 2,
					["inheritGlobalFade"] = true,
					["buttonsize"] = 38,
				},
				["bar5"] = {
					["inheritGlobalFade"] = true,
					["buttonsize"] = 38,
					["buttonsPerRow"] = 3,
				},
				["globalFadeAlpha"] = 0.87,
				["stanceBar"] = {
					["inheritGlobalFade"] = true,
				},
				["bar6"] = {
					["buttonsize"] = 38,
				},
				["bar4"] = {
					["enabled"] = false,
					["backdrop"] = false,
					["buttonsize"] = 38,
				},
			},
			["layoutSet"] = "dpsMelee",
			["nameplates"] = {
				["filters"] = {
				},
			},
			["tooltip"] = {
				["textFontSize"] = 11,
				["font"] = "Expressway",
				["healthBar"] = {
					["font"] = "Expressway",
				},
				["headerFontSize"] = 11,
				["fontSize"] = 11,
				["smallTextFontSize"] = 11,
			},
			["chat"] = {
				["chatHistory"] = false,
				["fontSize"] = 11,
				["tabFont"] = "Expressway",
				["tabFontSize"] = 11,
				["fadeUndockedTabs"] = false,
				["editBoxPosition"] = "ABOVE_CHAT",
				["fadeTabsNoBackdrop"] = false,
				["font"] = "Expressway",
				["panelBackdrop"] = "HIDEBOTH",
			},
		},
	},
}
ElvPrivateDB = {
	["profileKeys"] = {
		["猎猎思密达 - 阿什坎迪"] = "简洁界面 - 阿什坎迪",
		["简洁界面 - 阿什坎迪"] = "简洁界面 - 阿什坎迪",
		["今晚就动手 - 阿什坎迪"] = "今晚就动手 - 阿什坎迪",
	},
	["profiles"] = {
		["今晚就动手 - 阿什坎迪"] = {
			["general"] = {
				["worldMap"] = false,
			},
			["actionbar"] = {
				["masque"] = {
					["stanceBar"] = true,
					["petBar"] = true,
					["actionbars"] = true,
				},
			},
			["bags"] = {
				["bagBar"] = true,
			},
			["nameplates_v1"] = {
				["enable"] = true,
			},
			["install_complete"] = 1.42,
		},
		["简洁界面 - 阿什坎迪"] = {
			["general"] = {
				["loot"] = false,
				["lootRoll"] = false,
			},
			["bags"] = {
				["enable"] = false,
			},
			["actionbar"] = {
				["masque"] = {
					["stanceBar"] = true,
					["petBar"] = true,
					["actionbars"] = true,
				},
			},
			["install_complete"] = 2.08,
		},
	},
}
