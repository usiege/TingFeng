
TalentEmuSV = {
	["__upgraded"] = true,
	["var"] = {
		["Player-4792-026E8FC2"] = "930",
		["Player-4792-025EAE5E"] = "940",
		["Player-4792-03A26BE8"] = "210",
		["savedTalent"] = {
		},
	},
	["_version"] = 210524,
	["set"] = {
		["credible"] = false,
		["minimapPos"] = 185,
		["talents_in_tip"] = false,
		["supreme"] = false,
	},
}
