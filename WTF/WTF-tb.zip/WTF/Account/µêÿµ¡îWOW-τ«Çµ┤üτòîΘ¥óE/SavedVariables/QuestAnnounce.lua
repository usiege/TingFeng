
QuestAnnounceDB = {
	["profileKeys"] = {
		["猎猎思密达 - 阿什坎迪"] = "Default",
		["简洁界面 - 阿什坎迪"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["profile"] = {
				["announceTo"] = {
					["raidWarningFrame"] = false,
					["chatFrame"] = true,
					["uiErrorsFrame"] = false,
				},
				["settings"] = {
					["enable"] = true,
					["debug"] = false,
					["sound"] = false,
					["every"] = 1,
				},
				["announceIn"] = {
					["party"] = true,
					["guild"] = false,
					["say"] = false,
					["whisper"] = false,
					["officer"] = false,
				},
			},
		},
	},
}
