
MSBTProfiles_SavedVars = {
	["profiles"] = {
		["Default"] = {
			["enableBlizzardDamage"] = false,
			["creationVersion"] = "5.7.152",
			["alwaysShowQuestItems"] = false,
			["soundsDisabled"] = true,
			["scrollAreas"] = {
				["Incoming"] = {
					["direction"] = "Up",
					["disabled"] = true,
					["textAlignIndex"] = 2,
					["behavior"] = "MSBT_NORMAL",
					["stickyTextAlignIndex"] = 2,
					["scrollHeight"] = 195,
					["offsetX"] = -19,
					["offsetY"] = -185,
					["animationStyle"] = "Straight",
				},
				["Notification"] = {
					["disabled"] = true,
				},
				["Outgoing"] = {
					["direction"] = "Up",
					["behavior"] = "MSBT_NORMAL",
					["stickyTextAlignIndex"] = 2,
					["scrollHeight"] = 200,
					["offsetX"] = -19,
					["offsetY"] = 80,
					["textAlignIndex"] = 2,
					["animationStyle"] = "Straight",
				},
				["Static"] = {
					["disabled"] = true,
				},
			},
			["enableBlizzardHealing"] = true,
			["events"] = {
				["NOTIFICATION_MONEY"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_ITEM_COOLDOWN"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_CURRENCY"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_PET_COOLDOWN"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_LOOT"] = {
					["disabled"] = true,
				},
			},
			["qualityExclusions"] = {
				true, -- [1]
				true, -- [2]
				true, -- [3]
			},
		},
	},
}
MSBT_SavedMedia = {
	["fonts"] = {
	},
	["sounds"] = {
	},
}
