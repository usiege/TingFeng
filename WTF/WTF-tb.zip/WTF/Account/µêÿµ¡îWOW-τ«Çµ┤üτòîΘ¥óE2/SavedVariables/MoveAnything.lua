
MADB = {
	["noMMMW"] = false,
	["autoShowNext"] = true,
	["characters"] = {
	},
	["alwaysShowNudger"] = false,
	["tooltips"] = true,
	["profiles"] = {
		["default"] = {
			["name"] = "default",
			["frames"] = {
			},
		},
	},
	["closeGUIOnEscape"] = false,
	["playSound"] = false,
	["noBags"] = false,
	["frameListRows"] = 18,
}
