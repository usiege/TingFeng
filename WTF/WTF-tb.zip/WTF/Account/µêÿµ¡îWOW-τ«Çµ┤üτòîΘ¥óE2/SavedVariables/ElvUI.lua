
ElvDB = {
	["gold"] = {
		["阿什坎迪"] = {
			["简洁界面"] = 4,
			["今晚就动手"] = 44,
		},
	},
	["faction"] = {
		["阿什坎迪"] = {
			["简洁界面"] = "Alliance",
			["今晚就动手"] = "Alliance",
		},
	},
	["global"] = {
		["nameplate"] = {
			["filters"] = {
				["ElvUI_Boss"] = {
				},
				["ElvUI_NonTarget"] = {
				},
				["ElvUI_TankNonTarget"] = {
				},
				["ElvUI_Target"] = {
				},
				["ElvUI_TankTarget"] = {
				},
			},
		},
		["general"] = {
			["AceGUI"] = {
				["height"] = 767.76,
				["width"] = 1017.21,
			},
			["smallerWorldMapScale"] = 0.8500000000000001,
			["UIScale"] = 0.8,
		},
	},
	["LuaErrorDisabledAddOns"] = {
	},
	["profileKeys"] = {
		["猎猎思密达 - 阿什坎迪"] = "Default",
		["简洁界面 - 阿什坎迪"] = "Default",
		["今晚就动手 - 阿什坎迪"] = "Default",
		["简洁界面二 - 阿什坎迪"] = "Default",
	},
	["class"] = {
		["阿什坎迪"] = {
			["简洁界面"] = "WARRIOR",
			["今晚就动手"] = "ROGUE",
		},
	},
	["DisabledAddOns"] = {
	},
	["profiles"] = {
		["简洁2"] = {
			["databars"] = {
				["reputation"] = {
					["enable"] = true,
					["height"] = 6,
					["width"] = 393,
				},
				["threat"] = {
					["enable"] = false,
					["height"] = 24,
					["width"] = 472,
				},
				["experience"] = {
					["height"] = 8,
					["textFormat"] = "PERCENT",
					["width"] = 393,
				},
				["petExperience"] = {
					["width"] = 65,
				},
			},
			["currentTutorial"] = 3,
			["general"] = {
				["loginmessage"] = false,
				["fontSize"] = 14,
				["itemLevel"] = {
					["displayCharacterInfo"] = false,
					["itemLevelFontSize"] = 10,
				},
				["autoTrackReputation"] = true,
				["afk"] = false,
				["numberPrefixStyle"] = "CHINESE",
				["minimap"] = {
					["locationText"] = "SHOW",
					["icons"] = {
						["tracking"] = {
							["xOffset"] = -12,
							["scale"] = 0.6,
							["position"] = "TOPLEFT",
						},
					},
					["size"] = 140,
				},
				["bonusObjectivePosition"] = "AUTO",
				["valuecolor"] = {
					["b"] = 0.407842248678207,
					["g"] = 0.956860661506653,
					["r"] = 0.999997794628143,
				},
				["altPowerBar"] = {
					["statusBar"] = "Melli",
				},
				["backdropfadecolor"] = {
					["a"] = 0.85700567066669,
					["b"] = 0.058823529411765,
					["g"] = 0.058823529411765,
					["r"] = 0.058823529411765,
				},
				["objectiveFrameHeight"] = 550,
				["bottomPanel"] = false,
				["interruptAnnounce"] = "RAID",
				["totems"] = {
					["spacing"] = 8,
					["growthDirection"] = "HORIZONTAL",
					["size"] = 30,
				},
			},
			["movers"] = {
				["ElvUF_FocusCastbarMover"] = "TOPLEFT,ElvUF_Focus,BOTTOMLEFT,0,-1",
				["ElvUF_FocusTargetMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,361,-92",
				["BuffsMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-161,-5",
				["BossButton"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-441,346",
				["LootFrameMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,423,-416",
				["ZoneAbility"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,422,323",
				["DurabilityFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-76,-324",
				["ElvUF_PetCastbarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,423,121",
				["VehicleSeatMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-66,-261",
				["ElvUF_TargetTargetMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-416,256",
				["EuiExecuteMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,634,-367",
				["LossControlMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-407,101",
				["WTCombatAlertFrameMover"] = "TOP,ElvUIParent,TOP,0,-276",
				["MirrorTimer1Mover"] = "TOP,ElvUIParent,TOP,0,-140",
				["ElvAB_4"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-525,10",
				["AltPowerBarMover"] = "TOP,ElvUIParent,TOP,0,-196",
				["ReputationBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,0",
				["ObjectiveFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-83,-236",
				["MirrorTimer2Mover"] = "TOP,MirrorTimer1,BOTTOM,0,0",
				["ShiftAB"] = "BOTTOM,ElvUIParent,BOTTOM,-175,104",
				["ElvUF_TargetCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,253,245",
				["ElvUF_PlayerMover"] = "BOTTOM,ElvUIParent,BOTTOM,-253,256",
				["RightChatMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-4,4",
				["RaidCDAnchorMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,366,-300",
				["AutoButtonAnchor3Mover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-208,214",
				["ElvUF_AssistMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,123,-43",
				["WTRaidMarkersBarAnchor"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,310",
				["TopCenterContainerMover"] = "TOP,ElvUIParent,TOP,0,-51",
				["ThreatBarMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-4,4",
				["PetAB"] = "BOTTOM,ElvUIParent,BOTTOM,46,103",
				["ElvUF_RaidMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,0,-116",
				["LeftChatMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,27",
				["GMMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,315",
				["BagsMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-4,33",
				["WTChatBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,288",
				["WTMinimapButtonBarAnchor"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-4,-4",
				["ElvUF_FocusMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,222,-81",
				["AutoButtonAnchorMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-66,214",
				["ClassBarMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,475,-31",
				["MicrobarMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-20,4",
				["PetExperienceBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,423,176",
				["PowerBarContainerMover"] = "TOP,ElvUIParent,TOP,0,-55",
				["WTCustomEmoteFrameMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,324,56",
				["ExperienceBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,6",
				["ArenaHeaderMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-156,-264",
				["ElvUF_TargetMover"] = "BOTTOM,ElvUIParent,BOTTOM,253,256",
				["BNETMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,315",
				["TotemBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,371,255",
				["ElvUF_Raid40Mover"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-235",
				["WTParagonReputationToastFrameMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-49",
				["QuestTimerFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,0,-171",
				["ElvAB_1"] = "BOTTOM,ElvUIParent,BOTTOM,0,13",
				["ElvAB_2"] = "BOTTOM,ElvUIParent,BOTTOM,164,436",
				["BelowMinimapContainerMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-4,-166",
				["TalkingHeadFrameMover"] = "BOTTOM,ElvUIParent,BOTTOM,-2,144",
				["WTGameBarAnchor"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-4",
				["EUIMinimapButtonMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-138,-75",
				["ElvUIBankMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,191,289",
				["ElvAB_3"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,525,10",
				["ElvAB_5"] = "BOTTOM,ElvUIParent,BOTTOM,0,43",
				["VehicleLeaveButton"] = "BOTTOM,ElvUIParent,BOTTOM,206,131",
				["ElvUIBagMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-420,-249",
				["LevelUpBossBannerMover"] = "TOP,ElvUIParent,TOP,0,-107",
				["ExAE_FrameMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,360,276",
				["ElvUF_PlayerCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,131",
				["VOICECHAT"] = "TOP,ElvUIParent,TOP,-251,-3",
				["MirrorTimer3Mover"] = "TOP,MirrorTimer2,BOTTOM,0,0",
				["HonorBarMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-2,-251",
				["ElvAB_6"] = "BOTTOM,ElvUIParent,BOTTOM,0,73",
				["TooltipMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-78,323",
				["ElvUF_TankMover"] = "TOPLEFT,UIParent,TOPLEFT,4,-71",
				["BossHeaderMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-158,-262",
				["ElvUF_PetMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,423,139",
				["WTSwitchButtonBarMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-60,-196",
				["ElvUF_PartyMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,121,-291",
				["AlertFrameMover"] = "BOTTOM,ElvUIParent,BOTTOM,-3,417",
				["DebuffsMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-160,-133",
				["MinimapMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-4,-4",
			},
			["convertPages"] = true,
			["bags"] = {
				["bagWidth"] = 550,
				["split"] = {
					["bagSpacing"] = 7,
					["bag4"] = true,
					["bag1"] = true,
					["bag2"] = true,
					["bag3"] = true,
				},
				["vendorGrays"] = {
					["enable"] = true,
				},
				["bagSize"] = 40,
				["bankWidth"] = 550,
				["bankSize"] = 40,
				["itemLevelCustomColorEnable"] = true,
				["scrapIcon"] = true,
				["bagBar"] = {
					["growthDirection"] = "HORIZONTAL",
					["size"] = 25,
				},
			},
			["tooltip"] = {
				["itemCount"] = "NONE",
				["healthBar"] = {
					["height"] = 12,
					["font"] = "PT Sans Narrow",
					["fontSize"] = 12,
					["fontOutline"] = "NONE",
				},
				["showMount"] = false,
				["cursorAnchorType"] = "ANCHOR_CURSOR_RIGHT",
				["alwaysShowRealm"] = true,
				["modifierID"] = "SHIFT",
				["guildRanks"] = false,
			},
			["chat"] = {
				["customTimeColor"] = {
					["r"] = 0.70196078431373,
					["g"] = 0.70196078431373,
					["b"] = 0.70196078431373,
				},
				["emotionIcons"] = false,
				["panelColor"] = {
					["a"] = 0.215930461883545,
					["b"] = 0.0588235294117647,
					["g"] = 0.0588235294117647,
					["r"] = 0.0588235294117647,
				},
				["panelWidth"] = 350,
				["editBoxPosition"] = "ABOVE_CHAT",
				["copyChatLines"] = true,
				["tabSelectorColor"] = {
					["b"] = 0.407842248678207,
					["g"] = 0.956860661506653,
					["r"] = 0.999997794628143,
				},
				["panelWidthRight"] = 300,
				["panelHeight"] = 260,
				["tabSelector"] = "NONE",
				["scrollDownInterval"] = 30,
				["maxLines"] = 353,
				["panelBackdrop"] = "LEFT",
			},
			["dbConverted"] = 2.3,
			["unitframe"] = {
				["font"] = "聊天",
				["statusbar"] = "ElvUI Blank",
				["colors"] = {
					["auraBarBuff"] = {
						["b"] = 0.0392156019806862,
						["g"] = 0.486273437738419,
						["r"] = 0.999997794628143,
					},
					["castClassColor"] = true,
					["healthclass"] = true,
				},
				["smartRaidFilter"] = false,
				["smoothbars"] = true,
				["fontOutline"] = "THICKOUTLINE",
				["cooldown"] = {
					["fonts"] = {
						["enable"] = true,
						["fontSize"] = 15,
					},
				},
				["units"] = {
					["tank"] = {
						["width"] = 85,
						["verticalSpacing"] = 2,
					},
					["focustarget"] = {
						["power"] = {
							["enable"] = false,
						},
						["width"] = 80,
						["castbar"] = {
							["width"] = 80,
						},
					},
					["pet"] = {
						["infoPanel"] = {
							["height"] = 14,
						},
						["debuffs"] = {
							["enable"] = true,
						},
						["disableTargetGlow"] = false,
						["castbar"] = {
							["iconSize"] = 32,
							["width"] = 65,
						},
						["customTexts"] = {
							["名字"] = {
								["attachTextTo"] = "Health",
								["xOffset"] = 0,
								["text_format"] = "[namecolor][name:medium]",
								["yOffset"] = 0,
								["font"] = "聊天",
								["justifyH"] = "CENTER",
								["fontOutline"] = "OUTLINE",
								["enable"] = true,
								["size"] = 10,
							},
						},
						["power"] = {
							["height"] = 4,
						},
						["name"] = {
							["text_format"] = "[happiness:full]",
							["yOffset"] = 10,
						},
						["width"] = 65,
					},
					["party"] = {
						["debuffs"] = {
							["countFontSize"] = 8,
							["sizeOverride"] = 22,
							["priority"] = "",
							["numrows"] = 2,
							["yOffset"] = 11,
						},
						["power"] = {
							["text_format"] = "",
							["height"] = 4,
						},
						["healPrediction"] = {
							["enable"] = true,
						},
						["width"] = 120,
						["rdebuffs"] = {
							["font"] = "PT Sans Narrow",
							["yOffset"] = 12,
							["size"] = 20,
						},
						["name"] = {
							["text_format"] = "[namecolor][name:medium] [difficultycolor][level]",
						},
						["verticalSpacing"] = 6,
						["height"] = 44,
						["buffs"] = {
							["countFontSize"] = 8,
							["sizeOverride"] = 22,
							["yOffset"] = 11,
							["enable"] = true,
							["priority"] = "",
							["numrows"] = 2,
							["perrow"] = 5,
						},
						["visibility"] = "[@raid2,exists][@party1,noexists] hide;show",
						["health"] = {
							["text_format"] = "",
						},
					},
					["arena"] = {
						["enable"] = false,
					},
					["player"] = {
						["RestIcon"] = {
							["size"] = 20,
						},
						["debuffs"] = {
							["countFontSize"] = 10,
							["sizeOverride"] = 25,
							["yOffset"] = -30,
							["anchorPoint"] = "BOTTOMLEFT",
							["numrows"] = 2,
							["perrow"] = 6,
						},
						["portrait"] = {
							["overlay"] = true,
							["enable"] = true,
							["camDistanceScale"] = 4,
							["overlayAlpha"] = 0.8,
						},
						["power"] = {
							["attachTextTo"] = "Power",
							["text_format"] = "[powercolor][curpp]",
						},
						["disableMouseoverGlow"] = true,
						["width"] = 160,
						["name"] = {
							["position"] = "TOPLEFT",
							["text_format"] = "[name]   [level]",
							["yOffset"] = 16,
						},
						["CombatIcon"] = {
							["xOffset"] = -81,
							["yOffset"] = 28,
						},
						["health"] = {
							["xOffset"] = 0,
							["text_format"] = "[health:current:shortvalue]                   [perhp]%",
							["position"] = "RIGHT",
						},
						["castbar"] = {
							["height"] = 20,
							["insideInfoPanel"] = false,
							["width"] = 214,
						},
						["height"] = 45,
						["buffs"] = {
							["countFontSize"] = 10,
							["yOffset"] = 15,
							["durationPosition"] = "BOTTOM",
							["numrows"] = 2,
							["attachTo"] = "FRAME",
							["perrow"] = 6,
						},
						["classbar"] = {
							["detachedWidth"] = 360,
							["autoHide"] = true,
						},
						["aurabar"] = {
							["height"] = 10,
							["enable"] = false,
						},
					},
					["raid40"] = {
						["health"] = {
							["text_format"] = "[health:deficit]",
						},
						["power"] = {
							["enable"] = true,
						},
						["height"] = 40,
						["healPrediction"] = {
							["enable"] = true,
						},
						["enable"] = false,
					},
					["focus"] = {
						["enable"] = false,
						["width"] = 120,
						["health"] = {
							["xOffset"] = -37,
							["text_format"] = " [perhp]%",
							["yOffset"] = -18,
						},
						["castbar"] = {
							["width"] = 120,
						},
					},
					["target"] = {
						["debuffs"] = {
							["countFontSize"] = 5,
							["yOffset"] = 16,
							["numrows"] = 2,
							["priority"] = "Blacklist,Personal,nonPersonal",
							["attachTo"] = "FRAME",
							["perrow"] = 7,
						},
						["portrait"] = {
							["overlay"] = true,
							["enable"] = true,
							["camDistanceScale"] = 4,
							["overlayAlpha"] = 0.8,
						},
						["power"] = {
							["attachTextTo"] = "Power",
							["xOffset"] = -2,
							["text_format"] = "[powercolor][  >power:current]",
							["position"] = "RIGHT",
						},
						["customTexts"] = {
							["精英"] = {
								["attachTextTo"] = "Health",
								["xOffset"] = -80,
								["text_format"] = "[classification:icon][range]",
								["yOffset"] = 25,
								["font"] = "聊天",
								["justifyH"] = "CENTER",
								["fontOutline"] = "OUTLINE",
								["enable"] = true,
								["size"] = 10,
							},
						},
						["castbar"] = {
							["height"] = 10,
							["insideInfoPanel"] = false,
							["width"] = 160,
						},
						["disableMouseoverGlow"] = true,
						["width"] = 160,
						["name"] = {
							["position"] = "TOPRIGHT",
							["text_format"] = "[level]   [name]",
							["yOffset"] = 16,
						},
						["fader"] = {
							["range"] = false,
						},
						["health"] = {
							["attachTextTo"] = "InfoPanel",
							["xOffset"] = 0,
							["text_format"] = "[health:current:shortvalue]  -  [perhp]%",
							["yOffset"] = 3,
						},
						["orientation"] = "LEFT",
						["height"] = 45,
						["buffs"] = {
							["countFontSize"] = 5,
							["yOffset"] = -73,
							["anchorPoint"] = "BOTTOMLEFT",
							["growthX"] = "RIGHT",
							["numrows"] = 2,
							["priority"] = "Blacklist,Dispellable,Personal,nonPersonal,PlayerBuffs,Whitelist",
							["attachTo"] = "DEBUFFS",
							["perrow"] = 7,
						},
						["CombatIcon"] = {
							["xOffset"] = 81,
							["yOffset"] = 27,
						},
						["aurabar"] = {
							["height"] = 18,
							["enable"] = false,
						},
					},
					["raid"] = {
						["debuffs"] = {
							["enable"] = true,
							["anchorPoint"] = "CENTER",
						},
						["height"] = 45,
						["healPrediction"] = {
							["enable"] = true,
						},
						["buffs"] = {
							["enable"] = true,
							["anchorPoint"] = "CENTER",
						},
						["enable"] = false,
					},
					["assist"] = {
						["enable"] = false,
					},
					["targettarget"] = {
						["width"] = 100,
						["debuffs"] = {
							["enable"] = false,
							["anchorPoint"] = "TOPRIGHT",
						},
						["threatStyle"] = "GLOW",
						["power"] = {
							["enable"] = false,
						},
						["height"] = 35,
						["name"] = {
							["text_format"] = "[name:medium]",
						},
						["disableMouseoverGlow"] = true,
						["raidicon"] = {
							["attachTo"] = "LEFT",
							["xOffset"] = 2,
							["enable"] = false,
							["yOffset"] = 0,
						},
					},
				},
			},
			["datatexts"] = {
				["fontSize"] = 10,
				["panels"] = {
					["MinimapPanel"] = {
						["backdrop"] = false,
						["border"] = false,
					},
					["RightChatDataPanel"] = {
						"Gold", -- [1]
						"MeetingStone", -- [2]
						"System", -- [3]
						["enable"] = false,
						["backdrop"] = false,
					},
					["LeftChatDataPanel"] = {
						"WeakAuras", -- [1]
						"ElvUI", -- [2]
						"Durability", -- [3]
						["enable"] = false,
						["backdrop"] = false,
						["panelTransparency"] = true,
					},
				},
				["fontOutline"] = "OUTLINE",
			},
			["actionbar"] = {
				["bar3"] = {
					["point"] = "TOPLEFT",
					["buttons"] = 12,
					["macrotext"] = true,
					["buttonsPerRow"] = 4,
					["visibility"] = "[petbattle] hide; show",
					["buttonSize"] = 31,
				},
				["bar6"] = {
					["enabled"] = true,
					["macrotext"] = true,
					["point"] = "TOPLEFT",
					["buttonSize"] = 31,
				},
				["bar2"] = {
					["macrotext"] = true,
					["visibility"] = "[petbattle] hide; show",
					["buttonSize"] = 31,
				},
				["bar10"] = {
					["macrotext"] = true,
				},
				["bar8"] = {
					["macrotext"] = true,
				},
				["bar5"] = {
					["buttonSize"] = 31,
					["macrotext"] = true,
					["buttonsPerRow"] = 12,
					["visibility"] = "[petbattle] hide; show",
					["buttons"] = 12,
				},
				["microbar"] = {
					["buttonSize"] = 23,
					["buttons"] = 7,
				},
				["cooldown"] = {
					["fonts"] = {
						["enable"] = true,
					},
					["override"] = false,
				},
				["font"] = "傷害數字",
				["bar7"] = {
					["macrotext"] = true,
				},
				["bar1"] = {
					["macrotext"] = true,
					["buttonSize"] = 31,
				},
				["bar9"] = {
					["macrotext"] = true,
				},
				["stanceBar"] = {
					["buttonSpacing"] = 1,
					["style"] = "classic",
					["buttonSize"] = 25,
				},
				["barPet"] = {
					["backdrop"] = false,
					["buttonsPerRow"] = 10,
					["point"] = "TOPLEFT",
					["buttonSize"] = 28,
				},
				["bar4"] = {
					["point"] = "TOPLEFT",
					["buttonSize"] = 31,
					["macrotext"] = true,
					["buttonsPerRow"] = 4,
					["visibility"] = "[petbattle] hide; show",
					["backdrop"] = false,
				},
			},
			["nameplates"] = {
				["clampToScreen"] = true,
				["statusbar"] = "Melli",
				["units"] = {
					["ENEMY_NPC"] = {
						["debuffs"] = {
							["yOffset"] = 15,
							["size"] = 20,
						},
						["health"] = {
							["text"] = {
								["format"] = "[perhp]%",
							},
						},
						["buffs"] = {
							["enable"] = false,
							["size"] = 20,
						},
					},
					["TARGET"] = {
						["classpower"] = {
							["enable"] = true,
							["yOffset"] = -11,
							["width"] = 60,
						},
					},
					["FRIENDLY_NPC"] = {
						["debuffs"] = {
							["enable"] = false,
							["size"] = 20,
						},
						["health"] = {
							["text"] = {
								["format"] = "[perhp]%",
							},
						},
						["buffs"] = {
							["enable"] = false,
							["size"] = 20,
						},
					},
					["ENEMY_PLAYER"] = {
						["debuffs"] = {
							["yOffset"] = 15,
							["size"] = 20,
						},
						["health"] = {
							["text"] = {
								["format"] = "[health:current:shortvalue]  -  [perhp]%",
							},
						},
						["buffs"] = {
							["size"] = 20,
						},
					},
					["FRIENDLY_PLAYER"] = {
						["buffs"] = {
							["enable"] = false,
							["size"] = 20,
						},
						["debuffs"] = {
							["yOffset"] = 15,
							["size"] = 20,
						},
						["health"] = {
							["text"] = {
								["format"] = "[perhp]%",
							},
						},
						["nameOnly"] = true,
					},
				},
			},
			["v11NamePlateReset"] = true,
			["cooldown"] = {
				["fonts"] = {
					["enable"] = true,
				},
				["hideBlizzard"] = true,
			},
			["auras"] = {
				["buffs"] = {
					["timeFontSize"] = 11,
					["countFont"] = "傷害數字",
					["size"] = 26,
					["timeFont"] = "EUI",
					["timeFontOutline"] = "OUTLINE",
					["countFontOutline"] = "OUTLINE",
				},
				["debuffs"] = {
					["timeFontOutline"] = "OUTLINE",
					["countFont"] = "傷害數字",
					["timeFont"] = "傷害數字",
					["size"] = 26,
					["countFontOutline"] = "OUTLINE",
				},
			},
		},
		["简洁2-纯血条头像"] = {
			["databars"] = {
				["reputation"] = {
					["enable"] = true,
					["height"] = 6,
					["width"] = 393,
				},
				["threat"] = {
					["enable"] = false,
					["height"] = 24,
					["width"] = 472,
				},
				["experience"] = {
					["height"] = 8,
					["textFormat"] = "PERCENT",
					["width"] = 393,
				},
				["petExperience"] = {
					["width"] = 65,
				},
			},
			["currentTutorial"] = 3,
			["general"] = {
				["loginmessage"] = false,
				["fontSize"] = 14,
				["itemLevel"] = {
					["itemLevelFontSize"] = 10,
					["displayCharacterInfo"] = false,
				},
				["autoTrackReputation"] = true,
				["afk"] = false,
				["numberPrefixStyle"] = "CHINESE",
				["minimap"] = {
					["locationText"] = "SHOW",
					["icons"] = {
						["tracking"] = {
							["xOffset"] = -12,
							["scale"] = 0.6,
							["position"] = "TOPLEFT",
						},
					},
					["size"] = 140,
				},
				["bonusObjectivePosition"] = "AUTO",
				["valuecolor"] = {
					["b"] = 0.407842248678207,
					["g"] = 0.956860661506653,
					["r"] = 0.999997794628143,
				},
				["altPowerBar"] = {
					["statusBar"] = "Melli",
				},
				["backdropfadecolor"] = {
					["a"] = 0.85700567066669,
					["b"] = 0.058823529411765,
					["g"] = 0.058823529411765,
					["r"] = 0.058823529411765,
				},
				["objectiveFrameHeight"] = 550,
				["bottomPanel"] = false,
				["interruptAnnounce"] = "RAID",
				["totems"] = {
					["spacing"] = 8,
					["size"] = 30,
					["growthDirection"] = "HORIZONTAL",
				},
			},
			["movers"] = {
				["ElvUF_FocusCastbarMover"] = "TOPLEFT,ElvUF_Focus,BOTTOMLEFT,0,-1",
				["ElvUF_FocusTargetMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,361,-92",
				["BuffsMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-161,-5",
				["BossButton"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-441,346",
				["LootFrameMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,423,-416",
				["ZoneAbility"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,422,323",
				["PowerBarContainerMover"] = "TOP,ElvUIParent,TOP,0,-55",
				["ElvUF_PetCastbarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,423,121",
				["VehicleSeatMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-66,-261",
				["ElvUF_TargetTargetMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-405,256",
				["EuiExecuteMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,634,-367",
				["LossControlMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-407,101",
				["WTCombatAlertFrameMover"] = "TOP,ElvUIParent,TOP,0,-276",
				["MirrorTimer1Mover"] = "TOP,ElvUIParent,TOP,0,-140",
				["ElvAB_4"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-525,10",
				["AltPowerBarMover"] = "TOP,ElvUIParent,TOP,0,-196",
				["ReputationBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,0",
				["ObjectiveFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-83,-236",
				["MirrorTimer2Mover"] = "TOP,MirrorTimer1,BOTTOM,0,0",
				["ShiftAB"] = "BOTTOM,ElvUIParent,BOTTOM,-175,104",
				["ElvUF_TargetCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,253,245",
				["ElvUF_PlayerMover"] = "BOTTOM,ElvUIParent,BOTTOM,-253,256",
				["RightChatMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-4,4",
				["RaidCDAnchorMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,366,-300",
				["AutoButtonAnchor3Mover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-208,214",
				["ElvUF_AssistMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,123,-43",
				["WTRaidMarkersBarAnchor"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,310",
				["TopCenterContainerMover"] = "TOP,ElvUIParent,TOP,0,-51",
				["ThreatBarMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-4,4",
				["PetAB"] = "BOTTOM,ElvUIParent,BOTTOM,46,103",
				["ElvUF_RaidMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,0,-116",
				["LeftChatMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,27",
				["GMMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,315",
				["BagsMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-4,33",
				["WTChatBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,288",
				["WTMinimapButtonBarAnchor"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-4,-4",
				["ElvUF_FocusMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,222,-81",
				["AutoButtonAnchorMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-66,214",
				["EUIMinimapButtonMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-138,-75",
				["MicrobarMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-20,4",
				["PetExperienceBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,423,176",
				["WTCustomEmoteFrameMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,324,56",
				["ArenaHeaderMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-156,-264",
				["ExperienceBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,6",
				["BNETMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,315",
				["ElvUF_TargetMover"] = "BOTTOM,ElvUIParent,BOTTOM,253,256",
				["QuestTimerFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,0,-171",
				["ElvUF_PetMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,423,139",
				["ElvUF_Raid40Mover"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-235",
				["TalkingHeadFrameMover"] = "BOTTOM,ElvUIParent,BOTTOM,-2,144",
				["DurabilityFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-76,-324",
				["ElvAB_1"] = "BOTTOM,ElvUIParent,BOTTOM,0,13",
				["ElvAB_2"] = "BOTTOM,ElvUIParent,BOTTOM,164,436",
				["BelowMinimapContainerMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-4,-166",
				["ClassBarMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,475,-31",
				["WTGameBarAnchor"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-4",
				["ElvUIBankMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,191,289",
				["WTSwitchButtonBarMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-60,-196",
				["ElvAB_3"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,525,10",
				["ElvAB_5"] = "BOTTOM,ElvUIParent,BOTTOM,0,43",
				["VehicleLeaveButton"] = "BOTTOM,ElvUIParent,BOTTOM,206,131",
				["ElvUIBagMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-420,-249",
				["MirrorTimer3Mover"] = "TOP,MirrorTimer2,BOTTOM,0,0",
				["ExAE_FrameMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,360,276",
				["ElvUF_PlayerCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,131",
				["VOICECHAT"] = "TOP,ElvUIParent,TOP,-251,-3",
				["LevelUpBossBannerMover"] = "TOP,ElvUIParent,TOP,0,-107",
				["HonorBarMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-2,-251",
				["ElvAB_6"] = "BOTTOM,ElvUIParent,BOTTOM,0,73",
				["TooltipMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-78,323",
				["ElvUF_TankMover"] = "TOPLEFT,UIParent,TOPLEFT,4,-74",
				["BossHeaderMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-158,-262",
				["TotemBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,371,255",
				["WTParagonReputationToastFrameMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-49",
				["ElvUF_PartyMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,121,-291",
				["AlertFrameMover"] = "BOTTOM,ElvUIParent,BOTTOM,-3,417",
				["DebuffsMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-160,-133",
				["MinimapMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-4,-4",
			},
			["convertPages"] = true,
			["v11NamePlateReset"] = true,
			["tooltip"] = {
				["itemCount"] = "NONE",
				["healthBar"] = {
					["height"] = 12,
					["fontSize"] = 12,
					["font"] = "PT Sans Narrow",
					["fontOutline"] = "NONE",
				},
				["showMount"] = false,
				["cursorAnchorType"] = "ANCHOR_CURSOR_RIGHT",
				["alwaysShowRealm"] = true,
				["modifierID"] = "SHIFT",
				["guildRanks"] = false,
			},
			["auras"] = {
				["buffs"] = {
					["timeFontOutline"] = "OUTLINE",
					["countFont"] = "傷害數字",
					["size"] = 26,
					["timeFont"] = "EUI",
					["timeFontSize"] = 11,
					["countFontOutline"] = "OUTLINE",
				},
				["debuffs"] = {
					["timeFontOutline"] = "OUTLINE",
					["countFont"] = "傷害數字",
					["timeFont"] = "傷害數字",
					["size"] = 26,
					["countFontOutline"] = "OUTLINE",
				},
			},
			["dbConverted"] = 2.3,
			["unitframe"] = {
				["statusbar"] = "ElvUI Blank",
				["font"] = "聊天",
				["colors"] = {
					["auraBarBuff"] = {
						["b"] = 0.0392156019806862,
						["g"] = 0.486273437738419,
						["r"] = 0.999997794628143,
					},
					["castClassColor"] = true,
					["healthclass"] = true,
				},
				["smartRaidFilter"] = false,
				["smoothbars"] = true,
				["fontOutline"] = "THICKOUTLINE",
				["cooldown"] = {
					["fonts"] = {
						["enable"] = true,
						["fontSize"] = 15,
					},
				},
				["units"] = {
					["tank"] = {
						["width"] = 85,
						["verticalSpacing"] = 2,
					},
					["focustarget"] = {
						["castbar"] = {
							["width"] = 80,
						},
						["width"] = 80,
						["power"] = {
							["enable"] = false,
						},
					},
					["pet"] = {
						["infoPanel"] = {
							["height"] = 14,
						},
						["debuffs"] = {
							["enable"] = true,
						},
						["disableTargetGlow"] = false,
						["power"] = {
							["height"] = 4,
						},
						["customTexts"] = {
							["名字"] = {
								["attachTextTo"] = "Health",
								["enable"] = true,
								["text_format"] = "[namecolor][name:medium]",
								["yOffset"] = 0,
								["font"] = "聊天",
								["justifyH"] = "CENTER",
								["fontOutline"] = "OUTLINE",
								["xOffset"] = 0,
								["size"] = 10,
							},
						},
						["castbar"] = {
							["iconSize"] = 32,
							["width"] = 65,
						},
						["name"] = {
							["text_format"] = "[happiness:full]",
							["yOffset"] = 10,
						},
						["width"] = 65,
					},
					["targettarget"] = {
						["width"] = 100,
						["debuffs"] = {
							["enable"] = false,
							["anchorPoint"] = "TOPRIGHT",
						},
						["threatStyle"] = "GLOW",
						["power"] = {
							["enable"] = false,
						},
						["height"] = 35,
						["name"] = {
							["text_format"] = "[name:medium]",
						},
						["disableMouseoverGlow"] = true,
						["raidicon"] = {
							["attachTo"] = "LEFT",
							["xOffset"] = 2,
							["enable"] = false,
							["yOffset"] = 0,
						},
					},
					["raid"] = {
						["debuffs"] = {
							["enable"] = true,
							["anchorPoint"] = "CENTER",
						},
						["height"] = 45,
						["healPrediction"] = {
							["enable"] = true,
						},
						["buffs"] = {
							["enable"] = true,
							["anchorPoint"] = "CENTER",
						},
						["enable"] = false,
					},
					["party"] = {
						["debuffs"] = {
							["countFontSize"] = 8,
							["sizeOverride"] = 22,
							["priority"] = "",
							["numrows"] = 2,
							["yOffset"] = 11,
						},
						["power"] = {
							["text_format"] = "",
							["height"] = 4,
						},
						["healPrediction"] = {
							["enable"] = true,
						},
						["width"] = 120,
						["rdebuffs"] = {
							["font"] = "PT Sans Narrow",
							["yOffset"] = 12,
							["size"] = 20,
						},
						["name"] = {
							["text_format"] = "[namecolor][name:medium] [difficultycolor][level]",
						},
						["buffs"] = {
							["countFontSize"] = 8,
							["sizeOverride"] = 22,
							["yOffset"] = 11,
							["enable"] = true,
							["priority"] = "",
							["numrows"] = 2,
							["perrow"] = 5,
						},
						["height"] = 44,
						["verticalSpacing"] = 6,
						["visibility"] = "[@raid2,exists][@party1,noexists] hide;show",
						["health"] = {
							["text_format"] = "",
						},
					},
					["raid40"] = {
						["health"] = {
							["text_format"] = "[health:deficit]",
						},
						["power"] = {
							["enable"] = true,
						},
						["height"] = 40,
						["healPrediction"] = {
							["enable"] = true,
						},
						["enable"] = false,
					},
					["focus"] = {
						["enable"] = false,
						["width"] = 120,
						["health"] = {
							["xOffset"] = -37,
							["text_format"] = " [perhp]%",
							["yOffset"] = -18,
						},
						["castbar"] = {
							["width"] = 120,
						},
					},
					["assist"] = {
						["enable"] = false,
					},
					["arena"] = {
						["enable"] = false,
					},
					["target"] = {
						["debuffs"] = {
							["countFontSize"] = 5,
							["yOffset"] = 16,
							["numrows"] = 2,
							["priority"] = "Blacklist,Personal,nonPersonal",
							["attachTo"] = "FRAME",
							["perrow"] = 7,
						},
						["portrait"] = {
							["overlay"] = true,
							["overlayAlpha"] = 0.65,
							["fullOverlay"] = true,
						},
						["power"] = {
							["attachTextTo"] = "Power",
							["xOffset"] = -2,
							["text_format"] = "[powercolor][  >power:current]",
							["position"] = "RIGHT",
						},
						["customTexts"] = {
							["精英"] = {
								["attachTextTo"] = "Health",
								["enable"] = true,
								["text_format"] = "[classification:icon][range]",
								["yOffset"] = 25,
								["font"] = "聊天",
								["justifyH"] = "CENTER",
								["fontOutline"] = "OUTLINE",
								["xOffset"] = -80,
								["size"] = 10,
							},
						},
						["castbar"] = {
							["height"] = 10,
							["insideInfoPanel"] = false,
							["width"] = 180,
						},
						["disableMouseoverGlow"] = true,
						["width"] = 180,
						["fader"] = {
							["range"] = false,
						},
						["health"] = {
							["attachTextTo"] = "InfoPanel",
							["xOffset"] = 0,
							["text_format"] = "[health:current:shortvalue]  -  [perhp]%",
							["yOffset"] = 3,
						},
						["name"] = {
							["position"] = "TOPRIGHT",
							["text_format"] = "[level]   [name]",
							["yOffset"] = 16,
						},
						["height"] = 45,
						["orientation"] = "LEFT",
						["buffs"] = {
							["countFontSize"] = 5,
							["yOffset"] = -73,
							["anchorPoint"] = "BOTTOMLEFT",
							["growthX"] = "RIGHT",
							["numrows"] = 2,
							["priority"] = "Blacklist,Dispellable,Personal,nonPersonal,PlayerBuffs,Whitelist",
							["attachTo"] = "DEBUFFS",
							["perrow"] = 7,
						},
						["CombatIcon"] = {
							["xOffset"] = 81,
							["yOffset"] = 27,
						},
						["aurabar"] = {
							["height"] = 18,
							["enable"] = false,
						},
					},
					["player"] = {
						["RestIcon"] = {
							["size"] = 20,
						},
						["debuffs"] = {
							["countFontSize"] = 10,
							["sizeOverride"] = 25,
							["yOffset"] = -30,
							["anchorPoint"] = "BOTTOMLEFT",
							["numrows"] = 2,
							["perrow"] = 6,
						},
						["portrait"] = {
							["overlay"] = true,
							["overlayAlpha"] = 0.7,
							["fullOverlay"] = true,
						},
						["power"] = {
							["attachTextTo"] = "Power",
							["text_format"] = "[powercolor][curpp]",
						},
						["disableMouseoverGlow"] = true,
						["width"] = 180,
						["name"] = {
							["position"] = "TOPLEFT",
							["text_format"] = "[name]   [level]",
							["yOffset"] = 16,
						},
						["classbar"] = {
							["detachedWidth"] = 360,
							["autoHide"] = true,
						},
						["health"] = {
							["xOffset"] = 0,
							["text_format"] = "[health:current:shortvalue]                         [perhp]%",
							["position"] = "RIGHT",
						},
						["castbar"] = {
							["height"] = 20,
							["insideInfoPanel"] = false,
							["width"] = 214,
						},
						["height"] = 40,
						["buffs"] = {
							["countFontSize"] = 10,
							["yOffset"] = 15,
							["durationPosition"] = "BOTTOM",
							["numrows"] = 2,
							["attachTo"] = "FRAME",
							["perrow"] = 6,
						},
						["CombatIcon"] = {
							["xOffset"] = -81,
							["yOffset"] = 28,
						},
						["aurabar"] = {
							["height"] = 10,
							["enable"] = false,
						},
					},
				},
			},
			["datatexts"] = {
				["fontSize"] = 10,
				["panels"] = {
					["MinimapPanel"] = {
						["border"] = false,
						["backdrop"] = false,
					},
					["RightChatDataPanel"] = {
						"Gold", -- [1]
						"MeetingStone", -- [2]
						"System", -- [3]
						["enable"] = false,
						["backdrop"] = false,
					},
					["LeftChatDataPanel"] = {
						"WeakAuras", -- [1]
						"ElvUI", -- [2]
						"Durability", -- [3]
						["enable"] = false,
						["backdrop"] = false,
						["panelTransparency"] = true,
					},
				},
				["fontOutline"] = "OUTLINE",
			},
			["actionbar"] = {
				["bar3"] = {
					["point"] = "TOPLEFT",
					["buttonSize"] = 31,
					["macrotext"] = true,
					["buttonsPerRow"] = 4,
					["visibility"] = "[petbattle] hide; show",
					["buttons"] = 12,
				},
				["bar6"] = {
					["enabled"] = true,
					["macrotext"] = true,
					["point"] = "TOPLEFT",
					["buttonSize"] = 31,
				},
				["bar2"] = {
					["macrotext"] = true,
					["visibility"] = "[petbattle] hide; show",
					["buttonSize"] = 31,
				},
				["bar10"] = {
					["macrotext"] = true,
				},
				["bar8"] = {
					["macrotext"] = true,
				},
				["bar5"] = {
					["buttons"] = 12,
					["macrotext"] = true,
					["buttonsPerRow"] = 12,
					["visibility"] = "[petbattle] hide; show",
					["buttonSize"] = 31,
				},
				["microbar"] = {
					["buttonSize"] = 23,
					["buttons"] = 7,
				},
				["cooldown"] = {
					["fonts"] = {
						["enable"] = true,
					},
					["override"] = false,
				},
				["font"] = "傷害數字",
				["bar7"] = {
					["macrotext"] = true,
				},
				["bar1"] = {
					["macrotext"] = true,
					["buttonSize"] = 31,
				},
				["bar9"] = {
					["macrotext"] = true,
				},
				["stanceBar"] = {
					["buttonSpacing"] = 1,
					["style"] = "classic",
					["buttonSize"] = 25,
				},
				["barPet"] = {
					["backdrop"] = false,
					["buttonsPerRow"] = 10,
					["point"] = "TOPLEFT",
					["buttonSize"] = 28,
				},
				["bar4"] = {
					["point"] = "TOPLEFT",
					["buttonSize"] = 31,
					["macrotext"] = true,
					["buttonsPerRow"] = 4,
					["visibility"] = "[petbattle] hide; show",
					["backdrop"] = false,
				},
			},
			["nameplates"] = {
				["clampToScreen"] = true,
				["statusbar"] = "Melli",
				["units"] = {
					["ENEMY_NPC"] = {
						["debuffs"] = {
							["yOffset"] = 15,
							["size"] = 20,
						},
						["health"] = {
							["text"] = {
								["format"] = "[perhp]%",
							},
						},
						["buffs"] = {
							["enable"] = false,
							["size"] = 20,
						},
					},
					["TARGET"] = {
						["classpower"] = {
							["enable"] = true,
							["yOffset"] = -11,
							["width"] = 60,
						},
					},
					["FRIENDLY_NPC"] = {
						["debuffs"] = {
							["enable"] = false,
							["size"] = 20,
						},
						["health"] = {
							["text"] = {
								["format"] = "[perhp]%",
							},
						},
						["buffs"] = {
							["enable"] = false,
							["size"] = 20,
						},
					},
					["ENEMY_PLAYER"] = {
						["debuffs"] = {
							["yOffset"] = 15,
							["size"] = 20,
						},
						["health"] = {
							["text"] = {
								["format"] = "[health:current:shortvalue]  -  [perhp]%",
							},
						},
						["buffs"] = {
							["size"] = 20,
						},
					},
					["FRIENDLY_PLAYER"] = {
						["buffs"] = {
							["enable"] = false,
							["size"] = 20,
						},
						["debuffs"] = {
							["yOffset"] = 15,
							["size"] = 20,
						},
						["health"] = {
							["text"] = {
								["format"] = "[perhp]%",
							},
						},
						["nameOnly"] = true,
					},
				},
			},
			["bags"] = {
				["scrapIcon"] = true,
				["split"] = {
					["bagSpacing"] = 7,
					["bag4"] = true,
					["bag1"] = true,
					["bag2"] = true,
					["bag3"] = true,
				},
				["vendorGrays"] = {
					["enable"] = true,
				},
				["bagSize"] = 40,
				["bankWidth"] = 550,
				["bankSize"] = 40,
				["itemLevelCustomColorEnable"] = true,
				["bagWidth"] = 550,
				["bagBar"] = {
					["growthDirection"] = "HORIZONTAL",
					["size"] = 25,
				},
			},
			["cooldown"] = {
				["fonts"] = {
					["enable"] = true,
				},
				["hideBlizzard"] = true,
			},
			["chat"] = {
				["tabSelector"] = "NONE",
				["emotionIcons"] = false,
				["panelColor"] = {
					["a"] = 0.215930461883545,
					["b"] = 0.0588235294117647,
					["g"] = 0.0588235294117647,
					["r"] = 0.0588235294117647,
				},
				["panelWidth"] = 350,
				["editBoxPosition"] = "ABOVE_CHAT",
				["copyChatLines"] = true,
				["tabSelectorColor"] = {
					["b"] = 0.407842248678207,
					["g"] = 0.956860661506653,
					["r"] = 0.999997794628143,
				},
				["panelWidthRight"] = 300,
				["panelHeight"] = 260,
				["customTimeColor"] = {
					["b"] = 0.70196078431373,
					["g"] = 0.70196078431373,
					["r"] = 0.70196078431373,
				},
				["scrollDownInterval"] = 30,
				["maxLines"] = 353,
				["panelBackdrop"] = "LEFT",
			},
		},
		["Default"] = {
			["databars"] = {
				["threat"] = {
					["enable"] = false,
					["width"] = 472,
					["height"] = 24,
				},
				["reputation"] = {
					["enable"] = true,
					["width"] = 393,
					["height"] = 6,
				},
				["petExperience"] = {
					["width"] = 65,
				},
				["experience"] = {
					["width"] = 393,
					["textFormat"] = "PERCENT",
					["height"] = 8,
				},
			},
			["currentTutorial"] = 3,
			["general"] = {
				["totems"] = {
					["spacing"] = 8,
					["growthDirection"] = "HORIZONTAL",
					["size"] = 30,
				},
				["interruptAnnounce"] = "RAID",
				["backdropfadecolor"] = {
					["a"] = 0.85700567066669,
					["r"] = 0.058823529411765,
					["g"] = 0.058823529411765,
					["b"] = 0.058823529411765,
				},
				["valuecolor"] = {
					["r"] = 0.999997794628143,
					["g"] = 0.956860661506653,
					["b"] = 0.407842248678207,
				},
				["loginmessage"] = false,
				["altPowerBar"] = {
					["statusBar"] = "Melli",
				},
				["autoTrackReputation"] = true,
				["fontSize"] = 14,
				["minimap"] = {
					["locationText"] = "SHOW",
					["icons"] = {
						["tracking"] = {
							["scale"] = 0.6,
							["position"] = "TOPLEFT",
							["xOffset"] = -12,
						},
					},
					["size"] = 140,
				},
				["bottomPanel"] = false,
				["afk"] = false,
				["objectiveFrameHeight"] = 550,
				["numberPrefixStyle"] = "CHINESE",
				["itemLevel"] = {
					["displayCharacterInfo"] = false,
					["itemLevelFontSize"] = 10,
				},
				["bonusObjectivePosition"] = "AUTO",
			},
			["v11NamePlateReset"] = true,
			["chat"] = {
				["tabSelectorColor"] = {
					["r"] = 0.999997794628143,
					["g"] = 0.956860661506653,
					["b"] = 0.407842248678207,
				},
				["customTimeColor"] = {
					["r"] = 0.70196078431373,
					["g"] = 0.70196078431373,
					["b"] = 0.70196078431373,
				},
				["scrollDownInterval"] = 30,
				["panelWidth"] = 350,
				["emotionIcons"] = false,
				["panelHeight"] = 260,
				["panelWidthRight"] = 300,
				["panelBackdrop"] = "LEFT",
				["panelColor"] = {
					["a"] = 0.215930461883545,
					["r"] = 0.0588235294117647,
					["g"] = 0.0588235294117647,
					["b"] = 0.0588235294117647,
				},
				["editBoxPosition"] = "ABOVE_CHAT",
				["tabSelector"] = "NONE",
				["maxLines"] = 353,
				["copyChatLines"] = true,
			},
			["dbConverted"] = 2.31,
			["movers"] = {
				["ElvUF_FocusCastbarMover"] = "TOPLEFT,ElvUF_Focus,BOTTOMLEFT,0,-1",
				["ElvUF_FocusTargetMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,361,-92",
				["BuffsMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-161,-5",
				["BossButton"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-441,346",
				["LootFrameMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,423,-416",
				["ZoneAbility"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,422,323",
				["PowerBarContainerMover"] = "TOP,ElvUIParent,TOP,0,-55",
				["ElvUF_PetCastbarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,423,121",
				["VehicleSeatMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-66,-261",
				["ElvUF_TargetTargetMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-416,256",
				["EuiExecuteMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,634,-367",
				["LossControlMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-407,101",
				["WTCombatAlertFrameMover"] = "TOP,ElvUIParent,TOP,0,-276",
				["MirrorTimer1Mover"] = "TOP,ElvUIParent,TOP,0,-140",
				["ElvAB_4"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-525,10",
				["PetExperienceBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,423,176",
				["ReputationBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,0",
				["ObjectiveFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-83,-236",
				["MirrorTimer2Mover"] = "TOP,MirrorTimer1,BOTTOM,0,0",
				["ShiftAB"] = "BOTTOM,ElvUIParent,BOTTOM,-175,104",
				["ElvUF_TargetCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,253,245",
				["ElvUF_PlayerMover"] = "BOTTOM,ElvUIParent,BOTTOM,-253,256",
				["RightChatMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-4,4",
				["RaidCDAnchorMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,366,-300",
				["AutoButtonAnchor3Mover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-208,214",
				["ElvUF_AssistMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,123,-43",
				["WTRaidMarkersBarAnchor"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,310",
				["TopCenterContainerMover"] = "TOP,ElvUIParent,TOP,0,-51",
				["ThreatBarMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-4,4",
				["PetAB"] = "BOTTOM,ElvUIParent,BOTTOM,46,103",
				["ElvUF_RaidMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,0,-116",
				["LeftChatMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,27",
				["GMMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,315",
				["BagsMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-4,33",
				["WTChatBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,288",
				["WTMinimapButtonBarAnchor"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-4,-4",
				["ElvUF_FocusMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,222,-81",
				["AutoButtonAnchorMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-66,214",
				["ClassBarMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,475,-31",
				["MicrobarMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-20,4",
				["WTCustomEmoteFrameMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,324,56",
				["ArenaHeaderMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-156,-264",
				["AltPowerBarMover"] = "TOP,ElvUIParent,TOP,0,-196",
				["ExperienceBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,6",
				["WTParagonReputationToastFrameMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-49",
				["ElvUF_TargetMover"] = "BOTTOM,ElvUIParent,BOTTOM,253,256",
				["WTSwitchButtonBarMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-60,-196",
				["ElvUF_PetMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,423,139",
				["ElvUF_Raid40Mover"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-235",
				["DurabilityFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-76,-324",
				["EUIMinimapButtonMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-138,-75",
				["ElvAB_1"] = "BOTTOM,ElvUIParent,BOTTOM,0,13",
				["ElvAB_2"] = "BOTTOM,ElvUIParent,BOTTOM,164,436",
				["BelowMinimapContainerMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-4,-166",
				["ElvUIBankMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,191,289",
				["WTGameBarAnchor"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-4",
				["TalkingHeadFrameMover"] = "BOTTOM,ElvUIParent,BOTTOM,-2,144",
				["BNETMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,315",
				["ElvAB_3"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,525,10",
				["ElvAB_5"] = "BOTTOM,ElvUIParent,BOTTOM,0,43",
				["VehicleLeaveButton"] = "BOTTOM,ElvUIParent,BOTTOM,206,131",
				["MirrorTimer3Mover"] = "TOP,MirrorTimer2,BOTTOM,0,0",
				["LevelUpBossBannerMover"] = "TOP,ElvUIParent,TOP,0,-107",
				["ElvUF_PlayerCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,131",
				["ExAE_FrameMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,360,276",
				["VOICECHAT"] = "TOP,ElvUIParent,TOP,-251,-3",
				["ElvUIBagMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-420,-249",
				["HonorBarMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-2,-251",
				["ElvAB_6"] = "BOTTOM,ElvUIParent,BOTTOM,0,73",
				["TooltipMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-78,323",
				["ElvUF_TankMover"] = "TOPLEFT,UIParent,TOPLEFT,4,-71",
				["BossHeaderMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-158,-262",
				["TotemBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,371,255",
				["QuestTimerFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,0,-171",
				["ElvUF_PartyMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,121,-291",
				["AlertFrameMover"] = "BOTTOM,ElvUIParent,BOTTOM,-3,417",
				["DebuffsMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-160,-133",
				["MinimapMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-4,-4",
			},
			["convertPages"] = true,
			["tooltip"] = {
				["showMount"] = false,
				["cursorAnchorType"] = "ANCHOR_CURSOR_RIGHT",
				["healthBar"] = {
					["font"] = "PT Sans Narrow",
					["fontOutline"] = "NONE",
					["height"] = 12,
					["fontSize"] = 12,
				},
				["itemCount"] = "NONE",
				["modifierID"] = "SHIFT",
				["guildRanks"] = false,
				["alwaysShowRealm"] = true,
			},
			["unitframe"] = {
				["smartRaidFilter"] = false,
				["units"] = {
					["pet"] = {
						["debuffs"] = {
							["enable"] = true,
						},
						["power"] = {
							["height"] = 4,
						},
						["name"] = {
							["text_format"] = "[happiness:full]",
							["yOffset"] = 10,
						},
						["castbar"] = {
							["iconSize"] = 32,
							["width"] = 65,
						},
						["customTexts"] = {
							["名字"] = {
								["attachTextTo"] = "Health",
								["enable"] = true,
								["text_format"] = "[namecolor][name:medium]",
								["yOffset"] = 0,
								["font"] = "聊天",
								["justifyH"] = "CENTER",
								["fontOutline"] = "OUTLINE",
								["xOffset"] = 0,
								["size"] = 10,
							},
						},
						["width"] = 65,
						["infoPanel"] = {
							["height"] = 14,
						},
						["disableTargetGlow"] = false,
					},
					["tank"] = {
						["width"] = 85,
						["verticalSpacing"] = 2,
					},
					["arena"] = {
						["enable"] = false,
					},
					["focustarget"] = {
						["castbar"] = {
							["width"] = 80,
						},
						["width"] = 80,
						["power"] = {
							["enable"] = false,
						},
					},
					["targettarget"] = {
						["debuffs"] = {
							["enable"] = false,
							["anchorPoint"] = "TOPRIGHT",
						},
						["threatStyle"] = "GLOW",
						["power"] = {
							["enable"] = false,
						},
						["disableMouseoverGlow"] = true,
						["width"] = 100,
						["height"] = 35,
						["name"] = {
							["text_format"] = "[name:medium]",
						},
						["raidicon"] = {
							["attachTo"] = "LEFT",
							["yOffset"] = 0,
							["enable"] = false,
							["xOffset"] = 2,
						},
					},
					["target"] = {
						["debuffs"] = {
							["countFontSize"] = 5,
							["yOffset"] = 16,
							["priority"] = "Blacklist,Personal,nonPersonal",
							["numrows"] = 2,
							["attachTo"] = "FRAME",
							["perrow"] = 7,
						},
						["portrait"] = {
							["overlay"] = true,
							["enable"] = true,
							["overlayAlpha"] = 0.8,
							["camDistanceScale"] = 4,
						},
						["health"] = {
							["attachTextTo"] = "InfoPanel",
							["xOffset"] = 0,
							["text_format"] = "[health:current:shortvalue]  -  [perhp]%",
							["yOffset"] = 3,
						},
						["height"] = 45,
						["fader"] = {
							["range"] = false,
						},
						["CombatIcon"] = {
							["xOffset"] = 81,
							["yOffset"] = 27,
						},
						["aurabar"] = {
							["enable"] = false,
							["height"] = 18,
						},
						["power"] = {
							["attachTextTo"] = "Power",
							["text_format"] = "[powercolor][  >power:current]",
							["xOffset"] = -2,
							["position"] = "RIGHT",
						},
						["customTexts"] = {
							["精英"] = {
								["attachTextTo"] = "Health",
								["enable"] = true,
								["text_format"] = "[classification:icon][range]",
								["yOffset"] = 25,
								["font"] = "聊天",
								["justifyH"] = "CENTER",
								["fontOutline"] = "OUTLINE",
								["xOffset"] = -80,
								["size"] = 10,
							},
						},
						["disableMouseoverGlow"] = true,
						["width"] = 160,
						["name"] = {
							["position"] = "TOPRIGHT",
							["text_format"] = "[level]   [name]",
							["yOffset"] = 16,
						},
						["castbar"] = {
							["insideInfoPanel"] = false,
							["width"] = 160,
							["height"] = 10,
						},
						["orientation"] = "LEFT",
						["buffs"] = {
							["countFontSize"] = 5,
							["growthX"] = "RIGHT",
							["yOffset"] = -73,
							["anchorPoint"] = "BOTTOMLEFT",
							["priority"] = "Blacklist,Dispellable,Personal,nonPersonal,PlayerBuffs,Whitelist",
							["numrows"] = 2,
							["attachTo"] = "DEBUFFS",
							["perrow"] = 7,
						},
					},
					["focus"] = {
						["enable"] = false,
						["castbar"] = {
							["width"] = 120,
						},
						["width"] = 120,
						["health"] = {
							["xOffset"] = -37,
							["text_format"] = " [perhp]%",
							["yOffset"] = -18,
						},
					},
					["party"] = {
						["debuffs"] = {
							["countFontSize"] = 8,
							["sizeOverride"] = 22,
							["yOffset"] = 11,
							["priority"] = "",
							["numrows"] = 2,
						},
						["buffs"] = {
							["countFontSize"] = 8,
							["sizeOverride"] = 22,
							["enable"] = true,
							["yOffset"] = 11,
							["priority"] = "",
							["numrows"] = 2,
							["perrow"] = 5,
						},
						["healPrediction"] = {
							["enable"] = true,
						},
						["name"] = {
							["text_format"] = "[namecolor][name:medium] [difficultycolor][level]",
						},
						["height"] = 44,
						["verticalSpacing"] = 6,
						["visibility"] = "[@raid2,exists][@party1,noexists] hide;show",
						["width"] = 120,
						["rdebuffs"] = {
							["yOffset"] = 12,
							["font"] = "PT Sans Narrow",
							["size"] = 20,
						},
						["power"] = {
							["text_format"] = "",
							["height"] = 4,
						},
						["health"] = {
							["text_format"] = "",
						},
					},
					["raid40"] = {
						["healPrediction"] = {
							["enable"] = true,
						},
						["height"] = 40,
						["enable"] = false,
						["power"] = {
							["enable"] = true,
						},
						["health"] = {
							["text_format"] = "[health:deficit]",
						},
					},
					["assist"] = {
						["enable"] = false,
					},
					["raid"] = {
						["debuffs"] = {
							["enable"] = true,
							["anchorPoint"] = "CENTER",
						},
						["buffs"] = {
							["enable"] = true,
							["anchorPoint"] = "CENTER",
						},
						["enable"] = false,
						["healPrediction"] = {
							["enable"] = true,
						},
						["height"] = 45,
					},
					["player"] = {
						["debuffs"] = {
							["countFontSize"] = 10,
							["sizeOverride"] = 25,
							["yOffset"] = -30,
							["anchorPoint"] = "BOTTOMLEFT",
							["numrows"] = 2,
							["perrow"] = 6,
						},
						["portrait"] = {
							["overlay"] = true,
							["enable"] = true,
							["overlayAlpha"] = 0.8,
							["camDistanceScale"] = 4,
						},
						["CombatIcon"] = {
							["xOffset"] = -81,
							["yOffset"] = 28,
						},
						["disableMouseoverGlow"] = true,
						["height"] = 45,
						["buffs"] = {
							["countFontSize"] = 10,
							["yOffset"] = 15,
							["durationPosition"] = "BOTTOM",
							["numrows"] = 2,
							["attachTo"] = "FRAME",
							["perrow"] = 6,
						},
						["name"] = {
							["position"] = "TOPLEFT",
							["text_format"] = "[name]   [level]",
							["yOffset"] = 16,
						},
						["aurabar"] = {
							["enable"] = false,
							["height"] = 10,
						},
						["RestIcon"] = {
							["size"] = 20,
						},
						["classbar"] = {
							["autoHide"] = true,
							["detachedWidth"] = 360,
						},
						["power"] = {
							["attachTextTo"] = "Power",
							["text_format"] = "[powercolor][curpp]",
						},
						["castbar"] = {
							["insideInfoPanel"] = false,
							["width"] = 214,
							["height"] = 20,
						},
						["width"] = 160,
						["health"] = {
							["position"] = "RIGHT",
							["xOffset"] = 0,
							["text_format"] = "[health:current:shortvalue]                   [perhp]%",
						},
					},
				},
				["font"] = "聊天",
				["statusbar"] = "ElvUI Blank",
				["colors"] = {
					["auraBarBuff"] = {
						["r"] = 0.999997794628143,
						["g"] = 0.486273437738419,
						["b"] = 0.0392156019806862,
					},
					["healthclass"] = true,
					["castClassColor"] = true,
				},
				["fontOutline"] = "THICKOUTLINE",
				["smoothbars"] = true,
				["cooldown"] = {
					["fonts"] = {
						["enable"] = true,
						["fontSize"] = 15,
					},
				},
			},
			["datatexts"] = {
				["fontOutline"] = "OUTLINE",
				["fontSize"] = 10,
				["panels"] = {
					["MinimapPanel"] = {
						["border"] = false,
						["backdrop"] = false,
					},
					["RightChatDataPanel"] = {
						"Gold", -- [1]
						"MeetingStone", -- [2]
						"System", -- [3]
						["backdrop"] = false,
						["enable"] = false,
					},
					["LeftChatDataPanel"] = {
						"WeakAuras", -- [1]
						"ElvUI", -- [2]
						"Durability", -- [3]
						["panelTransparency"] = true,
						["backdrop"] = false,
						["enable"] = false,
					},
				},
			},
			["actionbar"] = {
				["bar3"] = {
					["buttonsPerRow"] = 4,
					["visibility"] = "[petbattle] hide; show",
					["buttonSize"] = 31,
					["point"] = "TOPLEFT",
					["buttons"] = 12,
					["macrotext"] = true,
				},
				["bar8"] = {
					["macrotext"] = true,
				},
				["bar9"] = {
					["macrotext"] = true,
				},
				["font"] = "傷害數字",
				["barPet"] = {
					["backdrop"] = false,
					["buttonsPerRow"] = 10,
					["point"] = "TOPLEFT",
					["buttonSize"] = 28,
				},
				["bar10"] = {
					["macrotext"] = true,
				},
				["bar7"] = {
					["macrotext"] = true,
				},
				["bar6"] = {
					["enabled"] = true,
					["buttonSize"] = 31,
					["point"] = "TOPLEFT",
					["macrotext"] = true,
				},
				["microbar"] = {
					["buttonSize"] = 23,
					["buttons"] = 7,
				},
				["bar2"] = {
					["visibility"] = "[petbattle] hide; show",
					["buttonSize"] = 31,
					["macrotext"] = true,
				},
				["bar5"] = {
					["buttonsPerRow"] = 12,
					["visibility"] = "[petbattle] hide; show",
					["buttonSize"] = 31,
					["buttons"] = 12,
					["macrotext"] = true,
				},
				["bar1"] = {
					["buttonSize"] = 31,
					["macrotext"] = true,
				},
				["stanceBar"] = {
					["buttonSpacing"] = 1,
					["buttonSize"] = 25,
					["style"] = "classic",
				},
				["cooldown"] = {
					["override"] = false,
					["fonts"] = {
						["enable"] = true,
					},
				},
				["bar4"] = {
					["backdrop"] = false,
					["buttonsPerRow"] = 4,
					["visibility"] = "[petbattle] hide; show",
					["buttonSize"] = 31,
					["point"] = "TOPLEFT",
					["macrotext"] = true,
				},
			},
			["nameplates"] = {
				["units"] = {
					["ENEMY_NPC"] = {
						["debuffs"] = {
							["yOffset"] = 15,
							["size"] = 20,
						},
						["health"] = {
							["text"] = {
								["format"] = "[perhp]%",
							},
						},
						["buffs"] = {
							["enable"] = false,
							["size"] = 20,
						},
					},
					["TARGET"] = {
						["classpower"] = {
							["width"] = 60,
							["enable"] = true,
							["yOffset"] = -11,
						},
					},
					["FRIENDLY_NPC"] = {
						["debuffs"] = {
							["enable"] = false,
							["size"] = 20,
						},
						["health"] = {
							["text"] = {
								["format"] = "[perhp]%",
							},
						},
						["buffs"] = {
							["enable"] = false,
							["size"] = 20,
						},
					},
					["FRIENDLY_PLAYER"] = {
						["debuffs"] = {
							["yOffset"] = 15,
							["size"] = 20,
						},
						["nameOnly"] = true,
						["buffs"] = {
							["enable"] = false,
							["size"] = 20,
						},
						["health"] = {
							["text"] = {
								["format"] = "[perhp]%",
							},
						},
					},
					["ENEMY_PLAYER"] = {
						["debuffs"] = {
							["yOffset"] = 15,
							["size"] = 20,
						},
						["buffs"] = {
							["size"] = 20,
						},
						["health"] = {
							["text"] = {
								["format"] = "[health:current:shortvalue]  -  [perhp]%",
							},
						},
					},
				},
				["statusbar"] = "Melli",
				["clampToScreen"] = true,
			},
			["auras"] = {
				["buffs"] = {
					["size"] = 26,
					["countFont"] = "傷害數字",
					["countFontOutline"] = "OUTLINE",
					["timeFontSize"] = 11,
					["timeFont"] = "EUI",
					["timeFontOutline"] = "OUTLINE",
				},
				["debuffs"] = {
					["size"] = 26,
					["countFont"] = "傷害數字",
					["countFontOutline"] = "OUTLINE",
					["timeFont"] = "傷害數字",
					["timeFontOutline"] = "OUTLINE",
				},
			},
			["cooldown"] = {
				["hideBlizzard"] = true,
				["fonts"] = {
					["enable"] = true,
				},
			},
			["bags"] = {
				["bagSize"] = 40,
				["itemLevelCustomColorEnable"] = true,
				["bankSize"] = 40,
				["bankWidth"] = 550,
				["split"] = {
					["bag1"] = true,
					["bag3"] = true,
					["bagSpacing"] = 7,
					["bag4"] = true,
					["bag2"] = true,
				},
				["scrapIcon"] = true,
				["vendorGrays"] = {
					["enable"] = true,
				},
				["bagWidth"] = 550,
				["bagBar"] = {
					["growthDirection"] = "HORIZONTAL",
					["size"] = 25,
				},
			},
		},
		["界面1"] = {
			["databars"] = {
				["petExperience"] = {
					["width"] = 65,
				},
				["threat"] = {
					["enable"] = false,
					["height"] = 24,
					["width"] = 472,
				},
				["experience"] = {
					["fontSize"] = 10,
					["height"] = 8,
					["textFormat"] = "PERCENT",
					["showBubbles"] = true,
					["width"] = 409,
				},
				["honor"] = {
					["enable"] = false,
				},
				["reputation"] = {
					["enable"] = true,
					["height"] = 6,
					["width"] = 409,
				},
				["azerite"] = {
					["enable"] = false,
				},
			},
			["currentTutorial"] = 6,
			["general"] = {
				["totems"] = {
					["spacing"] = 8,
					["growthDirection"] = "HORIZONTAL",
					["size"] = 30,
				},
				["fontSize"] = 14,
				["interruptAnnounce"] = "RAID",
				["afk"] = false,
				["autoRepair"] = true,
				["minimap"] = {
					["locationText"] = "SHOW",
					["icons"] = {
						["tracking"] = {
							["scale"] = 0.6,
							["xOffset"] = -12,
							["position"] = "TOPLEFT",
						},
						["lfgEye"] = {
							["position"] = "BOTTOM",
							["yOffset"] = -26,
						},
						["classHall"] = {
							["xOffset"] = -36,
							["yOffset"] = -45,
						},
					},
					["size"] = 140,
				},
				["bottomPanel"] = false,
				["backdropfadecolor"] = {
					["a"] = 0.85700567066669,
					["r"] = 0.058823529411765,
					["g"] = 0.058823529411765,
					["b"] = 0.058823529411765,
				},
				["valuecolor"] = {
					["r"] = 0.999997794628143,
					["g"] = 0.956860661506653,
					["b"] = 0.407842248678207,
				},
				["loginmessage"] = false,
				["itemLevel"] = {
					["displayCharacterInfo"] = false,
					["itemLevelFontSize"] = 10,
				},
				["talkingHeadFrameScale"] = 0.7,
				["altPowerBar"] = {
					["statusBar"] = "Melli",
				},
				["autoTrackReputation"] = true,
				["objectiveFrameHeight"] = 550,
				["numberPrefixStyle"] = "CHINESE",
				["vehicleSeatIndicatorSize"] = 80,
				["bonusObjectivePosition"] = "AUTO",
			},
			["v11NamePlateReset"] = true,
			["chat"] = {
				["customTimeColor"] = {
					["r"] = 0.70196078431373,
					["g"] = 0.70196078431373,
					["b"] = 0.70196078431373,
				},
				["panelWidth"] = 350,
				["maxLines"] = 353,
				["panelWidthRight"] = 50,
				["panelColor"] = {
					["a"] = 0.1851545572280884,
					["r"] = 0.05882352941176471,
					["g"] = 0.05882352941176471,
					["b"] = 0.05882352941176471,
				},
				["panelSnapLeftID"] = 1,
				["copyChatLines"] = true,
				["panelHeightRight"] = 60,
				["tabSelectorColor"] = {
					["r"] = 0.999997794628143,
					["g"] = 0.956860661506653,
					["b"] = 0.407842248678207,
				},
				["separateSizes"] = true,
				["panelHeight"] = 260,
				["editBoxPosition"] = "ABOVE_CHAT",
				["scrollDownInterval"] = 30,
				["tabSelector"] = "NONE",
				["panelBackdrop"] = "LEFT",
			},
			["dbConverted"] = 2.3,
			["euiscript"] = {
				["autobutton"] = {
					["enable"] = false,
					["questSize"] = 30,
					["slotSize"] = 30,
				},
				["raidcd_width"] = 150,
				["raidcd"] = false,
			},
			["movers"] = {
				["ElvUF_FocusCastbarMover"] = "TOPLEFT,ElvUF_Focus,BOTTOMLEFT,0,-1",
				["ElvUF_FocusTargetMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,503,-116",
				["BuffsMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-161,-5",
				["BossButton"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-441,346",
				["LootFrameMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,423,-416",
				["ZoneAbility"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,422,323",
				["PowerBarContainerMover"] = "TOP,ElvUIParent,TOP,0,-54",
				["ElvUF_PetCastbarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,423,121",
				["VehicleSeatMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-66,-261",
				["ElvUIBankMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,256,344",
				["WTSwitchButtonBarMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-60,-196",
				["LossControlMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-407,101",
				["WTCombatAlertFrameMover"] = "TOP,ElvUIParent,TOP,0,-276",
				["MirrorTimer1Mover"] = "TOP,ElvUIParent,TOP,0,-140",
				["QuestTimerFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,0,-171",
				["PetExperienceBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,423,176",
				["ReputationBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,0",
				["ObjectiveFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-83,-236",
				["MirrorTimer2Mover"] = "TOP,MirrorTimer1,BOTTOM,0,0",
				["ShiftAB"] = "BOTTOM,ElvUIParent,BOTTOM,-175,109",
				["ArenaHeaderMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-156,-264",
				["ElvUF_PlayerMover"] = "BOTTOM,ElvUIParent,BOTTOM,-231,270",
				["RightChatMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-4,4",
				["RaidCDAnchorMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,366,-300",
				["AutoButtonAnchor3Mover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-208,214",
				["ElvUF_AssistMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,123,-43",
				["WTRaidMarkersBarAnchor"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,310",
				["TopCenterContainerMover"] = "TOP,ElvUIParent,TOP,0,-51",
				["ThreatBarMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-4,4",
				["ElvUF_PlayerCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,132",
				["ElvUF_RaidMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,0,-116",
				["LeftChatMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,29",
				["GMMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,320",
				["MirrorTimer3Mover"] = "TOP,MirrorTimer2,BOTTOM,0,0",
				["ExAE_FrameMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,360,276",
				["WTMinimapButtonBarAnchor"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-4,-4",
				["ElvUF_FocusMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,397,-106",
				["AutoButtonAnchorMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-66,214",
				["ClassBarMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,475,-31",
				["MicrobarMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-15,4",
				["AltPowerBarMover"] = "TOP,ElvUIParent,TOP,0,-196",
				["ElvAB_4"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-38,240",
				["TalkingHeadFrameMover"] = "BOTTOM,ElvUIParent,BOTTOM,-2,144",
				["ExperienceBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,6",
				["ElvUF_TargetTargetMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-417,277",
				["ElvUF_TargetMover"] = "BOTTOM,ElvUIParent,BOTTOM,232,270",
				["WTParagonReputationToastFrameMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-49",
				["ElvUF_PetMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,423,139",
				["ElvUF_Raid40Mover"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-202",
				["BNETMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,315",
				["EUIMinimapButtonMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-138,-75",
				["ElvAB_1"] = "BOTTOM,ElvUIParent,BOTTOM,0,13",
				["ElvAB_2"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-235,4",
				["BelowMinimapContainerMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-4,-166",
				["ElvUF_TargetCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,232,259",
				["WTGameBarAnchor"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-4",
				["WTCustomEmoteFrameMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,324,56",
				["WTChatBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,288",
				["ElvAB_3"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-3,240",
				["ElvAB_5"] = "BOTTOM,ElvUIParent,BOTTOM,0,44",
				["VehicleLeaveButton"] = "BOTTOM,ElvUIParent,BOTTOM,238,130",
				["PetAB"] = "BOTTOM,ElvUIParent,BOTTOM,77,108",
				["ElvUIBagMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-409,-250",
				["BagsMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-237,4",
				["LevelUpBossBannerMover"] = "TOP,ElvUIParent,TOP,0,-107",
				["VOICECHAT"] = "TOPLEFT,UIParent,TOPLEFT,127,-4",
				["EuiExecuteMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,634,-367",
				["HonorBarMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-2,-251",
				["ElvAB_6"] = "BOTTOM,ElvUIParent,BOTTOM,0,76",
				["TooltipMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-78,323",
				["ElvUF_TankMover"] = "TOPLEFT,UIParent,TOPLEFT,4,-80",
				["BossHeaderMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-158,-262",
				["TotemBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,326,253",
				["DurabilityFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-76,-324",
				["ElvUF_PartyMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,121,-291",
				["AlertFrameMover"] = "BOTTOM,ElvUIParent,BOTTOM,-3,417",
				["DebuffsMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-160,-133",
				["MinimapMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-4,-4",
			},
			["convertPages"] = true,
			["AuraWatch"] = {
				["loadDefault"] = true,
				["myclass"] = "ROGUE",
			},
			["tooltip"] = {
				["showMount"] = false,
				["healthBar"] = {
					["height"] = 12,
					["font"] = "PT Sans Narrow",
					["fontSize"] = 12,
					["fontOutline"] = "NONE",
				},
				["itemCount"] = "NONE",
				["cursorAnchorType"] = "ANCHOR_CURSOR_RIGHT",
				["alwaysShowRealm"] = true,
				["modifierID"] = "SHIFT",
				["guildRanks"] = false,
			},
			["auras"] = {
				["buffs"] = {
					["timeFontSize"] = 11,
					["countFont"] = "傷害數字",
					["size"] = 26,
					["timeFont"] = "EUI",
					["timeFontOutline"] = "OUTLINE",
					["countFontOutline"] = "OUTLINE",
				},
				["debuffs"] = {
					["timeFontOutline"] = "OUTLINE",
					["countFont"] = "傷害數字",
					["timeFont"] = "傷害數字",
					["size"] = 26,
					["countFontOutline"] = "OUTLINE",
				},
			},
			["unitframe"] = {
				["number"] = "CNW",
				["fontSize"] = 11,
				["units"] = {
					["tank"] = {
						["height"] = 30,
						["verticalSpacing"] = 2,
						["width"] = 85,
					},
					["pet"] = {
						["infoPanel"] = {
							["height"] = 14,
						},
						["debuffs"] = {
							["enable"] = true,
						},
						["name"] = {
							["text_format"] = "[happiness:full]",
							["yOffset"] = 10,
						},
						["power"] = {
							["height"] = 4,
						},
						["customTexts"] = {
							["名字"] = {
								["attachTextTo"] = "Health",
								["enable"] = true,
								["text_format"] = "[namecolor][name:medium]",
								["yOffset"] = 0,
								["font"] = "聊天",
								["justifyH"] = "CENTER",
								["fontOutline"] = "OUTLINE",
								["xOffset"] = 0,
								["size"] = 10,
							},
						},
						["disableTargetGlow"] = false,
						["castbar"] = {
							["iconSize"] = 32,
							["width"] = 65,
						},
						["width"] = 65,
					},
					["focustarget"] = {
						["castbar"] = {
							["width"] = 80,
						},
						["width"] = 80,
						["power"] = {
							["enable"] = false,
						},
					},
					["targettarget"] = {
						["debuffs"] = {
							["enable"] = false,
							["anchorPoint"] = "TOPRIGHT",
						},
						["threatStyle"] = "GLOW",
						["power"] = {
							["enable"] = false,
						},
						["disableMouseoverGlow"] = true,
						["width"] = 100,
						["health"] = {
							["xOffset"] = 0,
							["text_format"] = "[perhp]%",
							["yOffset"] = -10,
						},
						["height"] = 35,
						["name"] = {
							["xOffset"] = -18,
							["text_format"] = "[name:medium]",
							["yOffset"] = 5,
						},
						["raidicon"] = {
							["attachTo"] = "LEFT",
							["xOffset"] = 2,
							["enable"] = false,
							["yOffset"] = 0,
						},
					},
					["player"] = {
						["RestIcon"] = {
							["size"] = 20,
						},
						["debuffs"] = {
							["countFontSize"] = 10,
							["sizeOverride"] = 25,
							["yOffset"] = -30,
							["anchorPoint"] = "BOTTOMLEFT",
							["numrows"] = 2,
							["perrow"] = 6,
						},
						["portrait"] = {
							["overlay"] = true,
							["enable"] = true,
							["camDistanceScale"] = 4,
							["overlayAlpha"] = 0.8,
						},
						["power"] = {
							["attachTextTo"] = "Power",
							["text_format"] = "[powercolor][curpp]",
						},
						["customTexts"] = {
						},
						["healPrediction"] = {
							["absorbStyle"] = "NORMAL",
						},
						["disableMouseoverGlow"] = true,
						["width"] = 160,
						["castbar"] = {
							["customTimeFont"] = {
								["enable"] = true,
							},
							["insideInfoPanel"] = false,
							["height"] = 20,
							["customTextFont"] = {
								["enable"] = true,
								["font"] = "傷害數字",
							},
							["width"] = 214,
						},
						["CombatIcon"] = {
							["xOffset"] = -81,
							["yOffset"] = 28,
						},
						["health"] = {
							["xOffset"] = 0,
							["text_format"] = "[health:current:shortvalue]                 [perhp]%",
							["position"] = "RIGHT",
						},
						["name"] = {
							["position"] = "TOPLEFT",
							["text_format"] = "[name]   [level]",
							["yOffset"] = 15,
						},
						["height"] = 45,
						["buffs"] = {
							["countFontSize"] = 10,
							["yOffset"] = 15,
							["durationPosition"] = "BOTTOM",
							["numrows"] = 2,
							["attachTo"] = "FRAME",
							["perrow"] = 6,
						},
						["classbar"] = {
							["detachedWidth"] = 360,
							["autoHide"] = true,
						},
						["aurabar"] = {
							["enable"] = false,
							["height"] = 10,
						},
					},
					["arena"] = {
						["enable"] = false,
						["height"] = 40,
						["width"] = 230,
					},
					["boss"] = {
						["infoPanel"] = {
							["height"] = 17,
						},
						["debuffs"] = {
							["maxDuration"] = 300,
							["sizeOverride"] = 27,
							["yOffset"] = -16,
						},
						["health"] = {
							["xOffset"] = 0,
							["text_format"] = "[healthcolor][health:current]（[health:percent]）",
						},
						["castbar"] = {
							["width"] = 230,
						},
						["height"] = 40,
						["buffs"] = {
							["maxDuration"] = 300,
							["sizeOverride"] = 27,
							["yOffset"] = 16,
						},
						["name"] = {
							["yOffset"] = 33,
						},
						["width"] = 230,
					},
					["raid40"] = {
						["name"] = {
							["text_format"] = "[name:short]",
						},
						["power"] = {
							["enable"] = true,
						},
						["height"] = 40,
						["healPrediction"] = {
							["enable"] = true,
						},
						["enable"] = false,
						["health"] = {
							["text_format"] = "[health:deficit]",
						},
					},
					["focus"] = {
						["debuffs"] = {
							["attachTo"] = "HEALTH",
							["sizeOverride"] = 30,
							["priority"] = "Blacklist,Personal,nonPersonal,Boss,RaidDebuffs,Dispellable,Whitelist",
						},
						["power"] = {
							["height"] = 3,
						},
						["enable"] = false,
						["width"] = 100,
						["name"] = {
							["yOffset"] = 7,
						},
						["height"] = 40,
						["castbar"] = {
							["width"] = 100,
						},
						["CombatIcon"] = {
							["enable"] = false,
						},
						["health"] = {
							["xOffset"] = -25,
							["text_format"] = "[perhp]%",
							["yOffset"] = -12,
						},
					},
					["target"] = {
						["debuffs"] = {
							["countFontSize"] = 5,
							["yOffset"] = 16,
							["numrows"] = 2,
							["priority"] = "Blacklist,Personal,nonPersonal",
							["attachTo"] = "FRAME",
							["perrow"] = 7,
						},
						["portrait"] = {
							["overlay"] = true,
							["enable"] = true,
							["camDistanceScale"] = 4,
							["overlayAlpha"] = 0.8,
						},
						["DragonOverlayStyle"] = "classic",
						["CombatIcon"] = {
							["xOffset"] = 81,
							["yOffset"] = 27,
						},
						["aurabar"] = {
							["enable"] = false,
							["height"] = 18,
						},
						["power"] = {
							["attachTextTo"] = "Power",
							["xOffset"] = -2,
							["text_format"] = "[powercolor][  >power:current]",
							["position"] = "RIGHT",
						},
						["customTexts"] = {
							["精英"] = {
								["attachTextTo"] = "Health",
								["enable"] = true,
								["text_format"] = "[classification:icon][range]",
								["yOffset"] = 25,
								["font"] = "聊天",
								["justifyH"] = "CENTER",
								["fontOutline"] = "OUTLINE",
								["xOffset"] = -80,
								["size"] = 10,
							},
						},
						["healPrediction"] = {
							["absorbStyle"] = "NORMAL",
						},
						["disableMouseoverGlow"] = true,
						["width"] = 160,
						["health"] = {
							["attachTextTo"] = "InfoPanel",
							["xOffset"] = 0,
							["text_format"] = "[health:current:shortvalue]  -  [perhp]%",
							["yOffset"] = 3,
						},
						["fader"] = {
							["range"] = false,
						},
						["name"] = {
							["position"] = "TOPRIGHT",
							["text_format"] = "[level]   [name]",
							["yOffset"] = 16,
						},
						["height"] = 45,
						["buffs"] = {
							["countFontSize"] = 5,
							["yOffset"] = -73,
							["anchorPoint"] = "BOTTOMLEFT",
							["growthX"] = "RIGHT",
							["numrows"] = 2,
							["priority"] = "Blacklist,Dispellable,Personal,nonPersonal,PlayerBuffs,Whitelist",
							["attachTo"] = "DEBUFFS",
							["perrow"] = 7,
						},
						["orientation"] = "LEFT",
						["castbar"] = {
							["customTimeFont"] = {
								["enable"] = true,
							},
							["insideInfoPanel"] = false,
							["height"] = 10,
							["customTextFont"] = {
								["enable"] = true,
								["font"] = "傷害數字",
							},
							["width"] = 160,
						},
					},
					["raid"] = {
						["debuffs"] = {
							["enable"] = true,
							["anchorPoint"] = "CENTER",
						},
						["enable"] = false,
						["buffs"] = {
							["enable"] = true,
							["anchorPoint"] = "CENTER",
						},
						["healPrediction"] = {
							["enable"] = true,
						},
						["height"] = 45,
					},
					["assist"] = {
						["enable"] = false,
					},
					["party"] = {
						["debuffs"] = {
							["countFontSize"] = 8,
							["sizeOverride"] = 22,
							["priority"] = "",
							["numrows"] = 2,
							["yOffset"] = 11,
						},
						["power"] = {
							["text_format"] = "",
							["height"] = 4,
						},
						["healPrediction"] = {
							["enable"] = true,
						},
						["width"] = 120,
						["name"] = {
							["xOffset"] = -5,
							["text_format"] = "[level][name:medium] [difficultycolor]",
							["yOffset"] = 3,
						},
						["classbar"] = {
							["height"] = 5,
						},
						["health"] = {
							["position"] = "RIGHT",
							["text_format"] = " [perhp]%",
							["yOffset"] = -10,
						},
						["verticalSpacing"] = 6,
						["height"] = 44,
						["buffs"] = {
							["countFontSize"] = 8,
							["sizeOverride"] = 22,
							["yOffset"] = 11,
							["enable"] = true,
							["priority"] = "",
							["numrows"] = 2,
							["perrow"] = 5,
						},
						["visibility"] = "[@raid2,exists][@party1,noexists] hide;show",
						["rdebuffs"] = {
							["font"] = "PT Sans Narrow",
							["yOffset"] = 12,
							["size"] = 20,
						},
					},
				},
				["font"] = "默认",
				["colors"] = {
					["auraBarBuff"] = {
						["r"] = 0.999997794628143,
						["g"] = 0.486273437738419,
						["b"] = 0.0392156019806862,
					},
					["castClassColor"] = true,
					["healthclass"] = true,
				},
				["smartRaidFilter"] = false,
				["statusbar"] = "ElvUI Blank",
				["smoothbars"] = true,
				["cooldown"] = {
					["fonts"] = {
						["enable"] = true,
						["fontSize"] = 15,
					},
				},
				["fontOutline"] = "THICKOUTLINE",
			},
			["datatexts"] = {
				["fontSize"] = 10,
				["panels"] = {
					["MinimapPanel"] = {
						["border"] = false,
						["backdrop"] = false,
					},
					["RightChatDataPanel"] = {
						"Gold", -- [1]
						"MeetingStone", -- [2]
						"System", -- [3]
						["backdrop"] = false,
						["enable"] = false,
					},
					["LeftChatDataPanel"] = {
						"WeakAuras", -- [1]
						"ElvUI", -- [2]
						"Durability", -- [3]
						["panelTransparency"] = true,
						["backdrop"] = false,
						["enable"] = false,
					},
				},
				["fontOutline"] = "OUTLINE",
			},
			["actionbar"] = {
				["bar3"] = {
					["point"] = "TOPLEFT",
					["buttons"] = 12,
					["macrotext"] = true,
					["buttonsPerRow"] = 1,
					["visibility"] = "[petbattle] hide; show",
				},
				["bar6"] = {
					["enabled"] = true,
					["macrotext"] = true,
				},
				["bar2"] = {
					["visibility"] = "[petbattle] hide; show",
					["macrotext"] = true,
				},
				["bar10"] = {
					["macrotext"] = true,
				},
				["bar8"] = {
					["macrotext"] = true,
				},
				["bar5"] = {
					["macrotext"] = true,
					["buttonsPerRow"] = 12,
					["visibility"] = "[petbattle] hide; show",
					["buttons"] = 12,
				},
				["microbar"] = {
					["buttonSize"] = 23,
					["buttons"] = 7,
				},
				["cooldown"] = {
					["fonts"] = {
						["enable"] = true,
					},
					["override"] = false,
				},
				["font"] = "傷害數字",
				["bar7"] = {
					["macrotext"] = true,
				},
				["bar1"] = {
					["macrotext"] = true,
				},
				["bar9"] = {
					["macrotext"] = true,
				},
				["stanceBar"] = {
					["buttonSpacing"] = 1,
					["style"] = "classic",
					["buttonSize"] = 25,
				},
				["barPet"] = {
					["backdrop"] = false,
					["buttonsPerRow"] = 10,
					["point"] = "TOPLEFT",
					["buttonSize"] = 24,
				},
				["bar4"] = {
					["macrotext"] = true,
					["point"] = "TOPLEFT",
					["backdrop"] = false,
					["visibility"] = "[petbattle] hide; show",
				},
			},
			["nameplates"] = {
				["statusbar"] = "Melli",
				["clampToScreen"] = true,
				["units"] = {
					["ENEMY_NPC"] = {
						["debuffs"] = {
							["yOffset"] = 15,
							["size"] = 20,
						},
						["health"] = {
							["text"] = {
								["fontSize"] = 10,
								["format"] = "[perhp]%",
							},
						},
						["buffs"] = {
							["enable"] = false,
							["size"] = 20,
						},
					},
					["TARGET"] = {
						["classpower"] = {
							["enable"] = true,
							["width"] = 60,
							["yOffset"] = -11,
						},
					},
					["FRIENDLY_NPC"] = {
						["debuffs"] = {
							["enable"] = false,
							["yOffset"] = 15,
							["size"] = 20,
						},
						["health"] = {
							["text"] = {
								["fontSize"] = 10,
								["format"] = "[perhp]%",
							},
						},
						["buffs"] = {
							["enable"] = false,
							["size"] = 20,
						},
					},
					["ENEMY_PLAYER"] = {
						["debuffs"] = {
							["yOffset"] = 20,
							["size"] = 20,
						},
						["health"] = {
							["text"] = {
								["fontSize"] = 10,
								["format"] = "[health:current:shortvalue]  -  [perhp]%",
							},
						},
						["buffs"] = {
							["size"] = 20,
						},
					},
					["FRIENDLY_PLAYER"] = {
						["buffs"] = {
							["enable"] = false,
							["size"] = 20,
						},
						["debuffs"] = {
							["yOffset"] = 15,
							["size"] = 20,
						},
						["health"] = {
							["text"] = {
								["fontSize"] = 10,
								["format"] = "[perhp]%",
							},
						},
						["nameOnly"] = true,
					},
				},
			},
			["nameplates_v1"] = {
				["classbar"] = {
					["position"] = "BELOW",
				},
				["cooldown"] = {
					["fonts"] = {
						["enable"] = true,
					},
				},
				["units"] = {
					["ENEMY_PLAYER"] = {
						["buffs"] = {
							["baseHeight"] = 20,
						},
						["debuffs"] = {
							["baseHeight"] = 20,
						},
					},
					["FRIENDLY_NPC"] = {
						["healthbar"] = {
							["text"] = {
								["enable"] = false,
							},
						},
					},
				},
			},
			["cooldown"] = {
				["fonts"] = {
					["enable"] = true,
				},
				["hideBlizzard"] = true,
			},
			["bags"] = {
				["scrapIcon"] = true,
				["split"] = {
					["bagSpacing"] = 7,
					["bag4"] = true,
					["bag1"] = true,
					["bag2"] = true,
					["bag3"] = true,
				},
				["vendorGrays"] = {
					["enable"] = true,
				},
				["bagSize"] = 40,
				["bankWidth"] = 550,
				["bankSize"] = 40,
				["itemLevelCustomColorEnable"] = true,
				["bagWidth"] = 550,
				["bagBar"] = {
					["growthDirection"] = "HORIZONTAL",
					["spacing"] = 2,
					["backdropSpacing"] = 2,
					["size"] = 25,
				},
			},
		},
		["Minimalistic"] = {
			["currentTutorial"] = 2,
			["general"] = {
				["font"] = "Expressway",
				["bottomPanel"] = false,
				["backdropfadecolor"] = {
					["a"] = 0.80000001192093,
					["r"] = 0.058823529411765,
					["g"] = 0.058823529411765,
					["b"] = 0.058823529411765,
				},
				["reputation"] = {
					["orientation"] = "HORIZONTAL",
					["textFormat"] = "PERCENT",
					["height"] = 16,
					["width"] = 200,
				},
				["bordercolor"] = {
					["r"] = 0.30588235294118,
					["g"] = 0.30588235294118,
					["b"] = 0.30588235294118,
				},
				["valuecolor"] = {
					["a"] = 1,
					["r"] = 1,
					["g"] = 1,
					["b"] = 1,
				},
				["fontSize"] = 11,
			},
			["movers"] = {
				["PetAB"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-50,-428",
				["ElvUF_RaidMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,51,120",
				["LeftChatMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,50,50",
				["GMMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,250,-50",
				["BossButton"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-117,-298",
				["LootFrameMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,249,-216",
				["ElvUF_RaidpetMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,50,827",
				["MicrobarMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-52",
				["VehicleSeatMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,51,-87",
				["ElvUF_TargetTargetMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,143",
				["ElvUF_Raid40Mover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,392,1073",
				["ElvAB_1"] = "BOTTOM,ElvUIParent,BOTTOM,0,50",
				["ElvAB_2"] = "BOTTOM,ElvUIParent,BOTTOM,0,90",
				["ElvAB_4"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-50,-394",
				["AltPowerBarMover"] = "TOP,ElvUIParent,TOP,0,-186",
				["ElvAB_3"] = "BOTTOM,ElvUIParent,BOTTOM,305,50",
				["ElvAB_5"] = "BOTTOM,ElvUIParent,BOTTOM,-305,50",
				["MinimapMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-50,-50",
				["ElvUF_TargetMover"] = "BOTTOM,ElvUIParent,BOTTOM,230,140",
				["ObjectiveFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-122,-393",
				["BNETMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,50,232",
				["ShiftAB"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,50,1150",
				["ElvUF_PlayerCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,133",
				["ElvUF_PartyMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,184,773",
				["ElvAB_6"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-488,330",
				["TooltipMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-50,50",
				["ElvUF_TankMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,50,995",
				["ElvUF_PlayerMover"] = "BOTTOM,ElvUIParent,BOTTOM,-230,140",
				["TotemBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,463,50",
				["ElvUF_PetMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,200",
				["RightChatMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-50,50",
				["AlertFrameMover"] = "TOP,ElvUIParent,TOP,0,-50",
				["ReputationBarMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-50,-228",
				["ElvUF_AssistMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,51,937",
			},
			["bags"] = {
				["itemLevelFontSize"] = 9,
				["countFontSize"] = 9,
			},
			["hideTutorial"] = true,
			["auras"] = {
				["font"] = "Expressway",
				["buffs"] = {
					["countFontSize"] = 11,
					["maxWraps"] = 2,
					["durationFontSize"] = 11,
				},
				["debuffs"] = {
					["countFontSize"] = 11,
					["durationFontSize"] = 11,
				},
			},
			["unitframe"] = {
				["statusbar"] = "ElvUI Blank",
				["fontOutline"] = "THICKOUTLINE",
				["smoothbars"] = true,
				["font"] = "Expressway",
				["fontSize"] = 9,
				["units"] = {
					["tank"] = {
						["enable"] = false,
					},
					["targettarget"] = {
						["infoPanel"] = {
							["enable"] = true,
						},
						["debuffs"] = {
							["enable"] = false,
						},
						["name"] = {
							["attachTextTo"] = "InfoPanel",
							["yOffset"] = -2,
							["position"] = "TOP",
						},
						["height"] = 50,
						["width"] = 122,
					},
					["player"] = {
						["infoPanel"] = {
							["enable"] = true,
						},
						["debuffs"] = {
							["perrow"] = 7,
						},
						["health"] = {
							["attachTextTo"] = "InfoPanel",
							["text_format"] = "[healthcolor][health:current-max]",
						},
						["power"] = {
							["attachTextTo"] = "InfoPanel",
							["text_format"] = "[powercolor][power:current-max]",
							["height"] = 15,
						},
						["height"] = 80,
						["castbar"] = {
							["iconAttached"] = false,
							["iconSize"] = 54,
							["height"] = 35,
							["width"] = 478,
						},
						["classbar"] = {
							["height"] = 15,
							["autoHide"] = true,
						},
						["name"] = {
							["attachTextTo"] = "InfoPanel",
							["text_format"] = "[namecolor][name]",
						},
					},
					["party"] = {
						["horizontalSpacing"] = 3,
						["debuffs"] = {
							["numrows"] = 4,
							["anchorPoint"] = "BOTTOM",
							["perrow"] = 1,
						},
						["power"] = {
							["text_format"] = "",
							["height"] = 5,
						},
						["enable"] = false,
						["rdebuffs"] = {
							["font"] = "Expressway",
						},
						["growthDirection"] = "RIGHT_DOWN",
						["infoPanel"] = {
							["enable"] = true,
						},
						["roleIcon"] = {
							["position"] = "TOPRIGHT",
						},
						["health"] = {
							["attachTextTo"] = "InfoPanel",
							["orientation"] = "VERTICAL",
							["text_format"] = "[healthcolor][health:current]",
							["position"] = "RIGHT",
						},
						["healPrediction"] = true,
						["height"] = 59,
						["verticalSpacing"] = 0,
						["name"] = {
							["attachTextTo"] = "InfoPanel",
							["text_format"] = "[namecolor][name:short]",
							["position"] = "LEFT",
						},
						["width"] = 110,
					},
					["pet"] = {
						["infoPanel"] = {
							["enable"] = true,
							["height"] = 14,
						},
						["debuffs"] = {
							["enable"] = true,
						},
						["threatStyle"] = "NONE",
						["castbar"] = {
							["width"] = 122,
						},
						["height"] = 50,
						["portrait"] = {
							["camDistanceScale"] = 2,
						},
						["width"] = 122,
					},
					["focus"] = {
						["infoPanel"] = {
							["height"] = 17,
							["enable"] = true,
						},
						["threatStyle"] = "NONE",
						["castbar"] = {
							["iconSize"] = 26,
							["width"] = 122,
						},
						["height"] = 56,
						["name"] = {
							["attachTextTo"] = "InfoPanel",
							["position"] = "LEFT",
						},
						["health"] = {
							["attachTextTo"] = "InfoPanel",
							["text_format"] = "[healthcolor][health:current]",
						},
						["width"] = 189,
					},
					["assist"] = {
						["enable"] = false,
					},
					["arena"] = {
						["castbar"] = {
							["width"] = 246,
						},
						["spacing"] = 26,
					},
					["raid"] = {
						["roleIcon"] = {
							["position"] = "RIGHT",
						},
						["debuffs"] = {
							["enable"] = true,
							["sizeOverride"] = 27,
							["perrow"] = 4,
						},
						["rdebuffs"] = {
							["enable"] = false,
							["font"] = "Expressway",
						},
						["growthDirection"] = "UP_RIGHT",
						["health"] = {
							["yOffset"] = -6,
						},
						["width"] = 140,
						["height"] = 28,
						["name"] = {
							["position"] = "LEFT",
						},
						["visibility"] = "[nogroup] hide;show",
						["groupsPerRowCol"] = 5,
					},
					["target"] = {
						["debuffs"] = {
							["perrow"] = 7,
						},
						["power"] = {
							["attachTextTo"] = "InfoPanel",
							["hideonnpc"] = false,
							["text_format"] = "[powercolor][power:current-max]",
							["height"] = 15,
						},
						["infoPanel"] = {
							["enable"] = true,
						},
						["name"] = {
							["attachTextTo"] = "InfoPanel",
							["text_format"] = "[namecolor][name]",
						},
						["castbar"] = {
							["iconSize"] = 54,
							["iconAttached"] = false,
						},
						["height"] = 80,
						["buffs"] = {
							["perrow"] = 7,
						},
						["smartAuraPosition"] = "DEBUFFS_ON_BUFFS",
						["health"] = {
							["attachTextTo"] = "InfoPanel",
							["text_format"] = "[healthcolor][health:current-max]",
						},
					},
				},
			},
			["datatexts"] = {
				["minimapPanels"] = false,
				["fontSize"] = 11,
				["leftChatPanel"] = false,
				["goldFormat"] = "SHORT",
				["panelTransparency"] = true,
				["font"] = "Expressway",
				["panels"] = {
					["BottomMiniPanel"] = "Time",
					["RightMiniPanel"] = "",
					["RightChatDataPanel"] = {
						["right"] = "",
						["left"] = "",
						["middle"] = "",
					},
					["LeftMiniPanel"] = "",
					["LeftChatDataPanel"] = {
						["right"] = "",
						["left"] = "",
						["middle"] = "",
					},
				},
				["rightChatPanel"] = false,
			},
			["actionbar"] = {
				["bar3"] = {
					["inheritGlobalFade"] = true,
					["buttonsize"] = 38,
					["buttonsPerRow"] = 3,
				},
				["fontSize"] = 9,
				["bar2"] = {
					["enabled"] = true,
					["inheritGlobalFade"] = true,
					["buttonsize"] = 38,
				},
				["bar1"] = {
					["heightMult"] = 2,
					["inheritGlobalFade"] = true,
					["buttonsize"] = 38,
				},
				["bar5"] = {
					["inheritGlobalFade"] = true,
					["buttonsize"] = 38,
					["buttonsPerRow"] = 3,
				},
				["globalFadeAlpha"] = 0.87,
				["stanceBar"] = {
					["inheritGlobalFade"] = true,
				},
				["bar6"] = {
					["buttonsize"] = 38,
				},
				["bar4"] = {
					["enabled"] = false,
					["backdrop"] = false,
					["buttonsize"] = 38,
				},
			},
			["layoutSet"] = "dpsMelee",
			["chat"] = {
				["chatHistory"] = false,
				["fontSize"] = 11,
				["tabFont"] = "Expressway",
				["tabFontSize"] = 11,
				["fadeUndockedTabs"] = false,
				["editBoxPosition"] = "ABOVE_CHAT",
				["fadeTabsNoBackdrop"] = false,
				["font"] = "Expressway",
				["panelBackdrop"] = "HIDEBOTH",
			},
			["tooltip"] = {
				["textFontSize"] = 11,
				["font"] = "Expressway",
				["healthBar"] = {
					["font"] = "Expressway",
				},
				["smallTextFontSize"] = 11,
				["fontSize"] = 11,
				["headerFontSize"] = 11,
			},
			["nameplates"] = {
				["filters"] = {
				},
			},
		},
		["简洁1-独立头像"] = {
			["databars"] = {
				["petExperience"] = {
					["width"] = 65,
				},
				["threat"] = {
					["enable"] = false,
					["height"] = 24,
					["width"] = 472,
				},
				["experience"] = {
					["fontSize"] = 10,
					["height"] = 8,
					["textFormat"] = "PERCENT",
					["showBubbles"] = true,
					["width"] = 409,
				},
				["honor"] = {
					["enable"] = false,
				},
				["reputation"] = {
					["enable"] = true,
					["height"] = 6,
					["width"] = 409,
				},
				["azerite"] = {
					["enable"] = false,
				},
			},
			["currentTutorial"] = 6,
			["general"] = {
				["totems"] = {
					["spacing"] = 8,
					["size"] = 30,
					["growthDirection"] = "HORIZONTAL",
				},
				["fontSize"] = 14,
				["autoTrackReputation"] = true,
				["afk"] = false,
				["autoRepair"] = true,
				["minimap"] = {
					["locationText"] = "SHOW",
					["icons"] = {
						["tracking"] = {
							["scale"] = 0.6,
							["xOffset"] = -12,
							["position"] = "TOPLEFT",
						},
						["lfgEye"] = {
							["yOffset"] = -26,
							["position"] = "BOTTOM",
						},
						["classHall"] = {
							["xOffset"] = -36,
							["yOffset"] = -45,
						},
					},
					["size"] = 140,
				},
				["bottomPanel"] = false,
				["backdropfadecolor"] = {
					["a"] = 0.85700567066669,
					["b"] = 0.058823529411765,
					["g"] = 0.058823529411765,
					["r"] = 0.058823529411765,
				},
				["valuecolor"] = {
					["b"] = 0.407842248678207,
					["g"] = 0.956860661506653,
					["r"] = 0.999997794628143,
				},
				["loginmessage"] = false,
				["itemLevel"] = {
					["displayCharacterInfo"] = false,
					["itemLevelFontSize"] = 10,
				},
				["talkingHeadFrameScale"] = 0.7,
				["altPowerBar"] = {
					["statusBar"] = "Melli",
				},
				["interruptAnnounce"] = "RAID",
				["objectiveFrameHeight"] = 550,
				["bonusObjectivePosition"] = "AUTO",
				["vehicleSeatIndicatorSize"] = 80,
				["numberPrefixStyle"] = "CHINESE",
			},
			["bags"] = {
				["scrapIcon"] = true,
				["split"] = {
					["bagSpacing"] = 7,
					["bag4"] = true,
					["bag1"] = true,
					["bag2"] = true,
					["bag3"] = true,
				},
				["vendorGrays"] = {
					["enable"] = true,
				},
				["bagSize"] = 40,
				["bankWidth"] = 550,
				["bankSize"] = 40,
				["itemLevelCustomColorEnable"] = true,
				["bagBar"] = {
					["growthDirection"] = "HORIZONTAL",
					["spacing"] = 2,
					["backdropSpacing"] = 2,
					["size"] = 25,
				},
				["bagWidth"] = 550,
			},
			["chat"] = {
				["customTimeColor"] = {
					["b"] = 0.70196078431373,
					["g"] = 0.70196078431373,
					["r"] = 0.70196078431373,
				},
				["panelWidth"] = 350,
				["maxLines"] = 353,
				["panelColor"] = {
					["a"] = 0.1851545572280884,
					["b"] = 0.05882352941176471,
					["g"] = 0.05882352941176471,
					["r"] = 0.05882352941176471,
				},
				["panelWidthRight"] = 50,
				["copyChatLines"] = true,
				["panelHeightRight"] = 60,
				["tabSelectorColor"] = {
					["b"] = 0.407842248678207,
					["g"] = 0.956860661506653,
					["r"] = 0.999997794628143,
				},
				["separateSizes"] = true,
				["panelHeight"] = 260,
				["editBoxPosition"] = "ABOVE_CHAT",
				["scrollDownInterval"] = 30,
				["tabSelector"] = "NONE",
				["panelBackdrop"] = "LEFT",
			},
			["dbConverted"] = 2.3,
			["euiscript"] = {
				["autobutton"] = {
					["enable"] = false,
					["questSize"] = 30,
					["slotSize"] = 30,
				},
				["raidcd_width"] = 150,
				["raidcd"] = false,
			},
			["movers"] = {
				["ElvUF_FocusCastbarMover"] = "TOPLEFT,ElvUF_Focus,BOTTOMLEFT,0,-1",
				["ElvUF_FocusTargetMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,503,-116",
				["BuffsMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-161,-5",
				["BossButton"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-441,346",
				["LootFrameMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,423,-416",
				["ZoneAbility"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,422,323",
				["PowerBarContainerMover"] = "TOP,ElvUIParent,TOP,0,-54",
				["ElvUF_PetCastbarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,423,121",
				["VehicleSeatMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-66,-261",
				["ElvUF_TargetTargetMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-417,277",
				["WTSwitchButtonBarMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-60,-196",
				["LossControlMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-407,101",
				["WTCombatAlertFrameMover"] = "TOP,ElvUIParent,TOP,0,-276",
				["MirrorTimer1Mover"] = "TOP,ElvUIParent,TOP,0,-140",
				["TalkingHeadFrameMover"] = "BOTTOM,ElvUIParent,BOTTOM,-2,144",
				["AltPowerBarMover"] = "TOP,ElvUIParent,TOP,0,-196",
				["ReputationBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,0",
				["ObjectiveFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-83,-236",
				["MirrorTimer2Mover"] = "TOP,MirrorTimer1,BOTTOM,0,0",
				["ShiftAB"] = "BOTTOM,ElvUIParent,BOTTOM,-176,109",
				["ArenaHeaderMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-156,-264",
				["ElvUF_PlayerMover"] = "BOTTOM,ElvUIParent,BOTTOM,-231,270",
				["RightChatMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-4,4",
				["RaidCDAnchorMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,366,-300",
				["AutoButtonAnchor3Mover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-208,214",
				["ElvUF_AssistMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,123,-43",
				["WTRaidMarkersBarAnchor"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,310",
				["TopCenterContainerMover"] = "TOP,UIParent,TOP,0,-51",
				["ThreatBarMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-4,4",
				["PetAB"] = "BOTTOM,ElvUIParent,BOTTOM,77,108",
				["ElvUF_RaidMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,0,-116",
				["LeftChatMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,29",
				["GMMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,320",
				["MirrorTimer3Mover"] = "TOP,MirrorTimer2,BOTTOM,0,0",
				["ExAE_FrameMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,360,276",
				["WTMinimapButtonBarAnchor"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-4,-4",
				["ElvUF_FocusMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,397,-106",
				["AutoButtonAnchorMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-66,214",
				["ClassBarMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,475,-31",
				["MicrobarMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-15,4",
				["PetExperienceBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,423,176",
				["WTCustomEmoteFrameMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,324,56",
				["QuestTimerFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,0,-171",
				["ExperienceBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,6",
				["ElvAB_4"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-38,240",
				["ElvUF_TargetMover"] = "BOTTOM,ElvUIParent,BOTTOM,233,270",
				["ElvUIBankMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,256,344",
				["ElvUF_PetMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,423,139",
				["ElvUF_Raid40Mover"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-202",
				["EuiExecuteMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,634,-367",
				["DurabilityFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-76,-324",
				["ElvAB_1"] = "BOTTOM,ElvUIParent,BOTTOM,0,13",
				["ElvAB_2"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-235,4",
				["BelowMinimapContainerMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-4,-166",
				["EUIMinimapButtonMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-138,-75",
				["WTGameBarAnchor"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-4",
				["ElvUF_TargetCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,233,259",
				["BNETMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,315",
				["ElvAB_3"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-3,240",
				["ElvAB_5"] = "BOTTOM,ElvUIParent,BOTTOM,0,44",
				["VehicleLeaveButton"] = "BOTTOM,ElvUIParent,BOTTOM,238,130",
				["WTChatBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,288",
				["LevelUpBossBannerMover"] = "TOP,ElvUIParent,TOP,0,-107",
				["ElvUF_PlayerCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,132",
				["BagsMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-237,4",
				["VOICECHAT"] = "TOPLEFT,UIParent,TOPLEFT,131,-4",
				["ElvUIBagMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-409,-250",
				["HonorBarMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-2,-251",
				["ElvAB_6"] = "BOTTOM,ElvUIParent,BOTTOM,0,76",
				["TooltipMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-78,323",
				["ElvUF_TankMover"] = "TOPLEFT,UIParent,TOPLEFT,4,-60",
				["BossHeaderMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-158,-262",
				["TotemBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,326,253",
				["WTParagonReputationToastFrameMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-49",
				["ElvUF_PartyMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,121,-291",
				["AlertFrameMover"] = "BOTTOM,ElvUIParent,BOTTOM,-3,417",
				["DebuffsMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-160,-133",
				["MinimapMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-4,-4",
			},
			["convertPages"] = true,
			["tooltip"] = {
				["showMount"] = false,
				["healthBar"] = {
					["height"] = 12,
					["fontSize"] = 12,
					["font"] = "PT Sans Narrow",
					["fontOutline"] = "NONE",
				},
				["itemCount"] = "NONE",
				["cursorAnchorType"] = "ANCHOR_CURSOR_RIGHT",
				["alwaysShowRealm"] = true,
				["modifierID"] = "SHIFT",
				["guildRanks"] = false,
			},
			["auras"] = {
				["buffs"] = {
					["timeFontOutline"] = "OUTLINE",
					["countFont"] = "傷害數字",
					["size"] = 26,
					["timeFont"] = "EUI",
					["timeFontSize"] = 11,
					["countFontOutline"] = "OUTLINE",
				},
				["debuffs"] = {
					["timeFontOutline"] = "OUTLINE",
					["countFont"] = "傷害數字",
					["timeFont"] = "傷害數字",
					["size"] = 26,
					["countFontOutline"] = "OUTLINE",
				},
			},
			["AuraWatch"] = {
				["loadDefault"] = true,
				["myclass"] = "ROGUE",
			},
			["unitframe"] = {
				["number"] = "CNW",
				["units"] = {
					["tank"] = {
						["height"] = 30,
						["verticalSpacing"] = 2,
						["width"] = 85,
					},
					["targettarget"] = {
						["debuffs"] = {
							["anchorPoint"] = "TOPRIGHT",
							["enable"] = false,
						},
						["threatStyle"] = "GLOW",
						["power"] = {
							["enable"] = false,
						},
						["disableMouseoverGlow"] = true,
						["width"] = 100,
						["name"] = {
							["xOffset"] = -18,
							["text_format"] = "[name:medium]",
							["yOffset"] = 5,
						},
						["height"] = 35,
						["health"] = {
							["xOffset"] = 0,
							["text_format"] = "[perhp]%",
							["yOffset"] = -10,
						},
						["raidicon"] = {
							["attachTo"] = "LEFT",
							["xOffset"] = 2,
							["enable"] = false,
							["yOffset"] = 0,
						},
					},
					["focustarget"] = {
						["castbar"] = {
							["width"] = 80,
						},
						["width"] = 80,
						["power"] = {
							["enable"] = false,
						},
					},
					["pet"] = {
						["infoPanel"] = {
							["height"] = 14,
						},
						["debuffs"] = {
							["enable"] = true,
						},
						["disableTargetGlow"] = false,
						["power"] = {
							["height"] = 4,
						},
						["customTexts"] = {
							["名字"] = {
								["attachTextTo"] = "Health",
								["enable"] = true,
								["text_format"] = "[namecolor][name:medium]",
								["yOffset"] = 0,
								["font"] = "聊天",
								["justifyH"] = "CENTER",
								["fontOutline"] = "OUTLINE",
								["xOffset"] = 0,
								["size"] = 10,
							},
						},
						["castbar"] = {
							["iconSize"] = 32,
							["width"] = 65,
						},
						["name"] = {
							["text_format"] = "[happiness:full]",
							["yOffset"] = 10,
						},
						["width"] = 65,
					},
					["boss"] = {
						["infoPanel"] = {
							["height"] = 17,
						},
						["debuffs"] = {
							["maxDuration"] = 300,
							["sizeOverride"] = 27,
							["yOffset"] = -16,
						},
						["name"] = {
							["yOffset"] = 33,
						},
						["castbar"] = {
							["width"] = 230,
						},
						["height"] = 40,
						["buffs"] = {
							["maxDuration"] = 300,
							["sizeOverride"] = 27,
							["yOffset"] = 16,
						},
						["health"] = {
							["xOffset"] = 0,
							["text_format"] = "[healthcolor][health:current]（[health:percent]）",
						},
						["width"] = 230,
					},
					["raid"] = {
						["debuffs"] = {
							["enable"] = true,
							["anchorPoint"] = "CENTER",
						},
						["height"] = 45,
						["healPrediction"] = {
							["enable"] = true,
						},
						["buffs"] = {
							["enable"] = true,
							["anchorPoint"] = "CENTER",
						},
						["enable"] = false,
					},
					["party"] = {
						["debuffs"] = {
							["countFontSize"] = 8,
							["sizeOverride"] = 22,
							["priority"] = "",
							["numrows"] = 2,
							["yOffset"] = 11,
						},
						["power"] = {
							["text_format"] = "",
							["height"] = 4,
						},
						["healPrediction"] = {
							["enable"] = true,
						},
						["width"] = 120,
						["name"] = {
							["xOffset"] = -5,
							["text_format"] = "[level][name:medium] [difficultycolor]",
							["yOffset"] = 3,
						},
						["classbar"] = {
							["height"] = 5,
						},
						["health"] = {
							["position"] = "RIGHT",
							["text_format"] = " [perhp]%",
							["yOffset"] = -10,
						},
						["verticalSpacing"] = 6,
						["height"] = 44,
						["buffs"] = {
							["countFontSize"] = 8,
							["sizeOverride"] = 22,
							["yOffset"] = 11,
							["enable"] = true,
							["priority"] = "",
							["numrows"] = 2,
							["perrow"] = 5,
						},
						["visibility"] = "[@raid2,exists][@party1,noexists] hide;show",
						["rdebuffs"] = {
							["font"] = "PT Sans Narrow",
							["yOffset"] = 12,
							["size"] = 20,
						},
					},
					["raid40"] = {
						["name"] = {
							["text_format"] = "[name:short]",
						},
						["power"] = {
							["enable"] = true,
						},
						["height"] = 40,
						["healPrediction"] = {
							["enable"] = true,
						},
						["enable"] = false,
						["health"] = {
							["text_format"] = "[health:deficit]",
						},
					},
					["focus"] = {
						["debuffs"] = {
							["attachTo"] = "HEALTH",
							["sizeOverride"] = 30,
							["priority"] = "Blacklist,Personal,nonPersonal,Boss,RaidDebuffs,Dispellable,Whitelist",
						},
						["castbar"] = {
							["width"] = 100,
						},
						["enable"] = false,
						["width"] = 100,
						["name"] = {
							["yOffset"] = 7,
						},
						["height"] = 40,
						["power"] = {
							["height"] = 3,
						},
						["CombatIcon"] = {
							["enable"] = false,
						},
						["health"] = {
							["xOffset"] = -25,
							["text_format"] = "[perhp]%",
							["yOffset"] = -12,
						},
					},
					["target"] = {
						["castbar"] = {
							["customTimeFont"] = {
								["enable"] = true,
							},
							["insideInfoPanel"] = false,
							["height"] = 10,
							["customTextFont"] = {
								["enable"] = true,
								["font"] = "傷害數字",
							},
							["width"] = 190,
						},
						["debuffs"] = {
							["countFontSize"] = 5,
							["yOffset"] = 16,
							["numrows"] = 2,
							["priority"] = "Blacklist,Personal,nonPersonal",
							["attachTo"] = "FRAME",
							["perrow"] = 7,
						},
						["portrait"] = {
							["enable"] = true,
							["camDistanceScale"] = 1.1,
							["overlayAlpha"] = 0.7,
						},
						["power"] = {
							["attachTextTo"] = "Power",
							["xOffset"] = -2,
							["text_format"] = "[powercolor][  >power:current]",
							["position"] = "RIGHT",
						},
						["customTexts"] = {
							["精英"] = {
								["attachTextTo"] = "Health",
								["enable"] = true,
								["text_format"] = "[classification:icon][range]",
								["yOffset"] = 25,
								["font"] = "聊天",
								["justifyH"] = "CENTER",
								["fontOutline"] = "OUTLINE",
								["xOffset"] = -80,
								["size"] = 10,
							},
						},
						["healPrediction"] = {
							["absorbStyle"] = "NORMAL",
						},
						["disableMouseoverGlow"] = true,
						["DragonOverlayStyle"] = "classic",
						["width"] = 190,
						["health"] = {
							["attachTextTo"] = "InfoPanel",
							["position"] = "LEFT",
							["xOffset"] = 0,
							["text_format"] = " [health:current:shortvalue]  -  [perhp]%",
							["yOffset"] = 3,
						},
						["name"] = {
							["position"] = "TOPRIGHT",
							["text_format"] = "[level]   [name]",
							["yOffset"] = 16,
						},
						["fader"] = {
							["range"] = false,
						},
						["height"] = 45,
						["buffs"] = {
							["countFontSize"] = 5,
							["yOffset"] = -73,
							["anchorPoint"] = "BOTTOMLEFT",
							["growthX"] = "RIGHT",
							["numrows"] = 2,
							["priority"] = "Blacklist,Dispellable,Personal,nonPersonal,PlayerBuffs,Whitelist",
							["attachTo"] = "DEBUFFS",
							["perrow"] = 7,
						},
						["CombatIcon"] = {
							["xOffset"] = 81,
							["yOffset"] = 27,
						},
						["aurabar"] = {
							["enable"] = false,
							["height"] = 18,
						},
					},
					["arena"] = {
						["enable"] = false,
						["height"] = 40,
						["width"] = 230,
					},
					["assist"] = {
						["enable"] = false,
					},
					["player"] = {
						["RestIcon"] = {
							["size"] = 20,
						},
						["debuffs"] = {
							["countFontSize"] = 10,
							["sizeOverride"] = 25,
							["yOffset"] = -30,
							["anchorPoint"] = "BOTTOMLEFT",
							["numrows"] = 2,
							["perrow"] = 6,
						},
						["portrait"] = {
							["enable"] = true,
							["camDistanceScale"] = 1.1,
							["overlayAlpha"] = 0.7,
						},
						["power"] = {
							["attachTextTo"] = "Power",
							["text_format"] = "[powercolor][curpp]",
						},
						["customTexts"] = {
						},
						["healPrediction"] = {
							["absorbStyle"] = "NORMAL",
						},
						["disableMouseoverGlow"] = true,
						["width"] = 190,
						["name"] = {
							["position"] = "TOPLEFT",
							["text_format"] = "[name]   [level]",
							["yOffset"] = 15,
						},
						["classbar"] = {
							["detachedWidth"] = 360,
							["autoHide"] = true,
						},
						["health"] = {
							["xOffset"] = 0,
							["text_format"] = "[health:current:shortvalue]               [perhp]%",
							["position"] = "RIGHT",
						},
						["castbar"] = {
							["customTimeFont"] = {
								["enable"] = true,
							},
							["insideInfoPanel"] = false,
							["height"] = 20,
							["customTextFont"] = {
								["enable"] = true,
								["font"] = "傷害數字",
							},
							["width"] = 214,
						},
						["height"] = 45,
						["buffs"] = {
							["countFontSize"] = 10,
							["yOffset"] = 15,
							["durationPosition"] = "BOTTOM",
							["numrows"] = 2,
							["attachTo"] = "FRAME",
							["perrow"] = 6,
						},
						["CombatIcon"] = {
							["xOffset"] = -81,
							["yOffset"] = 28,
						},
						["aurabar"] = {
							["enable"] = false,
							["height"] = 10,
						},
					},
				},
				["font"] = "默认",
				["colors"] = {
					["auraBarBuff"] = {
						["b"] = 0.0392156019806862,
						["g"] = 0.486273437738419,
						["r"] = 0.999997794628143,
					},
					["castClassColor"] = true,
					["healthclass"] = true,
				},
				["fontOutline"] = "THICKOUTLINE",
				["statusbar"] = "ElvUI Blank",
				["smoothbars"] = true,
				["cooldown"] = {
					["fonts"] = {
						["enable"] = true,
						["fontSize"] = 15,
					},
				},
				["smartRaidFilter"] = false,
			},
			["datatexts"] = {
				["fontSize"] = 10,
				["panels"] = {
					["MinimapPanel"] = {
						["backdrop"] = false,
						["border"] = false,
					},
					["RightChatDataPanel"] = {
						"Gold", -- [1]
						"MeetingStone", -- [2]
						"System", -- [3]
						["enable"] = false,
						["backdrop"] = false,
					},
					["LeftChatDataPanel"] = {
						"WeakAuras", -- [1]
						"ElvUI", -- [2]
						"Durability", -- [3]
						["enable"] = false,
						["backdrop"] = false,
						["panelTransparency"] = true,
					},
				},
				["fontOutline"] = "OUTLINE",
			},
			["actionbar"] = {
				["bar3"] = {
					["point"] = "TOPLEFT",
					["buttons"] = 12,
					["macrotext"] = true,
					["buttonsPerRow"] = 1,
					["visibility"] = "[petbattle] hide; show",
				},
				["bar6"] = {
					["enabled"] = true,
					["macrotext"] = true,
				},
				["bar2"] = {
					["visibility"] = "[petbattle] hide; show",
					["macrotext"] = true,
				},
				["bar10"] = {
					["macrotext"] = true,
				},
				["bar8"] = {
					["macrotext"] = true,
				},
				["bar5"] = {
					["macrotext"] = true,
					["buttonsPerRow"] = 12,
					["visibility"] = "[petbattle] hide; show",
					["buttons"] = 12,
				},
				["microbar"] = {
					["buttonSize"] = 23,
					["buttons"] = 7,
				},
				["cooldown"] = {
					["fonts"] = {
						["enable"] = true,
					},
					["override"] = false,
				},
				["font"] = "傷害數字",
				["bar7"] = {
					["macrotext"] = true,
				},
				["bar1"] = {
					["macrotext"] = true,
				},
				["bar9"] = {
					["macrotext"] = true,
				},
				["stanceBar"] = {
					["buttonSpacing"] = 1,
					["style"] = "classic",
					["buttonSize"] = 25,
				},
				["barPet"] = {
					["backdrop"] = false,
					["buttonsPerRow"] = 10,
					["point"] = "TOPLEFT",
					["buttonSize"] = 24,
				},
				["bar4"] = {
					["macrotext"] = true,
					["backdrop"] = false,
					["visibility"] = "[petbattle] hide; show",
					["point"] = "TOPLEFT",
				},
			},
			["nameplates"] = {
				["clampToScreen"] = true,
				["statusbar"] = "Melli",
				["units"] = {
					["ENEMY_NPC"] = {
						["debuffs"] = {
							["yOffset"] = 15,
							["size"] = 20,
						},
						["health"] = {
							["text"] = {
								["fontSize"] = 10,
								["format"] = "[perhp]%",
							},
						},
						["buffs"] = {
							["enable"] = false,
							["size"] = 20,
						},
					},
					["TARGET"] = {
						["classpower"] = {
							["enable"] = true,
							["yOffset"] = -11,
							["width"] = 60,
						},
					},
					["FRIENDLY_NPC"] = {
						["debuffs"] = {
							["enable"] = false,
							["yOffset"] = 15,
							["size"] = 20,
						},
						["health"] = {
							["text"] = {
								["fontSize"] = 10,
								["format"] = "[perhp]%",
							},
						},
						["buffs"] = {
							["enable"] = false,
							["size"] = 20,
						},
					},
					["ENEMY_PLAYER"] = {
						["debuffs"] = {
							["yOffset"] = 20,
							["size"] = 20,
						},
						["health"] = {
							["text"] = {
								["fontSize"] = 10,
								["format"] = "[health:current:shortvalue]  -  [perhp]%",
							},
						},
						["buffs"] = {
							["size"] = 20,
						},
					},
					["FRIENDLY_PLAYER"] = {
						["buffs"] = {
							["enable"] = false,
							["size"] = 20,
						},
						["debuffs"] = {
							["yOffset"] = 15,
							["size"] = 20,
						},
						["health"] = {
							["text"] = {
								["fontSize"] = 10,
								["format"] = "[perhp]%",
							},
						},
						["nameOnly"] = true,
					},
				},
			},
			["nameplates_v1"] = {
				["classbar"] = {
					["position"] = "BELOW",
				},
				["cooldown"] = {
					["fonts"] = {
						["enable"] = true,
					},
				},
				["units"] = {
					["ENEMY_PLAYER"] = {
						["buffs"] = {
							["baseHeight"] = 20,
						},
						["debuffs"] = {
							["baseHeight"] = 20,
						},
					},
					["FRIENDLY_NPC"] = {
						["healthbar"] = {
							["text"] = {
								["enable"] = false,
							},
						},
					},
				},
			},
			["cooldown"] = {
				["fonts"] = {
					["enable"] = true,
				},
				["hideBlizzard"] = true,
			},
			["v11NamePlateReset"] = true,
		},
		["简洁1-纯血条头像"] = {
			["databars"] = {
				["petExperience"] = {
					["width"] = 65,
				},
				["threat"] = {
					["enable"] = false,
					["height"] = 24,
					["width"] = 472,
				},
				["experience"] = {
					["fontSize"] = 10,
					["height"] = 8,
					["textFormat"] = "PERCENT",
					["showBubbles"] = true,
					["width"] = 409,
				},
				["honor"] = {
					["enable"] = false,
				},
				["reputation"] = {
					["enable"] = true,
					["height"] = 6,
					["width"] = 409,
				},
				["azerite"] = {
					["enable"] = false,
				},
			},
			["currentTutorial"] = 6,
			["general"] = {
				["totems"] = {
					["spacing"] = 8,
					["size"] = 30,
					["growthDirection"] = "HORIZONTAL",
				},
				["fontSize"] = 14,
				["autoTrackReputation"] = true,
				["afk"] = false,
				["autoRepair"] = true,
				["minimap"] = {
					["locationText"] = "SHOW",
					["icons"] = {
						["tracking"] = {
							["xOffset"] = -12,
							["scale"] = 0.6,
							["position"] = "TOPLEFT",
						},
						["lfgEye"] = {
							["yOffset"] = -26,
							["position"] = "BOTTOM",
						},
						["classHall"] = {
							["xOffset"] = -36,
							["yOffset"] = -45,
						},
					},
					["size"] = 140,
				},
				["bottomPanel"] = false,
				["backdropfadecolor"] = {
					["a"] = 0.85700567066669,
					["b"] = 0.058823529411765,
					["g"] = 0.058823529411765,
					["r"] = 0.058823529411765,
				},
				["valuecolor"] = {
					["b"] = 0.407842248678207,
					["g"] = 0.956860661506653,
					["r"] = 0.999997794628143,
				},
				["loginmessage"] = false,
				["itemLevel"] = {
					["displayCharacterInfo"] = false,
					["itemLevelFontSize"] = 10,
				},
				["talkingHeadFrameScale"] = 0.7,
				["altPowerBar"] = {
					["statusBar"] = "Melli",
				},
				["interruptAnnounce"] = "RAID",
				["objectiveFrameHeight"] = 550,
				["bonusObjectivePosition"] = "AUTO",
				["vehicleSeatIndicatorSize"] = 80,
				["numberPrefixStyle"] = "CHINESE",
			},
			["bags"] = {
				["bagWidth"] = 550,
				["split"] = {
					["bagSpacing"] = 7,
					["bag4"] = true,
					["bag1"] = true,
					["bag2"] = true,
					["bag3"] = true,
				},
				["vendorGrays"] = {
					["enable"] = true,
				},
				["bagSize"] = 40,
				["bankWidth"] = 550,
				["bankSize"] = 40,
				["itemLevelCustomColorEnable"] = true,
				["scrapIcon"] = true,
				["bagBar"] = {
					["growthDirection"] = "HORIZONTAL",
					["spacing"] = 2,
					["backdropSpacing"] = 2,
					["size"] = 25,
				},
			},
			["auras"] = {
				["buffs"] = {
					["timeFontSize"] = 11,
					["countFont"] = "傷害數字",
					["size"] = 26,
					["timeFont"] = "EUI",
					["timeFontOutline"] = "OUTLINE",
					["countFontOutline"] = "OUTLINE",
				},
				["debuffs"] = {
					["timeFontOutline"] = "OUTLINE",
					["countFont"] = "傷害數字",
					["timeFont"] = "傷害數字",
					["size"] = 26,
					["countFontOutline"] = "OUTLINE",
				},
			},
			["dbConverted"] = 2.3,
			["euiscript"] = {
				["autobutton"] = {
					["enable"] = false,
					["questSize"] = 30,
					["slotSize"] = 30,
				},
				["raidcd_width"] = 150,
				["raidcd"] = false,
			},
			["movers"] = {
				["ElvUF_FocusCastbarMover"] = "TOPLEFT,ElvUF_Focus,BOTTOMLEFT,0,-1",
				["ElvUF_FocusTargetMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,503,-116",
				["BuffsMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-161,-5",
				["BossButton"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-441,346",
				["LootFrameMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,423,-416",
				["ZoneAbility"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,422,323",
				["DurabilityFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-76,-324",
				["ElvUF_PetCastbarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,423,121",
				["VehicleSeatMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-66,-261",
				["ElvUIBankMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,256,344",
				["WTSwitchButtonBarMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-60,-196",
				["LossControlMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-407,101",
				["WTCombatAlertFrameMover"] = "TOP,ElvUIParent,TOP,0,-276",
				["MirrorTimer1Mover"] = "TOP,ElvUIParent,TOP,0,-140",
				["ElvAB_4"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-38,240",
				["AltPowerBarMover"] = "TOP,ElvUIParent,TOP,0,-196",
				["ReputationBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,0",
				["ObjectiveFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-83,-236",
				["MirrorTimer2Mover"] = "TOP,MirrorTimer1,BOTTOM,0,0",
				["ShiftAB"] = "BOTTOM,ElvUIParent,BOTTOM,-175,108",
				["ArenaHeaderMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-156,-264",
				["ElvUF_PlayerMover"] = "BOTTOM,ElvUIParent,BOTTOM,-231,270",
				["RightChatMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-4,4",
				["RaidCDAnchorMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,366,-300",
				["AutoButtonAnchor3Mover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-208,214",
				["ElvUF_AssistMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,123,-43",
				["WTRaidMarkersBarAnchor"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,310",
				["TopCenterContainerMover"] = "TOP,ElvUIParent,TOP,0,-51",
				["ThreatBarMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-4,4",
				["ElvUF_PlayerCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,132",
				["ElvUF_RaidMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,0,-116",
				["LeftChatMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,29",
				["GMMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,320",
				["MirrorTimer3Mover"] = "TOP,MirrorTimer2,BOTTOM,0,0",
				["WTChatBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,288",
				["WTMinimapButtonBarAnchor"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-4,-4",
				["ElvUF_FocusMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,397,-106",
				["AutoButtonAnchorMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-66,214",
				["EUIMinimapButtonMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-138,-75",
				["MicrobarMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-15,4",
				["PetExperienceBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,423,176",
				["WTCustomEmoteFrameMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,324,56",
				["TalkingHeadFrameMover"] = "BOTTOM,ElvUIParent,BOTTOM,-2,144",
				["ExperienceBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,6",
				["QuestTimerFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,0,-171",
				["ElvUF_TargetMover"] = "BOTTOM,ElvUIParent,BOTTOM,233,270",
				["ElvUF_TargetTargetMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-417,277",
				["TotemBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,326,253",
				["ElvUF_Raid40Mover"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-202",
				["WTParagonReputationToastFrameMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-49",
				["PowerBarContainerMover"] = "TOP,ElvUIParent,TOP,0,-54",
				["ElvAB_1"] = "BOTTOM,ElvUIParent,BOTTOM,0,13",
				["ElvAB_2"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-235,4",
				["BelowMinimapContainerMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-4,-166",
				["ClassBarMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,475,-31",
				["WTGameBarAnchor"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-4",
				["EuiExecuteMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,634,-367",
				["ElvUF_TargetCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,233,259",
				["ElvAB_3"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-3,240",
				["ElvAB_5"] = "BOTTOM,ElvUIParent,BOTTOM,0,44",
				["VehicleLeaveButton"] = "BOTTOM,ElvUIParent,BOTTOM,238,130",
				["ExAE_FrameMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,360,276",
				["ElvUIBagMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-409,-250",
				["PetAB"] = "BOTTOM,ElvUIParent,BOTTOM,77,108",
				["BagsMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-237,4",
				["VOICECHAT"] = "TOPLEFT,UIParent,TOPLEFT,131,-4",
				["LevelUpBossBannerMover"] = "TOP,ElvUIParent,TOP,0,-107",
				["HonorBarMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-2,-251",
				["ElvAB_6"] = "BOTTOM,ElvUIParent,BOTTOM,0,76",
				["TooltipMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-78,323",
				["ElvUF_TankMover"] = "TOPLEFT,UIParent,TOPLEFT,4,-68",
				["BossHeaderMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-158,-262",
				["ElvUF_PetMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,423,139",
				["BNETMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,315",
				["ElvUF_PartyMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,121,-291",
				["AlertFrameMover"] = "BOTTOM,ElvUIParent,BOTTOM,-3,417",
				["DebuffsMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-160,-133",
				["MinimapMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-4,-4",
			},
			["convertPages"] = true,
			["tooltip"] = {
				["itemCount"] = "NONE",
				["healthBar"] = {
					["height"] = 12,
					["fontSize"] = 12,
					["font"] = "PT Sans Narrow",
					["fontOutline"] = "NONE",
				},
				["showMount"] = false,
				["cursorAnchorType"] = "ANCHOR_CURSOR_RIGHT",
				["alwaysShowRealm"] = true,
				["modifierID"] = "SHIFT",
				["guildRanks"] = false,
			},
			["v11NamePlateReset"] = true,
			["actionbar"] = {
				["bar3"] = {
					["point"] = "TOPLEFT",
					["buttons"] = 12,
					["macrotext"] = true,
					["buttonsPerRow"] = 1,
					["visibility"] = "[petbattle] hide; show",
				},
				["bar6"] = {
					["enabled"] = true,
					["macrotext"] = true,
				},
				["bar2"] = {
					["visibility"] = "[petbattle] hide; show",
					["macrotext"] = true,
				},
				["bar10"] = {
					["macrotext"] = true,
				},
				["bar8"] = {
					["macrotext"] = true,
				},
				["bar5"] = {
					["macrotext"] = true,
					["buttonsPerRow"] = 12,
					["visibility"] = "[petbattle] hide; show",
					["buttons"] = 12,
				},
				["microbar"] = {
					["buttonSize"] = 23,
					["buttons"] = 7,
				},
				["cooldown"] = {
					["fonts"] = {
						["enable"] = true,
					},
					["override"] = false,
				},
				["font"] = "傷害數字",
				["bar7"] = {
					["macrotext"] = true,
				},
				["bar1"] = {
					["macrotext"] = true,
				},
				["bar9"] = {
					["macrotext"] = true,
				},
				["stanceBar"] = {
					["buttonSpacing"] = 1,
					["style"] = "classic",
					["buttonSize"] = 25,
				},
				["barPet"] = {
					["backdrop"] = false,
					["buttonsPerRow"] = 10,
					["point"] = "TOPLEFT",
					["buttonSize"] = 24,
				},
				["bar4"] = {
					["macrotext"] = true,
					["backdrop"] = false,
					["visibility"] = "[petbattle] hide; show",
					["point"] = "TOPLEFT",
				},
			},
			["unitframe"] = {
				["number"] = "CNW",
				["units"] = {
					["tank"] = {
						["height"] = 30,
						["verticalSpacing"] = 2,
						["width"] = 85,
					},
					["player"] = {
						["RestIcon"] = {
							["size"] = 20,
						},
						["debuffs"] = {
							["countFontSize"] = 10,
							["sizeOverride"] = 25,
							["yOffset"] = -30,
							["anchorPoint"] = "BOTTOMLEFT",
							["numrows"] = 2,
							["perrow"] = 6,
						},
						["portrait"] = {
							["overlay"] = true,
							["overlayAlpha"] = 0.7,
						},
						["power"] = {
							["attachTextTo"] = "Power",
							["text_format"] = "[powercolor][curpp]",
						},
						["customTexts"] = {
						},
						["healPrediction"] = {
							["absorbStyle"] = "NORMAL",
						},
						["disableMouseoverGlow"] = true,
						["width"] = 180,
						["name"] = {
							["position"] = "TOPLEFT",
							["text_format"] = "[name]   [level]",
							["yOffset"] = 15,
						},
						["classbar"] = {
							["detachedWidth"] = 360,
							["autoHide"] = true,
						},
						["health"] = {
							["xOffset"] = 0,
							["text_format"] = "[health:current:shortvalue]                        [perhp]%",
							["position"] = "RIGHT",
						},
						["castbar"] = {
							["customTimeFont"] = {
								["enable"] = true,
							},
							["insideInfoPanel"] = false,
							["height"] = 20,
							["customTextFont"] = {
								["enable"] = true,
								["font"] = "傷害數字",
							},
							["width"] = 214,
						},
						["height"] = 45,
						["buffs"] = {
							["countFontSize"] = 10,
							["yOffset"] = 15,
							["durationPosition"] = "BOTTOM",
							["numrows"] = 2,
							["attachTo"] = "FRAME",
							["perrow"] = 6,
						},
						["CombatIcon"] = {
							["xOffset"] = -81,
							["yOffset"] = 28,
						},
						["aurabar"] = {
							["enable"] = false,
							["height"] = 10,
						},
					},
					["focustarget"] = {
						["castbar"] = {
							["width"] = 80,
						},
						["width"] = 80,
						["power"] = {
							["enable"] = false,
						},
					},
					["pet"] = {
						["infoPanel"] = {
							["height"] = 14,
						},
						["debuffs"] = {
							["enable"] = true,
						},
						["disableTargetGlow"] = false,
						["power"] = {
							["height"] = 4,
						},
						["customTexts"] = {
							["名字"] = {
								["attachTextTo"] = "Health",
								["xOffset"] = 0,
								["text_format"] = "[namecolor][name:medium]",
								["yOffset"] = 0,
								["font"] = "聊天",
								["justifyH"] = "CENTER",
								["fontOutline"] = "OUTLINE",
								["enable"] = true,
								["size"] = 10,
							},
						},
						["castbar"] = {
							["iconSize"] = 32,
							["width"] = 65,
						},
						["name"] = {
							["text_format"] = "[happiness:full]",
							["yOffset"] = 10,
						},
						["width"] = 65,
					},
					["target"] = {
						["debuffs"] = {
							["countFontSize"] = 5,
							["yOffset"] = 16,
							["numrows"] = 2,
							["priority"] = "Blacklist,Personal,nonPersonal",
							["attachTo"] = "FRAME",
							["perrow"] = 7,
						},
						["portrait"] = {
							["overlay"] = true,
							["overlayAlpha"] = 0.7,
						},
						["DragonOverlayStyle"] = "classic",
						["CombatIcon"] = {
							["xOffset"] = 81,
							["yOffset"] = 27,
						},
						["aurabar"] = {
							["enable"] = false,
							["height"] = 18,
						},
						["power"] = {
							["attachTextTo"] = "Power",
							["xOffset"] = -2,
							["text_format"] = "[powercolor][  >power:current]",
							["position"] = "RIGHT",
						},
						["customTexts"] = {
							["精英"] = {
								["attachTextTo"] = "Health",
								["xOffset"] = -80,
								["text_format"] = "[classification:icon][range]",
								["yOffset"] = 25,
								["font"] = "聊天",
								["justifyH"] = "CENTER",
								["fontOutline"] = "OUTLINE",
								["enable"] = true,
								["size"] = 10,
							},
						},
						["healPrediction"] = {
							["absorbStyle"] = "NORMAL",
						},
						["disableMouseoverGlow"] = true,
						["width"] = 180,
						["castbar"] = {
							["customTimeFont"] = {
								["enable"] = true,
							},
							["insideInfoPanel"] = false,
							["height"] = 10,
							["customTextFont"] = {
								["enable"] = true,
								["font"] = "傷害數字",
							},
							["width"] = 180,
						},
						["health"] = {
							["attachTextTo"] = "InfoPanel",
							["xOffset"] = 0,
							["text_format"] = "[health:current:shortvalue]  -  [perhp]%",
							["yOffset"] = 3,
						},
						["fader"] = {
							["range"] = false,
						},
						["height"] = 45,
						["buffs"] = {
							["countFontSize"] = 5,
							["yOffset"] = -73,
							["anchorPoint"] = "BOTTOMLEFT",
							["growthX"] = "RIGHT",
							["numrows"] = 2,
							["priority"] = "Blacklist,Dispellable,Personal,nonPersonal,PlayerBuffs,Whitelist",
							["attachTo"] = "DEBUFFS",
							["perrow"] = 7,
						},
						["orientation"] = "LEFT",
						["name"] = {
							["position"] = "TOPRIGHT",
							["text_format"] = "[level]   [name]",
							["yOffset"] = 16,
						},
					},
					["arena"] = {
						["enable"] = false,
						["height"] = 40,
						["width"] = 230,
					},
					["party"] = {
						["debuffs"] = {
							["countFontSize"] = 8,
							["sizeOverride"] = 22,
							["priority"] = "",
							["numrows"] = 2,
							["yOffset"] = 11,
						},
						["power"] = {
							["text_format"] = "",
							["height"] = 4,
						},
						["healPrediction"] = {
							["enable"] = true,
						},
						["width"] = 120,
						["name"] = {
							["xOffset"] = -5,
							["text_format"] = "[level][name:medium] [difficultycolor]",
							["yOffset"] = 3,
						},
						["classbar"] = {
							["height"] = 5,
						},
						["health"] = {
							["position"] = "RIGHT",
							["text_format"] = " [perhp]%",
							["yOffset"] = -10,
						},
						["verticalSpacing"] = 6,
						["height"] = 44,
						["buffs"] = {
							["countFontSize"] = 8,
							["sizeOverride"] = 22,
							["yOffset"] = 11,
							["enable"] = true,
							["priority"] = "",
							["numrows"] = 2,
							["perrow"] = 5,
						},
						["visibility"] = "[@raid2,exists][@party1,noexists] hide;show",
						["rdebuffs"] = {
							["font"] = "PT Sans Narrow",
							["yOffset"] = 12,
							["size"] = 20,
						},
					},
					["raid40"] = {
						["name"] = {
							["text_format"] = "[name:short]",
						},
						["power"] = {
							["enable"] = true,
						},
						["height"] = 40,
						["healPrediction"] = {
							["enable"] = true,
						},
						["health"] = {
							["text_format"] = "[health:deficit]",
						},
						["enable"] = false,
					},
					["focus"] = {
						["debuffs"] = {
							["attachTo"] = "HEALTH",
							["sizeOverride"] = 30,
							["priority"] = "Blacklist,Personal,nonPersonal,Boss,RaidDebuffs,Dispellable,Whitelist",
						},
						["power"] = {
							["height"] = 3,
						},
						["enable"] = false,
						["width"] = 100,
						["name"] = {
							["yOffset"] = 7,
						},
						["height"] = 40,
						["castbar"] = {
							["width"] = 100,
						},
						["CombatIcon"] = {
							["enable"] = false,
						},
						["health"] = {
							["xOffset"] = -25,
							["text_format"] = "[perhp]%",
							["yOffset"] = -12,
						},
					},
					["assist"] = {
						["enable"] = false,
					},
					["raid"] = {
						["debuffs"] = {
							["enable"] = true,
							["anchorPoint"] = "CENTER",
						},
						["height"] = 45,
						["healPrediction"] = {
							["enable"] = true,
						},
						["buffs"] = {
							["enable"] = true,
							["anchorPoint"] = "CENTER",
						},
						["enable"] = false,
					},
					["boss"] = {
						["infoPanel"] = {
							["height"] = 17,
						},
						["debuffs"] = {
							["maxDuration"] = 300,
							["sizeOverride"] = 27,
							["yOffset"] = -16,
						},
						["name"] = {
							["yOffset"] = 33,
						},
						["castbar"] = {
							["width"] = 230,
						},
						["height"] = 40,
						["buffs"] = {
							["maxDuration"] = 300,
							["sizeOverride"] = 27,
							["yOffset"] = 16,
						},
						["health"] = {
							["xOffset"] = 0,
							["text_format"] = "[healthcolor][health:current]（[health:percent]）",
						},
						["width"] = 230,
					},
					["targettarget"] = {
						["debuffs"] = {
							["enable"] = false,
							["anchorPoint"] = "TOPRIGHT",
						},
						["threatStyle"] = "GLOW",
						["power"] = {
							["enable"] = false,
						},
						["disableMouseoverGlow"] = true,
						["width"] = 100,
						["name"] = {
							["xOffset"] = -18,
							["text_format"] = "[name:medium]",
							["yOffset"] = 5,
						},
						["height"] = 35,
						["health"] = {
							["xOffset"] = 0,
							["text_format"] = "[perhp]%",
							["yOffset"] = -10,
						},
						["raidicon"] = {
							["attachTo"] = "LEFT",
							["xOffset"] = 2,
							["enable"] = false,
							["yOffset"] = 0,
						},
					},
				},
				["smoothbars"] = true,
				["colors"] = {
					["auraBarBuff"] = {
						["b"] = 0.0392156019806862,
						["g"] = 0.486273437738419,
						["r"] = 0.999997794628143,
					},
					["castClassColor"] = true,
					["healthclass"] = true,
				},
				["fontOutline"] = "THICKOUTLINE",
				["smartRaidFilter"] = false,
				["statusbar"] = "ElvUI Blank",
				["cooldown"] = {
					["fonts"] = {
						["enable"] = true,
						["fontSize"] = 15,
					},
				},
				["font"] = "默认",
			},
			["datatexts"] = {
				["fontSize"] = 10,
				["panels"] = {
					["MinimapPanel"] = {
						["border"] = false,
						["backdrop"] = false,
					},
					["RightChatDataPanel"] = {
						"Gold", -- [1]
						"MeetingStone", -- [2]
						"System", -- [3]
						["enable"] = false,
						["backdrop"] = false,
					},
					["LeftChatDataPanel"] = {
						"WeakAuras", -- [1]
						"ElvUI", -- [2]
						"Durability", -- [3]
						["panelTransparency"] = true,
						["backdrop"] = false,
						["enable"] = false,
					},
				},
				["fontOutline"] = "OUTLINE",
			},
			["nameplates_v1"] = {
				["classbar"] = {
					["position"] = "BELOW",
				},
				["cooldown"] = {
					["fonts"] = {
						["enable"] = true,
					},
				},
				["units"] = {
					["ENEMY_PLAYER"] = {
						["debuffs"] = {
							["baseHeight"] = 20,
						},
						["buffs"] = {
							["baseHeight"] = 20,
						},
					},
					["FRIENDLY_NPC"] = {
						["healthbar"] = {
							["text"] = {
								["enable"] = false,
							},
						},
					},
				},
			},
			["nameplates"] = {
				["clampToScreen"] = true,
				["statusbar"] = "Melli",
				["units"] = {
					["ENEMY_NPC"] = {
						["debuffs"] = {
							["yOffset"] = 15,
							["size"] = 20,
						},
						["health"] = {
							["text"] = {
								["fontSize"] = 10,
								["format"] = "[perhp]%",
							},
						},
						["buffs"] = {
							["enable"] = false,
							["size"] = 20,
						},
					},
					["TARGET"] = {
						["classpower"] = {
							["enable"] = true,
							["yOffset"] = -11,
							["width"] = 60,
						},
					},
					["FRIENDLY_NPC"] = {
						["debuffs"] = {
							["enable"] = false,
							["yOffset"] = 15,
							["size"] = 20,
						},
						["health"] = {
							["text"] = {
								["fontSize"] = 10,
								["format"] = "[perhp]%",
							},
						},
						["buffs"] = {
							["enable"] = false,
							["size"] = 20,
						},
					},
					["ENEMY_PLAYER"] = {
						["debuffs"] = {
							["yOffset"] = 20,
							["size"] = 20,
						},
						["health"] = {
							["text"] = {
								["fontSize"] = 10,
								["format"] = "[health:current:shortvalue]  -  [perhp]%",
							},
						},
						["buffs"] = {
							["size"] = 20,
						},
					},
					["FRIENDLY_PLAYER"] = {
						["buffs"] = {
							["enable"] = false,
							["size"] = 20,
						},
						["debuffs"] = {
							["yOffset"] = 15,
							["size"] = 20,
						},
						["health"] = {
							["text"] = {
								["fontSize"] = 10,
								["format"] = "[perhp]%",
							},
						},
						["nameOnly"] = true,
					},
				},
			},
			["chat"] = {
				["customTimeColor"] = {
					["b"] = 0.70196078431373,
					["g"] = 0.70196078431373,
					["r"] = 0.70196078431373,
				},
				["panelWidth"] = 350,
				["maxLines"] = 353,
				["panelColor"] = {
					["a"] = 0.1851545572280884,
					["b"] = 0.05882352941176471,
					["g"] = 0.05882352941176471,
					["r"] = 0.05882352941176471,
				},
				["panelWidthRight"] = 50,
				["copyChatLines"] = true,
				["panelHeightRight"] = 60,
				["tabSelectorColor"] = {
					["b"] = 0.407842248678207,
					["g"] = 0.956860661506653,
					["r"] = 0.999997794628143,
				},
				["separateSizes"] = true,
				["panelHeight"] = 260,
				["editBoxPosition"] = "ABOVE_CHAT",
				["scrollDownInterval"] = 30,
				["tabSelector"] = "NONE",
				["panelBackdrop"] = "LEFT",
			},
			["cooldown"] = {
				["fonts"] = {
					["enable"] = true,
				},
				["hideBlizzard"] = true,
			},
			["AuraWatch"] = {
				["loadDefault"] = true,
				["myclass"] = "ROGUE",
			},
		},
		["简洁2-独立头像"] = {
			["databars"] = {
				["reputation"] = {
					["enable"] = true,
					["height"] = 6,
					["width"] = 393,
				},
				["threat"] = {
					["enable"] = false,
					["height"] = 24,
					["width"] = 472,
				},
				["experience"] = {
					["height"] = 8,
					["textFormat"] = "PERCENT",
					["width"] = 393,
				},
				["petExperience"] = {
					["width"] = 65,
				},
			},
			["currentTutorial"] = 3,
			["general"] = {
				["loginmessage"] = false,
				["fontSize"] = 14,
				["itemLevel"] = {
					["itemLevelFontSize"] = 10,
					["displayCharacterInfo"] = false,
				},
				["autoTrackReputation"] = true,
				["afk"] = false,
				["numberPrefixStyle"] = "CHINESE",
				["minimap"] = {
					["locationText"] = "SHOW",
					["icons"] = {
						["tracking"] = {
							["xOffset"] = -12,
							["scale"] = 0.6,
							["position"] = "TOPLEFT",
						},
					},
					["size"] = 140,
				},
				["bonusObjectivePosition"] = "AUTO",
				["valuecolor"] = {
					["b"] = 0.407842248678207,
					["g"] = 0.956860661506653,
					["r"] = 0.999997794628143,
				},
				["altPowerBar"] = {
					["statusBar"] = "Melli",
				},
				["backdropfadecolor"] = {
					["a"] = 0.85700567066669,
					["b"] = 0.058823529411765,
					["g"] = 0.058823529411765,
					["r"] = 0.058823529411765,
				},
				["objectiveFrameHeight"] = 550,
				["bottomPanel"] = false,
				["interruptAnnounce"] = "RAID",
				["totems"] = {
					["spacing"] = 8,
					["size"] = 30,
					["growthDirection"] = "HORIZONTAL",
				},
			},
			["movers"] = {
				["ElvUF_FocusCastbarMover"] = "TOPLEFT,ElvUF_Focus,BOTTOMLEFT,0,-1",
				["ElvUF_FocusTargetMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,361,-92",
				["BuffsMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-161,-5",
				["BossButton"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-441,346",
				["LootFrameMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,423,-416",
				["ZoneAbility"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,422,323",
				["DurabilityFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-76,-324",
				["ElvUF_PetCastbarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,423,121",
				["VehicleSeatMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-66,-261",
				["ElvUF_TargetTargetMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-405,256",
				["EuiExecuteMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,634,-367",
				["LossControlMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-407,101",
				["WTCombatAlertFrameMover"] = "TOP,ElvUIParent,TOP,0,-276",
				["MirrorTimer1Mover"] = "TOP,ElvUIParent,TOP,0,-140",
				["QuestTimerFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,0,-171",
				["AltPowerBarMover"] = "TOP,ElvUIParent,TOP,0,-196",
				["ReputationBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,0",
				["ObjectiveFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-83,-236",
				["BNETMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,315",
				["ShiftAB"] = "BOTTOM,ElvUIParent,BOTTOM,-175,104",
				["ElvUF_TargetCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,253,245",
				["ElvUF_PlayerMover"] = "BOTTOM,ElvUIParent,BOTTOM,-253,256",
				["RightChatMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-4,4",
				["RaidCDAnchorMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,366,-300",
				["AutoButtonAnchor3Mover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-208,214",
				["ElvUF_AssistMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,123,-43",
				["WTRaidMarkersBarAnchor"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,310",
				["TopCenterContainerMover"] = "TOP,ElvUIParent,TOP,0,-51",
				["ThreatBarMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-4,4",
				["PetAB"] = "BOTTOM,ElvUIParent,BOTTOM,46,103",
				["ElvUF_RaidMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,0,-116",
				["LeftChatMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,27",
				["GMMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,315",
				["BagsMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-4,33",
				["WTChatBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,288",
				["WTMinimapButtonBarAnchor"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-4,-4",
				["ElvUF_FocusMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,222,-81",
				["AutoButtonAnchorMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-66,214",
				["ClassBarMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,475,-31",
				["MicrobarMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-20,4",
				["PetExperienceBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,423,176",
				["WTCustomEmoteFrameMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,324,56",
				["ArenaHeaderMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-156,-264",
				["ExperienceBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,6",
				["MirrorTimer2Mover"] = "TOP,MirrorTimer1,BOTTOM,0,0",
				["ElvUF_TargetMover"] = "BOTTOM,ElvUIParent,BOTTOM,253,256",
				["ElvAB_4"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-525,10",
				["TotemBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,371,255",
				["ElvUF_Raid40Mover"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-235",
				["ElvUIBankMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,191,289",
				["PowerBarContainerMover"] = "TOP,ElvUIParent,TOP,0,-55",
				["ElvAB_1"] = "BOTTOM,ElvUIParent,BOTTOM,0,13",
				["ElvAB_2"] = "BOTTOM,ElvUIParent,BOTTOM,164,436",
				["BelowMinimapContainerMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-4,-166",
				["EUIMinimapButtonMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-138,-75",
				["WTGameBarAnchor"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-4",
				["WTSwitchButtonBarMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-60,-196",
				["WTParagonReputationToastFrameMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-49",
				["ElvAB_3"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,525,10",
				["ElvAB_5"] = "BOTTOM,ElvUIParent,BOTTOM,0,43",
				["VehicleLeaveButton"] = "BOTTOM,ElvUIParent,BOTTOM,206,131",
				["ElvUIBagMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-420,-249",
				["LevelUpBossBannerMover"] = "TOP,ElvUIParent,TOP,0,-107",
				["ExAE_FrameMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,360,276",
				["ElvUF_PlayerCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,131",
				["VOICECHAT"] = "TOP,ElvUIParent,TOP,-251,-3",
				["MirrorTimer3Mover"] = "TOP,MirrorTimer2,BOTTOM,0,0",
				["HonorBarMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-2,-251",
				["ElvAB_6"] = "BOTTOM,ElvUIParent,BOTTOM,0,73",
				["TooltipMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-78,323",
				["ElvUF_TankMover"] = "TOPLEFT,UIParent,TOPLEFT,4,-67",
				["BossHeaderMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-158,-262",
				["ElvUF_PetMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,423,139",
				["TalkingHeadFrameMover"] = "BOTTOM,ElvUIParent,BOTTOM,-2,144",
				["ElvUF_PartyMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,121,-291",
				["AlertFrameMover"] = "BOTTOM,ElvUIParent,BOTTOM,-3,417",
				["DebuffsMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-160,-133",
				["MinimapMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-4,-4",
			},
			["convertPages"] = true,
			["v11NamePlateReset"] = true,
			["tooltip"] = {
				["itemCount"] = "NONE",
				["healthBar"] = {
					["height"] = 12,
					["fontSize"] = 12,
					["font"] = "PT Sans Narrow",
					["fontOutline"] = "NONE",
				},
				["showMount"] = false,
				["cursorAnchorType"] = "ANCHOR_CURSOR_RIGHT",
				["alwaysShowRealm"] = true,
				["modifierID"] = "SHIFT",
				["guildRanks"] = false,
			},
			["auras"] = {
				["buffs"] = {
					["timeFontOutline"] = "OUTLINE",
					["countFont"] = "傷害數字",
					["size"] = 26,
					["timeFont"] = "EUI",
					["timeFontSize"] = 11,
					["countFontOutline"] = "OUTLINE",
				},
				["debuffs"] = {
					["timeFontOutline"] = "OUTLINE",
					["countFont"] = "傷害數字",
					["timeFont"] = "傷害數字",
					["size"] = 26,
					["countFontOutline"] = "OUTLINE",
				},
			},
			["dbConverted"] = 2.3,
			["unitframe"] = {
				["statusbar"] = "ElvUI Blank",
				["font"] = "聊天",
				["colors"] = {
					["auraBarBuff"] = {
						["b"] = 0.0392156019806862,
						["g"] = 0.486273437738419,
						["r"] = 0.999997794628143,
					},
					["castClassColor"] = true,
					["healthclass"] = true,
				},
				["fontOutline"] = "THICKOUTLINE",
				["smoothbars"] = true,
				["smartRaidFilter"] = false,
				["cooldown"] = {
					["fonts"] = {
						["enable"] = true,
						["fontSize"] = 15,
					},
				},
				["units"] = {
					["tank"] = {
						["width"] = 85,
						["verticalSpacing"] = 2,
					},
					["focustarget"] = {
						["castbar"] = {
							["width"] = 80,
						},
						["width"] = 80,
						["power"] = {
							["enable"] = false,
						},
					},
					["pet"] = {
						["infoPanel"] = {
							["height"] = 14,
						},
						["debuffs"] = {
							["enable"] = true,
						},
						["disableTargetGlow"] = false,
						["power"] = {
							["height"] = 4,
						},
						["customTexts"] = {
							["名字"] = {
								["attachTextTo"] = "Health",
								["xOffset"] = 0,
								["text_format"] = "[namecolor][name:medium]",
								["yOffset"] = 0,
								["font"] = "聊天",
								["justifyH"] = "CENTER",
								["fontOutline"] = "OUTLINE",
								["enable"] = true,
								["size"] = 10,
							},
						},
						["castbar"] = {
							["iconSize"] = 32,
							["width"] = 65,
						},
						["name"] = {
							["text_format"] = "[happiness:full]",
							["yOffset"] = 10,
						},
						["width"] = 65,
					},
					["target"] = {
						["debuffs"] = {
							["countFontSize"] = 5,
							["yOffset"] = 16,
							["numrows"] = 2,
							["priority"] = "Blacklist,Personal,nonPersonal",
							["attachTo"] = "FRAME",
							["perrow"] = 7,
						},
						["portrait"] = {
							["enable"] = true,
							["camDistanceScale"] = 1,
							["overlayAlpha"] = 0.65,
						},
						["power"] = {
							["attachTextTo"] = "Power",
							["xOffset"] = -2,
							["text_format"] = "[powercolor][  >power:current]",
							["position"] = "RIGHT",
						},
						["customTexts"] = {
							["精英"] = {
								["attachTextTo"] = "Health",
								["xOffset"] = -80,
								["text_format"] = "[classification:icon][range]",
								["yOffset"] = 25,
								["font"] = "聊天",
								["justifyH"] = "CENTER",
								["fontOutline"] = "OUTLINE",
								["enable"] = true,
								["size"] = 10,
							},
						},
						["disableMouseoverGlow"] = true,
						["width"] = 180,
						["fader"] = {
							["range"] = false,
						},
						["health"] = {
							["attachTextTo"] = "InfoPanel",
							["position"] = "LEFT",
							["xOffset"] = 0,
							["text_format"] = " [health:current:shortvalue]  -  [perhp]%",
							["yOffset"] = 3,
						},
						["name"] = {
							["position"] = "TOPRIGHT",
							["text_format"] = "[level]   [name]",
							["yOffset"] = 16,
						},
						["castbar"] = {
							["height"] = 10,
							["insideInfoPanel"] = false,
							["width"] = 180,
						},
						["height"] = 45,
						["buffs"] = {
							["countFontSize"] = 5,
							["yOffset"] = -73,
							["anchorPoint"] = "BOTTOMLEFT",
							["growthX"] = "RIGHT",
							["numrows"] = 2,
							["priority"] = "Blacklist,Dispellable,Personal,nonPersonal,PlayerBuffs,Whitelist",
							["attachTo"] = "DEBUFFS",
							["perrow"] = 7,
						},
						["CombatIcon"] = {
							["xOffset"] = 81,
							["yOffset"] = 27,
						},
						["aurabar"] = {
							["enable"] = false,
							["height"] = 18,
						},
					},
					["arena"] = {
						["enable"] = false,
					},
					["player"] = {
						["RestIcon"] = {
							["size"] = 20,
						},
						["debuffs"] = {
							["countFontSize"] = 10,
							["sizeOverride"] = 25,
							["yOffset"] = -30,
							["anchorPoint"] = "BOTTOMLEFT",
							["numrows"] = 2,
							["perrow"] = 6,
						},
						["portrait"] = {
							["enable"] = true,
							["camDistanceScale"] = 1,
							["overlayAlpha"] = 0.7,
						},
						["power"] = {
							["attachTextTo"] = "Power",
							["text_format"] = "[powercolor][curpp]",
						},
						["disableMouseoverGlow"] = true,
						["width"] = 180,
						["name"] = {
							["position"] = "TOPLEFT",
							["text_format"] = "[name]   [level]",
							["yOffset"] = 16,
						},
						["classbar"] = {
							["detachedWidth"] = 360,
							["autoHide"] = true,
						},
						["health"] = {
							["xOffset"] = 0,
							["text_format"] = "[health:current:shortvalue]               [perhp]%",
							["position"] = "RIGHT",
						},
						["castbar"] = {
							["height"] = 20,
							["insideInfoPanel"] = false,
							["width"] = 214,
						},
						["height"] = 45,
						["buffs"] = {
							["countFontSize"] = 10,
							["yOffset"] = 15,
							["durationPosition"] = "BOTTOM",
							["numrows"] = 2,
							["attachTo"] = "FRAME",
							["perrow"] = 6,
						},
						["CombatIcon"] = {
							["xOffset"] = -81,
							["yOffset"] = 28,
						},
						["aurabar"] = {
							["enable"] = false,
							["height"] = 10,
						},
					},
					["raid40"] = {
						["health"] = {
							["text_format"] = "[health:deficit]",
						},
						["power"] = {
							["enable"] = true,
						},
						["height"] = 40,
						["healPrediction"] = {
							["enable"] = true,
						},
						["enable"] = false,
					},
					["focus"] = {
						["enable"] = false,
						["width"] = 120,
						["health"] = {
							["xOffset"] = -37,
							["text_format"] = " [perhp]%",
							["yOffset"] = -18,
						},
						["castbar"] = {
							["width"] = 120,
						},
					},
					["assist"] = {
						["enable"] = false,
					},
					["raid"] = {
						["debuffs"] = {
							["enable"] = true,
							["anchorPoint"] = "CENTER",
						},
						["height"] = 45,
						["healPrediction"] = {
							["enable"] = true,
						},
						["buffs"] = {
							["enable"] = true,
							["anchorPoint"] = "CENTER",
						},
						["enable"] = false,
					},
					["party"] = {
						["debuffs"] = {
							["countFontSize"] = 8,
							["sizeOverride"] = 22,
							["priority"] = "",
							["numrows"] = 2,
							["yOffset"] = 11,
						},
						["power"] = {
							["text_format"] = "",
							["height"] = 4,
						},
						["healPrediction"] = {
							["enable"] = true,
						},
						["width"] = 120,
						["rdebuffs"] = {
							["font"] = "PT Sans Narrow",
							["yOffset"] = 12,
							["size"] = 20,
						},
						["name"] = {
							["text_format"] = "[namecolor][name:medium] [difficultycolor][level]",
						},
						["buffs"] = {
							["countFontSize"] = 8,
							["sizeOverride"] = 22,
							["yOffset"] = 11,
							["enable"] = true,
							["priority"] = "",
							["numrows"] = 2,
							["perrow"] = 5,
						},
						["height"] = 44,
						["verticalSpacing"] = 6,
						["visibility"] = "[@raid2,exists][@party1,noexists] hide;show",
						["health"] = {
							["text_format"] = "",
						},
					},
					["targettarget"] = {
						["width"] = 100,
						["debuffs"] = {
							["enable"] = false,
							["anchorPoint"] = "TOPRIGHT",
						},
						["threatStyle"] = "GLOW",
						["power"] = {
							["enable"] = false,
						},
						["height"] = 35,
						["name"] = {
							["text_format"] = "[name:medium]",
						},
						["disableMouseoverGlow"] = true,
						["raidicon"] = {
							["attachTo"] = "LEFT",
							["xOffset"] = 2,
							["enable"] = false,
							["yOffset"] = 0,
						},
					},
				},
			},
			["datatexts"] = {
				["fontSize"] = 10,
				["panels"] = {
					["MinimapPanel"] = {
						["border"] = false,
						["backdrop"] = false,
					},
					["RightChatDataPanel"] = {
						"Gold", -- [1]
						"MeetingStone", -- [2]
						"System", -- [3]
						["enable"] = false,
						["backdrop"] = false,
					},
					["LeftChatDataPanel"] = {
						"WeakAuras", -- [1]
						"ElvUI", -- [2]
						"Durability", -- [3]
						["enable"] = false,
						["backdrop"] = false,
						["panelTransparency"] = true,
					},
				},
				["fontOutline"] = "OUTLINE",
			},
			["actionbar"] = {
				["bar3"] = {
					["point"] = "TOPLEFT",
					["buttonSize"] = 31,
					["macrotext"] = true,
					["buttonsPerRow"] = 4,
					["visibility"] = "[petbattle] hide; show",
					["buttons"] = 12,
				},
				["bar6"] = {
					["enabled"] = true,
					["macrotext"] = true,
					["point"] = "TOPLEFT",
					["buttonSize"] = 31,
				},
				["bar2"] = {
					["macrotext"] = true,
					["visibility"] = "[petbattle] hide; show",
					["buttonSize"] = 31,
				},
				["bar10"] = {
					["macrotext"] = true,
				},
				["bar8"] = {
					["macrotext"] = true,
				},
				["bar5"] = {
					["buttons"] = 12,
					["macrotext"] = true,
					["buttonsPerRow"] = 12,
					["visibility"] = "[petbattle] hide; show",
					["buttonSize"] = 31,
				},
				["microbar"] = {
					["buttonSize"] = 23,
					["buttons"] = 7,
				},
				["cooldown"] = {
					["fonts"] = {
						["enable"] = true,
					},
					["override"] = false,
				},
				["font"] = "傷害數字",
				["bar7"] = {
					["macrotext"] = true,
				},
				["bar1"] = {
					["macrotext"] = true,
					["buttonSize"] = 31,
				},
				["bar9"] = {
					["macrotext"] = true,
				},
				["stanceBar"] = {
					["buttonSpacing"] = 1,
					["style"] = "classic",
					["buttonSize"] = 25,
				},
				["barPet"] = {
					["backdrop"] = false,
					["buttonsPerRow"] = 10,
					["point"] = "TOPLEFT",
					["buttonSize"] = 28,
				},
				["bar4"] = {
					["point"] = "TOPLEFT",
					["buttonSize"] = 31,
					["macrotext"] = true,
					["buttonsPerRow"] = 4,
					["visibility"] = "[petbattle] hide; show",
					["backdrop"] = false,
				},
			},
			["nameplates"] = {
				["clampToScreen"] = true,
				["statusbar"] = "Melli",
				["units"] = {
					["ENEMY_NPC"] = {
						["debuffs"] = {
							["yOffset"] = 15,
							["size"] = 20,
						},
						["health"] = {
							["text"] = {
								["format"] = "[perhp]%",
							},
						},
						["buffs"] = {
							["enable"] = false,
							["size"] = 20,
						},
					},
					["TARGET"] = {
						["classpower"] = {
							["enable"] = true,
							["yOffset"] = -11,
							["width"] = 60,
						},
					},
					["FRIENDLY_NPC"] = {
						["debuffs"] = {
							["enable"] = false,
							["size"] = 20,
						},
						["health"] = {
							["text"] = {
								["format"] = "[perhp]%",
							},
						},
						["buffs"] = {
							["enable"] = false,
							["size"] = 20,
						},
					},
					["ENEMY_PLAYER"] = {
						["debuffs"] = {
							["yOffset"] = 15,
							["size"] = 20,
						},
						["health"] = {
							["text"] = {
								["format"] = "[health:current:shortvalue]  -  [perhp]%",
							},
						},
						["buffs"] = {
							["size"] = 20,
						},
					},
					["FRIENDLY_PLAYER"] = {
						["buffs"] = {
							["enable"] = false,
							["size"] = 20,
						},
						["debuffs"] = {
							["yOffset"] = 15,
							["size"] = 20,
						},
						["health"] = {
							["text"] = {
								["format"] = "[perhp]%",
							},
						},
						["nameOnly"] = true,
					},
				},
			},
			["bags"] = {
				["bagWidth"] = 550,
				["split"] = {
					["bagSpacing"] = 7,
					["bag4"] = true,
					["bag1"] = true,
					["bag2"] = true,
					["bag3"] = true,
				},
				["vendorGrays"] = {
					["enable"] = true,
				},
				["bagSize"] = 40,
				["bankWidth"] = 550,
				["bankSize"] = 40,
				["itemLevelCustomColorEnable"] = true,
				["scrapIcon"] = true,
				["bagBar"] = {
					["growthDirection"] = "HORIZONTAL",
					["size"] = 25,
				},
			},
			["cooldown"] = {
				["fonts"] = {
					["enable"] = true,
				},
				["hideBlizzard"] = true,
			},
			["chat"] = {
				["customTimeColor"] = {
					["b"] = 0.70196078431373,
					["g"] = 0.70196078431373,
					["r"] = 0.70196078431373,
				},
				["emotionIcons"] = false,
				["panelColor"] = {
					["a"] = 0.215930461883545,
					["b"] = 0.0588235294117647,
					["g"] = 0.0588235294117647,
					["r"] = 0.0588235294117647,
				},
				["panelWidth"] = 350,
				["editBoxPosition"] = "ABOVE_CHAT",
				["copyChatLines"] = true,
				["tabSelectorColor"] = {
					["b"] = 0.407842248678207,
					["g"] = 0.956860661506653,
					["r"] = 0.999997794628143,
				},
				["panelWidthRight"] = 300,
				["panelHeight"] = 260,
				["tabSelector"] = "NONE",
				["scrollDownInterval"] = 30,
				["maxLines"] = 353,
				["panelBackdrop"] = "LEFT",
			},
		},
	},
}
ElvPrivateDB = {
	["profileKeys"] = {
		["猎猎思密达 - 阿什坎迪"] = "简洁界面 - 阿什坎迪",
		["简洁界面 - 阿什坎迪"] = "简洁界面 - 阿什坎迪",
		["今晚就动手 - 阿什坎迪"] = "今晚就动手 - 阿什坎迪",
		["简洁界面二 - 阿什坎迪"] = "简洁界面 - 阿什坎迪",
	},
	["profiles"] = {
		["今晚就动手 - 阿什坎迪"] = {
			["general"] = {
				["worldMap"] = false,
			},
			["actionbar"] = {
				["masque"] = {
					["stanceBar"] = true,
					["petBar"] = true,
					["actionbars"] = true,
				},
			},
			["bags"] = {
				["bagBar"] = true,
			},
			["nameplates_v1"] = {
				["enable"] = true,
			},
			["install_complete"] = 1.42,
		},
		["简洁界面 - 阿什坎迪"] = {
			["general"] = {
				["loot"] = false,
				["lootRoll"] = false,
			},
			["bags"] = {
				["enable"] = false,
			},
			["actionbar"] = {
				["masque"] = {
					["stanceBar"] = true,
					["petBar"] = true,
					["actionbars"] = true,
				},
			},
			["install_complete"] = 2.08,
		},
	},
}
