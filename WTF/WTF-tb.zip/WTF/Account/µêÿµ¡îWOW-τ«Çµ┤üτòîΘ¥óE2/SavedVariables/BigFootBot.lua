
ItemSourceDB = {
}
ObjectLocationDB = {
}
CreatureLocationDB = {
}
CreatureDB = {
}
QuestDB = {
}
QuestCompleteDB = {
}
QuestEventDB = {
}
SkillSourceDB = {
}
BigFootBot_Version = {
}
BigFootBot_Info = nil
PlayersDB = {
	["大哥别开火:阿什坎迪"] = {
		["race"] = 8,
		["name"] = "大哥别开火",
		["level"] = 2,
		["gender"] = 2,
		["class"] = 3,
		["server"] = "阿什坎迪",
	},
}
UtilDB = {
}
NPCMarkCollectionDB = {
}
BigFootBot_collectData = {
}
SpamChatDB = {
}
