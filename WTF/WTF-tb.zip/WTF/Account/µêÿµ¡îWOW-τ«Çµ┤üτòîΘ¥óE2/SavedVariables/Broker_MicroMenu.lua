
Broker_MicroMenuDB = {
	["profileKeys"] = {
	},
	["profiles"] = {
		["Default"] = {
		},
	},
}
