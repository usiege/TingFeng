
MasqueDB = {
	["profileKeys"] = {
		["猎猎思密达 - 阿什坎迪"] = "Default",
		["简洁界面 - 阿什坎迪"] = "Default",
		["今晚就动手 - 阿什坎迪"] = "Default",
		["暗黑界面 - 阿什坎迪"] = "Default",
		["简洁界面二 - 阿什坎迪"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["Groups"] = {
				["WeakAuras_R2ysYimvxvp"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_tEL8MyLASNc"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_NJwvJYt)uFb"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_gsFENwmX5Vi"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_YUN()RdsO9G"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_yTkjD4ckMp1"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_M8o8Y1AgiKn"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_)hCCKl94PQR"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_GKt9wmucJtY"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_OyOp60Y7fPi"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_rcunwsaraXE"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_ghQ)3i1qIkY"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_elAnNhLxnti"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_CkmZZHytB15"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_rI28jqbznfB"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_vJy(9DCdJpT"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_Hl27AlE0apM"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_RKfOql)NMRr"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_qouL1RByb3("] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_aNwUM9WjC26"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_VoWoe3Nrqn1"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_Hv5VJYkRw8Q"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_BT0)gycFjET"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_xGAaHi(vjUz"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_ZVAvkXSAIWB"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_PSBeTAN5SX6"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_)eB9w5jhbSA"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_giqX)H67fxz"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_wD3AKYYIFa0"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_pdC1j9i13(B"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_Xt4Dkm2rC56"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_qoCvpEKminH"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras"] = {
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_NIWDWgrZ5nj"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_01deS1TdBzm"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_StlgAqUaViB"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_ngXc(IBI6Gf"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_ONRYRoLHt5p"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_WPZURpxZvdl"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_oV7OGH88nbS"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_OCPY1FXIVsn"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_Lzi7swxwsPc"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_OsXEamCC6gs"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_LTA2xmmpOre"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_eewQ)qNXbGj"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_4Kkrq2XIyNO"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_R10FQk7abTD"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_(G6vQxNrw8u"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_Eu(qaWsfBoh"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_CWKA5taO1Wi"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_GJAdXrNNt(F"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_9bZJ0zPDfG0"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_TY32QcOltoa"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_wlYKnWkraer"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_Hrv9qCAltmA"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_vQEdFWFyTI9"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_r9Lz933VczK"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_i8B5zmW(zdG"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_wfhbcltdoxL"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_KqNkd2l95Qn"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_o38HtJEQjum"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_wHBa6E2dq2k"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_K48rnlhfHQZ"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_KbLNyE9wnQj"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_sYKPdk2L4)i"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_zwzJT3U)fRN"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_KyKTKBJFkVf"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_ga8gybetWTN"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_CZSiASTm)mH"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_IAzKObGM4EC"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_oLckeGnuPG4"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_sszQePISw6T"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_xiH76ucXldG"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_Whrr63XxLOu"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["ElvUI_Buffs"] = {
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_qwzaK8yPVVI"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_DQlRlF6H6AL"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_CQFFiV9Z21i"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_6dp2F8AYWWq"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_P9JYRZWc2(C"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["ElvUI"] = {
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_i3BT3bA34NC"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_0)e8iH2Ip)0"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_A5v9XTch4SJ"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_jbN6VOf10nb"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_5oSU0la1zLU"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_1VgZojlPoeg"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_BahRxduMOeC"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_Gutx0ViM)ZH"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_RQOB8LmlmCa"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_rb6tNEEMnA3"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_seC7yheCnR2"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_qf))RTsQ3oB"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_ezhhmZKIwCB"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_GHjQIVFGzlE"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_zqFrYox03ca"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_NH2He)NnhcY"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_AaDdyEM8yNd"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_QlfEVnjjf5t"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_EtTCeAt7SDE"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_4tOSf2PDAFr"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_3YN7NpZpu(n"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_yxTmMiBUZ(g"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_XQy2XkbeT7m"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_0yze2HVF5l3"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_OLgT086E6aq"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_lGqDy6amJ)7"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_5w8xf3qLS42"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_Im2qUbth5TA"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_QraHI)R8Jxe"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_Q9IWhK232ZJ"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_z26pPgVxv4m"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_sfd9VguzQ1l"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_bgcjWHi5X0C"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_(fCkjKRYtNH"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_sg6nbQPlCIH"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_g3AZvfAtd1b"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_CKGb5GhfJhw"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_wMv5h1pvWfn"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_rsIPzYfUBJI"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_lrPPSbnG5jg"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_RehYZUeQIVP"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_J36Gfr1w38C"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_3KWC6glEE7R"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_HCzrUoTzeXL"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_t6bOHEq1LGc"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_5yvpgvErTh)"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_rVmzj0u2Am4"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_fMy2Zod)kkx"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_5L5enVOpsJo"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_xT057N7xy2O"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_8XnaAL2a6h2"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_M76HhFqDMGN"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_jbB1alGGm5X"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_YNQ3yLY5hS("] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_ImJwWEUG2SD"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_xiJLrXG4kuz"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_ZvYA0Rto9QN"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_o9xBWsGWHnx"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_dK1BAXirHtv"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_B3rDPDm8aCV"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_cTzorRyjxJE"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_vAE(9jqff86"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_Gu(OnCQb5SN"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_VkpwcHowkHx"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_GxeJjwvUN0P"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_8DH3r61qd1t"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_HSW68EXOwvC"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_zLHj98fOCac"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_FW5o()Q6(aO"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_zVHTa0vtfqJ"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_5RWYBpvlxwz"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_)KYVc6UbCnT"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_3mEdd)RVMV3"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_rczclzcgvNu"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_SfAYsT3AVre"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_5Utqfgnawim"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_b)x2CoRZ7tp"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_soJl7(TULvs"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_sAKzdUtJoZj"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_PYYn8c3L(8z"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_rKCq3i3uivd"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["TellMeWhen"] = {
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_L(XcLlJwdHz"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_aDfAOH4XO6j"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_szP2zErA353"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_LSpSsxP(NIf"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_98PmZp(9HxH"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_ID4cTuqpaqj"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_KbFQd8TKWCD"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_rbJ4Nj0fEwG"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_9PdU(SCgKRF"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_LzsMtn8QsQa"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_zw(fgXq5IH0"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_rrruP1di3wc"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_AwSC)NsmfsA"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_5mtGP5EcHbH"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_hxiKkj)l(Ay"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_3fSNtiG7uTb"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_06(teiKBOBS"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_ajSl73m5aa("] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_u7aRmuomenV"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_qDU2lCa9O2A"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_r4cUzgfuvy9"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_Ux96ACN3FJO"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_PBHfo)tCzce"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_ySnnnDHxfss"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_WPv0FdvcViG"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_7PXlsEfw6om"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_Ro6Y2I4L0tn"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_qUUsC5B8WFQ"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_Lt7RfId7)gv"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_OAoOJAKef0Z"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["Masque"] = {
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
				},
				["WeakAuras_A4Itc5smDNq"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_RgVq)lXxTRM"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_65yf7oFlURe"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_EOncD5K0vp4"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_OOreyvkXNum"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_PE)w7y89aWN"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_mWqU)DwK52f"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_ZR5N1BFdeyi"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_Vhmmf)bRUaX"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_)g1w9pj98VE"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_Wo(mdEPwUYM"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_rrNyPijhOAe"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_827rF1461qd"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_krJIqDoBF7C"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_12R66zDk06K"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_)vbszEt8abZ"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_sX41UxrG9Ac"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_trHNMw(XjBN"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_ebhudRMa3UF"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_mF7w6KWRBv0"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_sqir7qHUyXE"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_m1R3oPznjKt"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_HQLcHR(kJHF"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_UuOiRy6yE78"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_HTM5MOYRbi4"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_6D6mcgmJusU"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_A(RV(O7QKh0"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_YCKGqem9Xeb"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_OPcMG1qIrdt"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_XeyPWMtzugP"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_AnFyAGDKMFr"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_bvmrYBogR0q"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_NSk(ivi7h(u"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_Bk)9GHvMb0m"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_y9jk7pzA52G"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_nc3GpCQWTE3"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_JuKWMd2BySH"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_EJVKauSI43x"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_LVcSSRy97uU"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_PVqJMpSGeXZ"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_doyTTBXx)aG"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_LxgTxTTUIGZ"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_8usJhREkYan"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_0scnWxbelYV"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_UUFQJ2dsydk"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_dAWDANJ5uE9"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_HHGZULaPpqA"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_UEQEu)NvI(u"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_7txLr2(wFOS"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_LcfjUSy8NXU"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_MwaFU99tiUk"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_oNSbPIDvOMw"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_0qpgmBoFP7W"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_mW)RwiRNYAf"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_AwRiY0wRYYf"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_fuyw)hy5uZ8"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_FoGa2LwAFVh"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_JuO0IMp0cUW"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_y0OJq)sKRH3"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_zpV8RS8LryK"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_w83D0Lovz9N"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_FzrbqhOcDK8"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_dOpSm5ZQnn1"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_EaV((AOfVOW"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_UIvvhZtNIU8"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_HcmSi89)(Ks"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_AwEPqr7LF8I"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_)ciAyJs(q6m"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_oa6qAn2uz7c"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_qO5A87W(GK1"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_dC0keq9)AYd"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_553xP3WoVBL"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_(Rf7CxzdBWj"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_GeQf9)v83XE"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_HSu03omFsuz"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["ElvUI_Pet Bar"] = {
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_KfBhtIaXqHT"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_P)cH2DC3PGV"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_d0XI3(Yv4xX"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_4fDAaZR217H"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_J6YvHk0faMV"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_LWSQTHuP6ku"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_3IT5hBScIRE"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_0Ud0qZm2Znb"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_kk)tG4ZrAUR"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_MNELpfjgiE4"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_8lbUw3FvnD0"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_qAmMniBXUNx"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_2g0WJfb76Go"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_N2VcG)7ClIu"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_IlmBqpplJ(R"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_EvpYrDW(kDv"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_ELze9SvUIIW"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_flVXna1dtuQ"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_xztDgSIkQ2g"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_q8R2fr)gOjp"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_W4LhrTt8bf5"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_(rjX2)akWhz"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_kS1T)qN39Ju"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_jSfwskF70PJ"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_g53e5Ws0P3L"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_KDeBeGSYZRK"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_WQPzCr02rvB"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_uPXSd6twadC"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_cXuSGOuakgq"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_)2P6wODgpOd"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_Z0mjtUPlaIW"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_tckqFKfgGy2"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_APb6(jGwggx"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_g)MLgF9EQLo"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_2siOcknoDcX"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_GsA28ml6aTO"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_cAI60uu2kjl"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_Ha4PorRbcMs"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_)LQ3)6hrTdz"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_cWTPyJcgrWV"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_KCtWOgHQ96V"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["TrufiGCD"] = {
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_R3Th)RqCnHo"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_DvATF0auZCR"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_wroROj6DFLe"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_BDQvI8HtAOa"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_X33nno(ZopQ"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_aJyTspXsqB0"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_a7HLYINWYLL"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_nplGuoD4n93"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_7zTMKyMAiIZ"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_wTYhRtpSDBy"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_)kdRXcFhGCq"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_QflFKfJ1SQ)"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_Ay(OyltsgPT"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_z2nO9ES2aYe"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_Ubbe7)c4zME"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_t27H632HDiv"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_16PDDXXxllG"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_((0GGr(A8Gv"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_of2cIJBdNW3"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_r5SMDCujlcn"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_xygWVLMi2vW"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_iblMih4QexS"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_SusLX8)8BgF"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_(TRRZ(uk3CA"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_688Fq6cN1Po"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_LQlkb0JjT3F"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_)aEEPdY2aTt"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_esE633vv0KS"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_2RBpqHiYPjY"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_wPf4Ow30Njz"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_obdgQanDodn"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_G)SooKJUuHE"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_6bNoECxEvdD"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_4jGE28W8cIO"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_N1(PbFTJSvW"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_FlMW26fyu8u"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_jNjeu3IZLj0"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_tx0Wcf(uuES"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_7JuhoyYcHXu"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_nvE6oi6Jksa"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_75DF4O2TOMv"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_IuPrs5(TPTG"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["OmniBar"] = {
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_oZLVqyqchSH"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_gHYAR7UddNp"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_kN8B6wjArgr"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_HWW2HCawJpb"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_BSRBV6sK0iL"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_i53BUbQ6qJi"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_mYILDqNn0yQ"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_n5Pb3Dhhkb5"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_bx6UkGrdaOp"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_0NJM7xB5EgB"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_t9XXcGKFB8e"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_6JQbBX(9oNC"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_reLhqLjY(W0"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_qe2Obd36hEF"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_)E3aI7L(hjs"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_tHMfQNysivc"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_jorwyGynA(("] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_68)xaGF9Tac"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["ElvUI_ActionBars"] = {
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_qm)w2LvHUPI"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_wOsR(rDfhbT"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_jnmJsMDe(6y"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_SObCNWXhhIu"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_B8yOfxme(V1"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_rixW7HYVvI9"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_0c8vNs()yvc"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_1tvZOU7w8Y7"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_cxNXxCCnmJw"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_YEuFSA(NAUg"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_qpc0g)iw2ld"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_AlKP8ti21Lw"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_GV6zEX)zi9D"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_15X5nTGpmiB"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_S5Vdf86u7j3"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_GMfJ9mszDko"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_Zq18Ot5j3ob"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_NXi(Fj0882P"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_)zNrqePQqoW"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_RZdqs4XLZV1"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_XPmIY8L9UWO"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_LnXKBcErqaf"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_pK1SpNVEiIV"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_gIxtEcLmgda"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_iWcWLqLaGqZ"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_QThOon3)UuW"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_Y(XnAqyMRL7"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_W2saEK0cs5b"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_SLNXjH5qQUe"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_g5FFUDT3Dd7"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_ddkzXtcnE1c"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_OfuNGuW33qX"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_Nfvyx0AvydZ"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_QVQ6AW6uRoE"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_TU7(230sBPl"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_l1ZN3WK12(r"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_9(DaQ8d6k8O"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_kMTbkVGeUTe"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_n7QQ0FXtrPs"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_gE1b)DLGXtE"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_qXCFRde2sui"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_dHE0AdDNA55"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_g2NhXZ6vF8X"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_jrdKuv4kqOa"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_3Kh7b5SPisQ"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_sBlI6zkjiKR"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_XOiM4bRuuuk"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_QoezhPk7o3W"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_8ufpl1T4ohL"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_ev7DUSbiFxA"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_YEf20dLOD8o"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_rt92GEa60cE"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_NCNIbxrSlz3"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_grHzZ7(r4Tf"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_2xCNeTbV9v8"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_5Xv9eG7rh3B"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_efP1N9SvEe7"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_ZBSFz51p9HZ"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_9(wssH567lA"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_bu7lzkfct8v"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_cfX1ZDdkETu"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_g()KUeTejL9"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_EKazP6dlf(Q"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_P4RB0sbSLj5"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_NyZ7ZqAxWoE"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_m1w95TauGcp"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_7vw1aObjERb"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_jTUs36WN)fJ"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_zFLY)16VXo7"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_FsRkF88w1hc"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_rIfS5FuJrZ9"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_)QfT4aqWnHS"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_L3zu3Gye1Ug"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["ElvUI_Stance Bar"] = {
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_GMbAR6xfznb"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_S7vjNzQupkm"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_)uNmRCG4mDU"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_ZERLeTNqN83"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_48mP(4LuIM9"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_Xlmq3u9HPUF"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_YUTkYrhRLdi"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_kadwTdr2GLE"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_X3aYJHLos6g"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_2LA(SRvNQ86"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_vJJMj(eRAI5"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_2W(NZ9Zu69a"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_WAf1mfFlXb8"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_sIAtoRCXXd7"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_9tG(kA22Lef"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_yw)IN(eppPO"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_HvyJzKiq3wv"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_WBpY1V75pZc"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_wDSDmBg1MsW"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_b83pcLYWFlz"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_Bg9Q8Djcu1p"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_T2HjrIKv38n"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_o2yJdzvUMP("] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_1k6HuycK3R2"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_q)u3M63Jqgd"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["GladiusEx"] = {
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_GVR6JUrnfNn"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_V7d7buiqtNv"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_jYFTR)NBLUS"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_M6mSWwyS7S("] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_)sbDd3lSSIp"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_hlsgExPse2a"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_bWo80vaiMBE"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_6EkuOnVhsuj"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_ZZGc5342Las"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_19cjLEPT8Q8"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_2ncuBA16bVT"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_pPvQFnTUclc"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_vCjyRkA6qQA"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_l0MPl(Xm71w"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_CQQqQGrYaS7"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_CAA2vkoMbLK"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["TrufiGCD_All Icons"] = {
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_oNcsnfsynvt"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_JbuOUoP9JRo"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_5Gy0M8sM)BC"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_myb)mVywbb2"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_2Cd)A3xtuav"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_Bnd00pK8gyl"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_Yf77cqtMFYH"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_WeQcHkzdVzj"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_DHmQMggbcMR"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_kAWH1ClkAb6"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_zHhRoF8fm5)"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_911lYlHB1lD"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_S9SqVIDuzb9"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_Af9UYobj)qs"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_kJA6EefT19l"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_J9(92(03wi2"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_BYNjNV4pYR9"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_8H1qSO2EAly"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_(4hN7DWzNcB"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_sMX6cs5RNSc"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_BM6O95EZXsg"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_aw8kGZLHPoH"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_(BKRn3GfZQW"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_Kl5Bah0uxb8"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_y5ujrjoiv)d"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_9sOwYXSR4N("] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_0PDlyvdHtVl"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_OWXnbwHviSi"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_zB9385J80pr"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_vYPfjp2aXTF"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_4JH1rebDRsF"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_iy(re9XN0eG"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_27Oyzy6BiS4"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_wqwzfBwAHEF"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["ElvUI_Debuffs"] = {
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_uhC71)GI0FG"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_Vde32FBGfVq"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_HTiFtnOx71s"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_RuNDEQDdVvs"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_ekWMqDiGkNQ"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_hV7VhCNtWju"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_YKMcIM5Jw1t"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_(TRpplGLclW"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_EVfWoJVPezm"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_fUfiigs4l(9"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_wD0oNN6Eg(S"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_0UVyfJ(kvN9"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_UI)vjfTYKdp"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_6g(HLjTc2tp"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_brxnqFaYk6E"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_yKSkqUGAT45"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_IkjI6stobmj"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_C8sWG6Xkmn8"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_TnJCaG(hiC3"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_pCyT9dNhaJY"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_mXx065qMh1o"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_C27bH(PTeGe"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_0JDj)Dc(2Oi"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_teniUjOcVGg"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_KFg8aBpqlAy"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_Elt1myYkz7B"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_KaVqf4KCgep"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_tFHru)eXbtz"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_Ef9rmQ(SOQE"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_USNo7sNYD15"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_(YdHyLYxlKX"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_wV1x)B6t7l0"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_ZnvhlBjZOHd"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_vxfDMIjGlCO"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_aBRLvgmNrEI"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_ynC(m)ZDOGX"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_69iIbkvAkWZ"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_5EwHJPn4s8K"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_SJwl8x49IWV"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_9a6Q9Tqf4B("] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_(qCbfFc3LCW"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_rXsS5SVCbaQ"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_b7FaMmKaJMV"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_WjMYy9tx21c"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_opB0vkDoI9h"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_zxFkI03OXw4"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_HqJOg4nioGh"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_3sPS1YjPbZ1"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_rwTiPwji9I4"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_IqtpyWuUHYJ"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_hx5DUsaR113"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_jwowMTfqGSk"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_eNG4ugnqPfg"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_mKochjWwwHr"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_EUy80uqQYkk"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_fBCJOv3acFn"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_awPT(2odk(m"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_iUwC67yE(U)"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
					["SkinID"] = "Epix",
				},
				["WeakAuras_T2Nk3eaFcvj"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_t2lE)HwvhWt"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_ffDhViEpkax"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_FN44FIWjlG5"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_FXj2bMkQ6vk"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_ctDHquAU7Zf"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["GladiusEx_增益"] = {
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_JgKD53MISK9"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_Powlj))Xyt3"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_sFfGO5lSS6h"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_L3Nhy6IhR3Z"] = {
					["Upgraded"] = true,
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["TrinketMenu"] = {
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["WeakAuras_SJ9aGrHHNWb"] = {
					["Upgraded"] = true,
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["GladiusEx_减益"] = {
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
				["TellMeWhen_分组: 1"] = {
					["Colors"] = {
						["Normal"] = {
							0.1490196078431373, -- [1]
							0.1490196078431373, -- [2]
							0.1490196078431373, -- [3]
							0.37629234790802, -- [4]
						},
					},
					["SkinID"] = "Epix",
					["Inherit"] = false,
				},
			},
		},
	},
}
