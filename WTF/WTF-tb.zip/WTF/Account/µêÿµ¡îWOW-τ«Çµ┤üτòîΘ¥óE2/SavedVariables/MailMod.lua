
MailMod_Config = {
	["ContactList"] = {
		["阿什坎迪"] = {
		},
	},
}
