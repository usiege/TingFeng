
CharacterStatsClassicDB = {
	["useBlizzardBlockValue"] = false,
	["useTransparentStatsBackground"] = true,
}
