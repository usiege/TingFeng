
RangeDisplayDB3 = {
	["profileKeys"] = {
	},
	["profiles"] = {
		["Default"] = {
			["units"] = {
				["pet"] = {
				},
				["arena2"] = {
				},
				["focus"] = {
				},
				["arena5"] = {
				},
				["arena4"] = {
				},
			},
		},
	},
}
