
ModernQuestWatchDB = {
	["userplaced"] = false,
	["point"] = {
		"TOPRIGHT", -- [1]
		"MinimapCluster", -- [2]
		"BOTTOMRIGHT", -- [3]
		0, -- [4]
		0, -- [5]
	},
	["db_version"] = 3,
}
