
GrailDatabase = {
	["_classic_"] = {
		["learned"] = {
		},
		["delayEvents"] = true,
		["delayEventsHandled"] = true,
	},
}
