
CharacterStatsClassicDB = {
	["useBlizzardBlockValue"] = false,
}
BetterQuestFrameDB = nil
