
MTSL_PLAYERS = {
	["阿什坎迪"] = {
		["暗黑界面"] = {
			["NAME"] = "暗黑界面",
			["REALM"] = "阿什坎迪",
			["XP_LEVEL"] = 4,
			["FACTION"] = "Alliance",
			["CLASS"] = "WARRIOR",
			["TRADESKILLS"] = {
			},
		},
		["简洁界面"] = {
			["NAME"] = "简洁界面",
			["REALM"] = "阿什坎迪",
			["XP_LEVEL"] = 2,
			["FACTION"] = "Alliance",
			["CLASS"] = "WARRIOR",
			["TRADESKILLS"] = {
			},
		},
	},
}
MTSLUI_PLAYER = {
	["UI_SPLIT_MODE"] = {
		["ACCOUNT"] = "Vertical",
		["CHAR"] = "Vertical",
		["DATABASE"] = "Vertical",
		["MTSL"] = "Vertical",
		["NPC"] = "Vertical",
	},
	["MTSL_LOCATION"] = {
		["FRAME"] = "right",
		["BUTTON"] = "right",
	},
	["MINIMAP"] = {
		["ANGLE"] = 90,
		["ACTIVE"] = 1,
		["RADIUS"] = 0,
		["SHAPE"] = "circle",
	},
	["TOOLTIP"] = {
		["ACTIVE"] = 1,
		["FACTIONS"] = "current character",
		["SHOW_KNOWN"] = "show",
	},
	["AUTO_SHOW_MTSL"] = 0,
	["INSTALLED_VERSION"] = "2.5.08",
	["FONT"] = {
		["NAME"] = "ARKai_T.ttf",
		["SIZE"] = {
			["LABEL"] = 11,
			["TITLE"] = 13,
			["TEXT"] = 10,
		},
	},
	["WELCOME_MSG"] = 1,
	["LINK_TO_CHAT"] = {
		["CHANNEL"] = "AUTO",
		["ACTIVE"] = 1,
	},
	["UI_SCALE"] = {
		["OPTIONSMENU"] = "1.00",
		["ACCOUNT"] = "1.00",
		["CHAR"] = "1.00",
		["DATABASE"] = "1.00",
		["MTSL"] = "1.00",
		["NPC"] = "1.00",
	},
}
MTSL_MISSING_DATA = {
}
