
alaMiscSV = {
	["instance_timer_sv"] = {
		["use_global_set"] = true,
		["set"] = {
			["*"] = {
				["locked"] = false,
				["enabled"] = true,
				["pos"] = {
					"TOP", -- [1]
					nil, -- [2]
					"TOP", -- [3]
					-0.7998265027999878, -- [4]
					-18.40005302429199, -- [5]
				},
			},
		},
		["_version"] = 20200728.1,
		["var"] = {
			["Player-4792-026E8FC2"] = {
				["hash"] = {
				},
				["list"] = {
				},
			},
			["Player-4792-025EAE5E"] = {
				["hash"] = {
				},
				["list"] = {
				},
			},
		},
	},
	["WA"] = {
	},
	["target_warn_sv"] = {
		["enabled"] = false,
		["Player-4792-025EAE5E"] = {
			["on"] = false,
			["locked"] = false,
		},
		["locked"] = false,
		["Player-4792-026E8FC2"] = {
			["on"] = false,
			["locked"] = false,
		},
	},
	["_version"] = 20200713,
	["honor_sv"] = {
		["rankText"] = false,
		["honorKillColorName"] = true,
		["honorKillDetail"] = true,
	},
}
