
EasyMail_SavedVars = {
	["Inclusive"] = "N",
	["Guild"] = "N",
	["DelPrompt"] = "Y",
	["Money"] = "Y",
	["MoveHFrame"] = "Y",
	["TextTooltip"] = "N",
	["OpenAll"] = "N",
	["AutoAdd"] = "N",
	["阿什坎迪"] = {
		["Alliance"] = {
			["LastAddressee"] = {
				["简洁界面"] = "",
			},
			["MailListLen"] = 15,
			["EasyMailList"] = {
			},
		},
	},
	["Total"] = "Y",
	["Friends"] = "N",
	["ClickDel"] = "N",
	["DelPending"] = "N",
	["ClickGet"] = "N",
	["BlizzList"] = "N",
}
EasyMail_Maillog = {
}
