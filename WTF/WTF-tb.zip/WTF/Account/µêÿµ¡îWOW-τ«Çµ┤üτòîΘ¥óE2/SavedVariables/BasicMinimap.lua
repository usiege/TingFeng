
BasicMinimapClassicSV = {
	["profileKeys"] = {
		["大哥别开火 - 阿什坎迪"] = "Default",
		["今晚就动手 - 阿什坎迪"] = "Default",
		["榴莲亡反 - 曼多基尔"] = "Default",
		["牛肉涨价 - 曼多基尔"] = "Default",
		["大力出七级 - 阿什坎迪"] = "Default",
	},
	["profiles"] = {
		["配置1"] = {
			["lock"] = true,
			["position"] = {
				"TOPRIGHT", -- [1]
				"TOPRIGHT", -- [2]
				-19.5988063812256, -- [3]
				-28.4000282287598, -- [4]
			},
		},
		["Default"] = {
			["zoomBtn"] = true,
			["borderSize"] = 4,
			["monochrome"] = true,
			["colorBorder"] = {
				nil, -- [1]
				0, -- [2]
			},
			["position"] = {
				"TOPRIGHT", -- [1]
				"TOPRIGHT", -- [2]
				-17.199857711792, -- [3]
				-19.6000099182129, -- [4]
			},
		},
	},
}
BasicMinimapSV = nil
