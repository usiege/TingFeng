
HHTD_SavedVariables = {
	["char"] = {
		["猎猎思密达 - 阿什坎迪"] = {
			["settingsMigrated"] = false,
		},
		["简洁界面 - 阿什坎迪"] = {
			["settingsMigrated"] = false,
		},
		["今晚就动手 - 阿什坎迪"] = {
			["settingsMigrated"] = false,
		},
		["暗黑界面 - 阿什坎迪"] = {
			["settingsMigrated"] = false,
		},
		["简洁界面二 - 阿什坎迪"] = {
			["settingsMigrated"] = false,
		},
	},
	["profileKeys"] = {
		["猎猎思密达 - 阿什坎迪"] = "简洁界面 - 阿什坎迪",
		["简洁界面 - 阿什坎迪"] = "简洁界面 - 阿什坎迪",
		["今晚就动手 - 阿什坎迪"] = "今晚就动手 - 阿什坎迪",
		["暗黑界面 - 阿什坎迪"] = "暗黑界面 - 阿什坎迪",
		["简洁界面二 - 阿什坎迪"] = "简洁界面 - 阿什坎迪",
	},
	["global"] = {
		["settingsMigrated"] = false,
		["oldNameEnableState"] = 0,
	},
	["namespaces"] = {
		["Announcer"] = {
		},
		["CM"] = {
		},
		["NPH"] = {
		},
	},
}
