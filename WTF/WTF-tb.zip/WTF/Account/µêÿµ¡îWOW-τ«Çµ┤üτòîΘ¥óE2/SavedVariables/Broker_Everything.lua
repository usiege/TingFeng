
Broker_Everything_DataDB = {
	["AceDBfix"] = 0,
}
Broker_Everything_CharacterDB = {
	["order"] = {
		"今晚就动手-阿什坎迪", -- [1]
	},
	["今晚就动手-阿什坎迪"] = {
		["race"] = "Human",
		["name"] = "今晚就动手",
		["faction"] = "Alliance",
		["orderId"] = 1,
		["level"] = 7,
		["class"] = "ROGUE",
	},
}
Broker_Everything_AceDB = {
	["profileKeys"] = {
		["今晚就动手 - 阿什坎迪"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
		},
	},
}
