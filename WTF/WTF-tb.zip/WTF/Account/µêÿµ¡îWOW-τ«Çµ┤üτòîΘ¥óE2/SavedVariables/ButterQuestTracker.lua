
ButterQuestTrackerConfig = {
	["char"] = {
		["简洁界面 - 阿什坎迪"] = {
			["QUESTS_LAST_UPDATED"] = {
				[5261] = 1631353743,
				[7] = 1631353743,
			},
		},
		["今晚就动手 - 阿什坎迪"] = {
			["QUESTS_LAST_UPDATED"] = {
				[40] = 1618930764,
				[47] = 1618930764,
				[62] = 1618930764,
			},
		},
	},
	["profileKeys"] = {
		["猎猎思密达 - 阿什坎迪"] = "Default",
		["简洁界面 - 阿什坎迪"] = "Default",
		["今晚就动手 - 阿什坎迪"] = "Default",
		["暗黑界面 - 阿什坎迪"] = "Default",
		["简洁界面二 - 阿什坎迪"] = "Default",
	},
	["global"] = {
		["PositionY"] = -240.9697265625,
		["PositionX"] = -65.9390869140625,
	},
}
