
MobHealthDB = nil
MobHealthConfig = nil
