
MaxCamDB = {
	["speed"] = 20,
	["db_version"] = 2.3,
	["nearIncrement"] = 1,
	["increment"] = 4,
	["nearDistance"] = 5,
	["distance"] = 3.34,
}
