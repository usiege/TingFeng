
alaTradeSkillSV = {
	["cmm"] = {
		[4792] = {
		},
	},
	["_GLOBAL"] = {
		["AuctionMaster"] = {
		},
		["CloudyTradeSkill"] = {
		},
		["Leatrix_Plus"] = {
		},
		["alaTrade"] = {
			["__ala_meta__"] = 2,
		},
		["db"] = {
		},
		["Auctioneer"] = {
		},
		["aux-addon"] = {
		},
		["AuctionBase"] = {
			["CreateFrame"] = 10,
		},
		["ui"] = {
			["ALADROP"] = 600,
			["ALASCR"] = 30,
			["ALA_HOOK_ChatEdit_InsertLink"] = 10,
			["ALA_HOOK_ChatEdit_InsertName"] = 10,
			["UISpecialFrames"] = 20,
			["UIParent"] = 30,
		},
		["tooltip"] = {
		},
		["MissingTradeSkillsList"] = {
		},
		["AuctionFaster"] = {
		},
		["AuctionDB"] = {
		},
		["Auctionator"] = {
			["Auctionator"] = 30,
		},
		["communication"] = {
		},
		["TradeSkillMaster"] = {
		},
		["Auctipus"] = {
		},
		["cooldown"] = {
		},
		["main"] = {
			["EnableAddOn"] = 10,
			["alaTradeSkillSV"] = 86,
			["LibStub"] = 20,
			["LoadAddOn"] = 10,
		},
	},
	["set"] = {
		["show_tradeskill_tip_craft_spell_price"] = true,
		["show_DBIcon"] = true,
		["first_auction_mod"] = "*",
		["show_tab"] = true,
		["show_board"] = false,
		["expand"] = false,
		["show_tradeskill_tip_recipe_price"] = true,
		["show_tradeskill_tip_craft_item_price"] = true,
		["show_tradeskill_frame_rank_info"] = true,
		["regular_exp"] = false,
		["blz_style"] = false,
		["minimapPos"] = 0,
		["lock_board"] = false,
		["explorer"] = {
			["searchText"] = "",
			["showItemInsteadOfSpell"] = false,
			["showProfit"] = false,
			["showRank"] = true,
			["showKnown"] = true,
			["showHighRank"] = false,
			["filter"] = {
			},
			["showSet"] = true,
			["showUnkown"] = false,
			["phase"] = 2,
			["update"] = true,
		},
		["board_pos"] = {
			"TOP", -- [1]
			"UIParent", -- [2]
			"BOTTOM", -- [3]
			260, -- [4]
			190, -- [5]
		},
		["hide_mtsl"] = false,
		["show_tradeskill_frame_price_info"] = true,
		["portrait_button"] = true,
		["bg_color"] = {
			0, -- [1]
			0, -- [2]
			0, -- [3]
			0.75, -- [4]
		},
		["show_call"] = true,
		["char_list"] = {
			"Player-4792-026E8FC2", -- [1]
			"Player-4792-03A26BE8", -- [2]
			"Player-4792-033FCC2E", -- [3]
		},
		["colored_rank_for_unknown"] = false,
		["default_skill_button_tip"] = true,
		["show_tradeskill_tip_material_craft_info"] = true,
		["show_tradeskill_tip_recipe_account_learned"] = true,
	},
	["fav"] = {
	},
	["_version"] = 210605.1,
	["var"] = {
		["Player-4792-033FCC2E"] = {
			["realm_id"] = 4792,
			["supreme_list"] = {
			},
			["realm_name"] = "阿什坎迪",
		},
		["Player-4792-03A26BE8"] = {
			["realm_id"] = 4792,
			["supreme_list"] = {
			},
			["realm_name"] = "阿什坎迪",
		},
		["Player-4792-026E8FC2"] = {
			["realm_id"] = 4792,
			["supreme_list"] = {
			},
			["realm_name"] = "阿什坎迪",
		},
	},
}
