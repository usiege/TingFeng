
GSEOptions = {
	["Update3023"] = true,
	["use2"] = false,
	["showGSEUsers"] = false,
	["editorHeight"] = 700,
	["filterList"] = {
		["All"] = false,
		["Spec"] = true,
		["Global"] = true,
		["Class"] = true,
	},
	["use11"] = false,
	["debug"] = false,
	["CONCAT"] = "|cffcc7777",
	["CommandColour"] = "|cFF00FF00",
	["showCurrentSpells"] = true,
	["Update2638"] = true,
	["hideSoundErrors"] = false,
	["Update2410"] = true,
	["requireTarget"] = false,
	["Update2411"] = true,
	["useTranslator"] = false,
	["initialised"] = true,
	["resetOOC"] = true,
	["MacroResetModifiers"] = {
		["Alt"] = false,
		["LeftControl"] = false,
		["LeftButton"] = false,
		["LeftAlt"] = false,
		["RightShift"] = false,
		["RightButton"] = false,
		["AnyMod"] = false,
		["Button5"] = false,
		["LeftShift"] = false,
		["Shift"] = false,
		["Control"] = false,
		["RightControl"] = false,
		["MiddleButton"] = false,
		["Button4"] = false,
		["RightAlt"] = false,
	},
	["EmphasisColour"] = "|cFFFFFF00",
	["WOWSHORTCUTS"] = "|cffddaaff",
	["deleteOrphansOnLogout"] = false,
	["showMiniMap"] = {
		["hide"] = true,
	},
	["DefaultDisabledMacroIcon"] = "Interface\\Icons\\INV_MISC_BOOK_08",
	["use13"] = false,
	["UseWLMExportFormat"] = true,
	["use1"] = false,
	["HideLoginMessage"] = false,
	["DebugPrintModConditionsOnKeyPress"] = false,
	["msClickRate"] = 100,
	["use14"] = false,
	["debugHeight"] = 500,
	["EQUALS"] = "|cffccddee",
	["NUMBER"] = "|cffffaa00",
	["sendDebugOutputToChatWindow"] = false,
	["DisabledSequences"] = {
	},
	["DefaultImportAction"] = "MERGE",
	["CreateGlobalButtons"] = false,
	["menuHeight"] = 500,
	["sendDebugOutputToDebugOutput"] = false,
	["use6"] = false,
	["saveAllMacrosLocal"] = true,
	["STANDARDFUNCS"] = "|cff55ddcc",
	["STRING"] = "|cff888888",
	["useExternalMSTimings"] = true,
	["clearUIErrors"] = false,
	["autoCreateMacroStubsGlobal"] = false,
	["TitleColour"] = "|cFFFF0000",
	["hideUIErrors"] = false,
	["Update2601"] = true,
	["editorWidth"] = 700.0001831054688,
	["DebugModules"] = {
		["Translator"] = false,
		["GUI"] = false,
		["Storage"] = false,
		["Editor"] = false,
		["Versions"] = false,
		["API"] = false,
		["Viewer"] = false,
		["Transmission"] = false,
	},
	["Update2415"] = true,
	["autoCreateMacroStubsClass"] = true,
	["AuthorColour"] = "|cFF00D1FF",
	["PromptSample"] = true,
	["UseVerboseExportFormat"] = false,
	["UNKNOWN"] = "|cffff6666",
	["RealtimeParse"] = false,
	["Update2633"] = true,
	["Updated801"] = true,
	["AddInPacks"] = {
		["GSE2Library"] = {
			["Name"] = "GSE2Library",
			["Version"] = "3.0.49",
		},
		["Samples"] = {
			["Name"] = "Samples",
			["Version"] = "2.6.55",
			["SequenceNames"] = {
				"Assorted Sample Macros", -- [1]
			},
		},
	},
	["overflowPersonalMacros"] = false,
	["INDENT"] = "|cffccaa88",
	["COMMENT"] = "|cff55cc55",
	["NormalColour"] = "|cFFFFFFFF",
	["use12"] = false,
	["showGSEoocqueue"] = true,
	["Update3000"] = true,
	["Update2305"] = true,
	["menuWidth"] = 700.0001831054688,
	["setDefaultIconQuestionMark"] = true,
	["KEYWORD"] = "|cff88bbdd",
	["debugWidth"] = 700.0001831054688,
}
GSELibrary = nil
GSEStorage = {
	{
	}, -- [1]
	{
	}, -- [2]
	{
	}, -- [3]
	{
	}, -- [4]
	{
	}, -- [5]
	{
	}, -- [6]
	{
	}, -- [7]
	{
	}, -- [8]
	{
	}, -- [9]
	{
	}, -- [10]
	{
	}, -- [11]
	{
	}, -- [12]
	[0] = {
	},
}
GSE3Storage = {
	{
	}, -- [1]
	{
	}, -- [2]
	{
	}, -- [3]
	{
	}, -- [4]
	{
	}, -- [5]
	{
	}, -- [6]
	{
	}, -- [7]
	{
	}, -- [8]
	{
	}, -- [9]
	{
	}, -- [10]
	{
	}, -- [11]
	{
	}, -- [12]
	[0] = {
	},
}
GSESpellCache = {
	["enUS"] = {
	},
	["zhCN"] = {
	},
}
