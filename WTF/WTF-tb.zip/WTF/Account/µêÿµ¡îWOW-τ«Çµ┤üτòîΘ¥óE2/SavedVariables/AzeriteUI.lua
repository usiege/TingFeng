
AzeriteUI_DB = {
	["UnitFramePlayer"] = {
		["profiles"] = {
			["faction"] = {
				["Alliance"] = {
					["enablePlayerManaOrb"] = true,
					["enableAuras"] = true,
				},
			},
			["character"] = {
				["简洁界面-阿什坎迪"] = {
					["enablePlayerManaOrb"] = true,
					["enableAuras"] = true,
				},
				["Azui-阿什坎迪"] = {
					["enablePlayerManaOrb"] = true,
					["enableAuras"] = true,
				},
				["今晚就动手-阿什坎迪"] = {
					["enablePlayerManaOrb"] = true,
					["enableAuras"] = true,
				},
			},
			["global"] = {
				["enablePlayerManaOrb"] = true,
				["enableAuras"] = true,
			},
			["realm"] = {
				["阿什坎迪"] = {
					["enablePlayerManaOrb"] = true,
					["enableAuras"] = true,
				},
			},
		},
	},
	["ExplorerMode"] = {
		["profiles"] = {
			["faction"] = {
				["Alliance"] = {
					["enableTrackerFading"] = false,
					["enableExplorer"] = true,
					["enableExplorerChat"] = true,
				},
			},
			["character"] = {
				["简洁界面-阿什坎迪"] = {
					["enableTrackerFading"] = false,
					["enableExplorer"] = true,
					["enableExplorerChat"] = true,
				},
				["Azui-阿什坎迪"] = {
					["enableTrackerFading"] = false,
					["enableExplorer"] = false,
					["enableExplorerChat"] = true,
				},
				["今晚就动手-阿什坎迪"] = {
					["enableTrackerFading"] = false,
					["enableExplorer"] = true,
					["enableExplorerChat"] = true,
				},
			},
			["global"] = {
				["enableTrackerFading"] = false,
				["enableExplorer"] = true,
				["enableExplorerChat"] = true,
			},
			["realm"] = {
				["阿什坎迪"] = {
					["enableTrackerFading"] = false,
					["enableExplorer"] = true,
					["enableExplorerChat"] = true,
				},
			},
		},
	},
	["NamePlates"] = {
		["profiles"] = {
			["faction"] = {
				["Alliance"] = {
					["clickThroughEnemies"] = false,
					["enableAuras"] = true,
					["clickThroughFriends"] = false,
					["nameplateShowSelf"] = false,
					["clickThroughSelf"] = false,
					["NameplatePersonalShowInCombat"] = true,
					["NameplatePersonalShowWithTarget"] = true,
					["NameplatePersonalShowAlways"] = false,
				},
			},
			["character"] = {
				["简洁界面-阿什坎迪"] = {
					["clickThroughEnemies"] = false,
					["enableAuras"] = true,
					["clickThroughFriends"] = false,
					["nameplateShowSelf"] = false,
					["clickThroughSelf"] = false,
					["NameplatePersonalShowInCombat"] = true,
					["NameplatePersonalShowWithTarget"] = true,
					["NameplatePersonalShowAlways"] = false,
				},
				["Azui-阿什坎迪"] = {
					["enableAuras"] = true,
					["clickThroughEnemies"] = false,
					["clickThroughFriends"] = false,
					["nameplateShowSelf"] = false,
					["clickThroughSelf"] = false,
					["NameplatePersonalShowAlways"] = false,
					["NameplatePersonalShowWithTarget"] = true,
					["NameplatePersonalShowInCombat"] = true,
				},
				["今晚就动手-阿什坎迪"] = {
					["clickThroughEnemies"] = false,
					["enableAuras"] = true,
					["clickThroughFriends"] = false,
					["nameplateShowSelf"] = false,
					["clickThroughSelf"] = false,
					["NameplatePersonalShowInCombat"] = true,
					["NameplatePersonalShowWithTarget"] = true,
					["NameplatePersonalShowAlways"] = false,
				},
			},
			["global"] = {
				["clickThroughEnemies"] = false,
				["enableAuras"] = true,
				["clickThroughFriends"] = false,
				["nameplateShowSelf"] = false,
				["clickThroughSelf"] = false,
				["NameplatePersonalShowInCombat"] = true,
				["NameplatePersonalShowWithTarget"] = true,
				["NameplatePersonalShowAlways"] = false,
			},
			["realm"] = {
				["阿什坎迪"] = {
					["clickThroughEnemies"] = false,
					["enableAuras"] = true,
					["clickThroughFriends"] = false,
					["nameplateShowSelf"] = false,
					["clickThroughSelf"] = false,
					["NameplatePersonalShowInCombat"] = true,
					["NameplatePersonalShowWithTarget"] = true,
					["NameplatePersonalShowAlways"] = false,
				},
			},
		},
	},
	["Minimap"] = {
		["profiles"] = {
			["faction"] = {
				["Alliance"] = {
					["useServerTime"] = false,
					["useStandardTime"] = true,
					["stickyBars"] = false,
				},
			},
			["character"] = {
				["简洁界面-阿什坎迪"] = {
					["useServerTime"] = false,
					["useStandardTime"] = true,
					["stickyBars"] = false,
				},
				["Azui-阿什坎迪"] = {
					["useServerTime"] = false,
					["useStandardTime"] = true,
					["stickyBars"] = false,
				},
				["今晚就动手-阿什坎迪"] = {
					["useServerTime"] = false,
					["useStandardTime"] = true,
					["stickyBars"] = false,
				},
			},
			["global"] = {
				["useServerTime"] = false,
				["useStandardTime"] = true,
				["stickyBars"] = false,
			},
			["realm"] = {
				["阿什坎迪"] = {
					["useServerTime"] = false,
					["useStandardTime"] = true,
					["stickyBars"] = false,
				},
			},
		},
	},
	["ModuleForge::ActionBars"] = {
		["profiles"] = {
			["faction"] = {
				["Alliance"] = {
					["Legacy::enableSideBarLeft"] = false,
					["Azerite::extraButtonsVisibility"] = "combat",
					["castOnDown"] = true,
					["buttonLock"] = true,
					["lastKeybindDisplayType"] = "keyboard",
					["gamePadType"] = "default",
					["Legacy::enableSideBarRight"] = false,
					["Azerite::extraButtonsCount"] = 5,
					["Legacy::enableSecondaryBar"] = false,
					["Azerite::petBarVisibility"] = "hover",
					["keybindDisplayPriority"] = "default",
					["Legacy::enablePetBar"] = true,
					["Azerite::petBarEnabled"] = true,
				},
			},
			["character"] = {
				["简洁界面-阿什坎迪"] = {
					["Legacy::enableSideBarLeft"] = false,
					["Azerite::extraButtonsVisibility"] = "always",
					["castOnDown"] = true,
					["buttonLock"] = true,
					["gamePadType"] = "default",
					["lastKeybindDisplayType"] = "keyboard",
					["Legacy::enableSideBarRight"] = false,
					["Azerite::extraButtonsCount"] = 17,
					["Legacy::enableSecondaryBar"] = false,
					["Azerite::petBarVisibility"] = "hover",
					["keybindDisplayPriority"] = "default",
					["Legacy::enablePetBar"] = true,
					["Azerite::petBarEnabled"] = true,
				},
				["Azui-阿什坎迪"] = {
					["Legacy::enableSideBarLeft"] = false,
					["Azerite::extraButtonsVisibility"] = "always",
					["castOnDown"] = true,
					["buttonLock"] = true,
					["gamePadType"] = "default",
					["lastKeybindDisplayType"] = "keyboard",
					["Legacy::enableSideBarRight"] = false,
					["Azerite::extraButtonsCount"] = 5,
					["Legacy::enableSecondaryBar"] = false,
					["Azerite::petBarVisibility"] = "hover",
					["keybindDisplayPriority"] = "default",
					["Legacy::enablePetBar"] = true,
					["Azerite::petBarEnabled"] = false,
				},
				["今晚就动手-阿什坎迪"] = {
					["Legacy::enableSideBarLeft"] = false,
					["Azerite::extraButtonsVisibility"] = "combat",
					["castOnDown"] = true,
					["buttonLock"] = true,
					["lastKeybindDisplayType"] = "keyboard",
					["gamePadType"] = "default",
					["Legacy::enableSideBarRight"] = false,
					["Azerite::extraButtonsCount"] = 5,
					["Legacy::enableSecondaryBar"] = false,
					["Azerite::petBarVisibility"] = "hover",
					["keybindDisplayPriority"] = "default",
					["Legacy::enablePetBar"] = true,
					["Azerite::petBarEnabled"] = true,
				},
			},
			["global"] = {
				["Legacy::enableSideBarLeft"] = false,
				["Azerite::extraButtonsVisibility"] = "combat",
				["castOnDown"] = true,
				["buttonLock"] = true,
				["lastKeybindDisplayType"] = "keyboard",
				["gamePadType"] = "default",
				["Legacy::enableSideBarRight"] = false,
				["Azerite::extraButtonsCount"] = 5,
				["Legacy::enableSecondaryBar"] = false,
				["Azerite::petBarVisibility"] = "hover",
				["keybindDisplayPriority"] = "default",
				["Legacy::enablePetBar"] = true,
				["Azerite::petBarEnabled"] = true,
			},
			["realm"] = {
				["阿什坎迪"] = {
					["Legacy::enableSideBarLeft"] = false,
					["Azerite::extraButtonsVisibility"] = "combat",
					["castOnDown"] = true,
					["buttonLock"] = true,
					["lastKeybindDisplayType"] = "keyboard",
					["gamePadType"] = "default",
					["Legacy::enableSideBarRight"] = false,
					["Azerite::extraButtonsCount"] = 5,
					["Legacy::enableSecondaryBar"] = false,
					["Azerite::petBarVisibility"] = "hover",
					["keybindDisplayPriority"] = "default",
					["Legacy::enablePetBar"] = true,
					["Azerite::petBarEnabled"] = true,
				},
			},
		},
	},
	["UnitFrameTarget"] = {
		["profiles"] = {
			["faction"] = {
				["Alliance"] = {
					["enableAuras"] = true,
				},
			},
			["character"] = {
				["简洁界面-阿什坎迪"] = {
					["enableAuras"] = true,
				},
				["Azui-阿什坎迪"] = {
					["enableAuras"] = true,
				},
				["今晚就动手-阿什坎迪"] = {
					["enableAuras"] = true,
				},
			},
			["global"] = {
				["enableAuras"] = true,
			},
			["realm"] = {
				["阿什坎迪"] = {
					["enableAuras"] = true,
				},
			},
		},
	},
	["BlizzardFloaterHUD"] = {
		["profiles"] = {
			["faction"] = {
				["Alliance"] = {
					["enableRaidWarnings"] = true,
				},
			},
			["character"] = {
				["简洁界面-阿什坎迪"] = {
					["enableRaidWarnings"] = true,
					["enableRaidBossEmotes"] = false,
				},
				["Azui-阿什坎迪"] = {
					["enableRaidBossEmotes"] = true,
					["enableObjectivesTracker"] = true,
					["enableRaidWarnings"] = true,
				},
				["今晚就动手-阿什坎迪"] = {
					["enableRaidWarnings"] = true,
				},
			},
			["global"] = {
				["enableRaidWarnings"] = true,
			},
			["realm"] = {
				["阿什坎迪"] = {
					["enableRaidWarnings"] = true,
				},
			},
		},
	},
	["UnitFrameParty"] = {
		["profiles"] = {
			["faction"] = {
				["Alliance"] = {
					["enablePartyFrames"] = true,
				},
			},
			["character"] = {
				["简洁界面-阿什坎迪"] = {
					["enablePartyFrames"] = true,
				},
				["Azui-阿什坎迪"] = {
					["enablePartyFrames"] = true,
				},
				["今晚就动手-阿什坎迪"] = {
					["enablePartyFrames"] = true,
				},
			},
			["global"] = {
				["enablePartyFrames"] = true,
			},
			["realm"] = {
				["阿什坎迪"] = {
					["enablePartyFrames"] = true,
				},
			},
		},
	},
	["BlizzardChatFrames"] = {
		["profiles"] = {
			["faction"] = {
				["Alliance"] = {
					["enableChatOutline"] = true,
				},
			},
			["character"] = {
				["简洁界面-阿什坎迪"] = {
					["enableChatOutline"] = true,
				},
				["Azui-阿什坎迪"] = {
					["enableChatOutline"] = false,
				},
				["今晚就动手-阿什坎迪"] = {
					["enableChatOutline"] = true,
				},
			},
			["global"] = {
				["enableChatOutline"] = true,
			},
			["realm"] = {
				["阿什坎迪"] = {
					["enableChatOutline"] = true,
				},
			},
		},
	},
	["UnitFramePlayerHUD"] = {
		["profiles"] = {
			["faction"] = {
				["Alliance"] = {
					["enableCast"] = true,
					["enableClassPower"] = true,
				},
			},
			["character"] = {
				["简洁界面-阿什坎迪"] = {
					["enableCast"] = true,
					["enableClassPower"] = true,
				},
				["Azui-阿什坎迪"] = {
					["enableCast"] = true,
					["enableClassPower"] = true,
				},
				["今晚就动手-阿什坎迪"] = {
					["enableCast"] = true,
					["enableClassPower"] = true,
				},
			},
			["global"] = {
				["enableCast"] = true,
				["enableClassPower"] = true,
			},
			["realm"] = {
				["阿什坎迪"] = {
					["enableCast"] = true,
					["enableClassPower"] = true,
				},
			},
		},
	},
	["UnitFrameRaid"] = {
		["profiles"] = {
			["faction"] = {
				["Alliance"] = {
					["enableRaidFrames"] = true,
					["enableRaidFrameTestMode"] = false,
				},
			},
			["character"] = {
				["简洁界面-阿什坎迪"] = {
					["enableRaidFrames"] = true,
					["enableRaidFrameTestMode"] = false,
				},
				["Azui-阿什坎迪"] = {
					["enableRaidFrames"] = true,
					["enableRaidFrameTestMode"] = false,
				},
				["今晚就动手-阿什坎迪"] = {
					["enableRaidFrames"] = true,
					["enableRaidFrameTestMode"] = false,
				},
			},
			["global"] = {
				["enableRaidFrames"] = true,
				["enableRaidFrameTestMode"] = false,
			},
			["realm"] = {
				["阿什坎迪"] = {
					["enableRaidFrames"] = true,
					["enableRaidFrameTestMode"] = false,
				},
			},
		},
	},
	["AzeriteUI"] = {
		["profiles"] = {
			["faction"] = {
				["Alliance"] = {
					["auraFilterLevel"] = 2,
					["loadDebugConsole"] = true,
					["aspectRatio"] = "wide",
					["enableHealerMode"] = false,
					["theme"] = "Azerite",
					["enableDebugConsole"] = false,
				},
			},
			["character"] = {
				["简洁界面-阿什坎迪"] = {
					["auraFilterLevel"] = 2,
					["loadDebugConsole"] = true,
					["aspectRatio"] = "wide",
					["enableHealerMode"] = true,
					["theme"] = "Azerite",
					["enableDebugConsole"] = false,
				},
				["Azui-阿什坎迪"] = {
					["aspectRatio"] = "wide",
					["loadDebugConsole"] = true,
					["auraFilterLevel"] = 2,
					["enableHealerMode"] = true,
					["theme"] = "Azerite",
					["enableDebugConsole"] = false,
				},
				["今晚就动手-阿什坎迪"] = {
					["auraFilterLevel"] = 2,
					["loadDebugConsole"] = true,
					["aspectRatio"] = "wide",
					["enableHealerMode"] = false,
					["theme"] = "Azerite",
					["enableDebugConsole"] = false,
				},
			},
			["global"] = {
				["auraFilterLevel"] = 2,
				["loadDebugConsole"] = true,
				["aspectRatio"] = "full",
				["enableHealerMode"] = false,
				["theme"] = "Azerite",
				["enableDebugConsole"] = false,
			},
			["realm"] = {
				["阿什坎迪"] = {
					["auraFilterLevel"] = 2,
					["loadDebugConsole"] = true,
					["aspectRatio"] = "wide",
					["enableHealerMode"] = false,
					["theme"] = "Azerite",
					["enableDebugConsole"] = false,
				},
			},
		},
	},
}
