
HandyNotes_NPCsBurningCrusadeClassicDB = {
	["namespaces"] = {
		["AltRecipes"] = {
		},
	},
	["profileKeys"] = {
		["大哥别开火 - 阿什坎迪"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
		},
	},
}
