
KuiNameplatesCoreSaved = {
	["2162_PERSONAL_FRAME_SIZE_TRANSITION"] = true,
	["226_AURAS_TRANSITION"] = true,
	["226_CLASSPOWERS_Y"] = true,
	["216_HEALTH_TRANSITION"] = true,
	["226_TARGET_SIZE"] = true,
	["profiles"] = {
		["default"] = {
			["health_text"] = true,
			["colour_hated"] = {
				1, -- [1]
				0.2745098039215687, -- [2]
				0.3019607843137255, -- [3]
			},
			["colour_player_class"] = true,
			["health_text_hostile_max"] = 4,
			["health_text_friend_max"] = 4,
			["fade_non_target_alpha"] = 0.8500000238418579,
			["castbar_unin_colour"] = {
				0.8980392156862745, -- [1]
				0.3568627450980392, -- [2]
				0.3529411764705882, -- [3]
			},
			["health_text_friend_dmg"] = 4,
			["fade_conditional_alpha"] = 0.5,
			["level_text"] = true,
			["castbar_colour"] = {
				0.4980392156862745, -- [1]
				0.9019607843137255, -- [2]
				0.4588235294117647, -- [3]
			},
			["castbar_height"] = 10,
		},
	},
}
