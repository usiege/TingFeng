
HandyNotes_TravelGuideClassicDB = {
	["profileKeys"] = {
		["今晚就动手 - 阿什坎迪"] = "今晚就动手 - 阿什坎迪",
	},
	["profiles"] = {
		["今晚就动手 - 阿什坎迪"] = {
		},
		["简洁界面 - 阿什坎迪"] = {
		},
	},
}
