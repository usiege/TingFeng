
QuestLogExDB = {
	["profileKeys"] = {
		["大哥别开火 - 阿什坎迪"] = "Sharkboxer - 巨龙追猎者",
		["动能甫杜 - 阿什坎迪"] = "Sharkboxer - 巨龙追猎者",
		["今晚就动手 - 阿什坎迪"] = "Sharkboxer - 巨龙追猎者",
		["吸你的血 - 阿什坎迪"] = "Sharkboxer - 巨龙追猎者",
		["交作业 - 阿什坎迪"] = "Sharkboxer - 巨龙追猎者",
		["你说怎么办 - 阿什坎迪"] = "Sharkboxer - 巨龙追猎者",
	},
	["profiles"] = {
		["Sharkboxer - 巨龙追猎者"] = {
		},
	},
}
