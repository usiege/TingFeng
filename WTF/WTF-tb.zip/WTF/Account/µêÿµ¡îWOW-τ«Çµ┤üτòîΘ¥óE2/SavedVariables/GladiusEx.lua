
GladiusExDB = {
	["namespaces"] = {
		["party_CastBar"] = {
		},
		["Highlight"] = {
		},
		["party_Alerts"] = {
		},
		["party_HealthBar"] = {
		},
		["party_ClassIcon"] = {
		},
		["party_Highlight"] = {
		},
		["party_DRTracker"] = {
		},
		["DRTracker"] = {
		},
		["party_PowerBar"] = {
		},
		["SkillHistory"] = {
		},
		["party_TargetBar"] = {
		},
		["Cooldowns"] = {
		},
		["arena"] = {
			["profiles"] = {
				["暗黑界面 - 阿什坎迪"] = {
					["y"] = {
						["anchor_arena"] = 455.8544501521355,
						["arena2"] = 475.4545481004498,
						["arena3"] = 400.2544249095681,
						["arena1"] = 550.6545492210171,
					},
					["x"] = {
						["anchor_arena"] = 957.5267720807606,
						["arena2"] = 1008.726675187449,
						["arena3"] = 1008.726675187449,
						["arena1"] = 1008.726675187449,
					},
				},
			},
		},
		["Auras"] = {
		},
		["CastBar"] = {
		},
		["party"] = {
			["profiles"] = {
				["暗黑界面 - 阿什坎迪"] = {
					["y"] = {
						["anchor_party"] = 481.4544505336053,
						["player"] = 570.2544518568284,
						["party2"] = 427.8544985630288,
						["party1"] = 499.0544996239914,
					},
					["x"] = {
						["anchor_party"] = 26.8121799649623,
						["player"] = 94.01212908643674,
						["party2"] = 94.01212908643674,
						["party1"] = 94.01212908643674,
					},
				},
			},
		},
		["party_SkillHistory"] = {
		},
		["PowerBar"] = {
		},
		["Interrupts"] = {
		},
		["party_Announcements"] = {
		},
		["HealthBar"] = {
		},
		["party_PetBar"] = {
		},
		["PetBar"] = {
		},
		["party_Cooldowns"] = {
		},
		["party_Clicks"] = {
		},
		["Announcements"] = {
		},
		["party_Interrupts"] = {
		},
		["Alerts"] = {
		},
		["TargetBar"] = {
		},
		["party_Tags"] = {
		},
		["party_Auras"] = {
		},
		["Tags"] = {
		},
		["Clicks"] = {
		},
		["ClassIcon"] = {
		},
	},
	["profileKeys"] = {
		["暗黑界面 - 阿什坎迪"] = "暗黑界面 - 阿什坎迪",
	},
	["profiles"] = {
		["简洁界面 - 阿什坎迪"] = {
		},
		["暗黑界面 - 阿什坎迪"] = {
		},
	},
}
