
AdiBagsDB = {
	["namespaces"] = {
		["ItemLevel"] = {
		},
		["FilterOverride"] = {
			["profiles"] = {
				["Default"] = {
					["version"] = 3,
				},
			},
		},
		["ItemCategory"] = {
		},
		["NewItem"] = {
		},
		["Equipment"] = {
		},
		["MoneyFrame"] = {
		},
		["DataSource"] = {
		},
		["Junk"] = {
		},
		["AdiBags_TooltipInfo"] = {
		},
	},
	["profileKeys"] = {
		["暗黑界面 - 阿什坎迪"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["autoOpen"] = false,
			["positions"] = {
				["anchor"] = {
					["xOffset"] = -63.9998779296875,
					["yOffset"] = 172.8485260009766,
				},
				["Backpack"] = {
					["xOffset"] = -261.8589123353595,
					["yOffset"] = 370.9455865822074,
				},
			},
			["positionMode"] = "manual",
		},
	},
}
