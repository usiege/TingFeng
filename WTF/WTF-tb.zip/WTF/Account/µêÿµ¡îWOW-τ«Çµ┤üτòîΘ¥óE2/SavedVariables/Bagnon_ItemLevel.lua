
BagnonItemLevel_DB = {
	["enableRarityColoring"] = true,
}
