
TrufiGCDGlSave = nil
