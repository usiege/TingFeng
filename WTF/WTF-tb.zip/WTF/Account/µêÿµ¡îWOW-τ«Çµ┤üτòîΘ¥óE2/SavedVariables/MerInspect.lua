
MerInspectDB = {
	["ShowOwnFrameWhenInspecting"] = false,
	["ShowCharacterItemStats"] = true,
	["ShowInspectAngularBorder"] = false,
	["ShowCharacterItemSheet"] = true,
	["ShowInspectItemSheet"] = true,
	["version"] = 1,
	["ShowItemStats"] = true,
	["ShowItemSlotString"] = true,
	["ShowInspectColoredLabel"] = true,
	["ShowItemBorder"] = true,
}
