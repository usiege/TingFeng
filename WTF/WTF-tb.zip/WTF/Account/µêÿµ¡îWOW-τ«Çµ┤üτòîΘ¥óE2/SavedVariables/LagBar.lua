
LagBar_DB = {
	["homeping"] = true,
	["impdisplay"] = true,
	["bgShown"] = false,
	["scale"] = 0.702358322143555,
	["fps"] = true,
	["LagBar"] = {
		["yOfs"] = 0,
		["xOfs"] = -0,
		["point"] = "TOPLEFT",
		["relativePoint"] = "TOPLEFT",
	},
	["worldping"] = true,
}
