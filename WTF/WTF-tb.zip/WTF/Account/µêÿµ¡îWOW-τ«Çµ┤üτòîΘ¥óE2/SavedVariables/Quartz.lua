
Quartz3DB = {
	["namespaces"] = {
		["Swing"] = {
		},
		["Buff"] = {
		},
		["Interrupt"] = {
		},
		["Flight"] = {
		},
		["Pet"] = {
			["profiles"] = {
				["Default"] = {
					["x"] = 950.25646972656,
				},
			},
		},
		["EnemyCasts"] = {
		},
		["Player"] = {
			["profiles"] = {
				["Default"] = {
					["x"] = 925.25646972656,
				},
			},
		},
		["GCD"] = {
		},
		["Focus"] = {
			["profiles"] = {
				["Default"] = {
					["x"] = 950.25646972656,
				},
			},
		},
		["Target"] = {
			["profiles"] = {
				["Default"] = {
					["x"] = 950.25646972656,
				},
			},
		},
		["Range"] = {
		},
		["Mirror"] = {
		},
		["Latency"] = {
		},
	},
	["profileKeys"] = {
		["大哥别开火 - 阿什坎迪"] = "Default",
		["动能甫杜 - 阿什坎迪"] = "Default",
		["今晚就动手 - 阿什坎迪"] = "Default",
		["吸你的血 - 阿什坎迪"] = "Default",
		["交作业 - 阿什坎迪"] = "Default",
		["你说怎么办 - 阿什坎迪"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
		},
	},
}
