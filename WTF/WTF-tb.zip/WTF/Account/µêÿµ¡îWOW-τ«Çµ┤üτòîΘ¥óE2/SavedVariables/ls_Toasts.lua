
LS_TOASTS_GLOBAL_CONFIG = {
	["profileKeys"] = {
		["你要闹哪样 - 曼多基尔"] = "Default",
		["今晚就动手 - 阿什坎迪"] = "Default",
		["你说怎么办 - 曼多基尔"] = "Default",
		["榴莲亡反 - 曼多基尔"] = "Default",
		["大哥别开火 - 阿什坎迪"] = "Default",
		["气你马扎罗 - 阿什坎迪"] = "Default",
		["你说怎么办 - 阿什坎迪"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["colors"] = {
				["threshold"] = 4,
				["name"] = true,
			},
			["anchors"] = {
				{
					["point"] = {
						["rP"] = "BOTTOM",
						["p"] = "BOTTOM",
						["x"] = -7,
						["y"] = 282,
					},
					["growth_direction"] = "UP",
				}, -- [1]
			},
			["version"] = 1130301,
			["types"] = {
				["loot_gold"] = {
					["enabled"] = true,
					["dnd"] = false,
					["sfx"] = true,
					["anchor"] = 1,
					["track_loss"] = false,
					["threshold"] = 1,
				},
				["loot_items"] = {
					["enabled"] = true,
					["dnd"] = false,
					["sfx"] = true,
					["anchor"] = 1,
					["ilvl"] = true,
					["quest"] = false,
					["threshold"] = 1,
				},
			},
		},
	},
}
