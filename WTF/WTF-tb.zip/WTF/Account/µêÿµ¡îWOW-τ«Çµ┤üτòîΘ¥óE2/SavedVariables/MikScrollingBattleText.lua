
MSBTProfiles_SavedVars = {
	["profiles"] = {
		["Default"] = {
			["enableBlizzardDamage"] = false,
			["creationVersion"] = "5.7.152",
			["alwaysShowQuestItems"] = false,
			["events"] = {
				["NOTIFICATION_MONEY"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_ITEM_COOLDOWN"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_CURRENCY"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_PET_COOLDOWN"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_LOOT"] = {
					["disabled"] = true,
				},
			},
			["enableBlizzardHealing"] = true,
			["scrollAreas"] = {
				["Static"] = {
					["disabled"] = true,
				},
				["Incoming"] = {
					["direction"] = "Up",
					["disabled"] = true,
					["animationStyle"] = "Straight",
					["behavior"] = "MSBT_NORMAL",
					["scrollHeight"] = 195,
					["offsetX"] = -19,
					["stickyTextAlignIndex"] = 2,
					["offsetY"] = -185,
					["textAlignIndex"] = 2,
				},
				["Outgoing"] = {
					["stickyTextAlignIndex"] = 2,
					["animationStyle"] = "Straight",
					["behavior"] = "MSBT_NORMAL",
					["scrollHeight"] = 200,
					["offsetX"] = -19,
					["direction"] = "Up",
					["offsetY"] = 80,
					["textAlignIndex"] = 2,
				},
				["Notification"] = {
					["disabled"] = true,
				},
			},
			["soundsDisabled"] = true,
			["qualityExclusions"] = {
				true, -- [1]
				true, -- [2]
				true, -- [3]
			},
		},
	},
}
MSBT_SavedMedia = {
	["fonts"] = {
	},
	["sounds"] = {
	},
}
