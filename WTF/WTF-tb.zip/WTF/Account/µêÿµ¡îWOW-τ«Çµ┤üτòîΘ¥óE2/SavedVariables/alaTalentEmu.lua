
alaTalentEmuSV = nil
