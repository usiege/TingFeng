
PLAYER_INFO_SAVED = {
	["夜空风雪-狮心"] = {
		["class"] = "WARRIOR",
	},
	["东哥的女秘书-雷霆之击"] = {
		["class"] = "ROGUE",
	},
	["袁伟的爹-雷霆之击"] = {
		["class"] = "WARRIOR",
	},
	["夜空仓库一-哈霍兰"] = {
		["class"] = "WARRIOR",
	},
	["暗黑界面-阿什坎迪"] = {
		["class"] = "WARRIOR",
	},
	["夜空风雪-哈霍兰"] = {
		["class"] = "WARRIOR",
	},
	["小巨人-雷霆之击"] = {
		["class"] = "MAGE",
	},
	["银河系超嘻嘻-狮心"] = {
		["class"] = "WARRIOR",
	},
	["椿去湫来丶-碧空之歌"] = {
		["class"] = "HUNTER",
	},
	["Yagami-雷霆之击"] = {
		["class"] = "ROGUE",
	},
	["雪夜舞-雷霆之击"] = {
		["class"] = "ROGUE",
	},
	["怒气值留一点-碧空之歌"] = {
		["class"] = "WARRIOR",
	},
	["Galaxy-雷霆之击"] = {
		["class"] = "MAGE",
	},
	["Yagamilight-哈霍兰"] = {
		["class"] = "ROGUE",
	},
	["简洁界面-阿什坎迪"] = {
		["class"] = "WARRIOR",
	},
	["我的牛丑吗-碧空之歌"] = {
		["class"] = "SHAMAN",
	},
	["谁记湫情丶-碧空之歌"] = {
		["class"] = "MAGE",
	},
	["银河系超新星-雷霆之击"] = {
		["class"] = "WARRIOR",
	},
	["伊芙加登-雷霆之击"] = {
		["class"] = "ROGUE",
	},
	["小德你快来-碧空之歌"] = {
		["class"] = "DRUID",
	},
}
