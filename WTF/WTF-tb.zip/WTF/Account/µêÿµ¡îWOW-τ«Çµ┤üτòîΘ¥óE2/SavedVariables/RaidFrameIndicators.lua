
IndicatorsDB = {
	["profileKeys"] = {
		["大哥别开火 - 阿什坎迪"] = "Sharkboxer - 巨龙追猎者",
		["动能甫杜 - 阿什坎迪"] = "Sharkboxer - 巨龙追猎者",
		["今晚就动手 - 阿什坎迪"] = "Sharkboxer - 巨龙追猎者",
		["吸你的血 - 阿什坎迪"] = "Sharkboxer - 巨龙追猎者",
		["交作业 - 阿什坎迪"] = "Sharkboxer - 巨龙追猎者",
		["你说怎么办 - 阿什坎迪"] = "Sharkboxer - 巨龙追猎者",
	},
	["profiles"] = {
		["可爱小电工 - 巨龙追猎者"] = {
		},
		["哈尔滨靓妞 - 巨龙追猎者"] = {
		},
		["哈尔滨靓妞 - 席瓦莱恩"] = {
		},
		["家家户户 - 水晶之牙"] = {
		},
		["Sharkboxer - 巨龙追猎者"] = {
			["indicatorFont"] = "默认",
			["showRaidIcons"] = false,
			["frameScale"] = 0.9,
			["iconPosition"] = "TOP",
		},
		["库里北 - 巨龙追猎者"] = {
		},
		["度搜分 - 德姆塞卡尔"] = {
		},
	},
}
