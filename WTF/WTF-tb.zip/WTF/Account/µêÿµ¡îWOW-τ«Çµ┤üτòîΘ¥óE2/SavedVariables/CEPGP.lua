
CEPGP = {
	["Alt"] = {
		["SyncEP"] = true,
		["SyncGP"] = true,
		["Links"] = {
		},
	},
	["Log"] = {
	},
	["Decay"] = {
		["Separate"] = false,
	},
	["Loot"] = {
		["Announcement"] = " 开始分配，使用弹窗或使用关键词密我！",
		["ExtraKeywords"] = {
			["Keywords"] = {
			},
		},
		["Keyword"] = "!need",
		["RaidVisibility"] = {
			true, -- [1]
			false, -- [2]
		},
		["MinThreshold"] = 2,
		["MinReq"] = {
			false, -- [1]
			0, -- [2]
		},
		["GUI"] = {
			["Timer"] = 0,
			["Buttons"] = {
				{
					true, -- [1]
					"Main Spec", -- [2]
					0, -- [3]
					"Need", -- [4]
				}, -- [1]
				{
					false, -- [1]
					"Off Spec", -- [2]
					0, -- [3]
					"Greed", -- [4]
				}, -- [2]
				{
					false, -- [1]
					"Disenchant", -- [2]
					0, -- [3]
					"Disenchant", -- [4]
				}, -- [3]
				{
					false, -- [1]
					"Minor Upgrade", -- [2]
					0, -- [3]
					"Minor", -- [4]
				}, -- [4]
				{
					false, -- [1]
					"", -- [2]
					0, -- [3]
				}, -- [5]
				{
					false, -- [1]
					"Pass", -- [2]
					100, -- [3]
				}, -- [6]
			},
		},
	},
	["Attendance"] = {
	},
	["Traffic"] = {
	},
	["Standby"] = {
		["ByRank"] = true,
		["Roster"] = {
		},
		["Percent"] = 100,
		["Keyword"] = "standby",
		["Ranks"] = {
			{
				"", -- [1]
				false, -- [2]
			}, -- [1]
			{
				"", -- [1]
				false, -- [2]
			}, -- [2]
			{
				"", -- [1]
				false, -- [2]
			}, -- [3]
			{
				"", -- [1]
				false, -- [2]
			}, -- [4]
			{
				"", -- [1]
				false, -- [2]
			}, -- [5]
			{
				"", -- [1]
				false, -- [2]
			}, -- [6]
			{
				"", -- [1]
				false, -- [2]
			}, -- [7]
			{
				"", -- [1]
				false, -- [2]
			}, -- [8]
			{
				"", -- [1]
				false, -- [2]
			}, -- [9]
			{
				"", -- [1]
				false, -- [2]
			}, -- [10]
		},
	},
	["Exclusions"] = {
		false, -- [1]
		false, -- [2]
		false, -- [3]
		false, -- [4]
		false, -- [5]
		false, -- [6]
		false, -- [7]
		false, -- [8]
		false, -- [9]
		false, -- [10]
	},
	["PollRate"] = 0.0001,
	["Notice"] = false,
	["EP"] = {
		["BossEP"] = {
			["High Priestess Jeklik"] = 2,
			["Ragnaros"] = 7,
			["Buru the Gorger"] = 3,
			["Ossirian the Unscarred"] = 4,
			["Golemagg the Incinerator"] = 5,
			["Grand Widow Faerlina"] = 12,
			["High Priestess Mar'li"] = 2,
			["Majordomo Executus"] = 5,
			["High Priest Venoxis"] = 2,
			["Gehennas"] = 5,
			["Taerar"] = 7,
			["Ysondre"] = 7,
			["High Priest Thekal"] = 2,
			["Noth the Plaguebringer"] = 12,
			["Bloodlord Mandokir"] = 2,
			["Moam"] = 3,
			["The Prophet Skeram"] = 10,
			["Flamegor"] = 7,
			["C'Thun"] = 12,
			["General Rajaxx"] = 3,
			["Princess Huhuran"] = 10,
			["Thaddius"] = 15,
			["Loatheb"] = 15,
			["The Silithid Royalty"] = 10,
			["Ayamiss the Hunter"] = 3,
			["Ebonroc"] = 7,
			["Heigan the Unclean"] = 12,
			["Azuregos"] = 7,
			["High Priestess Arlokk"] = 2,
			["Baron Geddon"] = 5,
			["Sulfuron Harbinger"] = 5,
			["Kurinnaxx"] = 3,
			["Edge of Madness"] = 2,
			["Gothik the Harvester"] = 12,
			["Jin'do the Hexxer"] = 2,
			["Gluth"] = 12,
			["Lord Kazzak"] = 7,
			["Firemaw"] = 7,
			["Viscidus"] = 10,
			["Shazzrah"] = 5,
			["Gahz'ranka"] = 2,
			["Battleguard Sartura"] = 10,
			["Emeriss"] = 7,
			["Kel'Thuzad"] = 15,
			["Nefarian"] = 10,
			["Fankriss the Unyielding"] = 10,
			["Lucifron"] = 5,
			["Anub'Rekhan"] = 12,
			["Vaelastrasz the Corrupt"] = 7,
			["The Twin Emperors"] = 10,
			["Broodlord Lashlayer"] = 7,
			["Maexxna"] = 15,
			["Hakkar"] = 3,
			["The Four Horsemen"] = 15,
			["Onyxia"] = 5,
			["Grobbulus"] = 12,
			["Instructor Razuvious"] = 12,
			["Razorgore the Untamed"] = 7,
			["Magmadar"] = 5,
			["Ouro"] = 10,
			["Patchwerk"] = 12,
			["Lethon"] = 7,
			["Sapphiron"] = 15,
			["Chromaggus"] = 7,
			["Garr"] = 5,
		},
		["AutoAward"] = {
		},
	},
	["GP"] = {
		["Min"] = 1,
		["Mod"] = 1,
		["RaidModifiers"] = {
			["Blackwing Lair"] = 100,
			["The Ruins of Ahn'Qiraj"] = 100,
			["Onyxia's Lair"] = 100,
			["Naxxramas"] = 100,
			["The Temple of Ahn'Qiraj"] = 100,
			["Molten Core"] = 100,
			["Zul'Gurub"] = 100,
		},
		["Multiplier"] = 2,
		["Base"] = 4.83,
		["SlotWeights"] = {
			["2HWEAPON"] = 2,
			["NECK"] = 0.5,
			["HEAD"] = 1,
			["WEAPON"] = 1.5,
			["WRIST"] = 0.5,
			["WEAPONMAINHAND"] = 1.5,
			["SHIELD"] = 0.5,
			["HOLDABLE"] = 0.5,
			["RANGED"] = 2,
			["THROWN"] = 0.5,
			["FEET"] = 0.75,
			["RELIC"] = 0.5,
			["FINGER"] = 0.5,
			["WEAPONOFFHAND"] = 0.5,
			["TRINKET"] = 0.75,
			["WAND"] = 0.5,
			["CLOAK"] = 0.5,
			["CHEST"] = 1,
			["ROBE"] = 1,
			["HAND"] = 0.75,
			["WAIST"] = 0.75,
			["EXCEPTION"] = 1,
			["LEGS"] = 1,
			["SHOULDER"] = 0.75,
		},
	},
	["Overrides"] = {
	},
	["Channel"] = "Guild",
	["LootChannel"] = "Raid",
	["Sync"] = {
		false, -- [1]
		1, -- [2]
	},
	["Backups"] = {
	},
	["ChangelogVersion"] = "1.12.25",
}
CHANNEL = "Guild"
CEPGP_lootChannel = "Raid"
COEF = 4.83
MOD_COEF = 2
MOD = 1
AUTOEP = {
	["High Priestess Jeklik"] = true,
	["Ragnaros"] = true,
	["Buru the Gorger"] = true,
	["Ossirian the Unscarred"] = true,
	["Golemagg the Incinerator"] = true,
	["Grand Widow Faerlina"] = true,
	["High Priestess Mar'li"] = true,
	["Majordomo Executus"] = true,
	["High Priest Venoxis"] = true,
	["Gehennas"] = true,
	["Taerar"] = true,
	["Ysondre"] = true,
	["High Priest Thekal"] = true,
	["Noth the Plaguebringer"] = true,
	["Bloodlord Mandokir"] = true,
	["Moam"] = true,
	["The Prophet Skeram"] = true,
	["Flamegor"] = true,
	["C'Thun"] = true,
	["General Rajaxx"] = true,
	["Princess Huhuran"] = true,
	["Thaddius"] = true,
	["Loatheb"] = true,
	["The Silithid Royalty"] = true,
	["Ayamiss the Hunter"] = true,
	["Ebonroc"] = true,
	["Heigan the Unclean"] = true,
	["Kurinnaxx"] = true,
	["Azuregos"] = true,
	["High Priestess Arlokk"] = true,
	["Baron Geddon"] = true,
	["Sulfuron Harbinger"] = true,
	["Edge of Madness"] = true,
	["Lethon"] = true,
	["Jin'do the Hexxer"] = true,
	["Gluth"] = true,
	["Lord Kazzak"] = true,
	["Firemaw"] = true,
	["Viscidus"] = true,
	["Shazzrah"] = true,
	["Gahz'ranka"] = true,
	["Battleguard Sartura"] = true,
	["Emeriss"] = true,
	["Kel'Thuzad"] = true,
	["Nefarian"] = true,
	["Fankriss the Unyielding"] = true,
	["Lucifron"] = true,
	["Anub'Rekhan"] = true,
	["Vaelastrasz the Corrupt"] = true,
	["The Twin Emperors"] = true,
	["Broodlord Lashlayer"] = true,
	["Maexxna"] = true,
	["Hakkar"] = true,
	["The Four Horsemen"] = true,
	["Onyxia"] = true,
	["Grobbulus"] = true,
	["Instructor Razuvious"] = true,
	["Razorgore the Untamed"] = true,
	["Magmadar"] = true,
	["Ouro"] = true,
	["Patchwerk"] = true,
	["Gothik the Harvester"] = true,
	["Sapphiron"] = true,
	["Chromaggus"] = true,
	["Garr"] = true,
}
EPVALS = {
	["High Priestess Jeklik"] = 2,
	["Ragnaros"] = 7,
	["Buru the Gorger"] = 3,
	["Ossirian the Unscarred"] = 4,
	["Golemagg the Incinerator"] = 5,
	["Grand Widow Faerlina"] = 12,
	["High Priestess Mar'li"] = 2,
	["Majordomo Executus"] = 5,
	["High Priest Venoxis"] = 2,
	["Gehennas"] = 5,
	["Taerar"] = 7,
	["Ysondre"] = 7,
	["High Priest Thekal"] = 2,
	["Noth the Plaguebringer"] = 12,
	["Bloodlord Mandokir"] = 2,
	["Moam"] = 3,
	["The Prophet Skeram"] = 10,
	["Flamegor"] = 7,
	["C'Thun"] = 12,
	["General Rajaxx"] = 3,
	["Princess Huhuran"] = 10,
	["Thaddius"] = 15,
	["Loatheb"] = 15,
	["The Silithid Royalty"] = 10,
	["Ayamiss the Hunter"] = 3,
	["Ebonroc"] = 7,
	["Heigan the Unclean"] = 12,
	["Kurinnaxx"] = 3,
	["Azuregos"] = 7,
	["High Priestess Arlokk"] = 2,
	["Baron Geddon"] = 5,
	["Sulfuron Harbinger"] = 5,
	["Edge of Madness"] = 2,
	["Lethon"] = 7,
	["Jin'do the Hexxer"] = 2,
	["Gluth"] = 12,
	["Lord Kazzak"] = 7,
	["Firemaw"] = 7,
	["Viscidus"] = 10,
	["Shazzrah"] = 5,
	["Gahz'ranka"] = 2,
	["Battleguard Sartura"] = 10,
	["Emeriss"] = 7,
	["Kel'Thuzad"] = 15,
	["Nefarian"] = 10,
	["Fankriss the Unyielding"] = 10,
	["Lucifron"] = 5,
	["Anub'Rekhan"] = 12,
	["Vaelastrasz the Corrupt"] = 7,
	["The Twin Emperors"] = 10,
	["Broodlord Lashlayer"] = 7,
	["Maexxna"] = 15,
	["Hakkar"] = 3,
	["The Four Horsemen"] = 15,
	["Onyxia"] = 5,
	["Grobbulus"] = 12,
	["Instructor Razuvious"] = 12,
	["Razorgore the Untamed"] = 7,
	["Magmadar"] = 5,
	["Ouro"] = 10,
	["Patchwerk"] = 12,
	["Gothik the Harvester"] = 12,
	["Sapphiron"] = 15,
	["Chromaggus"] = 7,
	["Garr"] = 5,
}
BASEGP = 1
STANDBYEP = false
STANDBYOFFLINE = false
STANDBYPERCENT = 100
STANDBYRANKS = {
	{
		"", -- [1]
		false, -- [2]
	}, -- [1]
	{
		"", -- [1]
		false, -- [2]
	}, -- [2]
	{
		"", -- [1]
		false, -- [2]
	}, -- [3]
	{
		"", -- [1]
		false, -- [2]
	}, -- [4]
	{
		"", -- [1]
		false, -- [2]
	}, -- [5]
	{
		"", -- [1]
		false, -- [2]
	}, -- [6]
	{
		"", -- [1]
		false, -- [2]
	}, -- [7]
	{
		"", -- [1]
		false, -- [2]
	}, -- [8]
	{
		"", -- [1]
		false, -- [2]
	}, -- [9]
	{
		"", -- [1]
		false, -- [2]
	}, -- [10]
}
SLOTWEIGHTS = {
	["2HWEAPON"] = 2,
	["NECK"] = 0.5,
	["HEAD"] = 1,
	["WEAPON"] = 1.5,
	["WRIST"] = 0.5,
	["WEAPONMAINHAND"] = 1.5,
	["SHIELD"] = 0.5,
	["HOLDABLE"] = 0.5,
	["RANGED"] = 2,
	["THROWN"] = 0.5,
	["FEET"] = 0.75,
	["RELIC"] = 0.5,
	["FINGER"] = 0.5,
	["WEAPONOFFHAND"] = 0.5,
	["TRINKET"] = 0.75,
	["WAND"] = 0.5,
	["CLOAK"] = 0.5,
	["CHEST"] = 1,
	["ROBE"] = 1,
	["HAND"] = 0.75,
	["WAIST"] = 0.75,
	["EXCEPTION"] = 1,
	["LEGS"] = 1,
	["SHOULDER"] = 0.75,
}
RECORDS = {
}
OVERRIDE_INDEX = {
}
TRAFFIC = {
}
CEPGP_raid_logs = {
}
CEPGP_standby_accept_whispers = false
CEPGP_standby_byrank = true
CEPGP_standby_manual = false
CEPGP_standby_whisper_msg = "standby"
CEPGP_notice = false
CEPGP_keyword = "!need"
ALLOW_FORCED_SYNC = false
CEPGP_force_sync_rank = 1
CEPGP_loot_GUI = false
CEPGP_auto_pass = false
CEPGP_raid_wide_dist = {
	true, -- [1]
	false, -- [2]
}
CEPGP_standby_share = false
CEPGP_min_threshold = 2
CEPGP_gp_tooltips = false
CEPGP_standbyRoster = {
}
CEPGP_suppress_announcements = false
CEPGP_minEP = {
	false, -- [1]
	0, -- [2]
}
CEPGP_minGPDecayFactor = nil
CEPGP_response_buttons = {
	{
		true, -- [1]
		"Main Spec", -- [2]
		0, -- [3]
		"Need", -- [4]
	}, -- [1]
	{
		false, -- [1]
		"Off Spec", -- [2]
		0, -- [3]
		"Greed", -- [4]
	}, -- [2]
	{
		false, -- [1]
		"Disenchant", -- [2]
		0, -- [3]
		"Disenchant", -- [4]
	}, -- [3]
	{
		false, -- [1]
		"Minor Upgrade", -- [2]
		0, -- [3]
		"Minor", -- [4]
	}, -- [4]
	{
		false, -- [1]
		"", -- [2]
		0, -- [3]
	}, -- [5]
	{
		false, -- [1]
		"Pass", -- [2]
		100, -- [3]
	}, -- [6]
}
CEPGP_response_time = 0
CEPGP_show_passes = false
CEPGP_PR_sort = true
