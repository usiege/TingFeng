
SpeedyAutoLootDB = {
	["global"] = {
	},
}
