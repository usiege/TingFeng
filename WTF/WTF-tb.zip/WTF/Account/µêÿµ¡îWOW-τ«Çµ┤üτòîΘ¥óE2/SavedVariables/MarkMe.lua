
MMGLOBALS = {
}
