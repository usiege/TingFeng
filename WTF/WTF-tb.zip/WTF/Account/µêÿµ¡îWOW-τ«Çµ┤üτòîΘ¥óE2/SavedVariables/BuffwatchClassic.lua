
BuffwatchConfig = {
	["debug"] = false,
	["ExpiredSound"] = false,
	["CooldownTextScale"] = 0.449999988079071,
	["Version"] = "2.01",
	["ExpiredWarning"] = true,
	["Spirals"] = true,
	["Alpha"] = 0.5,
	["HideCooldownText"] = true,
}
