
RatingBusterDB = {
	["profileKeys"] = {
		["猎猎思密达 - 阿什坎迪"] = "profile",
		["暗黑界面 - 阿什坎迪"] = "profile",
		["简洁界面二 - 阿什坎迪"] = "profile",
		["简洁界面 - 阿什坎迪"] = "profile",
	},
	["profiles"] = {
		["profile"] = {
		},
	},
}
