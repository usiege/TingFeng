
cvred = 1
cvgreen = 0.996
cvblue = 0.545
cvalpha = 1
