
BattleGroundEnemiesDB = {
	["profileKeys"] = {
		["大哥别开火 - 阿什坎迪"] = "Default",
		["简洁界面 - 阿什坎迪"] = "Default",
		["今晚就动手 - 阿什坎迪"] = "Default",
		["暗黑界面 - 阿什坎迪"] = "Default",
		["猎猎思密达 - 阿什坎迪"] = "Default",
		["简洁界面二 - 阿什坎迪"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["onlyShowWhenNewVersion"] = true,
			["Allies"] = {
				["Enabled"] = false,
			},
			["lastReadVersion"] = "9.0.5.6",
			["Enemies"] = {
				["40"] = {
					["Enabled"] = false,
				},
				["RangeIndicator_Alpha"] = 0.6000000000000001,
				["15"] = {
					["Position_Y"] = 617.4916546178429,
					["Framescale"] = 0.65,
					["Position_X"] = 1165.280087360196,
				},
			},
		},
	},
}
