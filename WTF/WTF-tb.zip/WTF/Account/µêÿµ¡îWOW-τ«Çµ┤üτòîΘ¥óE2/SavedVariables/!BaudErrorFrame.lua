
BaudErrorFrameConfig = {
	["enableSound"] = false,
}
