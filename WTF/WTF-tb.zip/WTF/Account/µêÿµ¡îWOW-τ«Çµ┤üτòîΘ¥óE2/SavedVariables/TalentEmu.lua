
TalentEmuSV = {
	["set"] = {
		["credible"] = false,
		["supreme"] = false,
		["talents_in_tip"] = false,
		["minimapPos"] = 185,
	},
	["_version"] = 210524,
	["__upgraded"] = true,
	["var"] = {
		["Player-4792-025EAE5E"] = "940",
		["Player-4792-03A26BE8"] = "210",
		["savedTalent"] = {
		},
		["Player-4792-033FCC2E"] = "130",
		["Player-4792-026E8FC2"] = "930",
	},
}
