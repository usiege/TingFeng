
EasyFramesDB = {
	["profileKeys"] = {
		["气你马扎罗 - 阿什坎迪"] = "Default",
		["今晚就动手 - 阿什坎迪"] = "Default",
		["你要的毛巾 - 阿什坎迪"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["player"] = {
				["portrait"] = "1",
			},
			["general"] = {
				["showWelcomeMessage"] = false,
				["barTexture"] = "Swag",
			},
			["target"] = {
				["portrait"] = "1",
			},
		},
	},
}
