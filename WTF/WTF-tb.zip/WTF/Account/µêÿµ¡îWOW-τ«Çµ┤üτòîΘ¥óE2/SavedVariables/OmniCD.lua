
OmniCDDB = {
	["profileKeys"] = {
		["暗黑界面 - 阿什坎迪"] = "Default",
	},
	["cooldowns"] = {
	},
	["version"] = 2.51,
	["global"] = {
		["disableElvMsg"] = true,
	},
	["profiles"] = {
		["Default"] = {
			["Party"] = {
				["noneZoneSetting"] = "party",
				["party"] = {
					["icons"] = {
						["scale"] = 0.56,
					},
					["manualPos"] = {
						["interruptBar"] = {
							["y"] = 384.4000057280064,
							["x"] = 682.2667093853161,
						},
						["raidCDBar"] = {
							["y"] = 384.4000057280064,
							["x"] = 682.2667093853161,
						},
					},
				},
				["visibility"] = {
					["arena"] = false,
					["none"] = true,
				},
			},
		},
	},
}
