
Bartender4DB = {
	["namespaces"] = {
		["ActionBars"] = {
			["profiles"] = {
				["大哥别开火 - 阿什坎迪"] = {
					["actionbars"] = {
						{
							["padding"] = 6,
							["version"] = 3,
							["position"] = {
								["y"] = 41.75,
								["x"] = -510,
								["point"] = "BOTTOM",
							},
						}, -- [1]
						{
							["enabled"] = false,
							["version"] = 3,
							["position"] = {
								["y"] = 191.999969482422,
								["x"] = -231.500091552734,
								["point"] = "BOTTOM",
							},
						}, -- [2]
						{
							["padding"] = 5,
							["rows"] = 12,
							["version"] = 3,
							["position"] = {
								["y"] = 610,
								["x"] = -82,
								["point"] = "BOTTOMRIGHT",
							},
						}, -- [3]
						{
							["padding"] = 5,
							["rows"] = 12,
							["version"] = 3,
							["position"] = {
								["y"] = 610,
								["x"] = -42,
								["point"] = "BOTTOMRIGHT",
							},
						}, -- [4]
						{
							["padding"] = 6,
							["version"] = 3,
							["position"] = {
								["y"] = 110,
								["x"] = 3,
								["point"] = "BOTTOM",
							},
						}, -- [5]
						{
							["padding"] = 6,
							["version"] = 3,
							["position"] = {
								["y"] = 110,
								["x"] = -510,
								["point"] = "BOTTOM",
							},
						}, -- [6]
						{
						}, -- [7]
						{
						}, -- [8]
						[10] = {
						},
					},
				},
				["牛肉涨价 - 曼多基尔"] = {
					["actionbars"] = {
						{
							["padding"] = 6,
							["version"] = 3,
							["position"] = {
								["y"] = 41.75,
								["x"] = -510,
								["point"] = "BOTTOM",
							},
						}, -- [1]
						{
							["enabled"] = false,
							["version"] = 3,
							["position"] = {
								["y"] = 191.999969482422,
								["x"] = -231.500091552734,
								["point"] = "BOTTOM",
							},
						}, -- [2]
						{
							["rows"] = 12,
							["padding"] = 5,
							["version"] = 3,
							["position"] = {
								["y"] = 610,
								["x"] = -82,
								["point"] = "BOTTOMRIGHT",
							},
						}, -- [3]
						{
							["rows"] = 12,
							["padding"] = 5,
							["version"] = 3,
							["position"] = {
								["y"] = 610,
								["x"] = -42,
								["point"] = "BOTTOMRIGHT",
							},
						}, -- [4]
						{
							["padding"] = 6,
							["version"] = 3,
							["position"] = {
								["y"] = 110,
								["x"] = 3,
								["point"] = "BOTTOM",
							},
						}, -- [5]
						{
							["padding"] = 6,
							["version"] = 3,
							["position"] = {
								["y"] = 110,
								["x"] = -510,
								["point"] = "BOTTOM",
							},
						}, -- [6]
						{
						}, -- [7]
						{
						}, -- [8]
						[10] = {
						},
					},
				},
				["bf_infobox"] = {
					["actionbars"] = {
						{
							["version"] = 3,
							["position"] = {
								["y"] = 47.8087908477573,
								["x"] = -219.656203239822,
								["point"] = "BOTTOM",
								["scale"] = 0.899999976158142,
							},
							["padding"] = 6,
							["states"] = {
								["actionbar"] = true,
								["stance"] = {
									["ROGUE"] = {
										["shadowdance"] = 8,
									},
								},
							},
						}, -- [1]
						{
							["enabled"] = false,
							["version"] = 3,
							["position"] = {
								["y"] = 178.5,
								["x"] = -231.500030517578,
								["point"] = "BOTTOM",
							},
						}, -- [2]
						{
							["rows"] = 12,
							["version"] = 3,
							["position"] = {
								["y"] = 173.564138152047,
								["x"] = -41.08922366958,
								["point"] = "RIGHT",
								["scale"] = 0.899999976158142,
							},
							["padding"] = 5,
						}, -- [3]
						{
							["rows"] = 12,
							["version"] = 3,
							["position"] = {
								["y"] = 173.564302946965,
								["x"] = -80.0422377743962,
								["point"] = "RIGHT",
								["scale"] = 0.899999976158142,
							},
							["padding"] = 5,
						}, -- [4]
						{
							["version"] = 3,
							["position"] = {
								["y"] = 85.7098434631071,
								["x"] = -219.656120842363,
								["point"] = "BOTTOM",
								["scale"] = 0.899999976158142,
							},
							["padding"] = 6,
						}, -- [5]
						{
							["version"] = 3,
							["position"] = {
								["y"] = 123.244845367939,
								["x"] = -219.655983513265,
								["point"] = "BOTTOM",
								["scale"] = 0.899999976158142,
							},
							["padding"] = 6,
						}, -- [6]
						{
						}, -- [7]
						{
						}, -- [8]
						nil, -- [9]
						{
						}, -- [10]
					},
				},
				["榴莲亡反 - 曼多基尔"] = {
					["actionbars"] = {
						{
							["padding"] = 6,
							["version"] = 3,
							["position"] = {
								["y"] = 41.75,
								["x"] = -510,
								["point"] = "BOTTOM",
							},
						}, -- [1]
						{
							["enabled"] = false,
							["version"] = 3,
							["position"] = {
								["y"] = 199.500030517578,
								["x"] = -231.499938964844,
								["point"] = "BOTTOM",
							},
						}, -- [2]
						{
							["padding"] = 5,
							["rows"] = 12,
							["version"] = 3,
							["position"] = {
								["y"] = 610,
								["x"] = -82,
								["point"] = "BOTTOMRIGHT",
							},
						}, -- [3]
						{
							["padding"] = 5,
							["rows"] = 12,
							["version"] = 3,
							["position"] = {
								["y"] = 610,
								["x"] = -42,
								["point"] = "BOTTOMRIGHT",
							},
						}, -- [4]
						{
							["padding"] = 6,
							["version"] = 3,
							["position"] = {
								["y"] = 110,
								["x"] = 3,
								["point"] = "BOTTOM",
							},
						}, -- [5]
						{
							["padding"] = 6,
							["version"] = 3,
							["position"] = {
								["y"] = 110,
								["x"] = -510,
								["point"] = "BOTTOM",
							},
						}, -- [6]
						{
						}, -- [7]
						{
						}, -- [8]
						[10] = {
						},
					},
				},
				["今晚就动手 - 阿什坎迪"] = {
					["actionbars"] = {
						{
							["padding"] = 6,
							["version"] = 3,
							["position"] = {
								["y"] = 41.75,
								["x"] = -510,
								["point"] = "BOTTOM",
							},
						}, -- [1]
						{
							["enabled"] = false,
							["version"] = 3,
							["position"] = {
								["y"] = 191.999969482422,
								["x"] = -231.500091552734,
								["point"] = "BOTTOM",
							},
						}, -- [2]
						{
							["rows"] = 12,
							["padding"] = 5,
							["version"] = 3,
							["position"] = {
								["y"] = 610,
								["x"] = -82,
								["point"] = "BOTTOMRIGHT",
							},
						}, -- [3]
						{
							["rows"] = 12,
							["padding"] = 5,
							["version"] = 3,
							["position"] = {
								["y"] = 610,
								["x"] = -42,
								["point"] = "BOTTOMRIGHT",
							},
						}, -- [4]
						{
							["padding"] = 6,
							["version"] = 3,
							["position"] = {
								["y"] = 110,
								["x"] = 3,
								["point"] = "BOTTOM",
							},
						}, -- [5]
						{
							["padding"] = 6,
							["version"] = 3,
							["position"] = {
								["y"] = 110,
								["x"] = -510,
								["point"] = "BOTTOM",
							},
						}, -- [6]
						{
						}, -- [7]
						{
						}, -- [8]
						[10] = {
						},
					},
				},
				["吸你的血 - 阿什坎迪"] = {
					["actionbars"] = {
						{
							["padding"] = 6,
							["version"] = 3,
							["position"] = {
								["y"] = 41.75,
								["x"] = -510,
								["point"] = "BOTTOM",
							},
						}, -- [1]
						{
							["enabled"] = false,
							["version"] = 3,
							["position"] = {
								["y"] = -205,
								["x"] = -231.499938964844,
								["point"] = "CENTER",
							},
						}, -- [2]
						{
							["padding"] = 5,
							["rows"] = 12,
							["version"] = 3,
							["position"] = {
								["y"] = 610,
								["x"] = -82,
								["point"] = "BOTTOMRIGHT",
							},
						}, -- [3]
						{
							["padding"] = 5,
							["rows"] = 12,
							["version"] = 3,
							["position"] = {
								["y"] = 610,
								["x"] = -42,
								["point"] = "BOTTOMRIGHT",
							},
						}, -- [4]
						{
							["padding"] = 6,
							["version"] = 3,
							["position"] = {
								["y"] = 110,
								["x"] = 3,
								["point"] = "BOTTOM",
							},
						}, -- [5]
						{
							["padding"] = 6,
							["version"] = 3,
							["position"] = {
								["y"] = 110,
								["x"] = -510,
								["point"] = "BOTTOM",
							},
						}, -- [6]
						{
						}, -- [7]
						{
						}, -- [8]
						[10] = {
						},
					},
				},
				["大力出七级 - 阿什坎迪"] = {
					["actionbars"] = {
						{
							["padding"] = 6,
							["version"] = 3,
							["position"] = {
								["y"] = 41.75,
								["x"] = -510,
								["point"] = "BOTTOM",
							},
						}, -- [1]
						{
							["enabled"] = false,
							["version"] = 3,
							["position"] = {
								["y"] = 191.999969482422,
								["x"] = -231.500091552734,
								["point"] = "BOTTOM",
							},
						}, -- [2]
						{
							["padding"] = 5,
							["rows"] = 12,
							["version"] = 3,
							["position"] = {
								["y"] = 610,
								["x"] = -82,
								["point"] = "BOTTOMRIGHT",
							},
						}, -- [3]
						{
							["padding"] = 5,
							["rows"] = 12,
							["version"] = 3,
							["position"] = {
								["y"] = 610,
								["x"] = -42,
								["point"] = "BOTTOMRIGHT",
							},
						}, -- [4]
						{
							["padding"] = 6,
							["version"] = 3,
							["position"] = {
								["y"] = 110,
								["x"] = 3,
								["point"] = "BOTTOM",
							},
						}, -- [5]
						{
							["padding"] = 6,
							["version"] = 3,
							["position"] = {
								["y"] = 110,
								["x"] = -510,
								["point"] = "BOTTOM",
							},
						}, -- [6]
						{
						}, -- [7]
						{
						}, -- [8]
						[10] = {
						},
					},
				},
			},
		},
		["MicroMenu"] = {
			["profiles"] = {
				["大哥别开火 - 阿什坎迪"] = {
					["padding"] = -2,
					["version"] = 3,
					["position"] = {
						["scale"] = 1,
						["x"] = 33,
						["point"] = "BOTTOM",
						["y"] = 42,
					},
				},
				["牛肉涨价 - 曼多基尔"] = {
					["padding"] = -2,
					["version"] = 3,
					["position"] = {
						["scale"] = 1,
						["x"] = 33,
						["point"] = "BOTTOM",
						["y"] = 42,
					},
				},
				["bf_infobox"] = {
					["position"] = {
						["y"] = 67.1986032962591,
						["x"] = -188.774516068886,
						["point"] = "BOTTOMRIGHT",
						["scale"] = 0.800000011920929,
					},
					["version"] = 3,
				},
				["榴莲亡反 - 曼多基尔"] = {
					["padding"] = -2,
					["version"] = 3,
					["position"] = {
						["scale"] = 1,
						["x"] = 33,
						["point"] = "BOTTOM",
						["y"] = 42,
					},
				},
				["今晚就动手 - 阿什坎迪"] = {
					["padding"] = -2,
					["version"] = 3,
					["position"] = {
						["scale"] = 1,
						["x"] = 33,
						["point"] = "BOTTOM",
						["y"] = 42,
					},
				},
				["吸你的血 - 阿什坎迪"] = {
					["padding"] = -2,
					["version"] = 3,
					["position"] = {
						["scale"] = 1,
						["x"] = 33,
						["point"] = "BOTTOM",
						["y"] = 42,
					},
				},
				["大力出七级 - 阿什坎迪"] = {
					["padding"] = -2,
					["version"] = 3,
					["position"] = {
						["scale"] = 1,
						["x"] = 33,
						["point"] = "BOTTOM",
						["y"] = 42,
					},
				},
			},
		},
		["XPBar"] = {
			["profiles"] = {
				["大哥别开火 - 阿什坎迪"] = {
					["enabled"] = true,
					["version"] = 3,
					["position"] = {
						["y"] = 54,
						["x"] = -514,
						["point"] = "BOTTOM",
					},
				},
				["牛肉涨价 - 曼多基尔"] = {
					["enabled"] = true,
					["version"] = 3,
					["position"] = {
						["y"] = 54,
						["x"] = -514,
						["point"] = "BOTTOM",
					},
				},
				["bf_infobox"] = {
					["enabled"] = true,
					["fadeout"] = true,
					["fadeoutalpha"] = 0.2,
					["position"] = {
						["y"] = 130.918542991776,
						["x"] = -217.145500980361,
						["point"] = "BOTTOM",
						["scale"] = 0.439999997615814,
					},
					["version"] = 3,
					["fadeoutdelay"] = 1,
				},
				["榴莲亡反 - 曼多基尔"] = {
					["enabled"] = true,
					["version"] = 3,
					["position"] = {
						["y"] = 54,
						["x"] = -514,
						["point"] = "BOTTOM",
					},
				},
				["今晚就动手 - 阿什坎迪"] = {
					["enabled"] = true,
					["version"] = 3,
					["position"] = {
						["y"] = 54,
						["x"] = -514,
						["point"] = "BOTTOM",
					},
				},
				["吸你的血 - 阿什坎迪"] = {
					["enabled"] = true,
					["version"] = 3,
					["position"] = {
						["y"] = 54,
						["x"] = -514,
						["point"] = "BOTTOM",
					},
				},
				["大力出七级 - 阿什坎迪"] = {
					["enabled"] = true,
					["version"] = 3,
					["position"] = {
						["y"] = 54,
						["x"] = -514,
						["point"] = "BOTTOM",
					},
				},
			},
		},
		["UnitFrames"] = {
			["profiles"] = {
				["bf_infobox"] = {
					["uiScale"] = 0.799999952316284,
					["useUiScale"] = "1",
					["unitframes"] = {
						["PartyMemberFrame2"] = {
							["version"] = 3,
						},
						["MinimapCluster"] = {
							["version"] = 3,
						},
						["PartyMemberFrame4"] = {
							["version"] = 3,
						},
						["BuffFrame"] = {
							["version"] = 3,
						},
						["PlayerFrame"] = {
							["version"] = 3,
							["position"] = {
								["y"] = -177.413604736328,
								["x"] = -294.894958496094,
								["point"] = "CENTER",
							},
						},
						["PartyMemberFrame1"] = {
							["version"] = 3,
						},
						["TargetFrame"] = {
							["version"] = 3,
							["position"] = {
								["y"] = -175.339569091797,
								["x"] = 278.129638671875,
								["point"] = "CENTER",
							},
						},
						["PartyMemberFrame3"] = {
							["version"] = 3,
						},
						["CastingBarFrame"] = {
							["position"] = {
								["y"] = 189.369018554688,
								["x"] = 3.20040893554688,
							},
							["version"] = 3,
						},
					},
				},
			},
		},
		["BlizzardArt"] = {
			["profiles"] = {
				["大哥别开火 - 阿什坎迪"] = {
					["enabled"] = true,
					["version"] = 3,
					["position"] = {
						["y"] = 47,
						["x"] = -512,
						["point"] = "BOTTOM",
					},
				},
				["牛肉涨价 - 曼多基尔"] = {
					["enabled"] = true,
					["version"] = 3,
					["position"] = {
						["y"] = 47,
						["x"] = -512,
						["point"] = "BOTTOM",
					},
				},
				["bf_infobox"] = {
					["position"] = {
						["y"] = 160.750564575195,
						["x"] = 317.538269042969,
						["point"] = "BOTTOMLEFT",
					},
					["version"] = 3,
				},
				["榴莲亡反 - 曼多基尔"] = {
					["enabled"] = true,
					["version"] = 3,
					["position"] = {
						["y"] = 47,
						["x"] = -512,
						["point"] = "BOTTOM",
					},
				},
				["今晚就动手 - 阿什坎迪"] = {
					["enabled"] = true,
					["version"] = 3,
					["position"] = {
						["y"] = 47,
						["x"] = -512,
						["point"] = "BOTTOM",
					},
				},
				["吸你的血 - 阿什坎迪"] = {
					["enabled"] = true,
					["version"] = 3,
					["position"] = {
						["y"] = 47,
						["x"] = -512,
						["point"] = "BOTTOM",
					},
				},
				["大力出七级 - 阿什坎迪"] = {
					["enabled"] = true,
					["version"] = 3,
					["position"] = {
						["y"] = 47,
						["x"] = -512,
						["point"] = "BOTTOM",
					},
				},
			},
		},
		["BagBar"] = {
			["profiles"] = {
				["大哥别开火 - 阿什坎迪"] = {
					["padding"] = 5,
					["version"] = 3,
					["position"] = {
						["y"] = 41,
						["x"] = 296,
						["point"] = "BOTTOM",
					},
				},
				["牛肉涨价 - 曼多基尔"] = {
					["padding"] = 5,
					["version"] = 3,
					["position"] = {
						["y"] = 41,
						["x"] = 296,
						["point"] = "BOTTOM",
					},
				},
				["bf_infobox"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 33.6007848024485,
						["x"] = -199.999711548655,
						["point"] = "BOTTOMRIGHT",
						["scale"] = 0.800000011920929,
					},
					["padding"] = 4,
				},
				["榴莲亡反 - 曼多基尔"] = {
					["padding"] = 5,
					["version"] = 3,
					["position"] = {
						["y"] = 41,
						["x"] = 296,
						["point"] = "BOTTOM",
					},
				},
				["今晚就动手 - 阿什坎迪"] = {
					["padding"] = 5,
					["version"] = 3,
					["position"] = {
						["y"] = 41,
						["x"] = 296,
						["point"] = "BOTTOM",
					},
				},
				["吸你的血 - 阿什坎迪"] = {
					["padding"] = 5,
					["version"] = 3,
					["position"] = {
						["y"] = 41,
						["x"] = 296,
						["point"] = "BOTTOM",
					},
				},
				["大力出七级 - 阿什坎迪"] = {
					["padding"] = 5,
					["version"] = 3,
					["position"] = {
						["y"] = 41,
						["x"] = 296,
						["point"] = "BOTTOM",
					},
				},
			},
		},
		["Vehicle"] = {
			["profiles"] = {
				["大哥别开火 - 阿什坎迪"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 42.5000457763672,
						["x"] = 104.5,
						["point"] = "CENTER",
					},
				},
				["牛肉涨价 - 曼多基尔"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 42.5000457763672,
						["x"] = 104.5,
						["point"] = "CENTER",
					},
				},
				["bf_infobox"] = {
					["position"] = {
						["y"] = 186.592132568359,
						["x"] = 224.599639892578,
						["point"] = "BOTTOM",
					},
					["version"] = 3,
				},
				["榴莲亡反 - 曼多基尔"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 42.4999847412109,
						["x"] = 104.499908447266,
						["point"] = "CENTER",
					},
				},
				["今晚就动手 - 阿什坎迪"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 42.5000457763672,
						["x"] = 104.5,
						["point"] = "CENTER",
					},
				},
				["吸你的血 - 阿什坎迪"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 42.4999694824219,
						["x"] = 104.500122070313,
						["point"] = "CENTER",
					},
				},
				["大力出七级 - 阿什坎迪"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 42.5000457763672,
						["x"] = 104.5,
						["point"] = "CENTER",
					},
				},
			},
		},
		["StanceBar"] = {
			["profiles"] = {
				["大哥别开火 - 阿什坎迪"] = {
					["version"] = 3,
					["position"] = {
						["y"] = -14.9999809265137,
						["x"] = -82.5000076293945,
						["point"] = "CENTER",
					},
				},
				["牛肉涨价 - 曼多基尔"] = {
					["version"] = 3,
					["position"] = {
						["y"] = -14.9999809265137,
						["x"] = -82.5000076293945,
						["point"] = "CENTER",
					},
				},
				["bf_infobox"] = {
					["alpha"] = 0.6,
					["position"] = {
						["y"] = 163.715153744084,
						["x"] = -219.516292354856,
						["point"] = "BOTTOM",
						["scale"] = 0.899999976158142,
					},
					["version"] = 3,
				},
				["榴莲亡反 - 曼多基尔"] = {
					["version"] = 3,
					["position"] = {
						["y"] = -15.0000305175781,
						["x"] = -82.4999389648438,
						["point"] = "CENTER",
					},
				},
				["今晚就动手 - 阿什坎迪"] = {
					["version"] = 3,
					["position"] = {
						["scale"] = 1,
						["x"] = -460,
						["point"] = "BOTTOM",
						["y"] = 143,
					},
				},
				["吸你的血 - 阿什坎迪"] = {
					["version"] = 3,
					["position"] = {
						["y"] = -15,
						["x"] = -82.4999389648438,
						["point"] = "CENTER",
					},
				},
				["大力出七级 - 阿什坎迪"] = {
					["version"] = 3,
					["position"] = {
						["y"] = -14.9999809265137,
						["x"] = -82.5000076293945,
						["point"] = "CENTER",
					},
				},
			},
		},
		["PetBar"] = {
			["profiles"] = {
				["大哥别开火 - 阿什坎迪"] = {
					["position"] = {
						["y"] = 143,
						["x"] = -460,
						["point"] = "BOTTOM",
					},
				},
				["牛肉涨价 - 曼多基尔"] = {
					["position"] = {
						["y"] = 143,
						["x"] = -460,
						["point"] = "BOTTOM",
					},
				},
				["bf_infobox"] = {
					["position"] = {
						["y"] = 125,
						["x"] = -89,
						["point"] = "BOTTOM",
					},
				},
				["榴莲亡反 - 曼多基尔"] = {
					["position"] = {
						["y"] = 143,
						["x"] = -460,
						["point"] = "BOTTOM",
					},
				},
				["今晚就动手 - 阿什坎迪"] = {
					["position"] = {
						["y"] = 143,
						["x"] = -120,
						["point"] = "BOTTOM",
					},
				},
				["吸你的血 - 阿什坎迪"] = {
					["position"] = {
						["y"] = 143,
						["x"] = -460,
						["point"] = "BOTTOM",
					},
				},
				["大力出七级 - 阿什坎迪"] = {
					["position"] = {
						["y"] = 143,
						["x"] = -460,
						["point"] = "BOTTOM",
					},
				},
			},
		},
		["RepBar"] = {
			["profiles"] = {
				["大哥别开火 - 阿什坎迪"] = {
					["enabled"] = true,
					["version"] = 3,
					["position"] = {
						["y"] = 61,
						["x"] = -514,
						["point"] = "BOTTOM",
					},
				},
				["牛肉涨价 - 曼多基尔"] = {
					["enabled"] = true,
					["version"] = 3,
					["position"] = {
						["y"] = 61,
						["x"] = -514,
						["point"] = "BOTTOM",
					},
				},
				["bf_infobox"] = {
					["enabled"] = true,
					["position"] = {
						["y"] = 7.04153995513082,
						["x"] = -216.327214851983,
						["point"] = "BOTTOM",
						["scale"] = 0.439999997615814,
					},
					["version"] = 3,
				},
				["榴莲亡反 - 曼多基尔"] = {
					["enabled"] = true,
					["version"] = 3,
					["position"] = {
						["y"] = 61,
						["x"] = -514,
						["point"] = "BOTTOM",
					},
				},
				["今晚就动手 - 阿什坎迪"] = {
					["enabled"] = true,
					["version"] = 3,
					["position"] = {
						["y"] = 61,
						["x"] = -514,
						["point"] = "BOTTOM",
					},
				},
				["吸你的血 - 阿什坎迪"] = {
					["enabled"] = true,
					["version"] = 3,
					["position"] = {
						["y"] = 61,
						["x"] = -514,
						["point"] = "BOTTOM",
					},
				},
				["大力出七级 - 阿什坎迪"] = {
					["enabled"] = true,
					["version"] = 3,
					["position"] = {
						["y"] = 61,
						["x"] = -514,
						["point"] = "BOTTOM",
					},
				},
			},
		},
	},
	["profileKeys"] = {
		["大哥别开火 - 阿什坎迪"] = "bf_infobox",
		["牛肉涨价 - 曼多基尔"] = "bf_infobox",
		["榴莲亡反 - 曼多基尔"] = "bf_infobox",
		["今晚就动手 - 阿什坎迪"] = "bf_infobox",
		["吸你的血 - 阿什坎迪"] = "bf_infobox",
		["大力出七级 - 阿什坎迪"] = "bf_infobox",
	},
	["profiles"] = {
		["大哥别开火 - 阿什坎迪"] = {
			["focuscastmodifier"] = false,
			["blizzardVehicle"] = true,
			["outofrange"] = "hotkey",
		},
		["牛肉涨价 - 曼多基尔"] = {
			["focuscastmodifier"] = false,
			["blizzardVehicle"] = true,
			["outofrange"] = "hotkey",
		},
		["bf_infobox"] = {
			["snapping"] = false,
			["focuscastmodifier"] = false,
		},
		["榴莲亡反 - 曼多基尔"] = {
			["focuscastmodifier"] = false,
			["blizzardVehicle"] = true,
			["outofrange"] = "hotkey",
		},
		["今晚就动手 - 阿什坎迪"] = {
			["focuscastmodifier"] = false,
			["blizzardVehicle"] = true,
			["outofrange"] = "hotkey",
		},
		["吸你的血 - 阿什坎迪"] = {
			["focuscastmodifier"] = false,
			["blizzardVehicle"] = true,
			["outofrange"] = "hotkey",
		},
		["大力出七级 - 阿什坎迪"] = {
			["focuscastmodifier"] = false,
			["blizzardVehicle"] = true,
			["outofrange"] = "hotkey",
		},
	},
}
