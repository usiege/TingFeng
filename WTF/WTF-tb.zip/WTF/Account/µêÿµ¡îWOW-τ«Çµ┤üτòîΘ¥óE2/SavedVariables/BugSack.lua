
BugSackDB = {
	["auto"] = false,
	["altwipe"] = false,
	["useMaster"] = false,
	["fontSize"] = "GameFontHighlight",
	["mute"] = true,
	["soundMedia"] = "BugSack: Fatality",
	["chatframe"] = false,
}
BugSackLDBIconDB = {
}
