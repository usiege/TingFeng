
AddOnSkinsDB = {
	["profileKeys"] = {
		["暗黑界面 - 阿什坎迪"] = "Default",
		["今晚就动手 - 阿什坎迪"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["NovaWorldBuffs"] = false,
		},
	},
}
AddOnSkinsDS = {
}
