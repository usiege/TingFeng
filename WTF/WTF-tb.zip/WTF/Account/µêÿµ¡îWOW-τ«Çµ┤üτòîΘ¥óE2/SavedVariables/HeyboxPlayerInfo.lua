
HEYBOX_SAVED_PLAYER_INFOS = {
	["暗黑界面-阿什坎迪"] = {
		["class"] = "WARRIOR",
	},
	["简洁界面-阿什坎迪"] = {
		["class"] = "WARRIOR",
	},
}
