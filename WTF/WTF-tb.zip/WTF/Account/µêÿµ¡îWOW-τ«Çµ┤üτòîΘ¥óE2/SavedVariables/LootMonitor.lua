
LootMonitorDB = {
	["LootLog"] = {
	},
	["Config"] = {
		["ShowMinimapIcon"] = true,
		["MinimapIconAngle"] = 310,
		["EnteringCheck"] = true,
		["OutputPos"] = {
			"RIGHT", -- [1]
			true, -- [2]
			"RIGHT", -- [3]
			-20.00000381469727, -- [4]
			0, -- [5]
		},
		["OutputToRaidWarning"] = false,
		["BossOnly"] = false,
		["Enabled"] = true,
		["SetWindowPos"] = {
			"CENTER", -- [1]
			true, -- [2]
			"CENTER", -- [3]
			209.9999847412109, -- [4]
			0, -- [5]
		},
		["ExpireDay"] = 14,
		["Quality"] = 3,
	},
}
