
FriendListColorsDB = nil
