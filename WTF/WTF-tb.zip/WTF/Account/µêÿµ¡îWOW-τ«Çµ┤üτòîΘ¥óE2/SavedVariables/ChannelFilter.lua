
ChannelFilter_Config = {
	["FilterLevel"] = 1,
	["SetFliterLv"] = 5,
	["OrderWords"] = {
		"成就", -- [1]
		"幻化", -- [2]
	},
	["BanEnabled"] = 1,
	["IgnoreWords"] = {
		"付款", -- [1]
		"代练", -- [2]
	},
	["NewConfig"] = 2,
	["Enabled"] = 1,
}
