
MAILBAGDB = {
	["MAIL_DEFAULT"] = true,
	["QUALITY_COLORS"] = true,
	["ADVANCED"] = true,
	["GROUP_STACKS"] = true,
}
