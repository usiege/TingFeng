
BFCDB = {
	["namespaces"] = {
		["CHATFRAME"] = {
		},
		["ICONFRAME"] = {
		},
	},
	["profileKeys"] = {
		["大哥别开火 - 阿什坎迪"] = "Default",
		["今晚就动手 - 阿什坎迪"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["enableReportButton"] = false,
			["enableRollButton"] = false,
			["modules"] = {
				["ICONFRAME"] = false,
				["CHATFRAME"] = false,
			},
			["enablecopy"] = true,
			["enableRaidersButton"] = false,
		},
	},
}
BFCSystemCacheDB = nil
