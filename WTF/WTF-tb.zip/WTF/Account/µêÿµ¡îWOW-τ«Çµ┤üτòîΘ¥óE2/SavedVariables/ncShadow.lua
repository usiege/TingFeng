
ncShadowLevel = 50
