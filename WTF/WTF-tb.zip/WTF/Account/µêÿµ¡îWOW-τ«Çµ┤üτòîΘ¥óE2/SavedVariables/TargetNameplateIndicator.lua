
TargetNameplateIndicatorDB = {
	["profileKeys"] = {
		["大哥别开火 - 阿什坎迪"] = "Default",
		["今晚就动手 - 阿什坎迪"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["target"] = {
				["self"] = {
					["texture"] = "Interface\\AddOns\\TargetNameplateIndicator\\Textures\\NeonRedArrow",
				},
				["hostile"] = {
					["width"] = 30,
					["height"] = 30,
					["texture"] = "Interface\\AddOns\\TargetNameplateIndicator\\Textures\\NeonRedArrow",
				},
				["friendly"] = {
					["width"] = 30,
					["height"] = 30,
					["texture"] = "Interface\\AddOns\\TargetNameplateIndicator\\Textures\\NeonRedArrow",
				},
			},
			["mouseover"] = {
				["enable"] = false,
				["self"] = {
					["texture"] = "Interface\\AddOns\\TargetNameplateIndicator\\Textures\\NeonRedArrow",
				},
				["hostile"] = {
					["texture"] = "Interface\\AddOns\\TargetNameplateIndicator\\Textures\\NeonRedArrow",
				},
				["friendly"] = {
					["texture"] = "Interface\\AddOns\\TargetNameplateIndicator\\Textures\\NeonRedArrow",
				},
			},
			["focus"] = {
				["enable"] = false,
				["self"] = {
					["texture"] = "Interface\\AddOns\\TargetNameplateIndicator\\Textures\\NeonRedArrow",
				},
				["hostile"] = {
					["texture"] = "Interface\\AddOns\\TargetNameplateIndicator\\Textures\\NeonRedArrow",
				},
				["friendly"] = {
					["texture"] = "Interface\\AddOns\\TargetNameplateIndicator\\Textures\\NeonRedArrow",
				},
			},
		},
	},
}
