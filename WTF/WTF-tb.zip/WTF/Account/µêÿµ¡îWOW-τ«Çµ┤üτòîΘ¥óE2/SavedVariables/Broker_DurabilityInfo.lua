
Broker_DurabilityInfoDB = {
	["profileKeys"] = {
	},
	["profiles"] = {
		["Default"] = {
		},
	},
}
