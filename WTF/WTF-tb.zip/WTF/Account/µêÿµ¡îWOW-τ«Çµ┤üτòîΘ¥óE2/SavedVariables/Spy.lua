
SpyDB = {
	["kosData"] = {
		["阿什坎迪"] = {
			["Alliance"] = {
				["简洁界面"] = {
				},
				["今晚就动手"] = {
				},
			},
		},
	},
	["removeKOSData"] = {
		["阿什坎迪"] = {
			["Alliance"] = {
			},
		},
	},
	["profileKeys"] = {
		["今晚就动手 - 阿什坎迪"] = "今晚就动手 - 阿什坎迪",
	},
	["profiles"] = {
		["今晚就动手 - 阿什坎迪"] = {
			["AppendUnitNameCheck"] = true,
			["MainWindowVis"] = false,
			["Colors"] = {
				["Bar"] = {
					["Bar Text"] = {
						["a"] = 1,
					},
				},
			},
			["AppendUnitKoSCheck"] = true,
		},
		["简洁界面 - 阿什坎迪"] = {
			["Colors"] = {
				["Bar"] = {
					["Bar Text"] = {
						["a"] = 1,
					},
				},
			},
			["AppendUnitNameCheck"] = true,
			["MainWindowVis"] = false,
			["AppendUnitKoSCheck"] = true,
		},
	},
}
