
WhisperPopDB = {
	["ignoreTags"] = 1,
	["listHeight"] = 320,
	["keepDatas"] = {
	},
	["sound"] = 1,
	["applyFilters"] = 1,
	["listWidth"] = 200,
	["keep"] = 1,
	["version"] = 4.12,
	["buttonScale"] = 100,
	["history"] = {
	},
	["time"] = 1,
	["listScale"] = 100,
	["foreignOnly"] = 1,
	["help"] = 1,
	["notifyButton"] = 1,
	["save"] = 1,
}
