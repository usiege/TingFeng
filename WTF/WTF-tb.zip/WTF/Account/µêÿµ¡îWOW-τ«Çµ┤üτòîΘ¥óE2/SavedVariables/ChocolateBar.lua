
ChocolateBarDB = {
	["profileKeys"] = {
		["今晚就动手 - 阿什坎迪"] = "Default",
	},
	["addonVersion"] = "v3.3.4",
	["profiles"] = {
		["Default"] = {
			["moduleOptions"] = {
				["MoreChocolate"] = {
				},
			},
			["objSettings"] = {
				["ShowMeMyHealIcon"] = {
					["barName"] = "ChocolateBar1",
				},
				["!BaudErrorFrame"] = {
					["showText"] = false,
					["barName"] = "ChocolateBar1",
					["align"] = "right",
				},
				["MeetingHorn"] = {
					["barName"] = "ChocolateBar1",
				},
				["alaTalentEmu"] = {
					["showText"] = false,
					["barName"] = "ChocolateBar1",
					["align"] = "right",
				},
				["DBM"] = {
					["showText"] = false,
					["barName"] = "ChocolateBar1",
					["align"] = "right",
				},
				["AtlasLoot"] = {
					["showText"] = false,
					["barName"] = "ChocolateBar1",
					["align"] = "right",
				},
				["Poisoner"] = {
					["barName"] = "ChocolateBar1",
				},
				["WeakAuras"] = {
					["showText"] = false,
					["barName"] = "ChocolateBar1",
					["align"] = "right",
				},
				["StealYourCarbon"] = {
					["showText"] = false,
					["barName"] = "ChocolateBar1",
					["align"] = "right",
				},
				["GoodLeader"] = {
					["barName"] = "ChocolateBar1",
				},
				["Atlas"] = {
					["showText"] = false,
					["barName"] = "ChocolateBar1",
					["align"] = "right",
				},
				["alacal"] = {
					["showText"] = false,
					["barName"] = "ChocolateBar1",
					["align"] = "right",
				},
				["Volume"] = {
					["barName"] = "ChocolateBar1",
				},
				["NWB"] = {
					["showText"] = false,
					["barName"] = "ChocolateBar1",
					["align"] = "right",
				},
				["HandyNotes_NPCs"] = {
					["showText"] = false,
					["barName"] = "ChocolateBar1",
					["align"] = "right",
				},
				["Friends"] = {
					["barName"] = "ChocolateBar1",
				},
				["Leatrix_Maps"] = {
					["showText"] = false,
					["barName"] = "ChocolateBar1",
					["align"] = "right",
				},
				["!!!163UI!!!"] = {
					["showText"] = false,
					["barName"] = "ChocolateBar1",
					["align"] = "right",
				},
				["MoreChocolate"] = {
					["showText"] = false,
					["barName"] = "ChocolateBar1",
					["align"] = "right",
				},
				["Dominos"] = {
					["showText"] = false,
					["barName"] = "ChocolateBar1",
					["align"] = "right",
				},
				["Equipment"] = {
					["barName"] = "ChocolateBar1",
				},
				["Accountant_Classic"] = {
					["barName"] = "ChocolateBar1",
				},
				["BagnonLauncher"] = {
					["showText"] = false,
					["barName"] = "ChocolateBar1",
					["align"] = "right",
				},
				["Masque"] = {
					["showText"] = false,
					["barName"] = "ChocolateBar1",
					["align"] = "right",
				},
			},
			["fixedStrata"] = true,
		},
	},
}
CB_PlayedTime = nil
