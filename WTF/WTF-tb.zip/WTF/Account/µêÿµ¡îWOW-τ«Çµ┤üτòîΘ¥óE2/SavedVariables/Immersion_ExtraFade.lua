
IEF_Config = {
	["hideTrackingBar"] = false,
	["hideFrameRateCinematic"] = true,
	["hideFrameRate"] = true,
	["trackingBarAlpha"] = 0.33,
	["hideChatFrame"] = false,
}
