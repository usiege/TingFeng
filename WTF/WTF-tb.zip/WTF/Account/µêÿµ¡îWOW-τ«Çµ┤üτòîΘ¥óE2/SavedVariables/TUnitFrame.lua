
TUF_Config = {
	["inited"] = true,
}
BUnitFrame_Config = {
	["tt"] = {
		["enabled"] = true,
		["theme"] = "classical",
	},
	["casting_flash"] = true,
	["version"] = 2.8,
	["focus"] = {
		["enabled"] = true,
		["theme"] = "vertical",
	},
	["casting_icon"] = true,
	["ttt"] = {
		["enabled"] = false,
		["theme"] = "classical",
	},
	["sysFocus_t"] = {
		["enabled"] = true,
		["theme"] = "classical",
	},
	["sysFocus_tt"] = {
		["enabled"] = false,
		["theme"] = "classical",
	},
}
