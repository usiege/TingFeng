
WWM_friendsWhisp = nil
WWM_guildWhisp = nil
WWM_totallastplayers = nil
WWM_entries = nil
