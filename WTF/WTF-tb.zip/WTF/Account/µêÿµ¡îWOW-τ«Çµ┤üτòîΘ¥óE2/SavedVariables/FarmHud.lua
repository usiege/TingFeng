
FarmHudDB = {
	["coords_color"] = {
		1, -- [1]
		0.82, -- [2]
		0, -- [3]
		0.7, -- [4]
	},
	["background_alpha"] = 0,
	["cardinalpoints_color2"] = {
		1, -- [1]
		0.82, -- [2]
		0, -- [3]
		0.7, -- [4]
	},
	["tracking^136459"] = "client",
	["tracking^136456"] = "client",
	["time_server"] = true,
	["tracking^136465"] = "client",
	["coords_radius"] = 0.51,
	["cardinalpoints_color1"] = {
		1, -- [1]
		0.82, -- [2]
		0, -- [3]
		0.7, -- [4]
	},
	["tracking^136458"] = "client",
	["hud_scale"] = 1.4,
	["tracking^136457"] = "client",
	["QuestArrowInfoMsg"] = false,
	["tracking^136463"] = "client",
	["gathercircle_color"] = {
		0, -- [1]
		1, -- [2]
		0, -- [3]
		0.5, -- [4]
	},
	["rotation"] = true,
	["buttons_alpha"] = 0.6,
	["hud_size"] = 1,
	["mouseoverinfo_color"] = {
		1, -- [1]
		0.82, -- [2]
		0, -- [3]
		0.7, -- [4]
	},
	["buttons_show"] = false,
	["coords_show"] = true,
	["showDummy"] = true,
	["gathercircle_show"] = true,
	["tracking^136453"] = "client",
	["cardinalpoints_show"] = true,
	["tracking^136455"] = "client",
	["cardinalpoints_radius"] = 0.47,
	["tracking^136464"] = "client",
	["tracking^136451"] = "client",
	["buttons_buttom"] = false,
	["time_bottom"] = false,
	["healcircle_color"] = {
		0, -- [1]
		0.7, -- [2]
		1, -- [3]
		0.5, -- [4]
	},
	["MinimapIcon"] = {
		["minimapPos"] = 220,
		["radius"] = 80,
		["hide"] = false,
	},
	["showDummyBg"] = true,
	["text_scale"] = 1.4,
	["time_show"] = true,
	["time_color"] = {
		1, -- [1]
		0.82, -- [2]
		0, -- [3]
		0.7, -- [4]
	},
	["tracking^136454"] = "client",
	["coords_bottom"] = false,
	["healcircle_show"] = true,
	["time_radius"] = 0.48,
	["SuperTrackedQuest"] = true,
	["holdKeyForMouseOn"] = "_none",
	["player_dot"] = "blizz",
	["time_local"] = true,
	["tracking^136452"] = "client",
	["buttons_radius"] = 0.56,
}
