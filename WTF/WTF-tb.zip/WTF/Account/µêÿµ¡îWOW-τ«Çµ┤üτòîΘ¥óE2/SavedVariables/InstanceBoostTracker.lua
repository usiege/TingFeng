
SavedAccountLockouts = {
}
SavedCharacterLockouts = {
}
SavedStatistics = {
}
SpeedyAutoLootDB = {
	["global"] = {
	},
}
