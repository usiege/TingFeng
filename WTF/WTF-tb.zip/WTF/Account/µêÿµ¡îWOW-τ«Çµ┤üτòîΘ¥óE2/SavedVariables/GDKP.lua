
GDKP_DB = {
	["profileKeys"] = {
		["今晚就动手 - 阿什坎迪"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["minimap"] = {
				["minimapPos"] = 240,
				["radius"] = 80,
				["hide"] = false,
			},
		},
	},
}
GDKP_Frames_Config = nil
