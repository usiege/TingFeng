
GladdyXZ = {
	["profileKeys"] = {
		["猎猎思密达 - 阿什坎迪"] = "简洁界面 - 阿什坎迪",
		["暗黑界面 - 阿什坎迪"] = "Default",
		["简洁界面二 - 阿什坎迪"] = "简洁界面 - 阿什坎迪",
		["简洁界面 - 阿什坎迪"] = "简洁界面 - 阿什坎迪",
	},
	["profiles"] = {
		["Default"] = {
			["auraFontSizeScale"] = 0.9,
			["rangeCheckTrinket"] = true,
			["npTotemPlatesSize"] = 30,
			["shadowsightTimerX"] = 406.3031616210938,
			["ciYOffset"] = -21.19999999999999,
			["classIconSize"] = 80,
			["shadowsightTimerRelPoint1"] = "TOP",
			["rangeCheckRacial"] = true,
			["shadowsightTimerY"] = -144.712158203125,
			["announcements"] = {
				["health"] = true,
			},
			["cooldownSize"] = 38,
			["y"] = 592.9090665288386,
			["shadowsightTimerRelPoint2"] = "TOP",
			["rangeCheckClassIcon"] = true,
			["cooldownFontScale"] = 0.7000000000000001,
			["x"] = 1012.241055847844,
			["frameScale"] = 0.6,
			["racialSize"] = 80,
			["barWidth"] = 200,
		},
		["简洁界面 - 阿什坎迪"] = {
			["frameScale"] = 0.7000000000000001,
			["locked"] = true,
			["x"] = 967.7646330264834,
			["y"] = 549.4666429643403,
		},
	},
}
