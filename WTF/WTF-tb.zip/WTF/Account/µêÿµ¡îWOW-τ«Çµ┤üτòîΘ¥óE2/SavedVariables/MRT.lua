
VMRT = {
	["Timers"] = {
		["specTimes"] = {
			[62] = 10,
			[63] = 10,
			[250] = 10,
			[251] = 10,
			[64] = 10,
			[253] = 10,
			[65] = 10,
			[255] = 10,
			[66] = 10,
			[257] = 10,
			[258] = 10,
			[259] = 10,
			[260] = 10,
			[261] = 25,
			[262] = 16,
			[263] = 10,
			[264] = 10,
			[265] = 22,
			[266] = 10,
			[267] = 10,
			[268] = 10,
			[269] = 10,
			[270] = 10,
			[70] = 10,
			[102] = 10,
			[71] = 10,
			[103] = 10,
			[72] = 10,
			[104] = 10,
			[73] = 10,
			[581] = 10,
			[105] = 10,
			[577] = 10,
			[256] = 10,
			[254] = 10,
			[252] = 10,
		},
		["Type"] = 2,
		["Strata"] = "HIGH",
		["timeToKillAnalyze"] = 15,
	},
	["ProfileKeys"] = {
		["猎猎思密达-阿什坎迪"] = "default",
		["简洁界面-阿什坎迪"] = "default",
		["简洁界面二-阿什坎迪"] = "default",
		["大哥别开火-阿什坎迪"] = "default",
		["暗黑界面-阿什坎迪"] = "default",
		["今晚就动手-阿什坎迪"] = "default",
	},
	["Encounter"] = {
		["list"] = {
			["暗黑界面"] = {
			},
			["简洁界面二"] = {
			},
			["猎猎思密达"] = {
			},
			["简洁界面"] = {
			},
			["大哥别开火"] = {
			},
			["今晚就动手"] = {
			},
		},
		["names"] = {
		},
	},
	["Marks"] = {
		["list"] = {
		},
	},
	["ExCD2"] = {
		["upd4525"] = true,
		["gnGUIDs"] = {
			["暗黑界面"] = 0,
			["简洁界面二"] = 0,
			["猎猎思密达"] = 0,
			["简洁界面"] = 0,
			["大哥别开火"] = 0,
			["今晚就动手"] = 0,
		},
		["NoRaid"] = true,
		["CDECol"] = {
		},
		["upd4380"] = true,
		["Save"] = {
		},
		["Profiles"] = {
			["Now"] = "default",
			["List"] = {
			},
		},
		["userDB"] = {
		},
		["colSet"] = {
			{
				["enabled"] = true,
				["frameGeneral"] = true,
				["iconGray"] = true,
				["textGeneral"] = true,
				["methodsGeneral"] = true,
				["blacklistGeneral"] = true,
				["fontShadow"] = false,
				["iconGeneral"] = true,
				["fontOutline"] = true,
				["visibilityGeneral"] = true,
				["fontGeneral"] = true,
				["textureAnimation"] = true,
				["textureGeneral"] = true,
			}, -- [1]
			{
				["enabled"] = true,
				["frameGeneral"] = true,
				["iconGray"] = true,
				["textGeneral"] = true,
				["methodsGeneral"] = true,
				["blacklistGeneral"] = true,
				["fontShadow"] = false,
				["iconGeneral"] = true,
				["fontOutline"] = true,
				["visibilityGeneral"] = true,
				["fontGeneral"] = true,
				["textureAnimation"] = true,
				["textureGeneral"] = true,
			}, -- [2]
			{
				["enabled"] = true,
				["frameGeneral"] = true,
				["iconGray"] = true,
				["textGeneral"] = true,
				["methodsGeneral"] = true,
				["blacklistGeneral"] = true,
				["fontShadow"] = false,
				["iconGeneral"] = true,
				["fontOutline"] = true,
				["visibilityGeneral"] = true,
				["fontGeneral"] = true,
				["textureAnimation"] = true,
				["textureGeneral"] = true,
			}, -- [3]
			{
				["frameGeneral"] = true,
				["iconGray"] = true,
				["textGeneral"] = true,
				["methodsGeneral"] = true,
				["blacklistGeneral"] = true,
				["fontShadow"] = false,
				["iconGeneral"] = true,
				["fontOutline"] = true,
				["visibilityGeneral"] = true,
				["fontGeneral"] = true,
				["textureAnimation"] = true,
				["textureGeneral"] = true,
			}, -- [4]
			{
				["frameGeneral"] = true,
				["iconGray"] = true,
				["textGeneral"] = true,
				["methodsGeneral"] = true,
				["blacklistGeneral"] = true,
				["fontShadow"] = false,
				["iconGeneral"] = true,
				["fontOutline"] = true,
				["visibilityGeneral"] = true,
				["fontGeneral"] = true,
				["textureAnimation"] = true,
				["textureGeneral"] = true,
			}, -- [5]
			{
				["frameGeneral"] = true,
				["iconGray"] = true,
				["textGeneral"] = true,
				["methodsGeneral"] = true,
				["blacklistGeneral"] = true,
				["fontShadow"] = false,
				["iconGeneral"] = true,
				["fontOutline"] = true,
				["visibilityGeneral"] = true,
				["fontGeneral"] = true,
				["textureAnimation"] = true,
				["textureGeneral"] = true,
			}, -- [6]
			{
				["frameGeneral"] = true,
				["iconGray"] = true,
				["textGeneral"] = true,
				["methodsGeneral"] = true,
				["blacklistGeneral"] = true,
				["fontShadow"] = false,
				["iconGeneral"] = true,
				["fontOutline"] = true,
				["visibilityGeneral"] = true,
				["fontGeneral"] = true,
				["textureAnimation"] = true,
				["textureGeneral"] = true,
			}, -- [7]
			{
				["frameGeneral"] = true,
				["iconGray"] = true,
				["textGeneral"] = true,
				["methodsGeneral"] = true,
				["blacklistGeneral"] = true,
				["fontShadow"] = false,
				["iconGeneral"] = true,
				["fontOutline"] = true,
				["visibilityGeneral"] = true,
				["fontGeneral"] = true,
				["textureAnimation"] = true,
				["textureGeneral"] = true,
			}, -- [8]
			{
				["frameGeneral"] = true,
				["iconGray"] = true,
				["textGeneral"] = true,
				["methodsGeneral"] = true,
				["blacklistGeneral"] = true,
				["fontShadow"] = false,
				["iconGeneral"] = true,
				["fontOutline"] = true,
				["visibilityGeneral"] = true,
				["fontGeneral"] = true,
				["textureAnimation"] = true,
				["textureGeneral"] = true,
			}, -- [9]
			{
				["frameGeneral"] = true,
				["iconGray"] = true,
				["textGeneral"] = true,
				["methodsGeneral"] = true,
				["blacklistGeneral"] = true,
				["fontShadow"] = false,
				["iconGeneral"] = true,
				["fontOutline"] = true,
				["visibilityGeneral"] = true,
				["fontGeneral"] = true,
				["textureAnimation"] = true,
				["textureGeneral"] = true,
			}, -- [10]
			{
				["frameGeneral"] = true,
				["iconGray"] = true,
				["textGeneral"] = true,
				["methodsGeneral"] = true,
				["blacklistGeneral"] = true,
				["fontShadow"] = false,
				["iconGeneral"] = true,
				["fontOutline"] = true,
				["visibilityGeneral"] = true,
				["fontGeneral"] = true,
				["textureAnimation"] = true,
				["textureGeneral"] = true,
			}, -- [11]
		},
		["Priority"] = {
		},
		["CDE"] = {
		},
		["OptFav"] = {
		},
	},
	["Attendance"] = {
		["data"] = {
		},
		["alts"] = {
		},
	},
	["Inspect"] = {
		["Soulbinds"] = {
		},
	},
	["InspectViewer"] = {
		["ColorizeLowIlvl685"] = false,
		["ColorizeNoEnch"] = true,
		["ColorizeNoGems"] = true,
		["ColorizeLowIlvl"] = true,
		["ColorizeNoTopEnchGems"] = false,
		["ColorizeNoValorUpgrade"] = false,
	},
	["InviteTool"] = {
		["Words"] = "инв inv byd штм 123",
		["InvByChat"] = true,
		["RaidDiff"] = 16,
		["PromoteRank"] = 2,
		["Ranks"] = {
			true, -- [1]
		},
		["LootThreshold"] = 2,
		["MasterLooters"] = "",
		["LootMethod"] = "group",
		["PromoteNames"] = "",
		["OnlyGuild"] = true,
		["Rank"] = 1,
	},
	["Addon"] = {
		["Timer"] = 0.1,
		["PreVersion"] = 4600,
		["Version"] = 4600,
		["migrateMRT"] = true,
	},
	["WhoPulled"] = {
	},
	["BossWatcher"] = {
		["optionsDamageGraph"] = true,
		["fightsNum"] = 2,
		["optionsPositionsDist"] = true,
		["optionsHealingGraph"] = true,
		["trackingDamageSpells"] = {
		},
	},
	["Profiles"] = {
	},
	["Profile"] = "default",
	["LootLink"] = {
	},
	["RaidGroups"] = {
		["KeepPosInGroup"] = true,
		["upd4550"] = true,
		["profiles"] = {
		},
	},
	["Note"] = {
		["BlackNames"] = {
		},
		["FontSize"] = 12,
		["AutoLoad"] = {
		},
		["Width"] = 200.000152587891,
		["BlackLastUpdateName"] = {
		},
		["Black"] = {
			"", -- [1]
			"", -- [2]
			"", -- [3]
		},
		["Strata"] = "HIGH",
		["Height"] = 100.000022888184,
		["OnlyPromoted"] = true,
		["BlackLastUpdateTime"] = {
		},
		["OptionsFormatting"] = true,
	},
	["Logging"] = {
	},
	["MarksBar"] = {
		["pulltimer"] = 10,
		["pulltimer_right"] = 10,
		["Show"] = {
			true, -- [1]
			true, -- [2]
			true, -- [3]
			true, -- [4]
			true, -- [5]
		},
		["Strata"] = "HIGH",
	},
	["VisNote"] = {
		["data"] = {
		},
		["sync_data"] = {
		},
	},
	["RaidCheck"] = {
		["FlaskExp"] = 1,
		["BuffsCheck"] = true,
		["ReadyCheckFrame"] = true,
		["ReadyCheckFrameTimerFade"] = 4,
		["ReadyCheckFrameOnlyRL"] = true,
		["WeaponEnch"] = {
		},
	},
}
