
TDDB_PACK2 = {
	["profileKeys"] = {
	},
	["profiles"] = {
		["Default"] = {
			["rules"] = {
				["saving"] = {
					16885, -- [1]
					{
						["rule"] = "type:商品 & !spell & !bop",
						["icon"] = 132905,
						["comment"] = "商品",
					}, -- [2]
				},
				["sorting"] = {
					6948, -- [1]
					{
						["rule"] = "type:坐骑",
						["icon"] = 132261,
						["comment"] = "坐骑",
					}, -- [2]
					{
						["rule"] = "type:宠物",
						["icon"] = 132598,
						["comment"] = "宠物",
					}, -- [3]
					{
						["comment"] = "工具",
						["children"] = {
							5060, -- [1]
							2901, -- [2]
							5956, -- [3]
							7005, -- [4]
							9149, -- [5]
							16207, -- [6]
							11145, -- [7]
							11130, -- [8]
							6339, -- [9]
							6218, -- [10]
							6219, -- [11]
							10498, -- [12]
							19727, -- [13]
							{
								["rule"] = "type:鱼竿",
								["icon"] = 132932,
								["comment"] = "鱼竿",
							}, -- [14]
						},
						["icon"] = 134065,
					}, -- [4]
					{
						["icon"] = 132722,
						["children"] = {
							{
								["rule"] = "slot:双手",
								["icon"] = 135324,
								["comment"] = "双手",
							}, -- [1]
							{
								["rule"] = "slot:主手",
								["icon"] = 133045,
								["comment"] = "主手",
							}, -- [2]
							{
								["rule"] = "slot:单手",
								["icon"] = 135641,
								["comment"] = "单手",
							}, -- [3]
							{
								["rule"] = "slot:副手",
								["icon"] = 134955,
								["comment"] = "副手",
							}, -- [4]
							{
								["rule"] = "slot:副手物品",
								["icon"] = 134333,
								["comment"] = "副手物品",
							}, -- [5]
							{
								["rule"] = "slot:远程",
								["icon"] = 135498,
								["comment"] = "远程",
							}, -- [6]
							{
								["rule"] = "type:枪械",
								["icon"] = 135610,
								["comment"] = "枪械",
							}, -- [7]
							{
								["rule"] = "type:弩",
								["icon"] = 135533,
								["comment"] = "弩",
							}, -- [8]
							{
								["rule"] = "type:投掷武器",
								["icon"] = 135427,
								["comment"] = "投掷武器",
							}, -- [9]
							{
								["rule"] = "slot:圣物",
								["icon"] = 134915,
								["comment"] = "圣物",
							}, -- [10]
							{
								["rule"] = "slot:头部",
								["icon"] = 133136,
								["comment"] = "头部",
							}, -- [11]
							{
								["rule"] = "slot:颈部",
								["icon"] = 133294,
								["comment"] = "颈部",
							}, -- [12]
							{
								["rule"] = "slot:肩部",
								["icon"] = 135033,
								["comment"] = "肩部",
							}, -- [13]
							{
								["rule"] = "slot:背部",
								["icon"] = 133768,
								["comment"] = "背部",
							}, -- [14]
							{
								["rule"] = "slot:胸部",
								["icon"] = 132644,
								["comment"] = "胸部",
							}, -- [15]
							{
								["rule"] = "slot:手腕",
								["icon"] = 132608,
								["comment"] = "手腕",
							}, -- [16]
							{
								["rule"] = "slot:手",
								["icon"] = 132948,
								["comment"] = "手",
							}, -- [17]
							{
								["rule"] = "slot:腰部",
								["icon"] = 132511,
								["comment"] = "腰部",
							}, -- [18]
							{
								["rule"] = "slot:腿部",
								["icon"] = 134588,
								["comment"] = "腿部",
							}, -- [19]
							{
								["rule"] = "slot:脚",
								["icon"] = 132541,
								["comment"] = "脚",
							}, -- [20]
							{
								["rule"] = "slot:手指",
								["icon"] = 133345,
								["comment"] = "手指",
							}, -- [21]
							{
								["rule"] = "slot:饰品",
								["icon"] = 134010,
								["comment"] = "饰品",
							}, -- [22]
							{
								["rule"] = "slot:衬衣",
								["icon"] = 135022,
								["comment"] = "衬衣",
							}, -- [23]
							{
								["rule"] = "slot:战袍",
								["icon"] = 135026,
								["comment"] = "战袍",
							}, -- [24]
						},
						["rule"] = "equip",
						["comment"] = "装备",
					}, -- [5]
					{
						["rule"] = "type:容器",
						["icon"] = 133652,
						["comment"] = "容器",
					}, -- [6]
					{
						["rule"] = "type:箭袋",
						["icon"] = 134407,
						["comment"] = "箭袋",
					}, -- [7]
					{
						["rule"] = "type:弹药",
						["icon"] = 132382,
						["comment"] = "弹药",
					}, -- [8]
					{
						["rule"] = "type:配方",
						["icon"] = 134939,
						["comment"] = "配方",
					}, -- [9]
					{
						["icon"] = 132905,
						["children"] = {
							{
								["rule"] = "tip:职业：",
								["icon"] = 132273,
								["comment"] = "职业物品",
							}, -- [1]
							{
								["rule"] = "type:布料",
								["icon"] = 132903,
								["comment"] = "布料",
							}, -- [2]
							{
								["rule"] = "type:皮革",
								["icon"] = 134256,
								["comment"] = "皮革",
							}, -- [3]
							{
								["rule"] = "type:金属和矿石",
								["icon"] = 133217,
								["comment"] = "金属和矿石",
							}, -- [4]
							{
								["rule"] = "type:肉类",
								["icon"] = 134027,
								["comment"] = "肉类",
							}, -- [5]
							{
								["rule"] = "type:草药",
								["icon"] = 134215,
								["comment"] = "草药",
							}, -- [6]
							{
								["rule"] = "type:元素",
								["icon"] = 135819,
								["comment"] = "元素",
							}, -- [7]
							{
								["rule"] = "type:附魔",
								["icon"] = 132864,
								["comment"] = "附魔",
							}, -- [8]
						},
						["rule"] = "type:商品",
						["comment"] = "商品",
					}, -- [10]
					{
						["icon"] = 134829,
						["children"] = {
							{
								["rule"] = "tip:职业：",
								["icon"] = 132273,
								["comment"] = "职业物品",
							}, -- [1]
							{
								["rule"] = "spell:急救",
								["icon"] = 133685,
								["comment"] = "急救",
							}, -- [2]
							{
								["rule"] = "spell:进食",
								["icon"] = 133945,
								["comment"] = "进食",
							}, -- [3]
							{
								["rule"] = "spell:喝水",
								["icon"] = 132794,
								["comment"] = "喝水",
							}, -- [4]
							{
								["rule"] = "spell:治疗药水",
								["icon"] = 134830,
								["comment"] = "治疗药水",
							}, -- [5]
							{
								["rule"] = "spell:恢复法力",
								["icon"] = 134851,
								["comment"] = "恢复法力",
							}, -- [6]
						},
						["rule"] = "type:消耗品 & tip:!任务",
						["comment"] = "消耗品",
					}, -- [11]
					{
						["rule"] = "type:材料",
						["icon"] = 133587,
						["comment"] = "材料",
					}, -- [12]
					{
						["icon"] = 134237,
						["children"] = {
							{
								["rule"] = "type:其它",
								["icon"] = 134400,
								["comment"] = "其它",
							}, -- [1]
							{
								["rule"] = "type:钥匙",
								["icon"] = 134237,
								["comment"] = "钥匙",
							}, -- [2]
						},
						["rule"] = "type:!任务 & tip:!任务",
						["comment"] = "其它",
					}, -- [13]
					{
						["icon"] = 133469,
						["children"] = {
							{
								["rule"] = "tip:该物品将触发一个任务",
								["icon"] = 132836,
								["comment"] = "该物品将触发一个任务",
							}, -- [1]
							{
								["icon"] = 133942,
								["rule"] = "spell",
							}, -- [2]
						},
						["rule"] = "type:任务 | tip:任务",
						["comment"] = "任务",
					}, -- [14]
				},
			},
			["version"] = 20001,
		},
	},
}
