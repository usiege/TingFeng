
TomTomDB = {
	["profileKeys"] = {
		["今晚就动手 - 阿什坎迪"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["arrow"] = {
				["position"] = {
					"CENTER", -- [1]
					nil, -- [2]
					"CENTER", -- [3]
					0, -- [4]
					0, -- [5]
				},
			},
			["block"] = {
				["enable"] = false,
				["position"] = {
					"CENTER", -- [1]
					nil, -- [2]
					"CENTER", -- [3]
					0, -- [4]
					-100, -- [5]
				},
			},
		},
	},
}
TomTomWaypoints = nil
TomTomWaypointsM = {
	["profileKeys"] = {
		["今晚就动手 - 阿什坎迪"] = "今晚就动手 - 阿什坎迪",
	},
	["profiles"] = {
		["今晚就动手 - 阿什坎迪"] = {
		},
		["简洁界面 - 阿什坎迪"] = {
		},
	},
}
