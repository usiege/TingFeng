
tdDropDownDB = {
	["SendMailNameEditBox"] = {
	},
}
