
WarGameHelperDB = {
	["MapData"] = {
		{
			["id"] = 2,
			["pvpType"] = 3,
			["name"] = "战歌峡谷",
			["value"] = "战歌峡谷",
		}, -- [1]
		{
			["id"] = 3,
			["pvpType"] = 3,
			["name"] = "阿拉希盆地",
			["value"] = "阿拉希盆地",
		}, -- [2]
		{
			["id"] = 7,
			["pvpType"] = 3,
			["name"] = "Eye of the Storm",
			["value"] = "storm",
		}, -- [3]
		{
			["id"] = 4,
			["pvpType"] = 4,
			["name"] = "纳格兰竞技场",
			["value"] = "纳格兰竞技场",
		}, -- [4]
		{
			["id"] = 5,
			["pvpType"] = 4,
			["name"] = "刀锋山竞技场",
			["value"] = "刀锋山竞技场",
		}, -- [5]
		{
			["id"] = 8,
			["pvpType"] = 4,
			["name"] = "洛丹伦废墟",
			["value"] = "洛丹伦废墟",
		}, -- [6]
		{
			["id"] = 6,
			["pvpType"] = 4,
			["name"] = "所有竞技场",
			["value"] = "所有竞技场",
		}, -- [7]
	},
	["Bracket"] = 4,
	["Map"] = 2,
	["Mode"] = 2,
	["UseTarget"] = false,
	["TournamentRules"] = true,
}
