
SkadaDB = {
	["profileKeys"] = {
		["大哥别开火 - 阿什坎迪"] = "Default",
		["动能甫杜 - 阿什坎迪"] = "Default",
		["今晚就动手 - 阿什坎迪"] = "Default",
		["吸你的血 - 阿什坎迪"] = "Default",
		["交作业 - 阿什坎迪"] = "Default",
		["你说怎么办 - 阿什坎迪"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["modeclicks"] = {
				["治疗"] = 1,
				["敌对伤害"] = 2,
				["伤害"] = 10,
				["友军误伤"] = 1,
				["打断"] = 1,
			},
			["windows"] = {
				{
					["hidden"] = true,
					["y"] = -125.5912628173828,
					["point"] = "RIGHT",
					["mode"] = "伤害",
					["barwidth"] = 269.02362060547,
					["background"] = {
						["borderthickness"] = 2,
						["height"] = 218.37998962402,
					},
					["x"] = -7.6307373046875,
				}, -- [1]
			},
			["icon"] = {
				["minimapPos"] = 305.082656509,
			},
			["versions"] = {
				["1.6.3"] = true,
				["1.6.4"] = true,
				["1.6.7"] = true,
			},
		},
	},
}
