
NRunDB_Global = {
	["nameplates"] = false,
	["anchors"] = {
		["main"] = {
			["y"] = 73.4815444946289,
			["x"] = 304.197204589844,
		},
		["secondary"] = {
			["y"] = -110.617073059082,
			["x"] = 294.617614746094,
		},
	},
	["width"] = 135,
	["height"] = 18,
	["charspec"] = {
	},
}
NugRunningConfigCustom = {
	["ROGUE"] = {
	},
	["WARRIOR"] = {
	},
}
