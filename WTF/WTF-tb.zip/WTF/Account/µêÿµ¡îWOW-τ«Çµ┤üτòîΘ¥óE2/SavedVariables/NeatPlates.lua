
NeatPlatesSettings = {
	["GlobalEmphasizedAuraList"] = "",
	["GlobalAdditonalAuras"] = {
	},
	["DefaultProfile"] = "默认",
	["GlobalEmphasizedAuraPriority"] = {
	},
	["GlobalAuraLookup"] = {
	},
	["GlobalEmphasizedAuraLookup"] = {
	},
	["GlobalAuraList"] = "",
	["GlobalAuraPriority"] = {
	},
}
