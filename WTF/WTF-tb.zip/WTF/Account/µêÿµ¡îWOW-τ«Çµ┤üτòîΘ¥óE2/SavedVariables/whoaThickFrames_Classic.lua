
cfg = {
	["darkFrames"] = true,
	["blueShamans"] = true,
	["styleFont"] = false,
	["bigAuras"] = true,
	["unclickeableFrame"] = false,
	["whoaTexture"] = false,
	["largeAuraSize"] = 20,
	["useBossFrames"] = false,
	["smallAuraSize"] = 20,
	["classColor"] = true,
	["reactionColor"] = true,
	["BlizzardReactionColor"] = false,
	["threatNumericIndicator"] = false,
	["usePartyFrames"] = true,
}
