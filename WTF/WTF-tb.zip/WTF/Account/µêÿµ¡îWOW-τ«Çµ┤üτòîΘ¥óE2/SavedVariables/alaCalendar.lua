
alaCalendarSV = {
	["var"] = {
		["Player-4792-033FCC2E"] = {
			["TAQ"] = {
			},
			["RAQ"] = {
			},
			["realm_name"] = "阿什坎迪",
			["MC"] = {
			},
			["SW"] = {
			},
			["NAXX"] = {
			},
			["BT"] = {
			},
			["PLAYER_LEVEL"] = 3,
			["ONY"] = {
			},
			["Gruul"] = {
			},
			["BWL"] = {
			},
			["Tempest"] = {
			},
			["Serpent"] = {
			},
			["Kara"] = {
			},
			["Hyjal"] = {
			},
			["realm_id"] = 4792,
			["ZG"] = {
			},
			["Magtheridon"] = {
			},
		},
		["Player-4792-03A26BE8"] = {
			["TAQ"] = {
			},
			["RAQ"] = {
			},
			["realm_name"] = "阿什坎迪",
			["MC"] = {
			},
			["SW"] = {
			},
			["NAXX"] = {
			},
			["BT"] = {
			},
			["PLAYER_LEVEL"] = 1,
			["ONY"] = {
			},
			["Gruul"] = {
			},
			["BWL"] = {
			},
			["Tempest"] = {
			},
			["Serpent"] = {
			},
			["Kara"] = {
			},
			["Hyjal"] = {
			},
			["realm_id"] = 4792,
			["ZG"] = {
			},
			["Magtheridon"] = {
			},
		},
		["Player-4792-026E8FC2"] = {
			["TAQ"] = {
			},
			["RAQ"] = {
			},
			["realm_name"] = "阿什坎迪",
			["MC"] = {
			},
			["SW"] = {
			},
			["NAXX"] = {
			},
			["BT"] = {
			},
			["PLAYER_LEVEL"] = 3,
			["ONY"] = {
			},
			["Gruul"] = {
			},
			["BWL"] = {
			},
			["Tempest"] = {
			},
			["Serpent"] = {
			},
			["Kara"] = {
			},
			["Hyjal"] = {
			},
			["realm_id"] = 4792,
			["ZG"] = {
			},
			["Magtheridon"] = {
			},
		},
	},
	["daily"] = {
		["reset"] = 1637449199,
	},
	["_version"] = 210918.01,
	["set"] = {
		["minimapPos"] = 215,
		["char_list"] = {
			"Player-4792-033FCC2E", -- [1]
			"Player-4792-03A26BE8", -- [2]
			"Player-4792-026E8FC2", -- [3]
		},
		["inst_hash"] = {
			["Eye of the Storm"] = true,
			["TAQ"] = false,
			["RAQ"] = false,
			["Alterac Valley"] = true,
			["Arathi Basin"] = true,
			["MC"] = false,
			["SW"] = true,
			["NAXX"] = false,
			["DarkMoon: Terokkar"] = true,
			["BT"] = true,
			["DarkMoon: Elwynn"] = true,
			["Warsong Gulch"] = true,
			["DarkMoon: Mulgore"] = true,
			["ONY"] = false,
			["Fishing Extravaganza"] = true,
			["BWL"] = false,
			["Hyjal"] = true,
			["Kara"] = true,
			["Serpent"] = true,
			["Tempest"] = true,
			["Gruul"] = true,
			["ZG"] = true,
			["Magtheridon"] = true,
		},
		["collapsed"] = {
		},
		["raid_list"] = {
			"NAXX", -- [1]
			"TAQ", -- [2]
			"RAQ", -- [3]
			"BWL", -- [4]
			"ZG", -- [5]
			"MC", -- [6]
			"ONY", -- [7]
			"Kara", -- [8]
			"Hyjal", -- [9]
			"Magtheridon", -- [10]
			"Serpent", -- [11]
			"Tempest", -- [12]
			"BT", -- [13]
			"Gruul", -- [14]
			"SW", -- [15]
		},
	},
}
