
AshToAsh_DB = {
	["AuraBlackList"] = {
	},
	["ClassBuffList"] = {
	},
	["EnlargeDebuffList"] = {
	},
}
