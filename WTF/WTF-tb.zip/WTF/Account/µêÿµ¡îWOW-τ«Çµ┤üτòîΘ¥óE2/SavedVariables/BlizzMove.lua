
BlizzMoveDB = {
	["saveScaleStrategy"] = "session",
	["points"] = {
	},
	["scales"] = {
	},
	["savePosStrategy"] = "session",
}
