
CombatIndicator_Config = nil
