
settings = {
	["followCheck"] = true,
	["followNameCheck"] = false,
	["followName"] = "这里输入队伍中要跟随的人",
	["command1"] = "11",
	["followLeaderCheck"] = true,
	["blueCheck"] = false,
	["greyCheck"] = true,
	["stopCheck"] = true,
	["greenCheck"] = false,
	["tradeCheck"] = false,
	["followPartyCheck"] = false,
	["repoCheck"] = true,
	["command2"] = "22",
}
