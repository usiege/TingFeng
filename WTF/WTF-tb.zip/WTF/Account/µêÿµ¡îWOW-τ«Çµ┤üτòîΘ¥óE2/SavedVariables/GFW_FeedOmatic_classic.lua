
GFW_FeedOMatic_DB = {
	["profileKeys"] = {
		["猎猎思密达 - 阿什坎迪"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
		},
	},
}
FOM_Cooking = {
}
