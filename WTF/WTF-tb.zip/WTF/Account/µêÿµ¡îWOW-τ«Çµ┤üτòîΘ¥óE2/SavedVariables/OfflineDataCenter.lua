
ODC_DB = {
	["大哥别开火-阿什坎迪"] = {
		["inventory"] = {
			{
				"1@|cffffffff|Hitem:6117::::::::2::::::::|h[侍从衬衣]|h|r", -- [1]
				"1@|cff9d9d9d|Hitem:6118::::::::2::::::::|h[侍从短裤]|h|r", -- [2]
				"1@|cffffffff|Hitem:43::::::::2::::::::|h[侍从之靴]|h|r", -- [3]
				"1@|cffffffff|Hitem:2361::::::::2::::::::|h[用旧的木槌]|h|r", -- [4]
			}, -- [1]
		},
		["bag"] = {
			{
				"4@|cffffffff|Hitem:4540::::::::2::::::::|h[大块的硬面包]|h|r", -- [1]
				"2@|cffffffff|Hitem:159::::::::2::::::::|h[清凉的泉水]|h|r", -- [2]
				"1@|cffffffff|Hitem:6948::::::::2::::::::|h[炉石]|h|r", -- [3]
			}, -- [1]
		},
		["whisperlog"] = {
		},
		["tradelog"] = {
		},
		["bank"] = {
		},
	},
}
ODC_Config = {
	["Options"] = {
		["whisperlog"] = {
			["maxmsg"] = 500,
		},
		["tradelog"] = {
			["maxmsg"] = 50,
			["autowhisper"] = "none",
		},
	},
	["UI"] = {
	},
	["DBver"] = 50,
	["icon"] = {
		["minimapPos"] = 195,
		["radius"] = 80,
		["hide"] = false,
	},
	["toggle"] = {
		["inventory"] = true,
		["bag"] = true,
		["whisperlog"] = true,
		["tradelog"] = true,
		["bank"] = true,
	},
}
MB_DB = nil
BB_DB = nil
IN_DB = nil
MB_Config = nil
