
ItemInfo_Config = {
	["rname"] = {
	},
	["auctionPrice"] = {
	},
	["ShowUnitPrice"] = false,
}
AlreadyKnownSettings = {
	["r"] = 0,
	["monochrome"] = false,
	["g"] = 1,
	["b"] = 0,
}
