
GS_Settings = {
	["Item"] = 1,
	["Player"] = 1,
}
