
CharacterStatsTbcDB = {
	["useBlizzardBlockValue"] = false,
	["statsPanelHidden"] = false,
}
