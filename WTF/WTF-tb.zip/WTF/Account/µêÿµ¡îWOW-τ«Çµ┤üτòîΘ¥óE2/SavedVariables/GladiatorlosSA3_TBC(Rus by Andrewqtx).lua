
GladiatorlosSADB = {
	["profileKeys"] = {
	},
	["profiles"] = {
		["Default"] = {
		},
	},
}
