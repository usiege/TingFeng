
Omen3DB = {
	["profileKeys"] = {
		["大哥别开火 - 阿什坎迪"] = "大哥别开火 - 阿什坎迪",
	},
	["profiles"] = {
		["大哥别开火 - 阿什坎迪"] = {
			["Shown"] = false,
		},
	},
}
