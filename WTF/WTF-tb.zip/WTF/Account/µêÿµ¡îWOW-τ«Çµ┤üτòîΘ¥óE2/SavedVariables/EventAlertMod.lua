
EA_Config = {
	["SCD_NocombatStillKeep"] = true,
	["ShowTimer"] = true,
	["DoAlertSound"] = true,
	["ChangeTimer"] = true,
	["SpecPowerCheck"] = {
		["Mana"] = false,
		["Happiness"] = false,
		["LifeBloom"] = false,
		["Focus"] = false,
		["RunicPower"] = false,
		["ComboPoints"] = false,
		["Runes"] = false,
		["LunarPower"] = false,
		["Fury"] = false,
		["SoulShards"] = false,
		["Chi"] = false,
		["HolyPower"] = false,
		["Energy"] = false,
		["Rage"] = false,
		["Maelstrom"] = false,
		["Insanity"] = false,
		["ArcaneCharges"] = false,
		["Pain"] = false,
	},
	["ICON_APPEND_SPELL_TIP"] = true,
	["UseFloatSec"] = 1,
	["ShowRunesBar"] = true,
	["ShareSettings"] = true,
	["NewLineByIconCount"] = 0,
	["ShowAuraValueWhenOver"] = 10,
	["IconSize"] = 30,
	["OPTION_ICON"] = true,
	["AllowESC"] = false,
	["Target_MyDebuff"] = true,
	["LockFrame"] = false,
	["ShowFrame"] = true,
	["SNameFontSize"] = 12,
	["AllowAltAlerts"] = false,
	["HUNTER_GlowPetFocus"] = 50,
	["ShowFlash"] = true,
	["BaseFontSize"] = 24,
	["AlertSoundValue"] = 1,
	["StackFontSize"] = 16,
	["ShowName"] = true,
	["Version"] = "TBC2.5.1_2021.06.26",
	["AlertSound"] = 568154,
	["TimerFontSize"] = 19.2,
	["SCD_ShowWhenWaitCooldown"] = true,
	["SCD_RemoveWhenCooldown"] = true,
	["SCD_GlowWhenUsable"] = true,
}
EA_Position = {
	["Execution"] = 0,
	["GreenDebuff"] = 0.5,
	["xOffset"] = -40,
	["TarAnchor"] = "CENTER",
	["yOffset"] = 0,
	["PlayerLv2BOSS"] = true,
	["relativePoint"] = "CENTER",
	["Anchor"] = "CENTER",
	["yLoc"] = 4.869155406951904,
	["SCD_UseCooldown"] = false,
	["Tar_yOffset"] = -75.13029479980469,
	["RedDebuff"] = 0.5,
	["Tar_xOffset"] = 19.31488227844238,
	["Scd_yOffset"] = -73.56175994873047,
	["TarrelativePoint"] = "CENTER",
	["Scd_xOffset"] = 420.1203308105469,
	["ScdAnchor"] = "LEFT",
	["Tar_NewLine"] = true,
	["xLoc"] = -242.4140777587891,
}
EA_Items = {
	["PALADIN"] = {
		[31850] = {
			["enable"] = true,
		},
		[20925] = {
			["enable"] = true,
		},
		[642] = {
			["enable"] = true,
		},
		[31884] = {
			["enable"] = true,
		},
		[498] = {
			["enable"] = true,
		},
		[31821] = {
			["enable"] = true,
		},
		[31842] = {
			["enable"] = true,
		},
	},
	["DRUID"] = {
		[5217] = {
			["enable"] = true,
		},
		[1850] = {
			["enable"] = true,
		},
		[774] = {
			["enable"] = true,
		},
		[16870] = {
			["enable"] = true,
		},
		[5215] = {
			["enable"] = true,
		},
		[22812] = {
			["enable"] = true,
		},
	},
	["OTHER"] = {
		[28271] = {
			["enable"] = true,
			["self"] = false,
		},
		[1850] = {
			["enable"] = true,
			["name"] = "突進",
			["self"] = false,
		},
		[5211] = {
			["enable"] = true,
			["self"] = false,
		},
		[10060] = {
			["enable"] = true,
		},
		[45438] = {
			["enable"] = true,
			["self"] = false,
		},
		[33206] = {
			["enable"] = true,
		},
		[29166] = {
			["enable"] = true,
		},
		[32182] = {
			["enable"] = true,
		},
		[1022] = {
			["enable"] = true,
			["name"] = "保護祝福",
			["self"] = false,
		},
		[6940] = {
			["enable"] = true,
			["name"] = "犧牲祝福",
			["self"] = false,
		},
		[33786] = {
			["enable"] = true,
			["self"] = false,
		},
		[2825] = {
			["enable"] = true,
			["name"] = "嗜血",
		},
	},
	["ROGUE"] = {
		[5171] = {
			["enable"] = true,
		},
		[1966] = {
			["enable"] = true,
		},
	},
}
EA_AltItems = {
	["DRUID"] = {
	},
	["PALADIN"] = {
	},
	["ROGUE"] = {
	},
}
EA_TarItems = {
	["DRUID"] = {
		[1079] = {
			["enable"] = true,
			["self"] = true,
		},
		[8921] = {
			["enable"] = true,
			["self"] = true,
		},
		[774] = {
			["enable"] = true,
			["self"] = true,
		},
		[5570] = {
			["enable"] = true,
			["self"] = true,
		},
		[1822] = {
			["enable"] = true,
			["self"] = true,
		},
		[33763] = {
			["enable"] = true,
			["self"] = true,
		},
	},
	["PALADIN"] = {
		[20066] = {
			["enable"] = true,
			["self"] = true,
		},
		[31803] = {
			["enable"] = true,
			["self"] = true,
		},
		[10326] = {
			["enable"] = true,
			["self"] = true,
		},
		[853] = {
			["enable"] = true,
			["self"] = true,
		},
	},
	["ROGUE"] = {
		[1943] = {
			["enable"] = true,
			["self"] = true,
		},
	},
}
EA_ScdItems = {
	["DRUID"] = {
		[1850] = {
			["enable"] = true,
		},
		[22842] = {
			["enable"] = true,
		},
		[17116] = {
			["enable"] = true,
		},
		[33917] = {
			["enable"] = true,
		},
		[5215] = {
			["enable"] = true,
		},
		[29166] = {
			["enable"] = true,
		},
		[6807] = {
			["enable"] = true,
		},
		[18562] = {
			["enable"] = true,
		},
		[22812] = {
			["enable"] = true,
		},
	},
	["PALADIN"] = {
		[28730] = {
			["enable"] = true,
		},
		[20066] = {
			["enable"] = true,
		},
		[498] = {
			["enable"] = true,
		},
		[20925] = {
			["enable"] = true,
		},
		[853] = {
			["enable"] = true,
		},
	},
	["ROGUE"] = {
	},
}
EA_GrpItems = {
	["DRUID"] = {
		{
			["IconPoint"] = "Top",
			["GroupIconID"] = 0,
			["enable"] = false,
			["LocY"] = -200,
			["LocX"] = 0,
			["ActiveTalentGroup"] = 1,
			["GroupResult"] = false,
			["GroupIndex"] = 1,
			["IconSize"] = 80,
			["Spells"] = {
				{
					["SpellIconPath"] = 132242,
					["Checks"] = {
						{
							["SubChecks"] = {
								{
									["CheckCD"] = 5217,
									["EventType"] = "UNIT_POWER_UPDATE",
									["SubCheckResult"] = false,
									["PowerType"] = "ENERGY",
									["PowerTypeNum"] = 3,
									["SubCheckAndOp"] = true,
									["UnitType"] = "player",
									["PowerLessThanValue"] = 40,
									["PowerCompType"] = 2,
								}, -- [1]
							},
							["CheckResult"] = false,
							["CheckAndOp"] = true,
						}, -- [1]
					},
					["SpellResult"] = false,
					["SpellIconID"] = 5217,
					["SpellName"] = "猛虎之怒",
				}, -- [1]
			},
			["IconAlpha"] = 0.5,
			["IconRelatePoint"] = "Top",
		}, -- [1]
		{
			["IconPoint"] = "Top",
			["GroupIconID"] = 0,
			["enable"] = false,
			["LocY"] = -200,
			["LocX"] = 0,
			["ActiveTalentGroup"] = 2,
			["GroupResult"] = false,
			["GroupIndex"] = 2,
			["IconSize"] = 80,
			["Spells"] = {
				{
					["SpellResult"] = false,
					["SpellIconID"] = 48438,
					["Checks"] = {
						{
							["SubChecks"] = {
								{
									["CheckCD"] = 48438,
									["EventType"] = "UNIT_POWER_UPDATE",
									["SubCheckResult"] = false,
									["PowerType"] = "MANA",
									["PowerTypeNum"] = 0,
									["SubCheckAndOp"] = true,
									["UnitType"] = "player",
									["PowerLessThanValue"] = 5000,
									["PowerCompType"] = 4,
								}, -- [1]
							},
							["CheckResult"] = false,
							["CheckAndOp"] = true,
						}, -- [1]
					},
				}, -- [1]
			},
			["IconAlpha"] = 0.5,
			["IconRelatePoint"] = "Top",
		}, -- [2]
		{
			["IconPoint"] = "Top",
			["GroupIconID"] = 0,
			["enable"] = false,
			["LocY"] = -200,
			["LocX"] = 80,
			["ActiveTalentGroup"] = 2,
			["GroupResult"] = false,
			["GroupIndex"] = 3,
			["IconSize"] = 80,
			["Spells"] = {
				{
					["SpellIconPath"] = 136048,
					["Checks"] = {
						{
							["SubChecks"] = {
								{
									["CheckCD"] = 29166,
									["EventType"] = "UNIT_POWER_UPDATE",
									["SubCheckResult"] = false,
									["PowerType"] = "MANA",
									["UnitType"] = "player",
									["PowerTypeNum"] = 0,
									["SubCheckAndOp"] = true,
									["PowerLessThanPercent"] = 80,
									["PowerCompType"] = 2,
								}, -- [1]
							},
							["CheckResult"] = false,
							["CheckAndOp"] = true,
						}, -- [1]
					},
					["SpellResult"] = false,
					["SpellIconID"] = 29166,
					["SpellName"] = "激活",
				}, -- [1]
			},
			["IconAlpha"] = 0.5,
			["IconRelatePoint"] = "Top",
		}, -- [3]
		{
			["IconPoint"] = "Top",
			["GroupIconID"] = 0,
			["enable"] = false,
			["LocY"] = -200,
			["LocX"] = -80,
			["ActiveTalentGroup"] = 2,
			["GroupResult"] = false,
			["GroupIndex"] = 4,
			["IconSize"] = 80,
			["Spells"] = {
				{
					["SpellIconPath"] = 134914,
					["Checks"] = {
						{
							["SubChecks"] = {
								{
									["CheckCD"] = 18562,
									["EventType"] = "UNIT_POWER_UPDATE",
									["SubCheckResult"] = false,
									["PowerType"] = "MANA",
									["PowerTypeNum"] = 0,
									["SubCheckAndOp"] = true,
									["UnitType"] = "player",
									["PowerLessThanValue"] = 1700,
									["PowerCompType"] = 4,
								}, -- [1]
							},
							["CheckResult"] = false,
							["CheckAndOp"] = true,
						}, -- [1]
					},
					["SpellResult"] = false,
					["SpellIconID"] = 18562,
					["SpellName"] = "迅捷治愈",
				}, -- [1]
			},
			["IconAlpha"] = 0.5,
			["IconRelatePoint"] = "Top",
		}, -- [4]
		{
			["IconPoint"] = "Top",
			["GroupIconID"] = 0,
			["enable"] = false,
			["LocY"] = -200,
			["LocX"] = -80,
			["ActiveTalentGroup"] = 1,
			["GroupResult"] = false,
			["GroupIndex"] = 5,
			["IconSize"] = 80,
			["Spells"] = {
				{
					["SpellIconPath"] = 132135,
					["Checks"] = {
						{
							["SubChecks"] = {
								{
									["CheckCD"] = 33878,
									["EventType"] = "UNIT_POWER_UPDATE",
									["SubCheckResult"] = false,
									["PowerType"] = "RAGE",
									["PowerTypeNum"] = 1,
									["SubCheckAndOp"] = true,
									["UnitType"] = "player",
									["PowerLessThanValue"] = 15,
									["PowerCompType"] = 4,
								}, -- [1]
							},
							["CheckResult"] = false,
							["CheckAndOp"] = true,
						}, -- [1]
					},
					["SpellResult"] = false,
					["SpellIconID"] = 33878,
					["SpellName"] = "裂伤（熊）",
				}, -- [1]
				{
					["SpellIconPath"] = 132131,
					["Checks"] = {
						{
							["SubChecks"] = {
								{
									["CheckCD"] = 33745,
									["EventType"] = "UNIT_POWER_UPDATE",
									["SubCheckResult"] = false,
									["PowerType"] = "RAGE",
									["PowerTypeNum"] = 1,
									["SubCheckAndOp"] = true,
									["UnitType"] = "player",
									["PowerLessThanValue"] = 15,
									["PowerCompType"] = 4,
								}, -- [1]
							},
							["CheckResult"] = false,
							["CheckAndOp"] = true,
						}, -- [1]
						{
							["SubChecks"] = {
								{
									["SubCheckResult"] = false,
									["UnitType"] = "target",
									["SubCheckAndOp"] = true,
									["CheckAuraNotExist"] = 33745,
									["CastByPlayer"] = true,
									["EventType"] = "UNIT_AURA",
								}, -- [1]
								{
									["SubCheckResult"] = false,
									["EventType"] = "UNIT_AURA",
									["StackLessThanValue"] = 2,
									["SubCheckAndOp"] = false,
									["CheckAuraExist"] = 33745,
									["CastByPlayer"] = true,
									["StackCompType"] = 2,
									["UnitType"] = "target",
								}, -- [2]
								{
									["TimeLessThanValue"] = 3,
									["TimeCompType"] = 2,
									["UnitType"] = "target",
									["SubCheckAndOp"] = false,
									["SubCheckResult"] = false,
									["CastByPlayer"] = true,
									["CheckAuraExist"] = 33745,
									["EventType"] = "UNIT_AURA",
								}, -- [3]
							},
							["CheckResult"] = false,
							["CheckAndOp"] = true,
						}, -- [2]
					},
					["SpellResult"] = false,
					["SpellIconID"] = 33745,
					["SpellName"] = "割伤",
				}, -- [2]
				{
					["SpellResult"] = false,
					["SpellIconID"] = 80313,
					["Checks"] = {
						{
							["SubChecks"] = {
								{
									["CheckCD"] = 80313,
									["EventType"] = "UNIT_POWER_UPDATE",
									["SubCheckResult"] = false,
									["PowerType"] = "RAGE",
									["PowerTypeNum"] = 1,
									["SubCheckAndOp"] = true,
									["UnitType"] = "player",
									["PowerLessThanValue"] = 15,
									["PowerCompType"] = 4,
								}, -- [1]
								{
									["SubCheckResult"] = false,
									["UnitType"] = "target",
									["SubCheckAndOp"] = true,
									["CastByPlayer"] = true,
									["EventType"] = "UNIT_AURA",
									["CheckAuraExist"] = 33745,
								}, -- [2]
							},
							["CheckResult"] = false,
							["CheckAndOp"] = true,
						}, -- [1]
						{
							["SubChecks"] = {
								{
									["TimeLessThanValue"] = 3,
									["TimeCompType"] = 2,
									["UnitType"] = "player",
									["SubCheckAndOp"] = true,
									["SubCheckResult"] = false,
									["CheckAuraExist"] = 80951,
									["EventType"] = "UNIT_AURA",
								}, -- [1]
								{
									["SubCheckResult"] = false,
									["UnitType"] = "player",
									["SubCheckAndOp"] = false,
									["CheckAuraNotExist"] = 80951,
									["EventType"] = "UNIT_AURA",
								}, -- [2]
							},
							["CheckResult"] = false,
							["CheckAndOp"] = true,
						}, -- [2]
					},
				}, -- [3]
				{
					["SpellResult"] = false,
					["SpellIconID"] = 77758,
					["Checks"] = {
						{
							["SubChecks"] = {
								{
									["CheckCD"] = 77758,
									["EventType"] = "UNIT_POWER_UPDATE",
									["SubCheckResult"] = false,
									["PowerType"] = "RAGE",
									["PowerTypeNum"] = 1,
									["SubCheckAndOp"] = true,
									["UnitType"] = "player",
									["PowerLessThanValue"] = 25,
									["PowerCompType"] = 4,
								}, -- [1]
							},
							["CheckResult"] = false,
							["CheckAndOp"] = true,
						}, -- [1]
					},
				}, -- [4]
				{
					["SpellIconPath"] = 134296,
					["Checks"] = {
						{
							["SubChecks"] = {
								{
									["CheckCD"] = 779,
									["EventType"] = "UNIT_POWER_UPDATE",
									["SubCheckResult"] = false,
									["PowerType"] = "RAGE",
									["PowerTypeNum"] = 1,
									["SubCheckAndOp"] = true,
									["UnitType"] = "player",
									["PowerLessThanValue"] = 15,
									["PowerCompType"] = 4,
								}, -- [1]
							},
							["CheckResult"] = false,
							["CheckAndOp"] = true,
						}, -- [1]
					},
					["SpellResult"] = false,
					["SpellIconID"] = 779,
					["SpellName"] = "横扫",
				}, -- [5]
			},
			["IconAlpha"] = 0.5,
			["IconRelatePoint"] = "Top",
		}, -- [5]
	},
	["PALADIN"] = {
		{
			["IconPoint"] = "Top",
			["GroupIconID"] = 0,
			["enable"] = false,
			["LocY"] = -200,
			["LocX"] = 0,
			["ActiveTalentGroup"] = 2,
			["GroupResult"] = false,
			["GroupIndex"] = 1,
			["IconSize"] = 80,
			["Spells"] = {
				{
					["SpellResult"] = false,
					["SpellIconID"] = 85673,
					["Checks"] = {
						{
							["SubChecks"] = {
								{
									["CheckCD"] = 85673,
									["EventType"] = "UNIT_POWER_UPDATE",
									["SubCheckResult"] = false,
									["PowerType"] = "HOLY_POWER",
									["PowerTypeNum"] = 9,
									["SubCheckAndOp"] = true,
									["UnitType"] = "player",
									["PowerLessThanValue"] = 3,
									["PowerCompType"] = 4,
								}, -- [1]
								{
									["HealthLessThanPercent"] = 80,
									["UnitType"] = "target",
									["SubCheckAndOp"] = true,
									["SubCheckResult"] = false,
									["EventType"] = "UNIT_HEALTH",
									["HealthCompType"] = 2,
								}, -- [2]
							},
							["CheckResult"] = false,
							["CheckAndOp"] = true,
						}, -- [1]
					},
				}, -- [1]
				{
					["SpellResult"] = false,
					["SpellIconID"] = 85222,
					["Checks"] = {
						{
							["SubChecks"] = {
								{
									["CheckCD"] = 85222,
									["EventType"] = "UNIT_POWER_UPDATE",
									["SubCheckResult"] = false,
									["PowerType"] = "HOLY_POWER",
									["PowerTypeNum"] = 9,
									["SubCheckAndOp"] = true,
									["UnitType"] = "player",
									["PowerLessThanValue"] = 3,
									["PowerCompType"] = 4,
								}, -- [1]
							},
							["CheckResult"] = false,
							["CheckAndOp"] = true,
						}, -- [1]
					},
				}, -- [2]
			},
			["IconAlpha"] = 0.5,
			["IconRelatePoint"] = "Top",
		}, -- [1]
		{
			["IconAlpha"] = 0.5,
			["GroupIconID"] = 0,
			["enable"] = false,
			["Spells"] = {
				{
					["SpellIconPath"] = 132326,
					["Checks"] = {
						{
							["SubChecks"] = {
								{
									["HealthLessThanPercent"] = 20,
									["UnitType"] = "target",
									["CheckCD"] = 24275,
									["SubCheckResult"] = false,
									["SubCheckAndOp"] = true,
									["EventType"] = "UNIT_HEALTH",
									["HealthCompType"] = 1,
								}, -- [1]
							},
							["CheckResult"] = false,
							["CheckAndOp"] = true,
						}, -- [1]
					},
					["SpellResult"] = false,
					["SpellIconID"] = 24275,
					["SpellName"] = "愤怒之锤",
				}, -- [1]
				{
					["SpellIconPath"] = 135903,
					["Checks"] = {
						{
							["SubChecks"] = {
								{
									["SubCheckResult"] = false,
									["UnitType"] = "player",
									["SubCheckAndOp"] = true,
									["CheckCD"] = 879,
									["CheckAuraExist"] = 59578,
									["EventType"] = "UNIT_AURA",
								}, -- [1]
							},
							["CheckResult"] = false,
							["CheckAndOp"] = true,
						}, -- [1]
					},
					["SpellResult"] = false,
					["SpellIconID"] = 879,
					["SpellName"] = "驱邪术",
				}, -- [2]
				{
					["SpellResult"] = false,
					["SpellIconID"] = 85256,
					["Checks"] = {
						{
							["SubChecks"] = {
								{
									["CheckCD"] = 85256,
									["EventType"] = "UNIT_POWER_UPDATE",
									["SubCheckResult"] = false,
									["PowerType"] = "HOLY_POWER",
									["PowerTypeNum"] = 9,
									["SubCheckAndOp"] = true,
									["UnitType"] = "player",
									["PowerLessThanValue"] = 3,
									["PowerCompType"] = 4,
								}, -- [1]
								{
									["SubCheckResult"] = false,
									["UnitType"] = "player",
									["SubCheckAndOp"] = false,
									["CheckCD"] = 85256,
									["CheckAuraExist"] = 90174,
									["EventType"] = "UNIT_AURA",
								}, -- [2]
							},
							["CheckResult"] = false,
							["CheckAndOp"] = true,
						}, -- [1]
					},
				}, -- [3]
				{
					["SpellIconPath"] = 135959,
					["Checks"] = {
						{
							["SubChecks"] = {
								{
									["PowerLessThanValue"] = 90,
									["EventType"] = "UNIT_POWER_UPDATE",
									["SubCheckResult"] = false,
									["PowerType"] = "MANA",
									["PowerTypeNum"] = 0,
									["CheckCD"] = 20271,
									["UnitType"] = "player",
									["SubCheckAndOp"] = true,
									["PowerCompType"] = 4,
								}, -- [1]
							},
							["CheckResult"] = false,
							["CheckAndOp"] = true,
						}, -- [1]
					},
					["SpellResult"] = false,
					["SpellIconID"] = 20271,
					["SpellName"] = "审判",
				}, -- [4]
				{
					["SpellIconPath"] = 135891,
					["Checks"] = {
						{
							["SubChecks"] = {
								{
									["PowerLessThanValue"] = 3,
									["EventType"] = "UNIT_POWER_UPDATE",
									["SubCheckResult"] = false,
									["PowerType"] = "HOLY_POWER",
									["PowerTypeNum"] = 9,
									["CheckCD"] = 35395,
									["UnitType"] = "player",
									["SubCheckAndOp"] = true,
									["PowerCompType"] = 1,
								}, -- [1]
								{
									["PowerLessThanValue"] = 100,
									["EventType"] = "UNIT_POWER_UPDATE",
									["SubCheckResult"] = false,
									["PowerType"] = "MANA",
									["PowerTypeNum"] = 0,
									["CheckCD"] = 35395,
									["UnitType"] = "player",
									["SubCheckAndOp"] = false,
									["PowerCompType"] = 4,
								}, -- [2]
							},
							["CheckResult"] = false,
							["CheckAndOp"] = true,
						}, -- [1]
					},
					["SpellResult"] = false,
					["SpellIconID"] = 35395,
					["SpellName"] = "十字军打击",
				}, -- [5]
			},
			["GroupResult"] = false,
			["LocX"] = 0,
			["ActiveTalentGroup"] = 1,
			["GroupIndex"] = 2,
			["LocY"] = -200,
			["HideOnLostTarget"] = true,
			["IconSize"] = 80,
			["IconPoint"] = "Top",
			["IconRelatePoint"] = "Top",
		}, -- [2]
	},
	["ROGUE"] = {
		{
			["IconAlpha"] = 0.5,
			["GroupIconID"] = 0,
			["enable"] = false,
			["Spells"] = {
				{
					["SpellIconPath"] = 132090,
					["Checks"] = {
						{
							["SubChecks"] = {
								{
									["CheckCD"] = 53,
									["EventType"] = "UNIT_POWER_UPDATE",
									["SubCheckResult"] = false,
									["PowerType"] = "ENERGY",
									["PowerTypeNum"] = 3,
									["SubCheckAndOp"] = true,
									["UnitType"] = "player",
									["PowerLessThanValue"] = 40,
									["PowerCompType"] = 4,
								}, -- [1]
								{
									["HealthLessThanPercent"] = 35,
									["UnitType"] = "target",
									["SubCheckAndOp"] = true,
									["SubCheckResult"] = false,
									["EventType"] = "UNIT_HEALTH",
									["HealthCompType"] = 2,
								}, -- [2]
							},
							["CheckResult"] = false,
							["CheckAndOp"] = true,
						}, -- [1]
					},
					["SpellResult"] = false,
					["SpellIconID"] = 53,
					["SpellName"] = "背刺",
				}, -- [1]
			},
			["LocX"] = 0,
			["GroupResult"] = false,
			["GroupIndex"] = 1,
			["IconSize"] = 80,
			["IconPoint"] = "Top",
			["LocY"] = -200,
			["IconRelatePoint"] = "Top",
		}, -- [1]
	},
}
EA_Pos = {
	["DEATHKNIGHT"] = {
		["Execution"] = 0,
		["GreenDebuff"] = 0.5,
		["xOffset"] = -40,
		["TarAnchor"] = "CENTER",
		["yOffset"] = 0,
		["PlayerLv2BOSS"] = true,
		["relativePoint"] = "CENTER",
		["Anchor"] = "CENTER",
		["yLoc"] = -140,
		["SCD_UseCooldown"] = false,
		["Tar_yOffset"] = -220,
		["RedDebuff"] = 0.5,
		["Tar_xOffset"] = 0,
		["Scd_yOffset"] = 80,
		["TarrelativePoint"] = "CENTER",
		["Scd_xOffset"] = 0,
		["ScdAnchor"] = "CENTER",
		["Tar_NewLine"] = true,
		["xLoc"] = 0,
	},
	["WARRIOR"] = {
		["Execution"] = 0,
		["GreenDebuff"] = 0.5,
		["xOffset"] = -40,
		["TarAnchor"] = "CENTER",
		["yOffset"] = 0,
		["PlayerLv2BOSS"] = true,
		["relativePoint"] = "CENTER",
		["Anchor"] = "CENTER",
		["yLoc"] = -140,
		["SCD_UseCooldown"] = false,
		["Tar_yOffset"] = -220,
		["RedDebuff"] = 0.5,
		["Tar_xOffset"] = 0,
		["Scd_yOffset"] = 80,
		["TarrelativePoint"] = "CENTER",
		["Scd_xOffset"] = 0,
		["ScdAnchor"] = "CENTER",
		["Tar_NewLine"] = true,
		["xLoc"] = 0,
	},
	["PALADIN"] = {
		["Execution"] = 0,
		["GreenDebuff"] = 0.5,
		["xOffset"] = -40,
		["TarAnchor"] = "CENTER",
		["yOffset"] = 0,
		["PlayerLv2BOSS"] = true,
		["relativePoint"] = "CENTER",
		["Anchor"] = "CENTER",
		["yLoc"] = -140,
		["SCD_UseCooldown"] = false,
		["Tar_yOffset"] = -220,
		["RedDebuff"] = 0.5,
		["Tar_xOffset"] = 0,
		["Scd_yOffset"] = 80,
		["TarrelativePoint"] = "CENTER",
		["Scd_xOffset"] = 0,
		["ScdAnchor"] = "CENTER",
		["Tar_NewLine"] = true,
		["xLoc"] = 0,
	},
	["MAGE"] = {
		["Execution"] = 0,
		["GreenDebuff"] = 0.5,
		["xOffset"] = -40,
		["TarAnchor"] = "CENTER",
		["yOffset"] = 0,
		["PlayerLv2BOSS"] = true,
		["relativePoint"] = "CENTER",
		["Anchor"] = "CENTER",
		["yLoc"] = -140,
		["SCD_UseCooldown"] = false,
		["Tar_yOffset"] = -220,
		["RedDebuff"] = 0.5,
		["Tar_xOffset"] = 0,
		["Scd_yOffset"] = 80,
		["TarrelativePoint"] = "CENTER",
		["Scd_xOffset"] = 0,
		["ScdAnchor"] = "CENTER",
		["Tar_NewLine"] = true,
		["xLoc"] = 0,
	},
	["PRIEST"] = {
		["Execution"] = 0,
		["GreenDebuff"] = 0.5,
		["xOffset"] = -40,
		["TarAnchor"] = "CENTER",
		["yOffset"] = 0,
		["PlayerLv2BOSS"] = true,
		["relativePoint"] = "CENTER",
		["Anchor"] = "CENTER",
		["yLoc"] = -140,
		["SCD_UseCooldown"] = false,
		["Tar_yOffset"] = -220,
		["RedDebuff"] = 0.5,
		["Tar_xOffset"] = 0,
		["Scd_yOffset"] = 80,
		["TarrelativePoint"] = "CENTER",
		["Scd_xOffset"] = 0,
		["ScdAnchor"] = "CENTER",
		["Tar_NewLine"] = true,
		["xLoc"] = 0,
	},
	["SHAMAN"] = {
		["Execution"] = 0,
		["GreenDebuff"] = 0.5,
		["xOffset"] = -40,
		["TarAnchor"] = "CENTER",
		["yOffset"] = 0,
		["PlayerLv2BOSS"] = true,
		["relativePoint"] = "CENTER",
		["Anchor"] = "CENTER",
		["yLoc"] = -140,
		["SCD_UseCooldown"] = false,
		["Tar_yOffset"] = -220,
		["RedDebuff"] = 0.5,
		["Tar_xOffset"] = 0,
		["Scd_yOffset"] = 80,
		["TarrelativePoint"] = "CENTER",
		["Scd_xOffset"] = 0,
		["ScdAnchor"] = "CENTER",
		["Tar_NewLine"] = true,
		["xLoc"] = 0,
	},
	["WARLOCK"] = {
		["Execution"] = 0,
		["GreenDebuff"] = 0.5,
		["xOffset"] = -40,
		["TarAnchor"] = "CENTER",
		["yOffset"] = 0,
		["PlayerLv2BOSS"] = true,
		["relativePoint"] = "CENTER",
		["Anchor"] = "CENTER",
		["yLoc"] = -140,
		["SCD_UseCooldown"] = false,
		["Tar_yOffset"] = -220,
		["RedDebuff"] = 0.5,
		["Tar_xOffset"] = 0,
		["Scd_yOffset"] = 80,
		["TarrelativePoint"] = "CENTER",
		["Scd_xOffset"] = 0,
		["ScdAnchor"] = "CENTER",
		["Tar_NewLine"] = true,
		["xLoc"] = 0,
	},
	["DEMONHUNTER"] = {
		["Execution"] = 0,
		["GreenDebuff"] = 0.5,
		["xOffset"] = -40,
		["TarAnchor"] = "CENTER",
		["yOffset"] = 0,
		["PlayerLv2BOSS"] = true,
		["relativePoint"] = "CENTER",
		["Anchor"] = "CENTER",
		["yLoc"] = -140,
		["SCD_UseCooldown"] = false,
		["Tar_yOffset"] = -220,
		["RedDebuff"] = 0.5,
		["Tar_xOffset"] = 0,
		["Scd_yOffset"] = 80,
		["TarrelativePoint"] = "CENTER",
		["Scd_xOffset"] = 0,
		["ScdAnchor"] = "CENTER",
		["Tar_NewLine"] = true,
		["xLoc"] = 0,
	},
	["HUNTER"] = {
		["Execution"] = 0,
		["GreenDebuff"] = 0.5,
		["xOffset"] = -40,
		["TarAnchor"] = "CENTER",
		["yOffset"] = 0,
		["PlayerLv2BOSS"] = true,
		["relativePoint"] = "CENTER",
		["Anchor"] = "CENTER",
		["yLoc"] = -140,
		["SCD_UseCooldown"] = false,
		["Tar_yOffset"] = -220,
		["RedDebuff"] = 0.5,
		["Tar_xOffset"] = 0,
		["Scd_yOffset"] = 80,
		["TarrelativePoint"] = "CENTER",
		["Scd_xOffset"] = 0,
		["ScdAnchor"] = "CENTER",
		["Tar_NewLine"] = true,
		["xLoc"] = 0,
	},
	["DRUID"] = {
		["Execution"] = 0,
		["GreenDebuff"] = 0.5,
		["xOffset"] = -40,
		["TarAnchor"] = "CENTER",
		["yOffset"] = 0,
		["PlayerLv2BOSS"] = true,
		["relativePoint"] = "CENTER",
		["Anchor"] = "CENTER",
		["yLoc"] = -140,
		["SCD_UseCooldown"] = false,
		["Tar_yOffset"] = -220,
		["RedDebuff"] = 0.5,
		["Tar_xOffset"] = 0,
		["Scd_yOffset"] = 80,
		["TarrelativePoint"] = "CENTER",
		["Scd_xOffset"] = 0,
		["ScdAnchor"] = "CENTER",
		["Tar_NewLine"] = true,
		["xLoc"] = 0,
	},
	["MONK"] = {
		["Execution"] = 0,
		["GreenDebuff"] = 0.5,
		["xOffset"] = -40,
		["TarAnchor"] = "CENTER",
		["yOffset"] = 0,
		["PlayerLv2BOSS"] = true,
		["relativePoint"] = "CENTER",
		["Anchor"] = "CENTER",
		["yLoc"] = -140,
		["SCD_UseCooldown"] = false,
		["Tar_yOffset"] = -220,
		["RedDebuff"] = 0.5,
		["Tar_xOffset"] = 0,
		["Scd_yOffset"] = 80,
		["TarrelativePoint"] = "CENTER",
		["Scd_xOffset"] = 0,
		["ScdAnchor"] = "CENTER",
		["Tar_NewLine"] = true,
		["xLoc"] = 0,
	},
	["ROGUE"] = {
		["Execution"] = 0,
		["GreenDebuff"] = 0.5,
		["xOffset"] = -40,
		["TarAnchor"] = "CENTER",
		["yOffset"] = 0,
		["PlayerLv2BOSS"] = true,
		["relativePoint"] = "CENTER",
		["Anchor"] = "CENTER",
		["yLoc"] = -140,
		["SCD_UseCooldown"] = false,
		["Tar_yOffset"] = -220,
		["RedDebuff"] = 0.5,
		["Tar_xOffset"] = 0,
		["Scd_yOffset"] = 80,
		["TarrelativePoint"] = "CENTER",
		["Scd_xOffset"] = 0,
		["ScdAnchor"] = "CENTER",
		["Tar_NewLine"] = true,
		["xLoc"] = 0,
	},
}
