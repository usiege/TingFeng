
SavedTemplates = {
}
RR_Options = {
	["ToggleVisible"] = 0,
	["SelectVisible"] = 0,
	["Filter"] = "bwl",
}
