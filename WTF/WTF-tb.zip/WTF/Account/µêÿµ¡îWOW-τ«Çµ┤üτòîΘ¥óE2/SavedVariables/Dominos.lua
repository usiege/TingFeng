
DominosDB = {
	["namespaces"] = {
		["ProgressBars"] = {
			["char"] = {
				["气你马扎罗 - 阿什坎迪"] = {
					["bars"] = {
						["exp"] = {
							["mode"] = "xp",
						},
					},
				},
				["今晚就动手 - 阿什坎迪"] = {
					["bars"] = {
						["exp"] = {
							["mode"] = "xp",
						},
					},
				},
				["榴莲亡反 - 曼多基尔"] = {
					["bars"] = {
						["exp"] = {
							["mode"] = "xp",
						},
					},
				},
				["吸你的血 - 阿什坎迪"] = {
					["bars"] = {
						["exp"] = {
							["mode"] = "xp",
						},
					},
				},
				["你说怎么办 - 阿什坎迪"] = {
					["bars"] = {
						["exp"] = {
							["mode"] = "xp",
						},
					},
				},
				["你说怎么办 - 曼多基尔"] = {
					["bars"] = {
						["exp"] = {
							["mode"] = "xp",
						},
					},
				},
				["我听不见 - 曼多基尔"] = {
					["bars"] = {
						["exp"] = {
							["mode"] = "xp",
						},
					},
				},
				["牛肉涨价 - 曼多基尔"] = {
					["bars"] = {
						["exp"] = {
							["mode"] = "xp",
						},
					},
				},
				["你要的毛巾 - 拉姆斯登"] = {
					["bars"] = {
						["exp"] = {
							["mode"] = "xp",
						},
					},
				},
				["绝境可达鸭 - 阿什坎迪"] = {
					["bars"] = {
						["exp"] = {
							["mode"] = "xp",
						},
					},
				},
				["暗黑界面 - 阿什坎迪"] = {
					["bars"] = {
						["exp"] = {
							["mode"] = "xp",
						},
					},
				},
				["大哥别开火 - 阿什坎迪"] = {
					["bars"] = {
						["exp"] = {
							["mode"] = "xp",
						},
					},
				},
				["你要的毛巾 - 阿什坎迪"] = {
					["bars"] = {
						["exp"] = {
							["mode"] = "xp",
						},
					},
				},
			},
			["global"] = {
				["version"] = 2,
			},
		},
	},
	["profileKeys"] = {
		["大哥别开火 - 阿什坎迪"] = "战士",
		["今晚就动手 - 阿什坎迪"] = "战士",
		["吸你的血 - 阿什坎迪"] = "战士",
		["你说怎么办 - 阿什坎迪"] = "战士",
		["动能甫杜 - 阿什坎迪"] = "战士",
		["绝境可达鸭 - 阿什坎迪"] = "战士",
		["交作业 - 阿什坎迪"] = "战士",
	},
	["global"] = {
		["configVersion"] = 1,
		["addonVersion"] = "9.0.28",
	},
	["profiles"] = {
		["猎人"] = {
			["minimap"] = {
				["minimapPos"] = 187.99414914251,
			},
			["frames"] = {
				{
					["showInPetBattleUI"] = false,
					["fadeOutDelay"] = false,
					["point"] = "BOTTOM",
					["pages"] = {
						["HUNTER"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
						["WARRIOR"] = {
							["berserker"] = 8,
							["page2"] = 1,
							["defensive"] = 7,
							["page5"] = 4,
							["page4"] = 3,
							["battle"] = 6,
							["page3"] = 2,
							["page6"] = 5,
						},
						["WARLOCK"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
						["ROGUE"] = {
							["page2"] = 1,
							["shadowdance"] = 6,
							["page5"] = 4,
							["page4"] = 3,
							["stealth"] = 6,
							["page3"] = 2,
							["page6"] = 5,
						},
						["MAGE"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
						["PALADIN"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
						["SHAMAN"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
					},
					["scale"] = 0.94,
					["showInOverrideUI"] = false,
					["fadeInDelay"] = false,
					["x"] = 9,
					["y"] = 7,
					["showstates"] = "",
					["fadeOutDuration"] = 0.10000000149012,
					["spacing"] = 4,
					["padH"] = 2,
					["fadeInDuration"] = 0.10000000149012,
					["numButtons"] = 12,
					["padW"] = 2,
				}, -- [1]
				{
					["showInPetBattleUI"] = false,
					["scale"] = 1,
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["fadeAlpha"] = 0,
					["anchor"] = "7BC",
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["HUNTER"] = {
						},
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["PALADIN"] = {
						},
						["SHAMAN"] = {
						},
					},
					["y"] = -14,
				}, -- [2]
				{
					["showInPetBattleUI"] = false,
					["point"] = "RIGHT",
					["scale"] = 0.95,
					["showInOverrideUI"] = false,
					["y"] = -46,
					["padW"] = 2,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["HUNTER"] = {
						},
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["PALADIN"] = {
						},
						["SHAMAN"] = {
						},
					},
					["numButtons"] = 12,
					["columns"] = 1,
				}, -- [3]
				{
					["showInPetBattleUI"] = false,
					["columns"] = 1,
					["scale"] = 0.95,
					["showInOverrideUI"] = false,
					["anchor"] = "3LC",
					["y"] = -45,
					["x"] = -40,
					["pages"] = {
						["HUNTER"] = {
						},
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["PALADIN"] = {
						},
						["SHAMAN"] = {
						},
					},
					["spacing"] = 4,
					["padH"] = 2,
					["padW"] = 2,
					["numButtons"] = 12,
					["point"] = "RIGHT",
				}, -- [4]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["fadeOutDelay"] = false,
					["scale"] = 0.94,
					["showInOverrideUI"] = false,
					["pages"] = {
						["HUNTER"] = {
						},
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["PALADIN"] = {
						},
						["SHAMAN"] = {
						},
					},
					["fadeInDuration"] = 0.10000000149012,
					["padW"] = 2,
					["anchor"] = "1TR",
					["fadeOutDuration"] = 0.10000000149012,
					["spacing"] = 4,
					["padH"] = 2,
					["fadeInDelay"] = false,
					["numButtons"] = 12,
					["y"] = 40,
				}, -- [5]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["scale"] = 0.94,
					["showInOverrideUI"] = false,
					["y"] = 85,
					["x"] = 15,
					["anchor"] = "5TR",
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["HUNTER"] = {
						},
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["PALADIN"] = {
						},
						["SHAMAN"] = {
						},
					},
					["numButtons"] = 12,
					["padW"] = 2,
				}, -- [6]
				{
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["padH"] = 2,
					["spacing"] = 4,
					["anchor"] = "8BC",
					["pages"] = {
						["HUNTER"] = {
						},
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["PALADIN"] = {
						},
						["SHAMAN"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 26,
				}, -- [7]
				{
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["anchor"] = "9BC",
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["HUNTER"] = {
						},
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["PALADIN"] = {
						},
						["SHAMAN"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 66,
				}, -- [8]
				{
					["showInPetBattleUI"] = false,
					["scale"] = 1,
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["y"] = 106,
					["anchor"] = "10BC",
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["HUNTER"] = {
						},
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["PALADIN"] = {
						},
						["SHAMAN"] = {
						},
					},
					["padW"] = 2,
				}, -- [9]
				{
					["showInPetBattleUI"] = false,
					["scale"] = 1,
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["y"] = 146,
					["showstates"] = "",
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["HUNTER"] = {
						},
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["PALADIN"] = {
						},
						["SHAMAN"] = {
						},
					},
					["padW"] = 2,
				}, -- [10]
				["exp"] = {
					["point"] = "BOTTOM",
					["scale"] = 0.67,
					["lockMode"] = true,
					["padW"] = 2,
					["fadeAlpha"] = 0.75,
					["fadeOutDuration"] = 0.10000000149012,
					["spacing"] = 1,
					["fadeInDuration"] = 0.10000000149012,
					["displayLevel"] = 1,
					["texture"] = "Smooth",
					["showInPetBattleUI"] = false,
					["columns"] = 20,
					["numButtons"] = 20,
					["displayLayer"] = "MEDIUM",
					["showInOverrideUI"] = false,
					["padH"] = 2,
					["width"] = 664,
					["fadeOutDelay"] = false,
					["font"] = "默认",
					["display"] = {
						["value"] = true,
						["bonus"] = true,
						["max"] = true,
						["label"] = true,
					},
					["x"] = 11.999899251951,
					["height"] = 8,
					["fadeInDelay"] = false,
					["y"] = 180,
					["alwaysShowText"] = true,
				},
				["bags"] = {
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
					["scale"] = 0.7,
					["spacing"] = 0,
				},
				["mirrorTimer2"] = {
					["showInPetBattleUI"] = false,
					["point"] = "TOP",
					["showInOverrideUI"] = false,
					["w"] = 206,
					["y"] = -226,
					["font"] = "默认",
					["padW"] = 1,
					["anchor"] = "mirrorTimer3TL",
					["display"] = {
						["border"] = true,
						["time"] = false,
						["spark"] = false,
						["label"] = true,
					},
					["padH"] = 1,
					["h"] = 26,
					["texture"] = "Blizzard",
				},
				["alerts"] = {
					["showInPetBattleUI"] = true,
					["point"] = "LEFT",
					["spacing"] = 2,
					["showInOverrideUI"] = true,
					["columns"] = 1,
				},
				["roll"] = {
					["showInPetBattleUI"] = true,
					["point"] = "LEFT",
					["spacing"] = 2,
					["showInOverrideUI"] = true,
					["columns"] = 1,
				},
				["vehicle"] = {
					["showInPetBattleUI"] = false,
					["x"] = 217,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["y"] = 141,
				},
				["mirrorTimer3"] = {
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
					["w"] = 206,
					["y"] = 215,
					["font"] = "默认",
					["display"] = {
						["border"] = true,
						["time"] = false,
						["spark"] = false,
						["label"] = true,
					},
					["padH"] = 1,
					["padW"] = 1,
					["h"] = 26,
					["texture"] = "Blizzard",
				},
				["pet"] = {
					["showInPetBattleUI"] = false,
					["x"] = 12.374954223633,
					["point"] = "BOTTOM",
					["spacing"] = 6,
					["showInOverrideUI"] = false,
					["y"] = 148.49998474121,
				},
				["talk"] = {
					["y"] = -21.499984741211,
					["relPoint"] = "CENTER",
					["point"] = "TOP",
					["showInPetBattleUI"] = true,
					["showInOverrideUI"] = true,
					["x"] = 12.75,
					["displayLayer"] = "LOW",
				},
				["menu"] = {
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOMRIGHT",
					["scale"] = 0.7,
					["showInOverrideUI"] = false,
					["y"] = 37,
					["showstates"] = "鼠标滑过隐藏",
					["clickThrough"] = false,
					["anchor"] = "bagsTR",
					["spacing"] = 0,
				},
				["mirrorTimer1"] = {
					["showInPetBattleUI"] = false,
					["point"] = "TOP",
					["showInOverrideUI"] = false,
					["w"] = 206,
					["y"] = -200,
					["font"] = "默认",
					["padW"] = 1,
					["anchor"] = "mirrorTimer2TC",
					["display"] = {
						["border"] = true,
						["time"] = false,
						["spark"] = false,
						["label"] = true,
					},
					["padH"] = 1,
					["h"] = 26,
					["texture"] = "Blizzard",
				},
				["cast"] = {
					["point"] = "BOTTOM",
					["scale"] = 0.75,
					["padW"] = 1,
					["h"] = 26,
					["fadeOutDuration"] = 0.10000000149012,
					["anchor"] = {
						["relFrame"] = "pet",
						["point"] = "BOTTOM",
						["relPoint"] = "TOP",
					},
					["fadeInDuration"] = 0.10000000149012,
					["displayLevel"] = 1,
					["texture"] = "Solid",
					["showInPetBattleUI"] = true,
					["showInOverrideUI"] = true,
					["w"] = 250,
					["latencyPadding"] = 0,
					["fadeOutDelay"] = false,
					["x"] = 16.49989827474,
					["y"] = 237.99996948242,
					["padH"] = 1,
					["display"] = {
						["time"] = true,
						["spark"] = false,
						["icon"] = true,
						["border"] = false,
						["latency"] = false,
					},
					["fadeInDelay"] = false,
					["displayLayer"] = "MEDIUM",
					["font"] = "Friz Quadrata TT",
				},
				["class"] = {
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOMRIGHT",
					["scale"] = 0.9,
					["showInOverrideUI"] = false,
					["y"] = 142.9333190918,
					["relPoint"] = "BOTTOM",
					["spacing"] = 2,
					["anchor"] = {
						["relFrame"] = "exp",
						["point"] = "BOTTOMLEFT",
						["relPoint"] = "TOPLEFT",
					},
					["x"] = -209.71123777929,
					["displayLevel"] = 1,
					["displayLayer"] = "MEDIUM",
				},
			},
			["showgrid"] = true,
		},
		["潜行者"] = {
			["minimap"] = {
				["minimapPos"] = 187.99414914251,
			},
			["frames"] = {
				{
					["showInPetBattleUI"] = false,
					["padW"] = 2,
					["point"] = "BOTTOM",
					["numButtons"] = 12,
					["scale"] = 0.94,
					["showInOverrideUI"] = false,
					["fadeInDelay"] = false,
					["x"] = 9,
					["y"] = 7,
					["showstates"] = "",
					["fadeOutDuration"] = 0.10000000149012,
					["spacing"] = 4,
					["padH"] = 2,
					["fadeInDuration"] = 0.10000000149012,
					["pages"] = {
						["WARRIOR"] = {
							["berserker"] = 8,
							["page2"] = 1,
							["defensive"] = 7,
							["page5"] = 4,
							["page4"] = 3,
							["battle"] = 6,
							["page3"] = 2,
							["page6"] = 5,
						},
						["WARLOCK"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
						["ROGUE"] = {
							["page2"] = 1,
							["shadowdance"] = 6,
							["page5"] = 4,
							["page4"] = 3,
							["stealth"] = 6,
							["page3"] = 2,
							["page6"] = 5,
						},
						["MAGE"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
						["PALADIN"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
						["SHAMAN"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
					},
					["fadeOutDelay"] = false,
				}, -- [1]
				{
					["showInPetBattleUI"] = false,
					["scale"] = 1,
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["fadeAlpha"] = 0,
					["anchor"] = "7BC",
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["PALADIN"] = {
						},
						["SHAMAN"] = {
						},
					},
					["y"] = -14,
				}, -- [2]
				{
					["showInPetBattleUI"] = false,
					["point"] = "RIGHT",
					["scale"] = 0.95,
					["showInOverrideUI"] = false,
					["y"] = -46,
					["padW"] = 2,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["PALADIN"] = {
						},
						["SHAMAN"] = {
						},
					},
					["numButtons"] = 12,
					["columns"] = 1,
				}, -- [3]
				{
					["showInPetBattleUI"] = false,
					["columns"] = 1,
					["scale"] = 0.95,
					["showInOverrideUI"] = false,
					["anchor"] = "3LC",
					["y"] = -45,
					["x"] = -40,
					["pages"] = {
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["PALADIN"] = {
						},
						["SHAMAN"] = {
						},
					},
					["spacing"] = 4,
					["padH"] = 2,
					["padW"] = 2,
					["numButtons"] = 12,
					["point"] = "RIGHT",
				}, -- [4]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["fadeOutDelay"] = false,
					["scale"] = 0.94,
					["showInOverrideUI"] = false,
					["pages"] = {
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["PALADIN"] = {
						},
						["SHAMAN"] = {
						},
					},
					["fadeInDuration"] = 0.10000000149012,
					["padW"] = 2,
					["anchor"] = "1TR",
					["fadeOutDuration"] = 0.10000000149012,
					["spacing"] = 4,
					["padH"] = 2,
					["fadeInDelay"] = false,
					["numButtons"] = 12,
					["y"] = 40,
				}, -- [5]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["scale"] = 0.94,
					["showInOverrideUI"] = false,
					["y"] = 85,
					["x"] = 15,
					["anchor"] = "5TR",
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["PALADIN"] = {
						},
						["SHAMAN"] = {
						},
					},
					["numButtons"] = 12,
					["padW"] = 2,
				}, -- [6]
				{
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["padH"] = 2,
					["spacing"] = 4,
					["anchor"] = "8BC",
					["pages"] = {
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["PALADIN"] = {
						},
						["SHAMAN"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 26,
				}, -- [7]
				{
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["anchor"] = "9BC",
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["PALADIN"] = {
						},
						["SHAMAN"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 66,
				}, -- [8]
				{
					["showInPetBattleUI"] = false,
					["scale"] = 1,
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["y"] = 106,
					["anchor"] = "10BC",
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["PALADIN"] = {
						},
						["SHAMAN"] = {
						},
					},
					["padW"] = 2,
				}, -- [9]
				{
					["showInPetBattleUI"] = false,
					["scale"] = 1,
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["y"] = 146,
					["showstates"] = "",
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["PALADIN"] = {
						},
						["SHAMAN"] = {
						},
					},
					["padW"] = 2,
				}, -- [10]
				["exp"] = {
					["point"] = "BOTTOM",
					["scale"] = 0.67,
					["lockMode"] = true,
					["padW"] = 2,
					["fadeAlpha"] = 0.75,
					["fadeOutDuration"] = 0.10000000149012,
					["spacing"] = 1,
					["fadeInDuration"] = 0.10000000149012,
					["displayLevel"] = 1,
					["texture"] = "Smooth",
					["showInPetBattleUI"] = false,
					["columns"] = 20,
					["numButtons"] = 20,
					["displayLayer"] = "MEDIUM",
					["showInOverrideUI"] = false,
					["padH"] = 2,
					["width"] = 664,
					["fadeOutDelay"] = false,
					["font"] = "默认",
					["display"] = {
						["value"] = true,
						["bonus"] = true,
						["max"] = true,
						["label"] = true,
					},
					["x"] = 11.999899251951,
					["height"] = 8,
					["fadeInDelay"] = false,
					["y"] = 180,
					["alwaysShowText"] = true,
				},
				["bags"] = {
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
					["scale"] = 0.7,
					["spacing"] = 0,
				},
				["mirrorTimer2"] = {
					["showInPetBattleUI"] = false,
					["point"] = "TOP",
					["showInOverrideUI"] = false,
					["w"] = 206,
					["y"] = -226,
					["font"] = "默认",
					["padW"] = 1,
					["anchor"] = "mirrorTimer3TL",
					["display"] = {
						["border"] = true,
						["time"] = false,
						["spark"] = false,
						["label"] = true,
					},
					["padH"] = 1,
					["h"] = 26,
					["texture"] = "Blizzard",
				},
				["alerts"] = {
					["showInPetBattleUI"] = true,
					["point"] = "LEFT",
					["spacing"] = 2,
					["showInOverrideUI"] = true,
					["columns"] = 1,
				},
				["roll"] = {
					["showInPetBattleUI"] = true,
					["point"] = "LEFT",
					["spacing"] = 2,
					["showInOverrideUI"] = true,
					["columns"] = 1,
				},
				["vehicle"] = {
					["showInPetBattleUI"] = false,
					["x"] = 217,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["y"] = 141,
				},
				["mirrorTimer3"] = {
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
					["w"] = 206,
					["y"] = 215,
					["font"] = "默认",
					["display"] = {
						["border"] = true,
						["time"] = false,
						["spark"] = false,
						["label"] = true,
					},
					["padH"] = 1,
					["padW"] = 1,
					["h"] = 26,
					["texture"] = "Blizzard",
				},
				["pet"] = {
					["showInPetBattleUI"] = false,
					["x"] = 12.374954223633,
					["point"] = "BOTTOM",
					["spacing"] = 6,
					["showInOverrideUI"] = false,
					["y"] = 148.49998474121,
				},
				["talk"] = {
					["y"] = -21.499984741211,
					["relPoint"] = "CENTER",
					["point"] = "TOP",
					["x"] = 12.75,
					["showInOverrideUI"] = true,
					["showInPetBattleUI"] = true,
					["displayLayer"] = "LOW",
				},
				["menu"] = {
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOMRIGHT",
					["scale"] = 0.7,
					["showInOverrideUI"] = false,
					["y"] = 37,
					["showstates"] = "鼠标滑过隐藏",
					["clickThrough"] = false,
					["anchor"] = "bagsTR",
					["spacing"] = 0,
				},
				["mirrorTimer1"] = {
					["showInPetBattleUI"] = false,
					["point"] = "TOP",
					["showInOverrideUI"] = false,
					["w"] = 206,
					["y"] = -200,
					["font"] = "默认",
					["padW"] = 1,
					["anchor"] = "mirrorTimer2TC",
					["display"] = {
						["border"] = true,
						["time"] = false,
						["spark"] = false,
						["label"] = true,
					},
					["padH"] = 1,
					["h"] = 26,
					["texture"] = "Blizzard",
				},
				["cast"] = {
					["point"] = "BOTTOM",
					["scale"] = 0.75,
					["padW"] = 1,
					["h"] = 26,
					["fadeOutDuration"] = 0.10000000149012,
					["anchor"] = {
						["relFrame"] = "pet",
						["point"] = "BOTTOM",
						["relPoint"] = "TOP",
					},
					["fadeInDuration"] = 0.10000000149012,
					["displayLevel"] = 1,
					["texture"] = "Solid",
					["showInPetBattleUI"] = true,
					["showInOverrideUI"] = true,
					["w"] = 250,
					["latencyPadding"] = 0,
					["fadeOutDelay"] = false,
					["x"] = 16.49989827474,
					["y"] = 237.99996948242,
					["padH"] = 1,
					["display"] = {
						["time"] = true,
						["spark"] = false,
						["icon"] = true,
						["border"] = false,
						["latency"] = false,
					},
					["fadeInDelay"] = false,
					["displayLayer"] = "MEDIUM",
					["font"] = "Friz Quadrata TT",
				},
				["class"] = {
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOMRIGHT",
					["scale"] = 0.9,
					["showInOverrideUI"] = false,
					["y"] = 142.9333190918,
					["relPoint"] = "BOTTOM",
					["spacing"] = 2,
					["anchor"] = {
						["relFrame"] = "exp",
						["point"] = "BOTTOMLEFT",
						["relPoint"] = "TOPLEFT",
					},
					["x"] = -209.71123777929,
					["displayLevel"] = 1,
					["displayLayer"] = "MEDIUM",
				},
			},
			["showgrid"] = true,
		},
		["术士"] = {
			["minimap"] = {
				["minimapPos"] = 187.99414914251,
			},
			["frames"] = {
				{
					["showInPetBattleUI"] = false,
					["padW"] = 2,
					["point"] = "BOTTOM",
					["numButtons"] = 12,
					["scale"] = 0.94,
					["showInOverrideUI"] = false,
					["fadeInDelay"] = false,
					["x"] = 9,
					["y"] = 7,
					["showstates"] = "",
					["fadeOutDuration"] = 0.10000000149012,
					["spacing"] = 4,
					["padH"] = 2,
					["fadeInDuration"] = 0.10000000149012,
					["pages"] = {
						["WARRIOR"] = {
							["berserker"] = 8,
							["page2"] = 1,
							["defensive"] = 7,
							["page5"] = 4,
							["page4"] = 3,
							["battle"] = 6,
							["page3"] = 2,
							["page6"] = 5,
						},
						["WARLOCK"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
						["ROGUE"] = {
							["page2"] = 1,
							["shadowdance"] = 6,
							["page5"] = 4,
							["page4"] = 3,
							["stealth"] = 6,
							["page3"] = 2,
							["page6"] = 5,
						},
						["MAGE"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
						["PALADIN"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
						["SHAMAN"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
					},
					["fadeOutDelay"] = false,
				}, -- [1]
				{
					["showInPetBattleUI"] = false,
					["scale"] = 1,
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["fadeAlpha"] = 0,
					["anchor"] = "7BC",
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["PALADIN"] = {
						},
						["SHAMAN"] = {
						},
					},
					["y"] = -14,
				}, -- [2]
				{
					["showInPetBattleUI"] = false,
					["point"] = "RIGHT",
					["scale"] = 0.95,
					["showInOverrideUI"] = false,
					["y"] = -46,
					["padW"] = 2,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["PALADIN"] = {
						},
						["SHAMAN"] = {
						},
					},
					["numButtons"] = 12,
					["columns"] = 1,
				}, -- [3]
				{
					["showInPetBattleUI"] = false,
					["columns"] = 1,
					["scale"] = 0.95,
					["showInOverrideUI"] = false,
					["anchor"] = "3LC",
					["y"] = -45,
					["x"] = -40,
					["pages"] = {
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["PALADIN"] = {
						},
						["SHAMAN"] = {
						},
					},
					["spacing"] = 4,
					["padH"] = 2,
					["padW"] = 2,
					["numButtons"] = 12,
					["point"] = "RIGHT",
				}, -- [4]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["fadeOutDelay"] = false,
					["scale"] = 0.94,
					["showInOverrideUI"] = false,
					["pages"] = {
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["PALADIN"] = {
						},
						["SHAMAN"] = {
						},
					},
					["fadeInDuration"] = 0.10000000149012,
					["padW"] = 2,
					["anchor"] = "1TR",
					["fadeOutDuration"] = 0.10000000149012,
					["spacing"] = 4,
					["padH"] = 2,
					["fadeInDelay"] = false,
					["numButtons"] = 12,
					["y"] = 40,
				}, -- [5]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["scale"] = 0.94,
					["showInOverrideUI"] = false,
					["y"] = 85,
					["x"] = 15,
					["anchor"] = "5TR",
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["PALADIN"] = {
						},
						["SHAMAN"] = {
						},
					},
					["numButtons"] = 12,
					["padW"] = 2,
				}, -- [6]
				{
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["padH"] = 2,
					["spacing"] = 4,
					["anchor"] = "8BC",
					["pages"] = {
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["PALADIN"] = {
						},
						["SHAMAN"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 26,
				}, -- [7]
				{
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["anchor"] = "9BC",
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["PALADIN"] = {
						},
						["SHAMAN"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 66,
				}, -- [8]
				{
					["showInPetBattleUI"] = false,
					["scale"] = 1,
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["y"] = 106,
					["anchor"] = "10BC",
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["PALADIN"] = {
						},
						["SHAMAN"] = {
						},
					},
					["padW"] = 2,
				}, -- [9]
				{
					["showInPetBattleUI"] = false,
					["scale"] = 1,
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["y"] = 146,
					["showstates"] = "",
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["PALADIN"] = {
						},
						["SHAMAN"] = {
						},
					},
					["padW"] = 2,
				}, -- [10]
				["exp"] = {
					["point"] = "BOTTOM",
					["scale"] = 0.67,
					["lockMode"] = true,
					["padW"] = 2,
					["fadeAlpha"] = 0.75,
					["fadeOutDuration"] = 0.10000000149012,
					["spacing"] = 1,
					["fadeInDuration"] = 0.10000000149012,
					["displayLevel"] = 1,
					["texture"] = "Smooth",
					["showInPetBattleUI"] = false,
					["columns"] = 20,
					["numButtons"] = 20,
					["displayLayer"] = "MEDIUM",
					["showInOverrideUI"] = false,
					["padH"] = 2,
					["width"] = 664,
					["fadeOutDelay"] = false,
					["font"] = "默认",
					["display"] = {
						["value"] = true,
						["bonus"] = true,
						["max"] = true,
						["label"] = true,
					},
					["x"] = 11.999899251951,
					["height"] = 8,
					["fadeInDelay"] = false,
					["y"] = 180,
					["alwaysShowText"] = true,
				},
				["bags"] = {
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
					["scale"] = 0.7,
					["spacing"] = 0,
				},
				["mirrorTimer2"] = {
					["showInPetBattleUI"] = false,
					["point"] = "TOP",
					["showInOverrideUI"] = false,
					["w"] = 206,
					["y"] = -226,
					["font"] = "默认",
					["padW"] = 1,
					["anchor"] = "mirrorTimer3TL",
					["display"] = {
						["border"] = true,
						["time"] = false,
						["spark"] = false,
						["label"] = true,
					},
					["padH"] = 1,
					["h"] = 26,
					["texture"] = "Blizzard",
				},
				["alerts"] = {
					["showInPetBattleUI"] = true,
					["point"] = "LEFT",
					["spacing"] = 2,
					["showInOverrideUI"] = true,
					["columns"] = 1,
				},
				["roll"] = {
					["showInPetBattleUI"] = true,
					["point"] = "LEFT",
					["spacing"] = 2,
					["showInOverrideUI"] = true,
					["columns"] = 1,
				},
				["vehicle"] = {
					["showInPetBattleUI"] = false,
					["x"] = 217,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["y"] = 141,
				},
				["mirrorTimer3"] = {
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
					["w"] = 206,
					["y"] = 215,
					["font"] = "默认",
					["display"] = {
						["border"] = true,
						["time"] = false,
						["spark"] = false,
						["label"] = true,
					},
					["padH"] = 1,
					["padW"] = 1,
					["h"] = 26,
					["texture"] = "Blizzard",
				},
				["pet"] = {
					["showInPetBattleUI"] = false,
					["x"] = 12.374954223633,
					["point"] = "BOTTOM",
					["spacing"] = 6,
					["showInOverrideUI"] = false,
					["y"] = 148.49998474121,
				},
				["talk"] = {
					["y"] = -21.499984741211,
					["relPoint"] = "CENTER",
					["point"] = "TOP",
					["x"] = 12.75,
					["showInOverrideUI"] = true,
					["showInPetBattleUI"] = true,
					["displayLayer"] = "LOW",
				},
				["menu"] = {
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOMRIGHT",
					["scale"] = 0.7,
					["showInOverrideUI"] = false,
					["y"] = 37,
					["showstates"] = "鼠标滑过隐藏",
					["clickThrough"] = false,
					["anchor"] = "bagsTR",
					["spacing"] = 0,
				},
				["mirrorTimer1"] = {
					["showInPetBattleUI"] = false,
					["point"] = "TOP",
					["showInOverrideUI"] = false,
					["w"] = 206,
					["y"] = -200,
					["font"] = "默认",
					["padW"] = 1,
					["anchor"] = "mirrorTimer2TC",
					["display"] = {
						["border"] = true,
						["time"] = false,
						["spark"] = false,
						["label"] = true,
					},
					["padH"] = 1,
					["h"] = 26,
					["texture"] = "Blizzard",
				},
				["cast"] = {
					["point"] = "BOTTOM",
					["scale"] = 0.75,
					["padW"] = 1,
					["h"] = 26,
					["fadeOutDuration"] = 0.10000000149012,
					["anchor"] = {
						["relFrame"] = "pet",
						["point"] = "BOTTOM",
						["relPoint"] = "TOP",
					},
					["fadeInDuration"] = 0.10000000149012,
					["displayLevel"] = 1,
					["texture"] = "Solid",
					["showInPetBattleUI"] = true,
					["showInOverrideUI"] = true,
					["w"] = 250,
					["latencyPadding"] = 0,
					["fadeOutDelay"] = false,
					["x"] = 16.49989827474,
					["y"] = 237.99996948242,
					["padH"] = 1,
					["display"] = {
						["time"] = true,
						["spark"] = false,
						["icon"] = true,
						["border"] = false,
						["latency"] = false,
					},
					["fadeInDelay"] = false,
					["displayLayer"] = "MEDIUM",
					["font"] = "Friz Quadrata TT",
				},
				["class"] = {
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOMRIGHT",
					["scale"] = 0.9,
					["showInOverrideUI"] = false,
					["y"] = 142.9333190918,
					["relPoint"] = "BOTTOM",
					["spacing"] = 2,
					["anchor"] = {
						["relFrame"] = "exp",
						["point"] = "BOTTOMLEFT",
						["relPoint"] = "TOPLEFT",
					},
					["x"] = -209.71123777929,
					["displayLevel"] = 1,
					["displayLayer"] = "MEDIUM",
				},
			},
			["showgrid"] = true,
		},
		["德鲁伊"] = {
			["minimap"] = {
				["minimapPos"] = 187.99414914251,
			},
			["frames"] = {
				{
					["showInPetBattleUI"] = false,
					["padW"] = 2,
					["point"] = "BOTTOM",
					["numButtons"] = 12,
					["scale"] = 0.94,
					["showInOverrideUI"] = false,
					["fadeInDelay"] = false,
					["x"] = 9,
					["y"] = 7,
					["showstates"] = "",
					["fadeOutDuration"] = 0.10000000149012,
					["spacing"] = 4,
					["padH"] = 2,
					["fadeInDuration"] = 0.10000000149012,
					["pages"] = {
						["WARRIOR"] = {
							["berserker"] = 8,
							["page2"] = 1,
							["defensive"] = 7,
							["page5"] = 4,
							["page4"] = 3,
							["battle"] = 6,
							["page3"] = 2,
							["page6"] = 5,
						},
						["WARLOCK"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
						["ROGUE"] = {
							["page2"] = 1,
							["shadowdance"] = 6,
							["page5"] = 4,
							["page4"] = 3,
							["stealth"] = 6,
							["page3"] = 2,
							["page6"] = 5,
						},
						["MAGE"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
						["PALADIN"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
						["SHAMAN"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
					},
					["fadeOutDelay"] = false,
				}, -- [1]
				{
					["showInPetBattleUI"] = false,
					["scale"] = 1,
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["fadeAlpha"] = 0,
					["anchor"] = "7BC",
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["PALADIN"] = {
						},
						["SHAMAN"] = {
						},
					},
					["y"] = -14,
				}, -- [2]
				{
					["showInPetBattleUI"] = false,
					["point"] = "RIGHT",
					["scale"] = 0.95,
					["showInOverrideUI"] = false,
					["y"] = -46,
					["padW"] = 2,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["PALADIN"] = {
						},
						["SHAMAN"] = {
						},
					},
					["numButtons"] = 12,
					["columns"] = 1,
				}, -- [3]
				{
					["showInPetBattleUI"] = false,
					["columns"] = 1,
					["scale"] = 0.95,
					["showInOverrideUI"] = false,
					["anchor"] = "3LC",
					["y"] = -45,
					["x"] = -40,
					["pages"] = {
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["PALADIN"] = {
						},
						["SHAMAN"] = {
						},
					},
					["spacing"] = 4,
					["padH"] = 2,
					["padW"] = 2,
					["numButtons"] = 12,
					["point"] = "RIGHT",
				}, -- [4]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["fadeOutDelay"] = false,
					["scale"] = 0.94,
					["showInOverrideUI"] = false,
					["pages"] = {
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["PALADIN"] = {
						},
						["SHAMAN"] = {
						},
					},
					["fadeInDuration"] = 0.10000000149012,
					["padW"] = 2,
					["anchor"] = "1TR",
					["fadeOutDuration"] = 0.10000000149012,
					["spacing"] = 4,
					["padH"] = 2,
					["fadeInDelay"] = false,
					["numButtons"] = 12,
					["y"] = 40,
				}, -- [5]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["scale"] = 0.94,
					["showInOverrideUI"] = false,
					["y"] = 85,
					["x"] = 15,
					["anchor"] = "5TR",
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["PALADIN"] = {
						},
						["SHAMAN"] = {
						},
					},
					["numButtons"] = 12,
					["padW"] = 2,
				}, -- [6]
				{
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["padH"] = 2,
					["spacing"] = 4,
					["anchor"] = "8BC",
					["pages"] = {
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["PALADIN"] = {
						},
						["SHAMAN"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 26,
				}, -- [7]
				{
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["anchor"] = "9BC",
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["PALADIN"] = {
						},
						["SHAMAN"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 66,
				}, -- [8]
				{
					["showInPetBattleUI"] = false,
					["scale"] = 1,
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["y"] = 106,
					["anchor"] = "10BC",
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["PALADIN"] = {
						},
						["SHAMAN"] = {
						},
					},
					["padW"] = 2,
				}, -- [9]
				{
					["showInPetBattleUI"] = false,
					["scale"] = 1,
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["y"] = 146,
					["showstates"] = "",
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["PALADIN"] = {
						},
						["SHAMAN"] = {
						},
					},
					["padW"] = 2,
				}, -- [10]
				["exp"] = {
					["point"] = "BOTTOM",
					["scale"] = 0.67,
					["lockMode"] = true,
					["padW"] = 2,
					["fadeAlpha"] = 0.75,
					["fadeOutDuration"] = 0.10000000149012,
					["spacing"] = 1,
					["fadeInDuration"] = 0.10000000149012,
					["displayLevel"] = 1,
					["texture"] = "Smooth",
					["showInPetBattleUI"] = false,
					["columns"] = 20,
					["numButtons"] = 20,
					["displayLayer"] = "MEDIUM",
					["showInOverrideUI"] = false,
					["padH"] = 2,
					["width"] = 664,
					["fadeOutDelay"] = false,
					["font"] = "默认",
					["display"] = {
						["value"] = true,
						["bonus"] = true,
						["max"] = true,
						["label"] = true,
					},
					["x"] = 11.999899251951,
					["height"] = 8,
					["fadeInDelay"] = false,
					["y"] = 180,
					["alwaysShowText"] = true,
				},
				["bags"] = {
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
					["scale"] = 0.7,
					["spacing"] = 0,
				},
				["mirrorTimer2"] = {
					["showInPetBattleUI"] = false,
					["point"] = "TOP",
					["showInOverrideUI"] = false,
					["w"] = 206,
					["y"] = -226,
					["font"] = "默认",
					["padW"] = 1,
					["anchor"] = "mirrorTimer3TL",
					["display"] = {
						["border"] = true,
						["time"] = false,
						["spark"] = false,
						["label"] = true,
					},
					["padH"] = 1,
					["h"] = 26,
					["texture"] = "Blizzard",
				},
				["alerts"] = {
					["showInPetBattleUI"] = true,
					["point"] = "LEFT",
					["spacing"] = 2,
					["showInOverrideUI"] = true,
					["columns"] = 1,
				},
				["roll"] = {
					["showInPetBattleUI"] = true,
					["point"] = "LEFT",
					["spacing"] = 2,
					["showInOverrideUI"] = true,
					["columns"] = 1,
				},
				["vehicle"] = {
					["showInPetBattleUI"] = false,
					["x"] = 217,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["y"] = 141,
				},
				["mirrorTimer3"] = {
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
					["w"] = 206,
					["y"] = 215,
					["font"] = "默认",
					["display"] = {
						["border"] = true,
						["time"] = false,
						["spark"] = false,
						["label"] = true,
					},
					["padH"] = 1,
					["padW"] = 1,
					["h"] = 26,
					["texture"] = "Blizzard",
				},
				["pet"] = {
					["showInPetBattleUI"] = false,
					["x"] = 12.374954223633,
					["point"] = "BOTTOM",
					["spacing"] = 6,
					["showInOverrideUI"] = false,
					["y"] = 148.49998474121,
				},
				["talk"] = {
					["y"] = -21.499984741211,
					["relPoint"] = "CENTER",
					["point"] = "TOP",
					["x"] = 12.75,
					["showInOverrideUI"] = true,
					["showInPetBattleUI"] = true,
					["displayLayer"] = "LOW",
				},
				["menu"] = {
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOMRIGHT",
					["scale"] = 0.7,
					["showInOverrideUI"] = false,
					["y"] = 37,
					["showstates"] = "鼠标滑过隐藏",
					["clickThrough"] = false,
					["anchor"] = "bagsTR",
					["spacing"] = 0,
				},
				["mirrorTimer1"] = {
					["showInPetBattleUI"] = false,
					["point"] = "TOP",
					["showInOverrideUI"] = false,
					["w"] = 206,
					["y"] = -200,
					["font"] = "默认",
					["padW"] = 1,
					["anchor"] = "mirrorTimer2TC",
					["display"] = {
						["border"] = true,
						["time"] = false,
						["spark"] = false,
						["label"] = true,
					},
					["padH"] = 1,
					["h"] = 26,
					["texture"] = "Blizzard",
				},
				["cast"] = {
					["point"] = "BOTTOM",
					["scale"] = 0.75,
					["padW"] = 1,
					["h"] = 26,
					["fadeOutDuration"] = 0.10000000149012,
					["anchor"] = {
						["relFrame"] = "pet",
						["point"] = "BOTTOM",
						["relPoint"] = "TOP",
					},
					["fadeInDuration"] = 0.10000000149012,
					["displayLevel"] = 1,
					["texture"] = "Solid",
					["showInPetBattleUI"] = true,
					["showInOverrideUI"] = true,
					["w"] = 250,
					["latencyPadding"] = 0,
					["fadeOutDelay"] = false,
					["x"] = 16.49989827474,
					["y"] = 237.99996948242,
					["padH"] = 1,
					["display"] = {
						["time"] = true,
						["spark"] = false,
						["icon"] = true,
						["border"] = false,
						["latency"] = false,
					},
					["fadeInDelay"] = false,
					["displayLayer"] = "MEDIUM",
					["font"] = "Friz Quadrata TT",
				},
				["class"] = {
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOMRIGHT",
					["scale"] = 0.9,
					["showInOverrideUI"] = false,
					["y"] = 142.9333190918,
					["relPoint"] = "BOTTOM",
					["spacing"] = 2,
					["anchor"] = {
						["relFrame"] = "exp",
						["point"] = "BOTTOMLEFT",
						["relPoint"] = "TOPLEFT",
					},
					["x"] = -209.71123777929,
					["displayLevel"] = 1,
					["displayLayer"] = "MEDIUM",
				},
			},
			["showgrid"] = true,
		},
		["萨满祭司"] = {
			["minimap"] = {
				["minimapPos"] = 187.99414914251,
			},
			["frames"] = {
				{
					["showInPetBattleUI"] = false,
					["padW"] = 2,
					["point"] = "BOTTOM",
					["numButtons"] = 12,
					["scale"] = 0.94,
					["showInOverrideUI"] = false,
					["fadeInDelay"] = false,
					["x"] = 9,
					["y"] = 7,
					["showstates"] = "",
					["fadeOutDuration"] = 0.10000000149012,
					["spacing"] = 4,
					["padH"] = 2,
					["fadeInDuration"] = 0.10000000149012,
					["pages"] = {
						["WARRIOR"] = {
							["berserker"] = 8,
							["page2"] = 1,
							["defensive"] = 7,
							["page5"] = 4,
							["page4"] = 3,
							["battle"] = 6,
							["page3"] = 2,
							["page6"] = 5,
						},
						["WARLOCK"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
						["ROGUE"] = {
							["page2"] = 1,
							["shadowdance"] = 6,
							["page5"] = 4,
							["page4"] = 3,
							["stealth"] = 6,
							["page3"] = 2,
							["page6"] = 5,
						},
						["MAGE"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
						["PALADIN"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
						["SHAMAN"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
					},
					["fadeOutDelay"] = false,
				}, -- [1]
				{
					["showInPetBattleUI"] = false,
					["scale"] = 1,
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["fadeAlpha"] = 0,
					["anchor"] = "7BC",
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["PALADIN"] = {
						},
						["SHAMAN"] = {
						},
					},
					["y"] = -14,
				}, -- [2]
				{
					["showInPetBattleUI"] = false,
					["point"] = "RIGHT",
					["scale"] = 0.95,
					["showInOverrideUI"] = false,
					["y"] = -46,
					["padW"] = 2,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["PALADIN"] = {
						},
						["SHAMAN"] = {
						},
					},
					["numButtons"] = 12,
					["columns"] = 1,
				}, -- [3]
				{
					["showInPetBattleUI"] = false,
					["columns"] = 1,
					["scale"] = 0.95,
					["showInOverrideUI"] = false,
					["anchor"] = "3LC",
					["y"] = -45,
					["x"] = -40,
					["pages"] = {
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["PALADIN"] = {
						},
						["SHAMAN"] = {
						},
					},
					["spacing"] = 4,
					["padH"] = 2,
					["padW"] = 2,
					["numButtons"] = 12,
					["point"] = "RIGHT",
				}, -- [4]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["fadeOutDelay"] = false,
					["scale"] = 0.94,
					["showInOverrideUI"] = false,
					["pages"] = {
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["PALADIN"] = {
						},
						["SHAMAN"] = {
						},
					},
					["fadeInDuration"] = 0.10000000149012,
					["padW"] = 2,
					["anchor"] = "1TR",
					["fadeOutDuration"] = 0.10000000149012,
					["spacing"] = 4,
					["padH"] = 2,
					["fadeInDelay"] = false,
					["numButtons"] = 12,
					["y"] = 40,
				}, -- [5]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["scale"] = 0.94,
					["showInOverrideUI"] = false,
					["y"] = 85,
					["x"] = 15,
					["anchor"] = "5TR",
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["PALADIN"] = {
						},
						["SHAMAN"] = {
						},
					},
					["numButtons"] = 12,
					["padW"] = 2,
				}, -- [6]
				{
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["padH"] = 2,
					["spacing"] = 4,
					["anchor"] = "8BC",
					["pages"] = {
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["PALADIN"] = {
						},
						["SHAMAN"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 26,
				}, -- [7]
				{
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["anchor"] = "9BC",
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["PALADIN"] = {
						},
						["SHAMAN"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 66,
				}, -- [8]
				{
					["showInPetBattleUI"] = false,
					["scale"] = 1,
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["y"] = 106,
					["anchor"] = "10BC",
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["PALADIN"] = {
						},
						["SHAMAN"] = {
						},
					},
					["padW"] = 2,
				}, -- [9]
				{
					["showInPetBattleUI"] = false,
					["scale"] = 1,
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["y"] = 146,
					["showstates"] = "",
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["PALADIN"] = {
						},
						["SHAMAN"] = {
						},
					},
					["padW"] = 2,
				}, -- [10]
				["exp"] = {
					["point"] = "BOTTOM",
					["scale"] = 0.67,
					["lockMode"] = true,
					["padW"] = 2,
					["fadeAlpha"] = 0.75,
					["fadeOutDuration"] = 0.10000000149012,
					["spacing"] = 1,
					["fadeInDuration"] = 0.10000000149012,
					["displayLevel"] = 1,
					["texture"] = "Smooth",
					["showInPetBattleUI"] = false,
					["columns"] = 20,
					["numButtons"] = 20,
					["displayLayer"] = "MEDIUM",
					["showInOverrideUI"] = false,
					["padH"] = 2,
					["width"] = 664,
					["fadeOutDelay"] = false,
					["font"] = "默认",
					["display"] = {
						["value"] = true,
						["bonus"] = true,
						["max"] = true,
						["label"] = true,
					},
					["x"] = 11.999899251951,
					["height"] = 8,
					["fadeInDelay"] = false,
					["y"] = 180,
					["alwaysShowText"] = true,
				},
				["bags"] = {
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
					["scale"] = 0.7,
					["spacing"] = 0,
				},
				["mirrorTimer2"] = {
					["showInPetBattleUI"] = false,
					["point"] = "TOP",
					["showInOverrideUI"] = false,
					["w"] = 206,
					["y"] = -226,
					["font"] = "默认",
					["padW"] = 1,
					["anchor"] = "mirrorTimer3TL",
					["display"] = {
						["border"] = true,
						["time"] = false,
						["spark"] = false,
						["label"] = true,
					},
					["padH"] = 1,
					["h"] = 26,
					["texture"] = "Blizzard",
				},
				["alerts"] = {
					["showInPetBattleUI"] = true,
					["point"] = "LEFT",
					["spacing"] = 2,
					["showInOverrideUI"] = true,
					["columns"] = 1,
				},
				["roll"] = {
					["showInPetBattleUI"] = true,
					["point"] = "LEFT",
					["spacing"] = 2,
					["showInOverrideUI"] = true,
					["columns"] = 1,
				},
				["vehicle"] = {
					["showInPetBattleUI"] = false,
					["x"] = 217,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["y"] = 141,
				},
				["mirrorTimer3"] = {
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
					["w"] = 206,
					["y"] = 215,
					["font"] = "默认",
					["display"] = {
						["border"] = true,
						["time"] = false,
						["spark"] = false,
						["label"] = true,
					},
					["padH"] = 1,
					["padW"] = 1,
					["h"] = 26,
					["texture"] = "Blizzard",
				},
				["pet"] = {
					["showInPetBattleUI"] = false,
					["x"] = 12.374954223633,
					["point"] = "BOTTOM",
					["spacing"] = 6,
					["showInOverrideUI"] = false,
					["y"] = 148.49998474121,
				},
				["talk"] = {
					["y"] = -21.499984741211,
					["relPoint"] = "CENTER",
					["point"] = "TOP",
					["x"] = 12.75,
					["showInOverrideUI"] = true,
					["showInPetBattleUI"] = true,
					["displayLayer"] = "LOW",
				},
				["menu"] = {
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOMRIGHT",
					["scale"] = 0.7,
					["showInOverrideUI"] = false,
					["y"] = 37,
					["showstates"] = "鼠标滑过隐藏",
					["clickThrough"] = false,
					["anchor"] = "bagsTR",
					["spacing"] = 0,
				},
				["mirrorTimer1"] = {
					["showInPetBattleUI"] = false,
					["point"] = "TOP",
					["showInOverrideUI"] = false,
					["w"] = 206,
					["y"] = -200,
					["font"] = "默认",
					["padW"] = 1,
					["anchor"] = "mirrorTimer2TC",
					["display"] = {
						["border"] = true,
						["time"] = false,
						["spark"] = false,
						["label"] = true,
					},
					["padH"] = 1,
					["h"] = 26,
					["texture"] = "Blizzard",
				},
				["cast"] = {
					["point"] = "BOTTOM",
					["scale"] = 0.75,
					["padW"] = 1,
					["h"] = 26,
					["fadeOutDuration"] = 0.10000000149012,
					["anchor"] = {
						["relFrame"] = "pet",
						["point"] = "BOTTOM",
						["relPoint"] = "TOP",
					},
					["fadeInDuration"] = 0.10000000149012,
					["displayLevel"] = 1,
					["texture"] = "Solid",
					["showInPetBattleUI"] = true,
					["showInOverrideUI"] = true,
					["w"] = 250,
					["latencyPadding"] = 0,
					["fadeOutDelay"] = false,
					["x"] = 16.49989827474,
					["y"] = 237.99996948242,
					["padH"] = 1,
					["display"] = {
						["time"] = true,
						["spark"] = false,
						["icon"] = true,
						["border"] = false,
						["latency"] = false,
					},
					["fadeInDelay"] = false,
					["displayLayer"] = "MEDIUM",
					["font"] = "Friz Quadrata TT",
				},
				["class"] = {
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOMRIGHT",
					["scale"] = 0.9,
					["showInOverrideUI"] = false,
					["y"] = 142.9333190918,
					["relPoint"] = "BOTTOM",
					["spacing"] = 2,
					["anchor"] = {
						["relFrame"] = "exp",
						["point"] = "BOTTOMLEFT",
						["relPoint"] = "TOPLEFT",
					},
					["x"] = -209.71123777929,
					["displayLevel"] = 1,
					["displayLayer"] = "MEDIUM",
				},
			},
			["showgrid"] = true,
		},
		["战士"] = {
			["showgrid"] = true,
			["frames"] = {
				{
					["point"] = "BOTTOM",
					["scale"] = 0.94,
					["padW"] = 2,
					["showstates"] = "",
					["fadeOutDuration"] = 0.10000000149012,
					["spacing"] = 4,
					["fadeInDuration"] = 0.10000000149012,
					["numButtons"] = 12,
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
					["fadeOutDelay"] = false,
					["x"] = 9,
					["padH"] = 2,
					["fadeInDelay"] = false,
					["y"] = 7,
					["pages"] = {
						["HUNTER"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
						["WARRIOR"] = {
							["berserker"] = 8,
							["page2"] = 1,
							["defensive"] = 7,
							["page5"] = 4,
							["page4"] = 3,
							["battle"] = 6,
							["page3"] = 2,
							["page6"] = 5,
						},
						["WARLOCK"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
						["ROGUE"] = {
							["page2"] = 1,
							["shadowdance"] = 6,
							["page5"] = 4,
							["page4"] = 3,
							["stealth"] = 6,
							["page3"] = 2,
							["page6"] = 5,
						},
						["MAGE"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
						["PALADIN"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
						["SHAMAN"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
					},
				}, -- [1]
				{
					["showInPetBattleUI"] = false,
					["scale"] = 1,
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["fadeAlpha"] = 0,
					["padH"] = 2,
					["spacing"] = 4,
					["anchor"] = "7BC",
					["numButtons"] = 12,
					["pages"] = {
						["HUNTER"] = {
						},
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["PALADIN"] = {
						},
						["SHAMAN"] = {
						},
					},
					["y"] = -14,
				}, -- [2]
				{
					["showInPetBattleUI"] = false,
					["columns"] = 1,
					["scale"] = 0.95,
					["showInOverrideUI"] = false,
					["y"] = -46,
					["padW"] = 2,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["HUNTER"] = {
						},
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["PALADIN"] = {
						},
						["SHAMAN"] = {
						},
					},
					["numButtons"] = 12,
					["point"] = "RIGHT",
				}, -- [3]
				{
					["showInPetBattleUI"] = false,
					["point"] = "RIGHT",
					["scale"] = 0.95,
					["showInOverrideUI"] = false,
					["padH"] = 2,
					["y"] = -45,
					["x"] = -40,
					["pages"] = {
						["HUNTER"] = {
						},
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["PALADIN"] = {
						},
						["SHAMAN"] = {
						},
					},
					["spacing"] = 4,
					["anchor"] = "3LC",
					["padW"] = 2,
					["numButtons"] = 12,
					["columns"] = 1,
				}, -- [4]
				{
					["showInPetBattleUI"] = false,
					["pages"] = {
						["HUNTER"] = {
						},
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["PALADIN"] = {
						},
						["SHAMAN"] = {
						},
					},
					["point"] = "BOTTOM",
					["fadeOutDelay"] = false,
					["scale"] = 0.94,
					["showInOverrideUI"] = false,
					["fadeInDuration"] = 0.10000000149012,
					["padW"] = 2,
					["anchor"] = "1TR",
					["fadeOutDuration"] = 0.10000000149012,
					["spacing"] = 4,
					["padH"] = 2,
					["fadeInDelay"] = false,
					["numButtons"] = 12,
					["y"] = 40,
				}, -- [5]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["scale"] = 0.94,
					["showInOverrideUI"] = false,
					["y"] = 85,
					["x"] = 15,
					["padH"] = 2,
					["spacing"] = 4,
					["anchor"] = "5TR",
					["pages"] = {
						["HUNTER"] = {
						},
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["PALADIN"] = {
						},
						["SHAMAN"] = {
						},
					},
					["numButtons"] = 12,
					["padW"] = 2,
				}, -- [6]
				{
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["y"] = 26,
					["anchor"] = "8BC",
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["HUNTER"] = {
						},
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["PALADIN"] = {
						},
						["SHAMAN"] = {
						},
					},
					["numButtons"] = 12,
					["padW"] = 2,
				}, -- [7]
				{
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["y"] = 66,
					["padH"] = 2,
					["spacing"] = 4,
					["anchor"] = "9BC",
					["pages"] = {
						["HUNTER"] = {
						},
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["PALADIN"] = {
						},
						["SHAMAN"] = {
						},
					},
					["numButtons"] = 12,
					["padW"] = 2,
				}, -- [8]
				{
					["showInPetBattleUI"] = false,
					["scale"] = 1,
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["y"] = 106,
					["padH"] = 2,
					["spacing"] = 4,
					["anchor"] = "10BC",
					["numButtons"] = 12,
					["pages"] = {
						["HUNTER"] = {
						},
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["PALADIN"] = {
						},
						["SHAMAN"] = {
						},
					},
					["padW"] = 2,
				}, -- [9]
				{
					["showInPetBattleUI"] = false,
					["scale"] = 1,
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["y"] = 146,
					["showstates"] = "",
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["HUNTER"] = {
						},
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["PALADIN"] = {
						},
						["SHAMAN"] = {
						},
					},
					["numButtons"] = 12,
					["padW"] = 2,
				}, -- [10]
				["exp"] = {
					["point"] = "BOTTOM",
					["scale"] = 0.67,
					["lockMode"] = true,
					["padW"] = 2,
					["fadeAlpha"] = 0.75,
					["fadeOutDuration"] = 0.10000000149012,
					["spacing"] = 1,
					["fadeInDuration"] = 0.10000000149012,
					["displayLevel"] = 1,
					["texture"] = "Smooth",
					["showInPetBattleUI"] = false,
					["display"] = {
						["value"] = true,
						["bonus"] = true,
						["max"] = true,
						["label"] = true,
					},
					["columns"] = 20,
					["numButtons"] = 20,
					["displayLayer"] = "MEDIUM",
					["showInOverrideUI"] = false,
					["width"] = 664,
					["y"] = 180,
					["font"] = "默认",
					["height"] = 8,
					["x"] = 11.999899251951,
					["padH"] = 2,
					["fadeInDelay"] = false,
					["fadeOutDelay"] = false,
					["alwaysShowText"] = true,
				},
				["bags"] = {
					["showInPetBattleUI"] = false,
					["spacing"] = 0,
					["scale"] = 0.7,
					["showInOverrideUI"] = false,
				},
				["mirrorTimer2"] = {
					["showInPetBattleUI"] = false,
					["point"] = "TOP",
					["showInOverrideUI"] = false,
					["w"] = 206,
					["y"] = -226,
					["h"] = 26,
					["padW"] = 1,
					["display"] = {
						["border"] = true,
						["time"] = false,
						["spark"] = false,
						["label"] = true,
					},
					["anchor"] = "mirrorTimer3TL",
					["padH"] = 1,
					["font"] = "默认",
					["texture"] = "Blizzard",
				},
				["cast"] = {
					["point"] = "BOTTOM",
					["scale"] = 0.75,
					["latencyPadding"] = 0,
					["h"] = 26,
					["fadeOutDuration"] = 0.10000000149012,
					["anchor"] = {
						["relFrame"] = "pet",
						["point"] = "BOTTOM",
						["relPoint"] = "TOP",
					},
					["fadeInDuration"] = 0.10000000149012,
					["displayLevel"] = 1,
					["texture"] = "Solid",
					["showInPetBattleUI"] = true,
					["showInOverrideUI"] = true,
					["w"] = 250,
					["padW"] = 1,
					["fadeOutDelay"] = false,
					["font"] = "Friz Quadrata TT",
					["y"] = 237.99996948242,
					["padH"] = 1,
					["display"] = {
						["time"] = true,
						["spark"] = false,
						["icon"] = true,
						["border"] = false,
						["latency"] = false,
					},
					["fadeInDelay"] = false,
					["displayLayer"] = "MEDIUM",
					["x"] = 16.49989827474,
				},
				["roll"] = {
					["showInPetBattleUI"] = true,
					["point"] = "LEFT",
					["spacing"] = 2,
					["showInOverrideUI"] = true,
					["columns"] = 1,
				},
				["vehicle"] = {
					["showInPetBattleUI"] = false,
					["x"] = 217,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["y"] = 141,
				},
				["mirrorTimer3"] = {
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
					["w"] = 206,
					["padW"] = 1,
					["h"] = 26,
					["display"] = {
						["border"] = true,
						["time"] = false,
						["spark"] = false,
						["label"] = true,
					},
					["padH"] = 1,
					["y"] = 215,
					["font"] = "默认",
					["texture"] = "Blizzard",
				},
				["pet"] = {
					["showInPetBattleUI"] = false,
					["x"] = 12.374954223633,
					["point"] = "BOTTOM",
					["spacing"] = 6,
					["showInOverrideUI"] = false,
					["y"] = 148.49998474121,
				},
				["talk"] = {
					["showInPetBattleUI"] = true,
					["x"] = 12.75,
					["point"] = "TOP",
					["y"] = -21.499984741211,
					["showInOverrideUI"] = true,
					["relPoint"] = "CENTER",
					["displayLayer"] = "LOW",
				},
				["menu"] = {
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOMRIGHT",
					["scale"] = 0.7,
					["showInOverrideUI"] = false,
					["y"] = 37,
					["showstates"] = "鼠标滑过隐藏",
					["clickThrough"] = false,
					["anchor"] = "bagsTR",
					["spacing"] = 0,
				},
				["mirrorTimer1"] = {
					["showInPetBattleUI"] = false,
					["point"] = "TOP",
					["showInOverrideUI"] = false,
					["w"] = 206,
					["y"] = -200,
					["h"] = 26,
					["padW"] = 1,
					["display"] = {
						["border"] = true,
						["time"] = false,
						["spark"] = false,
						["label"] = true,
					},
					["anchor"] = "mirrorTimer2TC",
					["padH"] = 1,
					["font"] = "默认",
					["texture"] = "Blizzard",
				},
				["alerts"] = {
					["showInPetBattleUI"] = true,
					["point"] = "LEFT",
					["spacing"] = 2,
					["showInOverrideUI"] = true,
					["columns"] = 1,
				},
				["class"] = {
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOMRIGHT",
					["scale"] = 0.9,
					["showInOverrideUI"] = false,
					["y"] = 142.9333190918,
					["relPoint"] = "BOTTOM",
					["spacing"] = 2,
					["anchor"] = {
						["relFrame"] = "exp",
						["point"] = "BOTTOMLEFT",
						["relPoint"] = "TOPLEFT",
					},
					["x"] = -209.71123777929,
					["displayLevel"] = 1,
					["displayLayer"] = "MEDIUM",
				},
			},
			["minimap"] = {
				["minimapPos"] = 187.99414914251,
			},
		},
		["法师"] = {
			["minimap"] = {
				["minimapPos"] = 187.99414914251,
			},
			["frames"] = {
				{
					["showInPetBattleUI"] = false,
					["padW"] = 2,
					["point"] = "BOTTOM",
					["numButtons"] = 12,
					["scale"] = 0.94,
					["showInOverrideUI"] = false,
					["fadeInDelay"] = false,
					["x"] = 9,
					["y"] = 7,
					["showstates"] = "",
					["fadeOutDuration"] = 0.10000000149012,
					["spacing"] = 4,
					["padH"] = 2,
					["fadeInDuration"] = 0.10000000149012,
					["pages"] = {
						["WARRIOR"] = {
							["berserker"] = 8,
							["page2"] = 1,
							["defensive"] = 7,
							["page5"] = 4,
							["page4"] = 3,
							["battle"] = 6,
							["page3"] = 2,
							["page6"] = 5,
						},
						["WARLOCK"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
						["ROGUE"] = {
							["page2"] = 1,
							["shadowdance"] = 6,
							["page5"] = 4,
							["page4"] = 3,
							["stealth"] = 6,
							["page3"] = 2,
							["page6"] = 5,
						},
						["MAGE"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
						["PALADIN"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
						["SHAMAN"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
					},
					["fadeOutDelay"] = false,
				}, -- [1]
				{
					["showInPetBattleUI"] = false,
					["scale"] = 1,
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["fadeAlpha"] = 0,
					["anchor"] = "7BC",
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["PALADIN"] = {
						},
						["SHAMAN"] = {
						},
					},
					["y"] = -14,
				}, -- [2]
				{
					["showInPetBattleUI"] = false,
					["point"] = "RIGHT",
					["scale"] = 0.95,
					["showInOverrideUI"] = false,
					["y"] = -46,
					["padW"] = 2,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["PALADIN"] = {
						},
						["SHAMAN"] = {
						},
					},
					["numButtons"] = 12,
					["columns"] = 1,
				}, -- [3]
				{
					["showInPetBattleUI"] = false,
					["columns"] = 1,
					["scale"] = 0.95,
					["showInOverrideUI"] = false,
					["anchor"] = "3LC",
					["y"] = -45,
					["x"] = -40,
					["pages"] = {
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["PALADIN"] = {
						},
						["SHAMAN"] = {
						},
					},
					["spacing"] = 4,
					["padH"] = 2,
					["padW"] = 2,
					["numButtons"] = 12,
					["point"] = "RIGHT",
				}, -- [4]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["fadeOutDelay"] = false,
					["scale"] = 0.94,
					["showInOverrideUI"] = false,
					["pages"] = {
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["PALADIN"] = {
						},
						["SHAMAN"] = {
						},
					},
					["fadeInDuration"] = 0.10000000149012,
					["padW"] = 2,
					["anchor"] = "1TR",
					["fadeOutDuration"] = 0.10000000149012,
					["spacing"] = 4,
					["padH"] = 2,
					["fadeInDelay"] = false,
					["numButtons"] = 12,
					["y"] = 40,
				}, -- [5]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["scale"] = 0.94,
					["showInOverrideUI"] = false,
					["y"] = 85,
					["x"] = 15,
					["anchor"] = "5TR",
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["PALADIN"] = {
						},
						["SHAMAN"] = {
						},
					},
					["numButtons"] = 12,
					["padW"] = 2,
				}, -- [6]
				{
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["padH"] = 2,
					["spacing"] = 4,
					["anchor"] = "8BC",
					["pages"] = {
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["PALADIN"] = {
						},
						["SHAMAN"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 26,
				}, -- [7]
				{
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["anchor"] = "9BC",
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["PALADIN"] = {
						},
						["SHAMAN"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 66,
				}, -- [8]
				{
					["showInPetBattleUI"] = false,
					["scale"] = 1,
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["y"] = 106,
					["anchor"] = "10BC",
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["PALADIN"] = {
						},
						["SHAMAN"] = {
						},
					},
					["padW"] = 2,
				}, -- [9]
				{
					["showInPetBattleUI"] = false,
					["scale"] = 1,
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["y"] = 146,
					["showstates"] = "",
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["PALADIN"] = {
						},
						["SHAMAN"] = {
						},
					},
					["padW"] = 2,
				}, -- [10]
				["exp"] = {
					["point"] = "BOTTOM",
					["scale"] = 0.67,
					["lockMode"] = true,
					["padW"] = 2,
					["fadeAlpha"] = 0.75,
					["fadeOutDuration"] = 0.10000000149012,
					["spacing"] = 1,
					["fadeInDuration"] = 0.10000000149012,
					["displayLevel"] = 1,
					["texture"] = "Smooth",
					["showInPetBattleUI"] = false,
					["columns"] = 20,
					["numButtons"] = 20,
					["displayLayer"] = "MEDIUM",
					["showInOverrideUI"] = false,
					["padH"] = 2,
					["width"] = 664,
					["fadeOutDelay"] = false,
					["font"] = "默认",
					["display"] = {
						["value"] = true,
						["bonus"] = true,
						["max"] = true,
						["label"] = true,
					},
					["x"] = 11.999899251951,
					["height"] = 8,
					["fadeInDelay"] = false,
					["y"] = 180,
					["alwaysShowText"] = true,
				},
				["bags"] = {
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
					["scale"] = 0.7,
					["spacing"] = 0,
				},
				["mirrorTimer2"] = {
					["showInPetBattleUI"] = false,
					["point"] = "TOP",
					["showInOverrideUI"] = false,
					["w"] = 206,
					["y"] = -226,
					["font"] = "默认",
					["padW"] = 1,
					["anchor"] = "mirrorTimer3TL",
					["display"] = {
						["border"] = true,
						["time"] = false,
						["spark"] = false,
						["label"] = true,
					},
					["padH"] = 1,
					["h"] = 26,
					["texture"] = "Blizzard",
				},
				["alerts"] = {
					["showInPetBattleUI"] = true,
					["point"] = "LEFT",
					["spacing"] = 2,
					["showInOverrideUI"] = true,
					["columns"] = 1,
				},
				["roll"] = {
					["showInPetBattleUI"] = true,
					["point"] = "LEFT",
					["spacing"] = 2,
					["showInOverrideUI"] = true,
					["columns"] = 1,
				},
				["vehicle"] = {
					["showInPetBattleUI"] = false,
					["x"] = 217,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["y"] = 141,
				},
				["mirrorTimer3"] = {
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
					["w"] = 206,
					["y"] = 215,
					["font"] = "默认",
					["display"] = {
						["border"] = true,
						["time"] = false,
						["spark"] = false,
						["label"] = true,
					},
					["padH"] = 1,
					["padW"] = 1,
					["h"] = 26,
					["texture"] = "Blizzard",
				},
				["pet"] = {
					["showInPetBattleUI"] = false,
					["x"] = 12.374954223633,
					["point"] = "BOTTOM",
					["spacing"] = 6,
					["showInOverrideUI"] = false,
					["y"] = 148.49998474121,
				},
				["talk"] = {
					["y"] = -21.499984741211,
					["relPoint"] = "CENTER",
					["point"] = "TOP",
					["x"] = 12.75,
					["showInOverrideUI"] = true,
					["showInPetBattleUI"] = true,
					["displayLayer"] = "LOW",
				},
				["menu"] = {
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOMRIGHT",
					["scale"] = 0.7,
					["showInOverrideUI"] = false,
					["y"] = 37,
					["showstates"] = "鼠标滑过隐藏",
					["clickThrough"] = false,
					["anchor"] = "bagsTR",
					["spacing"] = 0,
				},
				["mirrorTimer1"] = {
					["showInPetBattleUI"] = false,
					["point"] = "TOP",
					["showInOverrideUI"] = false,
					["w"] = 206,
					["y"] = -200,
					["font"] = "默认",
					["padW"] = 1,
					["anchor"] = "mirrorTimer2TC",
					["display"] = {
						["border"] = true,
						["time"] = false,
						["spark"] = false,
						["label"] = true,
					},
					["padH"] = 1,
					["h"] = 26,
					["texture"] = "Blizzard",
				},
				["cast"] = {
					["point"] = "BOTTOM",
					["scale"] = 0.75,
					["padW"] = 1,
					["h"] = 26,
					["fadeOutDuration"] = 0.10000000149012,
					["anchor"] = {
						["relFrame"] = "pet",
						["point"] = "BOTTOM",
						["relPoint"] = "TOP",
					},
					["fadeInDuration"] = 0.10000000149012,
					["displayLevel"] = 1,
					["texture"] = "Solid",
					["showInPetBattleUI"] = true,
					["showInOverrideUI"] = true,
					["w"] = 250,
					["latencyPadding"] = 0,
					["fadeOutDelay"] = false,
					["x"] = 16.49989827474,
					["y"] = 237.99996948242,
					["padH"] = 1,
					["display"] = {
						["time"] = true,
						["spark"] = false,
						["icon"] = true,
						["border"] = false,
						["latency"] = false,
					},
					["fadeInDelay"] = false,
					["displayLayer"] = "MEDIUM",
					["font"] = "Friz Quadrata TT",
				},
				["class"] = {
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOMRIGHT",
					["scale"] = 0.9,
					["showInOverrideUI"] = false,
					["y"] = 142.9333190918,
					["relPoint"] = "BOTTOM",
					["spacing"] = 2,
					["anchor"] = {
						["relFrame"] = "exp",
						["point"] = "BOTTOMLEFT",
						["relPoint"] = "TOPLEFT",
					},
					["x"] = -209.71123777929,
					["displayLevel"] = 1,
					["displayLayer"] = "MEDIUM",
				},
			},
			["showgrid"] = true,
		},
		["圣骑士"] = {
			["minimap"] = {
				["minimapPos"] = 187.99414914251,
			},
			["frames"] = {
				{
					["showInPetBattleUI"] = false,
					["padW"] = 2,
					["point"] = "BOTTOM",
					["numButtons"] = 12,
					["scale"] = 0.94,
					["showInOverrideUI"] = false,
					["fadeInDelay"] = false,
					["x"] = 9,
					["y"] = 7,
					["showstates"] = "",
					["fadeOutDuration"] = 0.10000000149012,
					["spacing"] = 4,
					["padH"] = 2,
					["fadeInDuration"] = 0.10000000149012,
					["pages"] = {
						["WARRIOR"] = {
							["page4"] = 3,
							["page2"] = 1,
							["page3"] = 2,
							["page5"] = 4,
							["berserker"] = 8,
							["battle"] = 6,
							["defensive"] = 7,
							["page6"] = 5,
						},
						["WARLOCK"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
						["ROGUE"] = {
							["shadowdance"] = 6,
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["stealth"] = 6,
							["page3"] = 2,
							["page6"] = 5,
						},
						["MAGE"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
						["SHAMAN"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
						["PALADIN"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
					},
					["fadeOutDelay"] = false,
				}, -- [1]
				{
					["showInPetBattleUI"] = false,
					["scale"] = 1,
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["fadeAlpha"] = 0,
					["y"] = -14,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["SHAMAN"] = {
						},
						["PALADIN"] = {
						},
					},
					["numButtons"] = 12,
					["anchor"] = "7BC",
				}, -- [2]
				{
					["showInPetBattleUI"] = false,
					["point"] = "RIGHT",
					["scale"] = 0.95,
					["showInOverrideUI"] = false,
					["y"] = -46,
					["columns"] = 1,
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["SHAMAN"] = {
						},
						["PALADIN"] = {
						},
					},
					["padW"] = 2,
				}, -- [3]
				{
					["showInPetBattleUI"] = false,
					["columns"] = 1,
					["scale"] = 0.95,
					["showInOverrideUI"] = false,
					["point"] = "RIGHT",
					["y"] = -45,
					["x"] = -40,
					["numButtons"] = 12,
					["spacing"] = 4,
					["padH"] = 2,
					["padW"] = 2,
					["pages"] = {
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["SHAMAN"] = {
						},
						["PALADIN"] = {
						},
					},
					["anchor"] = "3LC",
				}, -- [4]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["y"] = 40,
					["scale"] = 0.94,
					["showInOverrideUI"] = false,
					["numButtons"] = 12,
					["fadeInDelay"] = false,
					["padW"] = 2,
					["padH"] = 2,
					["fadeOutDuration"] = 0.10000000149012,
					["spacing"] = 4,
					["anchor"] = "1TR",
					["fadeInDuration"] = 0.10000000149012,
					["pages"] = {
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["SHAMAN"] = {
						},
						["PALADIN"] = {
						},
					},
					["fadeOutDelay"] = false,
				}, -- [5]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["scale"] = 0.94,
					["showInOverrideUI"] = false,
					["y"] = 85,
					["x"] = 15,
					["padW"] = 2,
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["SHAMAN"] = {
						},
						["PALADIN"] = {
						},
					},
					["anchor"] = "5TR",
				}, -- [6]
				{
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["y"] = 26,
					["spacing"] = 4,
					["anchor"] = "8BC",
					["numButtons"] = 12,
					["pages"] = {
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["SHAMAN"] = {
						},
						["PALADIN"] = {
						},
					},
					["padH"] = 2,
				}, -- [7]
				{
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["y"] = 66,
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["SHAMAN"] = {
						},
						["PALADIN"] = {
						},
					},
					["anchor"] = "9BC",
				}, -- [8]
				{
					["showInPetBattleUI"] = false,
					["scale"] = 1,
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["y"] = 106,
					["padW"] = 2,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["SHAMAN"] = {
						},
						["PALADIN"] = {
						},
					},
					["numButtons"] = 12,
					["anchor"] = "10BC",
				}, -- [9]
				{
					["showInPetBattleUI"] = false,
					["scale"] = 1,
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["y"] = 146,
					["showstates"] = "",
					["spacing"] = 4,
					["padH"] = 2,
					["padW"] = 2,
					["pages"] = {
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["SHAMAN"] = {
						},
						["PALADIN"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [10]
				["exp"] = {
					["point"] = "BOTTOM",
					["scale"] = 0.67,
					["lockMode"] = true,
					["padW"] = 2,
					["fadeAlpha"] = 0.75,
					["fadeOutDuration"] = 0.10000000149012,
					["spacing"] = 1,
					["fadeInDuration"] = 0.10000000149012,
					["displayLevel"] = 1,
					["texture"] = "Smooth",
					["showInPetBattleUI"] = false,
					["columns"] = 20,
					["alwaysShowText"] = true,
					["fadeOutDelay"] = false,
					["showInOverrideUI"] = false,
					["height"] = 8,
					["width"] = 664,
					["y"] = 180,
					["font"] = "默认",
					["padH"] = 2,
					["x"] = 11.999899251951,
					["display"] = {
						["value"] = true,
						["label"] = true,
						["max"] = true,
						["bonus"] = true,
					},
					["fadeInDelay"] = false,
					["displayLayer"] = "MEDIUM",
					["numButtons"] = 20,
				},
				["bags"] = {
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
					["scale"] = 0.7,
					["spacing"] = 0,
				},
				["mirrorTimer2"] = {
					["showInPetBattleUI"] = false,
					["point"] = "TOP",
					["showInOverrideUI"] = false,
					["w"] = 206,
					["y"] = -226,
					["font"] = "默认",
					["padW"] = 1,
					["h"] = 26,
					["display"] = {
						["border"] = true,
						["spark"] = false,
						["time"] = false,
						["label"] = true,
					},
					["padH"] = 1,
					["anchor"] = "mirrorTimer3TL",
					["texture"] = "Blizzard",
				},
				["cast"] = {
					["point"] = "BOTTOM",
					["scale"] = 0.75,
					["latencyPadding"] = 0,
					["h"] = 26,
					["fadeOutDuration"] = 0.10000000149012,
					["anchor"] = {
						["relFrame"] = "pet",
						["point"] = "BOTTOM",
						["relPoint"] = "TOP",
					},
					["fadeInDuration"] = 0.10000000149012,
					["displayLevel"] = 1,
					["texture"] = "Solid",
					["showInPetBattleUI"] = true,
					["showInOverrideUI"] = true,
					["w"] = 250,
					["x"] = 16.49989827474,
					["fadeOutDelay"] = false,
					["font"] = "Friz Quadrata TT",
					["displayLayer"] = "MEDIUM",
					["display"] = {
						["time"] = true,
						["spark"] = false,
						["border"] = false,
						["icon"] = true,
						["latency"] = false,
					},
					["padH"] = 1,
					["fadeInDelay"] = false,
					["y"] = 237.99996948242,
					["padW"] = 1,
				},
				["roll"] = {
					["showInPetBattleUI"] = true,
					["point"] = "LEFT",
					["spacing"] = 2,
					["showInOverrideUI"] = true,
					["columns"] = 1,
				},
				["vehicle"] = {
					["showInPetBattleUI"] = false,
					["x"] = 217,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["y"] = 141,
				},
				["mirrorTimer3"] = {
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
					["w"] = 206,
					["padW"] = 1,
					["font"] = "默认",
					["padH"] = 1,
					["display"] = {
						["border"] = true,
						["spark"] = false,
						["time"] = false,
						["label"] = true,
					},
					["h"] = 26,
					["y"] = 215,
					["texture"] = "Blizzard",
				},
				["pet"] = {
					["showInPetBattleUI"] = false,
					["x"] = 12.374954223633,
					["point"] = "BOTTOM",
					["spacing"] = 6,
					["showInOverrideUI"] = false,
					["y"] = 148.49998474121,
				},
				["talk"] = {
					["showInPetBattleUI"] = true,
					["relPoint"] = "CENTER",
					["point"] = "TOP",
					["y"] = -21.499984741211,
					["showInOverrideUI"] = true,
					["x"] = 12.75,
					["displayLayer"] = "LOW",
				},
				["menu"] = {
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOMRIGHT",
					["scale"] = 0.7,
					["showInOverrideUI"] = false,
					["y"] = 37,
					["showstates"] = "鼠标滑过隐藏",
					["clickThrough"] = false,
					["anchor"] = "bagsTR",
					["spacing"] = 0,
				},
				["mirrorTimer1"] = {
					["showInPetBattleUI"] = false,
					["point"] = "TOP",
					["showInOverrideUI"] = false,
					["w"] = 206,
					["y"] = -200,
					["font"] = "默认",
					["padW"] = 1,
					["h"] = 26,
					["display"] = {
						["border"] = true,
						["spark"] = false,
						["time"] = false,
						["label"] = true,
					},
					["padH"] = 1,
					["anchor"] = "mirrorTimer2TC",
					["texture"] = "Blizzard",
				},
				["alerts"] = {
					["showInPetBattleUI"] = true,
					["point"] = "LEFT",
					["spacing"] = 2,
					["showInOverrideUI"] = true,
					["columns"] = 1,
				},
				["class"] = {
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOMRIGHT",
					["scale"] = 0.9,
					["showInOverrideUI"] = false,
					["y"] = 142.9333190918,
					["relPoint"] = "BOTTOM",
					["spacing"] = 2,
					["anchor"] = {
						["relFrame"] = "exp",
						["point"] = "BOTTOMLEFT",
						["relPoint"] = "TOPLEFT",
					},
					["x"] = -209.71123777929,
					["displayLevel"] = 1,
					["displayLayer"] = "MEDIUM",
				},
			},
			["showgrid"] = true,
		},
		["牧师"] = {
			["minimap"] = {
				["minimapPos"] = 187.99414914251,
			},
			["frames"] = {
				{
					["showInPetBattleUI"] = false,
					["padW"] = 2,
					["point"] = "BOTTOM",
					["numButtons"] = 12,
					["scale"] = 0.94,
					["showInOverrideUI"] = false,
					["fadeInDelay"] = false,
					["x"] = 9,
					["y"] = 7,
					["showstates"] = "",
					["fadeOutDuration"] = 0.10000000149012,
					["spacing"] = 4,
					["padH"] = 2,
					["fadeInDuration"] = 0.10000000149012,
					["pages"] = {
						["WARRIOR"] = {
							["page4"] = 3,
							["page2"] = 1,
							["page3"] = 2,
							["page5"] = 4,
							["berserker"] = 8,
							["battle"] = 6,
							["defensive"] = 7,
							["page6"] = 5,
						},
						["WARLOCK"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
						["ROGUE"] = {
							["shadowdance"] = 6,
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["stealth"] = 6,
							["page3"] = 2,
							["page6"] = 5,
						},
						["MAGE"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
						["SHAMAN"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
						["PALADIN"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
					},
					["fadeOutDelay"] = false,
				}, -- [1]
				{
					["showInPetBattleUI"] = false,
					["scale"] = 1,
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["fadeAlpha"] = 0,
					["y"] = -14,
					["spacing"] = 4,
					["anchor"] = "7BC",
					["pages"] = {
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["SHAMAN"] = {
						},
						["PALADIN"] = {
						},
					},
					["numButtons"] = 12,
					["padH"] = 2,
				}, -- [2]
				{
					["showInPetBattleUI"] = false,
					["columns"] = 1,
					["scale"] = 0.95,
					["showInOverrideUI"] = false,
					["y"] = -46,
					["point"] = "RIGHT",
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["SHAMAN"] = {
						},
						["PALADIN"] = {
						},
					},
					["padW"] = 2,
				}, -- [3]
				{
					["showInPetBattleUI"] = false,
					["point"] = "RIGHT",
					["scale"] = 0.95,
					["showInOverrideUI"] = false,
					["columns"] = 1,
					["y"] = -45,
					["x"] = -40,
					["numButtons"] = 12,
					["spacing"] = 4,
					["anchor"] = "3LC",
					["padW"] = 2,
					["pages"] = {
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["SHAMAN"] = {
						},
						["PALADIN"] = {
						},
					},
					["padH"] = 2,
				}, -- [4]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["y"] = 40,
					["scale"] = 0.94,
					["showInOverrideUI"] = false,
					["numButtons"] = 12,
					["fadeInDelay"] = false,
					["padW"] = 2,
					["padH"] = 2,
					["fadeOutDuration"] = 0.10000000149012,
					["spacing"] = 4,
					["anchor"] = "1TR",
					["fadeInDuration"] = 0.10000000149012,
					["pages"] = {
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["SHAMAN"] = {
						},
						["PALADIN"] = {
						},
					},
					["fadeOutDelay"] = false,
				}, -- [5]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["scale"] = 0.94,
					["showInOverrideUI"] = false,
					["y"] = 85,
					["x"] = 15,
					["padW"] = 2,
					["spacing"] = 4,
					["anchor"] = "5TR",
					["numButtons"] = 12,
					["pages"] = {
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["SHAMAN"] = {
						},
						["PALADIN"] = {
						},
					},
					["padH"] = 2,
				}, -- [6]
				{
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["y"] = 26,
					["padW"] = 2,
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["SHAMAN"] = {
						},
						["PALADIN"] = {
						},
					},
					["anchor"] = "8BC",
				}, -- [7]
				{
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["y"] = 66,
					["padW"] = 2,
					["spacing"] = 4,
					["anchor"] = "9BC",
					["numButtons"] = 12,
					["pages"] = {
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["SHAMAN"] = {
						},
						["PALADIN"] = {
						},
					},
					["padH"] = 2,
				}, -- [8]
				{
					["showInPetBattleUI"] = false,
					["scale"] = 1,
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["y"] = 106,
					["padW"] = 2,
					["spacing"] = 4,
					["anchor"] = "10BC",
					["pages"] = {
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["SHAMAN"] = {
						},
						["PALADIN"] = {
						},
					},
					["numButtons"] = 12,
					["padH"] = 2,
				}, -- [9]
				{
					["showInPetBattleUI"] = false,
					["scale"] = 1,
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["y"] = 146,
					["showstates"] = "",
					["spacing"] = 4,
					["padH"] = 2,
					["padW"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["WARRIOR"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["SHAMAN"] = {
						},
						["PALADIN"] = {
						},
					},
				}, -- [10]
				["exp"] = {
					["point"] = "BOTTOM",
					["scale"] = 0.67,
					["lockMode"] = true,
					["padW"] = 2,
					["fadeAlpha"] = 0.75,
					["fadeOutDuration"] = 0.10000000149012,
					["spacing"] = 1,
					["fadeInDuration"] = 0.10000000149012,
					["displayLevel"] = 1,
					["texture"] = "Smooth",
					["showInPetBattleUI"] = false,
					["columns"] = 20,
					["alwaysShowText"] = true,
					["y"] = 180,
					["showInOverrideUI"] = false,
					["display"] = {
						["value"] = true,
						["label"] = true,
						["max"] = true,
						["bonus"] = true,
					},
					["width"] = 664,
					["fadeOutDelay"] = false,
					["font"] = "默认",
					["height"] = 8,
					["x"] = 11.999899251951,
					["padH"] = 2,
					["fadeInDelay"] = false,
					["displayLayer"] = "MEDIUM",
					["numButtons"] = 20,
				},
				["bags"] = {
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
					["scale"] = 0.7,
					["spacing"] = 0,
				},
				["mirrorTimer2"] = {
					["showInPetBattleUI"] = false,
					["point"] = "TOP",
					["showInOverrideUI"] = false,
					["w"] = 206,
					["y"] = -226,
					["h"] = 26,
					["padW"] = 1,
					["font"] = "默认",
					["anchor"] = "mirrorTimer3TL",
					["padH"] = 1,
					["display"] = {
						["border"] = true,
						["spark"] = false,
						["time"] = false,
						["label"] = true,
					},
					["texture"] = "Blizzard",
				},
				["cast"] = {
					["point"] = "BOTTOM",
					["scale"] = 0.75,
					["padW"] = 1,
					["h"] = 26,
					["fadeOutDuration"] = 0.10000000149012,
					["anchor"] = {
						["relFrame"] = "pet",
						["point"] = "BOTTOM",
						["relPoint"] = "TOP",
					},
					["fadeInDuration"] = 0.10000000149012,
					["displayLevel"] = 1,
					["texture"] = "Solid",
					["showInPetBattleUI"] = true,
					["showInOverrideUI"] = true,
					["w"] = 250,
					["font"] = "Friz Quadrata TT",
					["fadeOutDelay"] = false,
					["x"] = 16.49989827474,
					["displayLayer"] = "MEDIUM",
					["display"] = {
						["time"] = true,
						["spark"] = false,
						["border"] = false,
						["icon"] = true,
						["latency"] = false,
					},
					["padH"] = 1,
					["fadeInDelay"] = false,
					["y"] = 237.99996948242,
					["latencyPadding"] = 0,
				},
				["roll"] = {
					["showInPetBattleUI"] = true,
					["point"] = "LEFT",
					["spacing"] = 2,
					["showInOverrideUI"] = true,
					["columns"] = 1,
				},
				["vehicle"] = {
					["showInPetBattleUI"] = false,
					["x"] = 217,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["y"] = 141,
				},
				["mirrorTimer3"] = {
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
					["w"] = 206,
					["y"] = 215,
					["h"] = 26,
					["padH"] = 1,
					["display"] = {
						["border"] = true,
						["spark"] = false,
						["time"] = false,
						["label"] = true,
					},
					["font"] = "默认",
					["padW"] = 1,
					["texture"] = "Blizzard",
				},
				["pet"] = {
					["showInPetBattleUI"] = false,
					["x"] = 12.374954223633,
					["point"] = "BOTTOM",
					["spacing"] = 6,
					["showInOverrideUI"] = false,
					["y"] = 148.49998474121,
				},
				["talk"] = {
					["y"] = -21.499984741211,
					["x"] = 12.75,
					["point"] = "TOP",
					["showInPetBattleUI"] = true,
					["showInOverrideUI"] = true,
					["relPoint"] = "CENTER",
					["displayLayer"] = "LOW",
				},
				["menu"] = {
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOMRIGHT",
					["scale"] = 0.7,
					["showInOverrideUI"] = false,
					["y"] = 37,
					["showstates"] = "鼠标滑过隐藏",
					["clickThrough"] = false,
					["anchor"] = "bagsTR",
					["spacing"] = 0,
				},
				["mirrorTimer1"] = {
					["showInPetBattleUI"] = false,
					["point"] = "TOP",
					["showInOverrideUI"] = false,
					["w"] = 206,
					["y"] = -200,
					["h"] = 26,
					["padW"] = 1,
					["font"] = "默认",
					["anchor"] = "mirrorTimer2TC",
					["padH"] = 1,
					["display"] = {
						["border"] = true,
						["spark"] = false,
						["time"] = false,
						["label"] = true,
					},
					["texture"] = "Blizzard",
				},
				["alerts"] = {
					["showInPetBattleUI"] = true,
					["point"] = "LEFT",
					["spacing"] = 2,
					["showInOverrideUI"] = true,
					["columns"] = 1,
				},
				["class"] = {
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOMRIGHT",
					["scale"] = 0.9,
					["showInOverrideUI"] = false,
					["y"] = 142.9333190918,
					["relPoint"] = "BOTTOM",
					["spacing"] = 2,
					["anchor"] = {
						["relFrame"] = "exp",
						["point"] = "BOTTOMLEFT",
						["relPoint"] = "TOPLEFT",
					},
					["x"] = -209.71123777929,
					["displayLevel"] = 1,
					["displayLayer"] = "MEDIUM",
				},
			},
			["showgrid"] = true,
		},
	},
}
