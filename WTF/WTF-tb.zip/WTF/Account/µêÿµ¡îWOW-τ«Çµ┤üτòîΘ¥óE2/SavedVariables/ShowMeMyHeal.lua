
ShowMeMyHealDB = {
	["profileKeys"] = {
		["大哥别开火 - 阿什坎迪"] = "Default",
		["动能甫杜 - 阿什坎迪"] = "Default",
		["今晚就动手 - 阿什坎迪"] = "Default",
		["交作业 - 阿什坎迪"] = "Default",
		["吸你的血 - 阿什坎迪"] = "Default",
		["你说怎么办 - 阿什坎迪"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["fontSizeNormalHeal"] = 28,
			["fontSizeCriticalHeal"] = 27,
			["offsetY"] = 287,
		},
	},
}
