
BigWigsClassicDB = nil
BigWigsIconClassicDB = {
}
BigWigsStatsClassicDB = nil
BigWigs3DB = nil
BigWigsIconDB = nil
BigWigsStatsDB = nil
