
ClassicAuraDurationsDB = {
}
