
AdvancedInterfaceOptionsSaved = {
	["CustomVars"] = {
	},
	["DBVersion"] = 3,
	["ModifiedCVars"] = {
		["nameplateminscale"] = "Interface\\AddOns\\NeatPlates\\NeatPlatesPanel.lua:1159",
		["chatstyle"] = "Interface\\FrameXML\\InterfaceOptionsPanels.lua:830",
		["nameplateshowenemies"] = "Interface\\AddOns\\NeatPlates\\NeatPlatesPanel.lua:1159",
		["activecufprofile"] = "...rd_CUFProfiles\\Blizzard_CompactUnitFrameProfiles.lua:17",
		["sound_mastervolume"] = "Interface\\FrameXML\\OptionsPanelTemplates.lua:423",
		["camerapitchmovespeed"] = "Interface\\FrameXML\\OptionsPanelTemplates.lua:423",
		["sound_ambiencevolume"] = "Interface\\FrameXML\\OptionsPanelTemplates.lua:423",
		["cameradistancemaxzoomfactor"] = "Interface\\FrameXML\\OptionsPanelTemplates.lua:423",
		["removechatdelay"] = "Interface\\AddOns\\PhanxChat\\Options.lua:52",
		["raidgraphicsgroundclutter"] = "Interface\\SharedXML\\VideoOptionsPanels.lua:285",
		["chatclasscoloroverride"] = "Interface\\AddOns\\alaChat_Classic\\chat.lua:151",
		["raidgraphicsenvironmentdetail"] = "Interface\\SharedXML\\VideoOptionsPanels.lua:285",
		["actionbuttonusekeydown"] = "...face\\AddOns\\AbyssUIClassic\\AbyssUIClassic_Config.lua:1227",
		["mousespeed"] = "Interface\\FrameXML\\OptionsPanelTemplates.lua:423",
		["camerayawsmoothspeed"] = "Interface\\FrameXML\\OptionsPanelTemplates.lua:423",
		["nameplatemaxdistance"] = "...ns\\AbyssUIClassic\\AbyssUIClassic_FunctionsExtras.lua:200",
		["camerayawmovespeed"] = "Interface\\FrameXML\\OptionsPanelTemplates.lua:423",
		["nameplateshowall"] = "Interface\\AddOns\\NeatPlates\\NeatPlatesPanel.lua:1159",
		["graphicsgroundclutter"] = "Interface\\SharedXML\\VideoOptionsPanels.lua:285",
		["graphicsenvironmentdetail"] = "Interface\\SharedXML\\VideoOptionsPanels.lua:285",
		["sound_musicvolume"] = "Interface\\FrameXML\\OptionsPanelTemplates.lua:423",
		["enablefloatingcombattext"] = "Interface\\SharedXML\\CvarUtil.lua:9",
	},
	["CharVars"] = {
	},
	["AccountVars"] = {
	},
	["EnforceSettings"] = false,
}
