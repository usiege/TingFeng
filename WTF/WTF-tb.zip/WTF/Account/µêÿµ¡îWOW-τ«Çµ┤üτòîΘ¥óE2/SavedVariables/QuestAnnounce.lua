
QuestAnnounceDB = {
	["profileKeys"] = {
		["猎猎思密达 - 阿什坎迪"] = "Default",
		["简洁界面 - 阿什坎迪"] = "Default",
		["简洁界面二 - 阿什坎迪"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["profile"] = {
				["announceTo"] = {
					["raidWarningFrame"] = false,
					["chatFrame"] = true,
					["uiErrorsFrame"] = false,
				},
				["settings"] = {
					["enable"] = true,
					["every"] = 1,
					["debug"] = false,
					["sound"] = false,
				},
				["announceIn"] = {
					["party"] = true,
					["guild"] = false,
					["say"] = false,
					["whisper"] = false,
					["officer"] = false,
				},
			},
		},
	},
}
