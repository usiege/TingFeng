
BFTT_Config = {
	["GuildRank"] = 2,
	["Actor"] = 2,
	["ItemLevel"] = 1,
	["Talent"] = 1,
	["TOT"] = 1,
	["Fade"] = 1,
	["PositionY"] = -25,
	["PositionX"] = -20,
	["Anchor"] = 1,
	["TooltipType"] = 1,
}
