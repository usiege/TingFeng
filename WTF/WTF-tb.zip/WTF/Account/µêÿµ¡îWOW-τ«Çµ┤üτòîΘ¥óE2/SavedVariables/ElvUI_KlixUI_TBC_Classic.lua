
KUIDataDB = {
	["Version"] = "0.03",
}
AddonPanelProfilesDB = {
}
AddonPanelServerDB = {
	["阿什坎迪"] = {
		["暗黑界面"] = true,
	},
}
