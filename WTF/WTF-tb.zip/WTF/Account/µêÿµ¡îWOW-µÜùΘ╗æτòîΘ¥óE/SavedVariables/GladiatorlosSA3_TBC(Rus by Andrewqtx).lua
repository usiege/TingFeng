
GladiatorlosSADB = {
	["profileKeys"] = {
		["简洁界面 - 阿什坎迪"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
		},
	},
}
