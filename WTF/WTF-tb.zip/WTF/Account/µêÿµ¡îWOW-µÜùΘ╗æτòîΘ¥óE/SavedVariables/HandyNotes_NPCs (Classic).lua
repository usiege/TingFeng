
HandyNotes_NPCsClassicDB = {
	["namespaces"] = {
		["AltRecipes"] = {
			["realm"] = {
				["阿什坎迪"] = {
					["今晚就动手"] = {
						["professions"] = {
							["Fishing"] = 2,
							["Mining"] = 1,
						},
					},
				},
			},
		},
	},
	["profileKeys"] = {
		["简洁界面二 - 阿什坎迪"] = "Default",
		["简洁界面 - 阿什坎迪"] = "Default",
		["今晚就动手 - 阿什坎迪"] = "Default",
		["撒慢慢 - 阿什坎迪"] = "Default",
		["大哥别开火 - 阿什坎迪"] = "Default",
		["暗黑界面 - 阿什坎迪"] = "Default",
		["交作业 - 阿什坎迪"] = "Default",
		["猎猎思密达 - 阿什坎迪"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
		},
	},
}
