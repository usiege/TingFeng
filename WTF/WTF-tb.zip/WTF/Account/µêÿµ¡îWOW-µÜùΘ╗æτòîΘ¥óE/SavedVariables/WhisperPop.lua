
WhisperPopDB = {
	["version"] = 4.12,
	["listHeight"] = 320,
	["keepDatas"] = {
	},
	["sound"] = 1,
	["time"] = 1,
	["listWidth"] = 200,
	["keep"] = 1,
	["help"] = 1,
	["buttonScale"] = 100,
	["history"] = {
	},
	["listScale"] = 100,
	["applyFilters"] = 1,
	["foreignOnly"] = 1,
	["ignoreTags"] = 1,
	["notifyButton"] = 1,
	["save"] = 1,
}
