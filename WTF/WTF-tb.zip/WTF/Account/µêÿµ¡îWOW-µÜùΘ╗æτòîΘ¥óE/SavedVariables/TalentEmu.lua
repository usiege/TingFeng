
TalentEmuSV = {
	["__upgraded"] = true,
	["set"] = {
		["credible"] = false,
		["supreme"] = false,
		["talents_in_tip"] = false,
		["minimapPos"] = 185,
	},
	["_version"] = 210524,
	["var"] = {
		["Player-4792-025EAE5E"] = "940",
		["Player-4792-03A26BE8"] = "210",
		["savedTalent"] = {
		},
	},
}
