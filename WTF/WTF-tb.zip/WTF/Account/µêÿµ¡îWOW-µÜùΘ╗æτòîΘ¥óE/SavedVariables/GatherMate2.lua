
GatherMate2DB = {
	["global"] = {
		["data_version"] = 5,
	},
	["profileKeys"] = {
		["简洁界面二 - 阿什坎迪"] = "Default",
		["简洁界面 - 阿什坎迪"] = "Default",
		["今晚就动手 - 阿什坎迪"] = "Default",
		["撒慢慢 - 阿什坎迪"] = "Default",
		["大哥别开火 - 阿什坎迪"] = "Default",
		["暗黑界面 - 阿什坎迪"] = "Default",
		["交作业 - 阿什坎迪"] = "Default",
		["猎猎思密达 - 阿什坎迪"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
		},
	},
}
GatherMate2HerbDB = {
}
GatherMate2MineDB = {
}
GatherMate2FishDB = {
}
GatherMate2GasDB = {
}
GatherMate2TreasureDB = {
}
