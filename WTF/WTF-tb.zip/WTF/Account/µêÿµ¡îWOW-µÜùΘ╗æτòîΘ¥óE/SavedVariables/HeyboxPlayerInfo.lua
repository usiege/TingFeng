
HEYBOX_SAVED_PLAYER_INFOS = {
	["简洁界面二-阿什坎迪"] = {
		["class"] = "DRUID",
	},
	["暗黑界面-阿什坎迪"] = {
		["class"] = "WARRIOR",
	},
	["简洁界面-阿什坎迪"] = {
		["class"] = "WARRIOR",
	},
}
