
__DEJUNK_SAVED_VARIABLES__ = {
	["DDBL_Version"] = "2.0.2",
	["Global"] = {
		["version"] = 1,
	},
	["Profiles"] = {
		["简洁界面二-阿什坎迪"] = {
			["version"] = 3,
		},
		["猎猎思密达-阿什坎迪"] = {
			["version"] = 3,
		},
		["暗黑界面-阿什坎迪"] = {
			["sell"] = {
				["auto"] = true,
				["autoOpen"] = true,
			},
			["version"] = 3,
			["general"] = {
				["autoRepair"] = true,
			},
		},
		["简洁界面-阿什坎迪"] = {
			["version"] = 3,
		},
	},
}
DEJUNK_ADDON_SV = nil
