
alaChatSV = {
	["misc"] = {
		["ArrowKey"] = false,
		["ChatHyperlink"] = true,
		["FontFlag"] = "none",
		["ArrowHistory"] = false,
		["Font"] = "Fonts\\ARHei.ttf",
		["StickyChannel"] = true,
		["ColoredPlayerName"] = true,
		["HoverHyperlink"] = true,
		["StickyBNWhisper"] = true,
		["ChatFrameToBorder"] = true,
		["StickyWhisper"] = true,
		["TabChangeChatType"] = false,
	},
	["general"] = {
		["detailedtip"] = true,
	},
	["companion"] = {
		["PlayerLinkFormat"] = "#INDEX.##NAME##:LEVEL#",
		["NewMemberNoticeStr"] = "** 新公会成员：Lv#LEVEL# #CLASS# #NAME# **",
		["WelToGuildDelay"] = true,
		["NewMemberNotice"] = false,
		["ShowSubGroup"] = true,
		["WelToGuildStrSet"] = "欢迎 #NAME# ！",
		["WelToGuild"] = false,
		["ShowLevel"] = true,
	},
	["chatfilter"] = {
		["_TemporaryDisabled"] = false,
		["NameSet"] = "#加基森\n#冬泉谷\n#玛拉顿\n#斯坦索姆\n#航空\n#航班\n#飞机\n#专机\n#直达\n#直飞\n",
		["Rep"] = true,
		["StrSet"] = "HclubTicket:\n航空\n航班\n专机\n直达\n直飞\n安全便捷\n收米\n出米\n托管\n公众号\n大米\n",
		["PinStyle"] = "char",
		["RepeatedSentence"] = true,
		["toggle"] = false,
		["ButtonInDock"] = true,
		["RepInterval"] = 30,
		["CaseInsensitive"] = true,
	},
	["emote"] = {
		["toggle"] = true,
		["PinStyle"] = "char",
		["IconInEditBox"] = false,
	},
	["__version"] = 210726.01,
	["copy"] = {
		["toggle"] = true,
		["format"] = "none",
		["color"] = {
			1, -- [1]
			0.5, -- [2]
			0, -- [3]
		},
	},
	["docker"] = {
		["BackdropColor"] = {
			0, -- [1]
			0, -- [2]
			0, -- [3]
			0, -- [4]
		},
		["Direction"] = "RIGHT",
		["PinInt"] = 2,
		["XToBorder"] = 0,
		["PinStyle"] = "char",
		["_manualPosition"] = {
			"BOTTOMLEFT", -- [1]
			nil, -- [2]
			"BOTTOMLEFT", -- [3]
			29.28157806396484, -- [4]
			0.9657731652259827, -- [5]
		},
		["PinSize"] = 18,
		["FadedAlpha"] = 0.5,
		["BackdropAlpha"] = 0.25,
		["FadeOutTime"] = 2,
		["Backdrop"] = true,
		["FadeOutDelay"] = 1,
		["AutoAdjustEditBox"] = false,
		["FadInTime"] = 0.5,
		["Position"] = "manual",
		["YToBorder"] = 0,
		["alpha"] = 0.9,
	},
	["utils"] = {
		["DBMPull"] = true,
		["roll"] = true,
		["ReadyCheck"] = true,
		["StatReport"] = true,
		["DBMPullLen"] = 6,
	},
	["highlight"] = {
		["_TemporaryDisabled"] = false,
		["color"] = {
			0, -- [1]
			1, -- [2]
			0, -- [3]
			0, -- [4]
		},
		["ButtonInDock"] = true,
		["ShowMatchedOnly.SAY-YELL"] = true,
		["StrSet"] = "",
		["ShowMatchedOnly.NORMAL"] = false,
		["PinStyle"] = "char",
		["KeepShowMatchedOnly"] = false,
		["ShowMatchedOnly"] = false,
		["toggle"] = false,
		["format"] = "#HL#",
		["ShowMatchedOnly.CHANNEL"] = true,
		["CaseInsensitive"] = true,
	},
	["shortchattype"] = {
		["toggle"] = true,
		["format"] = "n.w",
	},
	["__upgraded"] = true,
	["channeltab"] = {
		["ChannelBlockButton_Size"] = 20,
		["INSTANCE_CHAT"] = false,
		["ChannelBlockButton_World"] = false,
		["OFFICER"] = false,
		["PARTY"] = true,
		["TRADE"] = true,
		["PinStyle"] = "char",
		["LeaveChannelModifier"] = "none",
		["toggle"] = true,
		["AutoJoinWorld"] = true,
		["WHISPER"] = true,
		["GENERAL"] = true,
		["SAY"] = true,
		["YELL"] = true,
		["GUILD"] = true,
		["AutoAddChannelToDefaultChatFrame"] = false,
		["UseColor"] = true,
		["ChannelBlockButton_BLZ"] = false,
		["LOOK_FOR_GROUP"] = true,
		["LOCAL_DEFENSE"] = false,
		["RAID"] = true,
		["BF_WORLD"] = true,
		["_channelblocked"] = {
		},
		["RAID_WARNING"] = false,
		["_chatblocked"] = {
		},
		["_bfworldcf"] = {
			["Player-4792-00BAD688"] = {
				true, -- [1]
			},
			["Player-4792-025EAE5E"] = {
				true, -- [1]
			},
			["Player-4792-03A26BE8"] = {
				true, -- [1]
			},
			["Player-4792-010DE60B"] = {
				true, -- [1]
			},
			["Player-4792-033FCC2E"] = {
				true, -- [1]
			},
		},
		["UNMANAGEDCHANNEL"] = false,
	},
}
