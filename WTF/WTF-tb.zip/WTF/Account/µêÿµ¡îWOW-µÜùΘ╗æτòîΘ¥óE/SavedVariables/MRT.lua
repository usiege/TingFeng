
VMRT = {
	["Timers"] = {
		["specTimes"] = {
			[62] = 10,
			[63] = 10,
			[250] = 10,
			[251] = 10,
			[64] = 10,
			[253] = 10,
			[65] = 10,
			[255] = 10,
			[66] = 10,
			[257] = 10,
			[258] = 10,
			[259] = 10,
			[260] = 10,
			[261] = 25,
			[262] = 16,
			[263] = 10,
			[264] = 10,
			[265] = 22,
			[266] = 10,
			[267] = 10,
			[268] = 10,
			[269] = 10,
			[270] = 10,
			[70] = 10,
			[102] = 10,
			[71] = 10,
			[103] = 10,
			[72] = 10,
			[104] = 10,
			[73] = 10,
			[252] = 10,
			[105] = 10,
			[254] = 10,
			[256] = 10,
			[577] = 10,
			[581] = 10,
		},
		["Type"] = 2,
		["timeToKillAnalyze"] = 15,
		["Strata"] = "HIGH",
	},
	["ProfileKeys"] = {
		["猎猎思密达-阿什坎迪"] = "default",
		["简洁界面-阿什坎迪"] = "default",
		["暗黑界面-阿什坎迪"] = "default",
		["大哥别开火-阿什坎迪"] = "default",
		["今晚就动手-阿什坎迪"] = "default",
	},
	["Encounter"] = {
		["names"] = {
		},
		["list"] = {
			["简洁界面"] = {
			},
			["今晚就动手"] = {
			},
			["简洁界面二"] = {
			},
			["暗黑界面"] = {
			},
			["大哥别开火"] = {
			},
			["猎猎思密达"] = {
			},
		},
	},
	["Marks"] = {
		["list"] = {
		},
	},
	["ExCD2"] = {
		["upd4525"] = true,
		["gnGUIDs"] = {
			["简洁界面"] = 0,
			["今晚就动手"] = 0,
			["简洁界面二"] = 0,
			["暗黑界面"] = 0,
			["大哥别开火"] = 0,
			["猎猎思密达"] = 0,
		},
		["NoRaid"] = true,
		["CDECol"] = {
		},
		["upd4380"] = true,
		["Save"] = {
		},
		["Profiles"] = {
			["Now"] = "default",
			["List"] = {
			},
		},
		["userDB"] = {
		},
		["colSet"] = {
			{
				["enabled"] = true,
				["frameGeneral"] = true,
				["iconGray"] = true,
				["textGeneral"] = true,
				["methodsGeneral"] = true,
				["blacklistGeneral"] = true,
				["textureGeneral"] = true,
				["iconGeneral"] = true,
				["fontOutline"] = true,
				["visibilityGeneral"] = true,
				["fontGeneral"] = true,
				["textureAnimation"] = true,
				["fontShadow"] = false,
			}, -- [1]
			{
				["enabled"] = true,
				["frameGeneral"] = true,
				["iconGray"] = true,
				["textGeneral"] = true,
				["methodsGeneral"] = true,
				["blacklistGeneral"] = true,
				["textureGeneral"] = true,
				["iconGeneral"] = true,
				["fontOutline"] = true,
				["visibilityGeneral"] = true,
				["fontGeneral"] = true,
				["textureAnimation"] = true,
				["fontShadow"] = false,
			}, -- [2]
			{
				["enabled"] = true,
				["frameGeneral"] = true,
				["iconGray"] = true,
				["textGeneral"] = true,
				["methodsGeneral"] = true,
				["blacklistGeneral"] = true,
				["textureGeneral"] = true,
				["iconGeneral"] = true,
				["fontOutline"] = true,
				["visibilityGeneral"] = true,
				["fontGeneral"] = true,
				["textureAnimation"] = true,
				["fontShadow"] = false,
			}, -- [3]
			{
				["frameGeneral"] = true,
				["iconGray"] = true,
				["textGeneral"] = true,
				["methodsGeneral"] = true,
				["blacklistGeneral"] = true,
				["textureGeneral"] = true,
				["iconGeneral"] = true,
				["fontOutline"] = true,
				["visibilityGeneral"] = true,
				["fontGeneral"] = true,
				["textureAnimation"] = true,
				["fontShadow"] = false,
			}, -- [4]
			{
				["frameGeneral"] = true,
				["iconGray"] = true,
				["textGeneral"] = true,
				["methodsGeneral"] = true,
				["blacklistGeneral"] = true,
				["textureGeneral"] = true,
				["iconGeneral"] = true,
				["fontOutline"] = true,
				["visibilityGeneral"] = true,
				["fontGeneral"] = true,
				["textureAnimation"] = true,
				["fontShadow"] = false,
			}, -- [5]
			{
				["frameGeneral"] = true,
				["iconGray"] = true,
				["textGeneral"] = true,
				["methodsGeneral"] = true,
				["blacklistGeneral"] = true,
				["textureGeneral"] = true,
				["iconGeneral"] = true,
				["fontOutline"] = true,
				["visibilityGeneral"] = true,
				["fontGeneral"] = true,
				["textureAnimation"] = true,
				["fontShadow"] = false,
			}, -- [6]
			{
				["frameGeneral"] = true,
				["iconGray"] = true,
				["textGeneral"] = true,
				["methodsGeneral"] = true,
				["blacklistGeneral"] = true,
				["textureGeneral"] = true,
				["iconGeneral"] = true,
				["fontOutline"] = true,
				["visibilityGeneral"] = true,
				["fontGeneral"] = true,
				["textureAnimation"] = true,
				["fontShadow"] = false,
			}, -- [7]
			{
				["frameGeneral"] = true,
				["iconGray"] = true,
				["textGeneral"] = true,
				["methodsGeneral"] = true,
				["blacklistGeneral"] = true,
				["textureGeneral"] = true,
				["iconGeneral"] = true,
				["fontOutline"] = true,
				["visibilityGeneral"] = true,
				["fontGeneral"] = true,
				["textureAnimation"] = true,
				["fontShadow"] = false,
			}, -- [8]
			{
				["frameGeneral"] = true,
				["iconGray"] = true,
				["textGeneral"] = true,
				["methodsGeneral"] = true,
				["blacklistGeneral"] = true,
				["textureGeneral"] = true,
				["iconGeneral"] = true,
				["fontOutline"] = true,
				["visibilityGeneral"] = true,
				["fontGeneral"] = true,
				["textureAnimation"] = true,
				["fontShadow"] = false,
			}, -- [9]
			{
				["frameGeneral"] = true,
				["iconGray"] = true,
				["textGeneral"] = true,
				["methodsGeneral"] = true,
				["blacklistGeneral"] = true,
				["textureGeneral"] = true,
				["iconGeneral"] = true,
				["fontOutline"] = true,
				["visibilityGeneral"] = true,
				["fontGeneral"] = true,
				["textureAnimation"] = true,
				["fontShadow"] = false,
			}, -- [10]
			{
				["frameGeneral"] = true,
				["iconGray"] = true,
				["textGeneral"] = true,
				["methodsGeneral"] = true,
				["blacklistGeneral"] = true,
				["textureGeneral"] = true,
				["iconGeneral"] = true,
				["fontOutline"] = true,
				["visibilityGeneral"] = true,
				["fontGeneral"] = true,
				["textureAnimation"] = true,
				["fontShadow"] = false,
			}, -- [11]
		},
		["Priority"] = {
		},
		["CDE"] = {
		},
		["OptFav"] = {
		},
	},
	["Attendance"] = {
		["data"] = {
		},
		["alts"] = {
		},
	},
	["Inspect"] = {
		["Soulbinds"] = {
		},
	},
	["InspectViewer"] = {
		["ColorizeLowIlvl685"] = false,
		["ColorizeNoEnch"] = true,
		["ColorizeNoGems"] = true,
		["ColorizeNoTopEnchGems"] = false,
		["ColorizeLowIlvl"] = true,
		["ColorizeNoValorUpgrade"] = false,
	},
	["RaidCheck"] = {
		["FlaskExp"] = 1,
		["BuffsCheck"] = true,
		["ReadyCheckFrame"] = true,
		["ReadyCheckFrameTimerFade"] = 4,
		["WeaponEnch"] = {
		},
		["ReadyCheckFrameOnlyRL"] = true,
	},
	["Addon"] = {
		["Timer"] = 0.1,
		["migrateMRT"] = true,
		["Version"] = 4600,
		["PreVersion"] = 4600,
	},
	["WhoPulled"] = {
	},
	["Profiles"] = {
	},
	["BossWatcher"] = {
		["optionsDamageGraph"] = true,
		["fightsNum"] = 2,
		["optionsPositionsDist"] = true,
		["optionsHealingGraph"] = true,
		["trackingDamageSpells"] = {
		},
	},
	["Profile"] = "default",
	["LootLink"] = {
	},
	["RaidGroups"] = {
		["KeepPosInGroup"] = true,
		["upd4550"] = true,
		["profiles"] = {
		},
	},
	["Note"] = {
		["BlackNames"] = {
		},
		["FontSize"] = 12,
		["AutoLoad"] = {
		},
		["Width"] = 200.000152587891,
		["BlackLastUpdateName"] = {
		},
		["Black"] = {
			"", -- [1]
			"", -- [2]
			"", -- [3]
		},
		["Strata"] = "HIGH",
		["Height"] = 100.000022888184,
		["BlackLastUpdateTime"] = {
		},
		["OnlyPromoted"] = true,
		["OptionsFormatting"] = true,
	},
	["Logging"] = {
	},
	["MarksBar"] = {
		["pulltimer"] = 10,
		["pulltimer_right"] = 10,
		["Strata"] = "HIGH",
		["Show"] = {
			true, -- [1]
			true, -- [2]
			true, -- [3]
			true, -- [4]
			true, -- [5]
		},
	},
	["VisNote"] = {
		["data"] = {
		},
		["sync_data"] = {
		},
	},
	["InviteTool"] = {
		["Words"] = "инв inv byd штм 123",
		["InvByChat"] = true,
		["RaidDiff"] = 16,
		["PromoteRank"] = 2,
		["Ranks"] = {
			true, -- [1]
		},
		["LootThreshold"] = 2,
		["MasterLooters"] = "",
		["LootMethod"] = "group",
		["PromoteNames"] = "",
		["OnlyGuild"] = true,
		["Rank"] = 1,
	},
}
