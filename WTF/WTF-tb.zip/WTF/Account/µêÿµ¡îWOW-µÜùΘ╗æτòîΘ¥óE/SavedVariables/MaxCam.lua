
MaxCamDB = {
	["distance"] = 3.34,
	["db_version"] = 2.3,
	["speed"] = 20,
	["increment"] = 4,
	["nearDistance"] = 5,
	["nearIncrement"] = 1,
}
