
HHTD_SavedVariables = {
	["char"] = {
		["大哥别开火 - 阿什坎迪"] = {
			["settingsMigrated"] = false,
		},
		["简洁界面 - 阿什坎迪"] = {
			["settingsMigrated"] = false,
		},
		["今晚就动手 - 阿什坎迪"] = {
			["settingsMigrated"] = false,
		},
		["暗黑界面 - 阿什坎迪"] = {
			["settingsMigrated"] = false,
		},
		["猎猎思密达 - 阿什坎迪"] = {
			["settingsMigrated"] = false,
		},
	},
	["profileKeys"] = {
		["简洁界面二 - 阿什坎迪"] = "暗黑界面 - 阿什坎迪",
		["简洁界面 - 阿什坎迪"] = "暗黑界面 - 阿什坎迪",
		["今晚就动手 - 阿什坎迪"] = "暗黑界面 - 阿什坎迪",
		["撒慢慢 - 阿什坎迪"] = "暗黑界面 - 阿什坎迪",
		["大哥别开火 - 阿什坎迪"] = "暗黑界面 - 阿什坎迪",
		["暗黑界面 - 阿什坎迪"] = "暗黑界面 - 阿什坎迪",
		["交作业 - 阿什坎迪"] = "暗黑界面 - 阿什坎迪",
		["猎猎思密达 - 阿什坎迪"] = "暗黑界面 - 阿什坎迪",
	},
	["global"] = {
		["settingsMigrated"] = false,
		["oldNameEnableState"] = 0,
	},
	["namespaces"] = {
		["Announcer"] = {
		},
		["CM"] = {
		},
		["NPH"] = {
		},
	},
}
