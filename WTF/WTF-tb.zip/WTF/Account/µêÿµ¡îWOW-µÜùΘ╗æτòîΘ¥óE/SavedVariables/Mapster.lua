
MapsterDB = {
	["namespaces"] = {
		["FogClear"] = {
		},
		["Coords"] = {
		},
	},
	["profileKeys"] = {
		["今晚就动手 - 阿什坎迪"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
		},
	},
}
