
CodexLiteSV = {
	["__version"] = 20210612,
	["setting"] = {
		["minimap_player_arrow_on_top"] = true,
		["pin_size"] = 15,
		["quest_lvl_orange"] = 7,
		["minimap_node_inset"] = true,
		["varied_size"] = 20,
		["auto_accept"] = false,
		["min_rate"] = 1,
		["show_buttons_in_log"] = true,
		["_checkedConflicts"] = true,
		["tip_info"] = true,
		["show_in_continent"] = false,
		["show_db_icon"] = false,
		["hide_node_modifier"] = "SHIFT",
		["quest_lvl_highest_ofs"] = 1,
		["quest_lvl_yellow"] = 2,
		["show_quest_starter"] = true,
		["quest_lvl_lowest_ofs"] = -6,
		["quest_auto_inverse_modifier"] = "SHIFT",
		["quest_lvl_red"] = 9,
		["show_quest_ender"] = true,
		["minimap_alpha"] = 1,
		["large_size"] = 24,
		["objective_tooltip_info"] = true,
		["show_id_in_tooltip"] = true,
		["pin_scale_max"] = 1.25,
		["quest_lvl_green"] = -1,
		["auto_complete"] = false,
		["worldmap_alpha"] = 1,
	},
	["_GlobalRef"] = {
	},
	["_GlobalAssign"] = {
	},
	["quest_temporarily_blocked"] = {
		["Player-4792-010DE60B"] = {
		},
		["Player-4792-025EAE5E"] = {
		},
		["Player-4792-03A26BE8"] = {
		},
	},
	["quest_permanently_bl_list"] = {
		["Player-4792-010DE60B"] = {
		},
		["Player-4792-025EAE5E"] = {
		},
		["Player-4792-03A26BE8"] = {
		},
	},
	["quest_permanently_blocked"] = {
		["Player-4792-010DE60B"] = {
		},
		["Player-4792-025EAE5E"] = {
		},
		["Player-4792-03A26BE8"] = {
		},
	},
	["minimap"] = {
		["minimapPos"] = 226.9091347245456,
	},
}
