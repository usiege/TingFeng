
ParrotDB = {
	["profileKeys"] = {
		["大哥别开火 - 阿什坎迪"] = "Default",
		["今晚就动手 - 阿什坎迪"] = "Default",
	},
	["namespaces"] = {
		["CombatEvents"] = {
			["profiles"] = {
				["Default"] = {
					["Notification"] = {
						["Currency gains"] = {
							["disabled"] = true,
						},
						["Player killing blows"] = {
							["disabled"] = true,
						},
						["Power gain"] = {
							["disabled"] = true,
						},
						["Pet debuff gains"] = {
							["disabled"] = true,
						},
						["Experience gains"] = {
							["disabled"] = true,
						},
						["Debuff fades"] = {
							["disabled"] = true,
						},
						["Pet buff gains"] = {
							["disabled"] = true,
						},
						["Enemy debuff fades"] = {
							["disabled"] = true,
						},
						["Enemy buff gains"] = {
							["disabled"] = true,
						},
						["Combo points full"] = {
							["disabled"] = false,
						},
						["Buff fades"] = {
							["disabled"] = true,
						},
						["Reputation gains"] = {
							["disabled"] = true,
						},
						["Buff stack gains"] = {
							["disabled"] = true,
						},
						["Enemy buff fades"] = {
							["disabled"] = true,
						},
						["Enter combat"] = {
							["disabled"] = true,
						},
						["Item buff fades"] = {
							["disabled"] = true,
						},
						["Item buff gains"] = {
							["disabled"] = true,
						},
						["Combo point gain"] = {
							["disabled"] = false,
						},
						["Pet debuff fades"] = {
							["disabled"] = true,
						},
						["Power loss"] = {
							["disabled"] = true,
						},
						["Pet buff fades"] = {
							["disabled"] = true,
						},
						["Enemy debuff gains"] = {
							["disabled"] = true,
						},
						["Loot money"] = {
							["disabled"] = true,
						},
						["Target buff stack gains"] = {
							["disabled"] = true,
						},
						["Skill cooldown finish"] = {
							["disabled"] = true,
						},
						["Skill gains"] = {
							["disabled"] = true,
						},
						["NPC killing blows"] = {
							["disabled"] = true,
						},
						["Leave combat"] = {
							["disabled"] = true,
						},
						["Debuff gains"] = {
							["disabled"] = true,
						},
						["Extra attacks"] = {
							["disabled"] = true,
						},
						["Loot items"] = {
							["disabled"] = true,
						},
						["Buff gains"] = {
							["disabled"] = true,
						},
						["Reputation losses"] = {
							["disabled"] = true,
						},
						["Target buff gains"] = {
							["disabled"] = true,
						},
						["Debuff stack gains"] = {
							["disabled"] = true,
						},
					},
					["dbver"] = 5,
					["Outgoing"] = {
						["Pet dispel"] = {
							["disabled"] = true,
						},
						["Spell steal"] = {
							["disabled"] = true,
						},
						["Dispel"] = {
							["disabled"] = true,
						},
						["Dispel fail"] = {
							["disabled"] = true,
						},
						["Pet dispel fail"] = {
							["disabled"] = true,
						},
					},
					["Incoming"] = {
						["Pet skill parries"] = {
							["disabled"] = true,
						},
						["Skill immunes"] = {
							["disabled"] = true,
						},
						["Pet dispel fail"] = {
							["disabled"] = true,
						},
						["Self damage misses"] = {
							["disabled"] = true,
						},
						["Melee reflects"] = {
							["disabled"] = true,
						},
						["Skill misses"] = {
							["disabled"] = true,
						},
						["Melee dodges"] = {
							["disabled"] = true,
						},
						["Melee damage"] = {
							["disabled"] = false,
						},
						["Heals over time"] = {
							["disabled"] = true,
						},
						["Environmental damage"] = {
							["disabled"] = true,
						},
						["Pet melee resists"] = {
							["disabled"] = true,
						},
						["Skill deflects"] = {
							["disabled"] = true,
						},
						["Pet skill reflects"] = {
							["disabled"] = true,
						},
						["Melee evades"] = {
							["disabled"] = true,
						},
						["Pet melee deflects"] = {
							["disabled"] = true,
						},
						["Pet melee misses"] = {
							["disabled"] = true,
						},
						["Pet dispel"] = {
							["disabled"] = true,
						},
						["Pet skill immunes"] = {
							["disabled"] = true,
						},
						["Pet skill dodges"] = {
							["disabled"] = true,
						},
						["Skill DoTs"] = {
							["disabled"] = false,
						},
						["Skill parries"] = {
							["disabled"] = true,
						},
						["Pet heals"] = {
							["disabled"] = true,
						},
						["Melee resists"] = {
							["disabled"] = true,
						},
						["Melee misses"] = {
							["disabled"] = true,
						},
						["Melee blocks"] = {
							["disabled"] = true,
						},
						["Dispel fail"] = {
							["disabled"] = true,
						},
						["Melee absorbs"] = {
							["disabled"] = true,
						},
						["Pet skill resists"] = {
							["disabled"] = true,
						},
						["Skill interrupts"] = {
							["disabled"] = true,
						},
						["Melee immunes"] = {
							["disabled"] = true,
						},
						["Pet melee damage"] = {
							["disabled"] = true,
						},
						["Spell steal"] = {
							["disabled"] = true,
						},
						["Heals"] = {
							["disabled"] = true,
						},
						["Pet skill evades"] = {
							["disabled"] = true,
						},
						["Pet melee blocks"] = {
							["disabled"] = true,
						},
						["Pet melee evades"] = {
							["disabled"] = true,
						},
						["Melee deflects"] = {
							["disabled"] = true,
						},
						["Dispel"] = {
							["disabled"] = true,
						},
						["Pet melee parries"] = {
							["disabled"] = true,
						},
						["Pet melee immunes"] = {
							["disabled"] = true,
						},
						["Pet skill DoTs"] = {
							["disabled"] = true,
						},
						["Pet skill blocks"] = {
							["disabled"] = true,
						},
						["Skill dodges"] = {
							["disabled"] = true,
						},
						["Self damage absorbs"] = {
							["disabled"] = true,
						},
						["Skill reflects"] = {
							["disabled"] = true,
						},
						["Skill evades"] = {
							["disabled"] = true,
						},
						["Pet Skill interrupts"] = {
							["disabled"] = true,
						},
						["Skill resists"] = {
							["disabled"] = true,
						},
						["Self heals over time"] = {
							["disabled"] = true,
						},
						["Pet skill absorbs"] = {
							["disabled"] = true,
						},
						["Pet skill misses"] = {
							["disabled"] = true,
						},
						["Pet heals over time"] = {
							["disabled"] = true,
						},
						["Pet melee reflects"] = {
							["disabled"] = true,
						},
						["Skill absorbs"] = {
							["disabled"] = true,
						},
						["Melee parries"] = {
							["disabled"] = true,
						},
						["Pet melee dodges"] = {
							["disabled"] = true,
						},
						["Reactive skills"] = {
							["disabled"] = false,
						},
						["Self heals"] = {
							["disabled"] = true,
						},
						["Skill blocks"] = {
							["disabled"] = true,
						},
						["Pet skill deflects"] = {
							["disabled"] = true,
						},
						["Skill damage"] = {
							["disabled"] = false,
						},
						["Self damage"] = {
							["disabled"] = false,
						},
						["Pet skill damage"] = {
							["disabled"] = true,
						},
						["Pet melee absorbs"] = {
							["disabled"] = true,
						},
					},
				},
			},
		},
		["Suppressions"] = {
		},
		["ScrollAreas"] = {
			["profiles"] = {
				["Default"] = {
					["areas"] = {
						["Incoming"] = {
							["stickyDirection"] = "DOWN;RIGHT",
							["direction"] = "DOWN;LEFT",
							["stickyAnimationStyle"] = "Pow",
							["iconSide"] = "RIGHT",
							["xOffset"] = -121.8109130859375,
							["size"] = 260,
							["animationStyle"] = "Parabola",
							["yOffset"] = -31.931640625,
						},
						["Outgoing"] = {
							["stickyDirection"] = "DOWN;LEFT",
							["direction"] = "DOWN;RIGHT",
							["stickyAnimationStyle"] = "Pow",
							["iconSide"] = "LEFT",
							["xOffset"] = 116.0159912109375,
							["size"] = 260,
							["animationStyle"] = "Parabola",
							["yOffset"] = -30.96585083007813,
						},
					},
					["dbver"] = 2,
				},
			},
		},
		["Cooldowns"] = {
		},
		["Display"] = {
		},
		["Triggers"] = {
			["profiles"] = {
				["Default"] = {
					["triggers2"] = 0,
					["dbver2"] = 0,
					["dbver3"] = 1,
					["triggers"] = {
						[1001] = {
							["disabled"] = true,
						},
					},
				},
			},
		},
	},
}
