
NITdatabase = {
	["profileKeys"] = {
		["暗黑界面 - 阿什坎迪"] = "Default",
	},
	["global"] = {
		["阿什坎迪"] = {
			["trades"] = {
			},
			["myChars"] = {
				["暗黑界面"] = {
					["fishingSkill"] = 0,
					["cookingSkill"] = 0,
					["profSkill1"] = 0,
					["firstaidSkillMax"] = 0,
					["profSkill2"] = 0,
					["savedInstances"] = {
					},
					["maxXP"] = 2100,
					["gender"] = "Male",
					["prof1"] = "none",
					["restedXP"] = 3098,
					["totalBagSlots"] = 20,
					["freeBagSlots"] = 19,
					["currentXP"] = 1579,
					["raceEnglish"] = "Human",
					["profSkillMax1"] = 0,
					["race"] = "人类",
					["time"] = 1640186102,
					["gold"] = 14,
					["realm"] = "阿什坎迪",
					["raceLocalized"] = "人类",
					["fishingSkillMax"] = 0,
					["firstaidSkill"] = 0,
					["classEnglish"] = "WARRIOR",
					["level"] = 4,
					["prof2"] = "none",
					["guild"] = "No guild",
					["guildRankName"] = "No guild rank",
					["durabilityAverage"] = 100,
					["resting"] = false,
					["cooldowns"] = {
					},
					["cookingSkillMax"] = 0,
					["classLocalized"] = "战士",
					["profSkillMax2"] = 0,
				},
			},
			["instances"] = {
			},
		},
		["resetCharData"] = false,
	},
}
