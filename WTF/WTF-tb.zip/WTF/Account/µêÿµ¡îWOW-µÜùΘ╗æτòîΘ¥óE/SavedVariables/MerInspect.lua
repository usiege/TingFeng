
MerInspectDB = {
	["ShowOwnFrameWhenInspecting"] = true,
	["ShowCharacterItemStats"] = true,
	["ShowInspectAngularBorder"] = true,
	["ShowCharacterItemSheet"] = true,
	["ShowInspectItemSheet"] = true,
	["version"] = 1,
	["ShowItemStats"] = true,
	["ShowItemSlotString"] = true,
	["ShowInspectColoredLabel"] = true,
	["ShowItemBorder"] = true,
}
