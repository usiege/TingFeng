
Accountant_ClassicSaveData = {
	["阿什坎迪"] = {
		["简洁界面"] = {
			["options"] = {
				["weekdate"] = "",
				["weekstart"] = 1,
				["date"] = "06/12/21",
				["class"] = "WARRIOR",
				["prvmonth"] = "11",
				["totalcash"] = 4,
				["prvday"] = "28/11/21",
				["dateweek"] = "12/05/21",
				["version"] = "v2.12.09",
				["faction"] = "Alliance",
				["lastsessiondate"] = "03/10/21",
				["curryear"] = "2021",
				["prvdateweek"] = "11/28/21",
				["month"] = "12",
			},
			["data"] = {
				["TRAIN"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["TAXI"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["TRADE"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["OTHER"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["REPAIRS"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["LOOT"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["MERCH"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 4,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 4,
						["Out"] = 0,
					},
				},
				["AH"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["MAIL"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["QUEST"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
			},
		},
		["暗黑界面"] = {
			["options"] = {
				["weekdate"] = "",
				["weekstart"] = 1,
				["date"] = "06/12/21",
				["class"] = "WARRIOR",
				["prvmonth"] = "11",
				["totalcash"] = 14,
				["prvday"] = "28/11/21",
				["dateweek"] = "12/05/21",
				["version"] = "v2.12.09",
				["faction"] = "Alliance",
				["curryear"] = "2021",
				["lastsessiondate"] = "06/12/21",
				["prvdateweek"] = "11/28/21",
				["month"] = "12",
			},
			["data"] = {
				["TRAIN"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["TAXI"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["TRADE"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["OTHER"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 15,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 15,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 15,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["REPAIRS"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["LOOT"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["MAIL"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["AH"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["MERCH"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 6,
						["Out"] = 7,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 6,
						["Out"] = 7,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 6,
						["Out"] = 7,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["QUEST"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
			},
		},
		["简洁界面二"] = {
			["options"] = {
				["weekdate"] = "",
				["weekstart"] = 1,
				["date"] = "06/12/21",
				["class"] = "DRUID",
				["month"] = "12",
				["lastsessiondate"] = "03/10/21",
				["prvday"] = "28/11/21",
				["dateweek"] = "12/05/21",
				["version"] = "v2.12.09",
				["faction"] = "Alliance",
				["totalcash"] = 0,
				["curryear"] = "2021",
				["prvdateweek"] = "11/28/21",
				["prvmonth"] = "11",
			},
			["data"] = {
				["TRAIN"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["TAXI"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["TRADE"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["OTHER"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["REPAIRS"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["LOOT"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["MERCH"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["AH"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["MAIL"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["QUEST"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
			},
		},
		["猎猎思密达"] = {
			["options"] = {
				["weekdate"] = "",
				["weekstart"] = 1,
				["date"] = "06/12/21",
				["class"] = "HUNTER",
				["prvday"] = "28/11/21",
				["totalcash"] = 0,
				["prvmonth"] = "11",
				["dateweek"] = "12/05/21",
				["version"] = "v2.12.09",
				["month"] = "12",
				["lastsessiondate"] = "28/11/21",
				["curryear"] = "2021",
				["prvdateweek"] = "11/28/21",
				["faction"] = "Alliance",
			},
			["data"] = {
				["TRAIN"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["TAXI"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["TRADE"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["OTHER"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["REPAIRS"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["LOOT"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["MERCH"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["AH"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["MAIL"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["QUEST"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
			},
		},
	},
}
Accountant_ClassicDB = {
	["profileKeys"] = {
		["大哥别开火 - 阿什坎迪"] = "Default",
		["简洁界面 - 阿什坎迪"] = "Default",
		["今晚就动手 - 阿什坎迪"] = "Default",
		["吸你的血 - 阿什坎迪"] = "Default",
		["你说怎么办 - 阿什坎迪"] = "Default",
		["动能甫杜 - 阿什坎迪"] = "Default",
		["猎猎思密达 - 阿什坎迪"] = "Default",
		["交作业 - 阿什坎迪"] = "Default",
		["简洁界面二 - 阿什坎迪"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["showmoneyinfo"] = false,
			["selectedCharacter"] = 4,
			["oprofileCopied"] = true,
			["MnyFramePoint"] = {
				nil, -- [1]
				nil, -- [2]
				nil, -- [3]
				265.0759887695313, -- [4]
				-3.148121356964111, -- [5]
			},
			["AcFramePoint"] = {
				"TOP", -- [1]
				nil, -- [2]
				"TOP", -- [3]
				-302.21124267578, -- [4]
				-117.82691955566, -- [5]
			},
		},
	},
}
Accountant_Classic_NewDB = nil
Accountant_ClassicZoneDB = {
	["阿什坎迪"] = {
		["简洁界面"] = {
			["data"] = {
				["PrvWeek"] = {
					["REPAIRS"] = {
					},
					["TAXI"] = {
					},
					["TRADE"] = {
					},
					["OTHER"] = {
					},
					["TRAIN"] = {
					},
					["MERCH"] = {
					},
					["LOOT"] = {
					},
					["MAIL"] = {
					},
					["AH"] = {
					},
					["QUEST"] = {
					},
				},
				["PrvDay"] = {
					["REPAIRS"] = {
					},
					["TAXI"] = {
					},
					["TRADE"] = {
					},
					["OTHER"] = {
					},
					["TRAIN"] = {
					},
					["MERCH"] = {
					},
					["LOOT"] = {
					},
					["MAIL"] = {
					},
					["AH"] = {
					},
					["QUEST"] = {
					},
				},
				["Year"] = {
					["REPAIRS"] = {
					},
					["TAXI"] = {
					},
					["TRADE"] = {
					},
					["MAIL"] = {
					},
					["OTHER"] = {
					},
					["MERCH"] = {
						["艾尔文森林 - 北郡山谷"] = {
							["In"] = 4,
							["Out"] = 0,
						},
					},
					["TRAIN"] = {
					},
					["AH"] = {
					},
					["LOOT"] = {
					},
					["QUEST"] = {
					},
				},
				["Week"] = {
					["REPAIRS"] = {
					},
					["TAXI"] = {
					},
					["TRADE"] = {
					},
					["MAIL"] = {
					},
					["OTHER"] = {
					},
					["MERCH"] = {
					},
					["LOOT"] = {
					},
					["AH"] = {
					},
					["TRAIN"] = {
					},
					["QUEST"] = {
					},
				},
				["Day"] = {
					["REPAIRS"] = {
					},
					["TAXI"] = {
					},
					["TRADE"] = {
					},
					["MAIL"] = {
					},
					["OTHER"] = {
					},
					["MERCH"] = {
					},
					["LOOT"] = {
					},
					["AH"] = {
					},
					["TRAIN"] = {
					},
					["QUEST"] = {
					},
				},
				["Month"] = {
					["REPAIRS"] = {
					},
					["TAXI"] = {
					},
					["TRADE"] = {
					},
					["MAIL"] = {
					},
					["OTHER"] = {
					},
					["MERCH"] = {
					},
					["LOOT"] = {
					},
					["AH"] = {
					},
					["TRAIN"] = {
					},
					["QUEST"] = {
					},
				},
				["PrvYear"] = {
					["REPAIRS"] = {
					},
					["TAXI"] = {
					},
					["TRADE"] = {
					},
					["MAIL"] = {
					},
					["OTHER"] = {
					},
					["MERCH"] = {
					},
					["TRAIN"] = {
					},
					["AH"] = {
					},
					["LOOT"] = {
					},
					["QUEST"] = {
					},
				},
				["PrvMonth"] = {
					["REPAIRS"] = {
					},
					["TAXI"] = {
					},
					["TRADE"] = {
					},
					["OTHER"] = {
					},
					["TRAIN"] = {
					},
					["MERCH"] = {
					},
					["LOOT"] = {
					},
					["MAIL"] = {
					},
					["AH"] = {
					},
					["QUEST"] = {
					},
				},
				["Session"] = {
					["REPAIRS"] = {
					},
					["TAXI"] = {
					},
					["TRADE"] = {
					},
					["MAIL"] = {
					},
					["OTHER"] = {
					},
					["MERCH"] = {
						["艾尔文森林 - 北郡山谷"] = {
							["In"] = 4,
							["Out"] = 0,
						},
					},
					["LOOT"] = {
					},
					["AH"] = {
					},
					["TRAIN"] = {
					},
					["QUEST"] = {
					},
				},
				["Total"] = {
					["REPAIRS"] = {
					},
					["TAXI"] = {
					},
					["TRADE"] = {
					},
					["MAIL"] = {
					},
					["OTHER"] = {
					},
					["MERCH"] = {
						["艾尔文森林 - 北郡山谷"] = {
							["In"] = 4,
							["Out"] = 0,
						},
					},
					["TRAIN"] = {
					},
					["AH"] = {
					},
					["LOOT"] = {
					},
					["QUEST"] = {
					},
				},
			},
		},
		["暗黑界面"] = {
			["data"] = {
				["PrvWeek"] = {
					["REPAIRS"] = {
					},
					["TAXI"] = {
					},
					["TRADE"] = {
					},
					["OTHER"] = {
					},
					["TRAIN"] = {
					},
					["MERCH"] = {
					},
					["LOOT"] = {
					},
					["MAIL"] = {
					},
					["AH"] = {
					},
					["QUEST"] = {
					},
				},
				["PrvDay"] = {
					["REPAIRS"] = {
					},
					["TAXI"] = {
					},
					["TRADE"] = {
					},
					["OTHER"] = {
					},
					["TRAIN"] = {
					},
					["MERCH"] = {
					},
					["LOOT"] = {
					},
					["MAIL"] = {
					},
					["AH"] = {
					},
					["QUEST"] = {
					},
				},
				["Total"] = {
					["REPAIRS"] = {
					},
					["TAXI"] = {
					},
					["TRADE"] = {
					},
					["MAIL"] = {
					},
					["OTHER"] = {
						[""] = {
							["In"] = 15,
							["Out"] = 0,
						},
					},
					["MERCH"] = {
						["艾尔文森林 - 北郡山谷"] = {
							["In"] = 6,
							["Out"] = 7,
						},
					},
					["LOOT"] = {
					},
					["AH"] = {
					},
					["TRAIN"] = {
					},
					["QUEST"] = {
					},
				},
				["Week"] = {
					["REPAIRS"] = {
					},
					["TAXI"] = {
					},
					["TRADE"] = {
					},
					["MAIL"] = {
					},
					["OTHER"] = {
					},
					["MERCH"] = {
					},
					["LOOT"] = {
					},
					["AH"] = {
					},
					["TRAIN"] = {
					},
					["QUEST"] = {
					},
				},
				["Year"] = {
					["REPAIRS"] = {
					},
					["TAXI"] = {
					},
					["TRADE"] = {
					},
					["MAIL"] = {
					},
					["OTHER"] = {
						[""] = {
							["In"] = 15,
							["Out"] = 0,
						},
					},
					["MERCH"] = {
						["艾尔文森林 - 北郡山谷"] = {
							["In"] = 6,
							["Out"] = 7,
						},
					},
					["LOOT"] = {
					},
					["AH"] = {
					},
					["TRAIN"] = {
					},
					["QUEST"] = {
					},
				},
				["Month"] = {
					["REPAIRS"] = {
					},
					["TAXI"] = {
					},
					["TRADE"] = {
					},
					["MAIL"] = {
					},
					["OTHER"] = {
					},
					["MERCH"] = {
					},
					["LOOT"] = {
					},
					["AH"] = {
					},
					["TRAIN"] = {
					},
					["QUEST"] = {
					},
				},
				["PrvYear"] = {
					["REPAIRS"] = {
					},
					["TAXI"] = {
					},
					["TRADE"] = {
					},
					["MAIL"] = {
					},
					["OTHER"] = {
					},
					["MERCH"] = {
					},
					["LOOT"] = {
					},
					["AH"] = {
					},
					["TRAIN"] = {
					},
					["QUEST"] = {
					},
				},
				["PrvMonth"] = {
					["REPAIRS"] = {
					},
					["TAXI"] = {
					},
					["TRADE"] = {
					},
					["OTHER"] = {
						[""] = {
							["In"] = 15,
							["Out"] = 0,
						},
					},
					["TRAIN"] = {
					},
					["MERCH"] = {
						["艾尔文森林 - 北郡山谷"] = {
							["In"] = 6,
							["Out"] = 7,
						},
					},
					["LOOT"] = {
					},
					["MAIL"] = {
					},
					["AH"] = {
					},
					["QUEST"] = {
					},
				},
				["Session"] = {
					["REPAIRS"] = {
					},
					["TAXI"] = {
					},
					["TRADE"] = {
					},
					["MAIL"] = {
					},
					["OTHER"] = {
					},
					["MERCH"] = {
					},
					["LOOT"] = {
					},
					["AH"] = {
					},
					["TRAIN"] = {
					},
					["QUEST"] = {
					},
				},
				["Day"] = {
					["REPAIRS"] = {
					},
					["TAXI"] = {
					},
					["TRADE"] = {
					},
					["MAIL"] = {
					},
					["OTHER"] = {
					},
					["MERCH"] = {
					},
					["LOOT"] = {
					},
					["AH"] = {
					},
					["TRAIN"] = {
					},
					["QUEST"] = {
					},
				},
			},
		},
		["简洁界面二"] = {
			["data"] = {
				["PrvWeek"] = {
					["REPAIRS"] = {
					},
					["TAXI"] = {
					},
					["TRADE"] = {
					},
					["OTHER"] = {
					},
					["TRAIN"] = {
					},
					["MERCH"] = {
					},
					["LOOT"] = {
					},
					["MAIL"] = {
					},
					["AH"] = {
					},
					["QUEST"] = {
					},
				},
				["PrvDay"] = {
					["REPAIRS"] = {
					},
					["TAXI"] = {
					},
					["TRADE"] = {
					},
					["OTHER"] = {
					},
					["TRAIN"] = {
					},
					["MERCH"] = {
					},
					["LOOT"] = {
					},
					["MAIL"] = {
					},
					["AH"] = {
					},
					["QUEST"] = {
					},
				},
				["Day"] = {
					["REPAIRS"] = {
					},
					["TAXI"] = {
					},
					["TRADE"] = {
					},
					["MAIL"] = {
					},
					["OTHER"] = {
					},
					["MERCH"] = {
					},
					["LOOT"] = {
					},
					["AH"] = {
					},
					["TRAIN"] = {
					},
					["QUEST"] = {
					},
				},
				["Week"] = {
					["REPAIRS"] = {
					},
					["TAXI"] = {
					},
					["TRADE"] = {
					},
					["MAIL"] = {
					},
					["OTHER"] = {
					},
					["MERCH"] = {
					},
					["LOOT"] = {
					},
					["AH"] = {
					},
					["TRAIN"] = {
					},
					["QUEST"] = {
					},
				},
				["Year"] = {
					["REPAIRS"] = {
					},
					["TAXI"] = {
					},
					["TRADE"] = {
					},
					["MAIL"] = {
					},
					["OTHER"] = {
					},
					["MERCH"] = {
					},
					["TRAIN"] = {
					},
					["AH"] = {
					},
					["LOOT"] = {
					},
					["QUEST"] = {
					},
				},
				["Month"] = {
					["REPAIRS"] = {
					},
					["TAXI"] = {
					},
					["TRADE"] = {
					},
					["MAIL"] = {
					},
					["OTHER"] = {
					},
					["MERCH"] = {
					},
					["LOOT"] = {
					},
					["AH"] = {
					},
					["TRAIN"] = {
					},
					["QUEST"] = {
					},
				},
				["PrvYear"] = {
					["REPAIRS"] = {
					},
					["TAXI"] = {
					},
					["TRADE"] = {
					},
					["MAIL"] = {
					},
					["OTHER"] = {
					},
					["MERCH"] = {
					},
					["TRAIN"] = {
					},
					["AH"] = {
					},
					["LOOT"] = {
					},
					["QUEST"] = {
					},
				},
				["PrvMonth"] = {
					["REPAIRS"] = {
					},
					["TAXI"] = {
					},
					["TRADE"] = {
					},
					["OTHER"] = {
					},
					["TRAIN"] = {
					},
					["MERCH"] = {
					},
					["LOOT"] = {
					},
					["MAIL"] = {
					},
					["AH"] = {
					},
					["QUEST"] = {
					},
				},
				["Session"] = {
					["REPAIRS"] = {
					},
					["TAXI"] = {
					},
					["TRADE"] = {
					},
					["MAIL"] = {
					},
					["OTHER"] = {
					},
					["MERCH"] = {
					},
					["TRAIN"] = {
					},
					["AH"] = {
					},
					["LOOT"] = {
					},
					["QUEST"] = {
					},
				},
				["Total"] = {
					["REPAIRS"] = {
					},
					["TAXI"] = {
					},
					["TRADE"] = {
					},
					["MAIL"] = {
					},
					["OTHER"] = {
					},
					["MERCH"] = {
					},
					["TRAIN"] = {
					},
					["AH"] = {
					},
					["LOOT"] = {
					},
					["QUEST"] = {
					},
				},
			},
		},
		["猎猎思密达"] = {
			["data"] = {
				["PrvWeek"] = {
					["REPAIRS"] = {
					},
					["TAXI"] = {
					},
					["TRADE"] = {
					},
					["OTHER"] = {
					},
					["TRAIN"] = {
					},
					["MERCH"] = {
					},
					["LOOT"] = {
					},
					["MAIL"] = {
					},
					["AH"] = {
					},
					["QUEST"] = {
					},
				},
				["PrvDay"] = {
					["REPAIRS"] = {
					},
					["TAXI"] = {
					},
					["TRADE"] = {
					},
					["OTHER"] = {
					},
					["TRAIN"] = {
					},
					["MERCH"] = {
					},
					["LOOT"] = {
					},
					["MAIL"] = {
					},
					["AH"] = {
					},
					["QUEST"] = {
					},
				},
				["Year"] = {
					["REPAIRS"] = {
					},
					["TAXI"] = {
					},
					["TRADE"] = {
					},
					["MAIL"] = {
					},
					["OTHER"] = {
					},
					["MERCH"] = {
					},
					["TRAIN"] = {
					},
					["AH"] = {
					},
					["LOOT"] = {
					},
					["QUEST"] = {
					},
				},
				["Week"] = {
					["REPAIRS"] = {
					},
					["TAXI"] = {
					},
					["TRADE"] = {
					},
					["MAIL"] = {
					},
					["OTHER"] = {
					},
					["MERCH"] = {
					},
					["LOOT"] = {
					},
					["AH"] = {
					},
					["TRAIN"] = {
					},
					["QUEST"] = {
					},
				},
				["Day"] = {
					["REPAIRS"] = {
					},
					["TAXI"] = {
					},
					["TRADE"] = {
					},
					["MAIL"] = {
					},
					["OTHER"] = {
					},
					["MERCH"] = {
					},
					["LOOT"] = {
					},
					["AH"] = {
					},
					["TRAIN"] = {
					},
					["QUEST"] = {
					},
				},
				["Month"] = {
					["REPAIRS"] = {
					},
					["TAXI"] = {
					},
					["TRADE"] = {
					},
					["MAIL"] = {
					},
					["OTHER"] = {
					},
					["MERCH"] = {
					},
					["LOOT"] = {
					},
					["AH"] = {
					},
					["TRAIN"] = {
					},
					["QUEST"] = {
					},
				},
				["PrvYear"] = {
					["REPAIRS"] = {
					},
					["TAXI"] = {
					},
					["TRADE"] = {
					},
					["MAIL"] = {
					},
					["OTHER"] = {
					},
					["MERCH"] = {
					},
					["TRAIN"] = {
					},
					["AH"] = {
					},
					["LOOT"] = {
					},
					["QUEST"] = {
					},
				},
				["PrvMonth"] = {
					["REPAIRS"] = {
					},
					["TAXI"] = {
					},
					["TRADE"] = {
					},
					["OTHER"] = {
					},
					["TRAIN"] = {
					},
					["MERCH"] = {
					},
					["LOOT"] = {
					},
					["MAIL"] = {
					},
					["AH"] = {
					},
					["QUEST"] = {
					},
				},
				["Session"] = {
					["REPAIRS"] = {
					},
					["TAXI"] = {
					},
					["TRADE"] = {
					},
					["MAIL"] = {
					},
					["OTHER"] = {
					},
					["MERCH"] = {
					},
					["LOOT"] = {
					},
					["AH"] = {
					},
					["TRAIN"] = {
					},
					["QUEST"] = {
					},
				},
				["Total"] = {
					["REPAIRS"] = {
					},
					["TAXI"] = {
					},
					["TRADE"] = {
					},
					["MAIL"] = {
					},
					["OTHER"] = {
					},
					["MERCH"] = {
					},
					["TRAIN"] = {
					},
					["AH"] = {
					},
					["LOOT"] = {
					},
					["QUEST"] = {
					},
				},
			},
		},
	},
}
