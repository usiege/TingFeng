
Blizzard_Console_SavedVars = {
	["version"] = 3,
	["messageHistory"] = {
		{
			"Sorting particles normally.", -- [1]
			0, -- [2]
		}, -- [1]
		{
			"Multithreaded rendering enabled.", -- [1]
			0, -- [2]
		}, -- [2]
		{
			"Multithreaded BeginDraw enabled.", -- [1]
			0, -- [2]
		}, -- [3]
		{
			"Multithread shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [4]
		{
			"Multithreaded prepass enabled.", -- [1]
			0, -- [2]
		}, -- [5]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [6]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [7]
		{
			"Multithreaded alpha M2 pass enabled.", -- [1]
			0, -- [2]
		}, -- [8]
		{
			"Multithreaded opaque WMO pass enabled.", -- [1]
			0, -- [2]
		}, -- [9]
		{
			"Multithreaded terrain pass enabled.", -- [1]
			0, -- [2]
		}, -- [10]
		{
			"Water detail changed to 0", -- [1]
			0, -- [2]
		}, -- [11]
		{
			"Ripple detail changed to 2", -- [1]
			0, -- [2]
		}, -- [12]
		{
			"Reflection mode changed to 3", -- [1]
			0, -- [2]
		}, -- [13]
		{
			"Reflection downscale changed to 0", -- [1]
			0, -- [2]
		}, -- [14]
		{
			"Sunshafts quality changed to 0", -- [1]
			0, -- [2]
		}, -- [15]
		{
			"Enabling BSP node cache (first time - starting up)", -- [1]
			0, -- [2]
		}, -- [16]
		{
			"Volume fog enabled.", -- [1]
			0, -- [2]
		}, -- [17]
		{
			"Particulate volumes enabled.", -- [1]
			0, -- [2]
		}, -- [18]
		{
			"Projected textures disabled.", -- [1]
			0, -- [2]
		}, -- [19]
		{
			"Spell Clutter set to dynamic", -- [1]
			0, -- [2]
		}, -- [20]
		{
			"Shadow mode changed to 0 - Blob shadows, precomputed terrain shadows", -- [1]
			0, -- [2]
		}, -- [21]
		{
			"Shadow texture size changed to 1024.", -- [1]
			0, -- [2]
		}, -- [22]
		{
			"Soft shadows changed to 0.", -- [1]
			0, -- [2]
		}, -- [23]
		{
			"Shadow RT mode changed to 0 (Disabled)", -- [1]
			0, -- [2]
		}, -- [24]
		{
			"maxLightCount must be in range 0 to 32.", -- [1]
			0, -- [2]
		}, -- [25]
		{
			"CVar 'maxLightCount' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [26]
		{
			"SSAO mode set to 0", -- [1]
			0, -- [2]
		}, -- [27]
		{
			"SSAO type set to 0", -- [1]
			0, -- [2]
		}, -- [28]
		{
			"SkyCloudLOD set to 0", -- [1]
			0, -- [2]
		}, -- [29]
		{
			"Texture filtering mode updated.", -- [1]
			0, -- [2]
		}, -- [30]
		{
			"Terrain mip level changed to 0.", -- [1]
			0, -- [2]
		}, -- [31]
		{
			"Render scale changed to 1", -- [1]
			0, -- [2]
		}, -- [32]
		{
			"Resample quality changed to 0", -- [1]
			0, -- [2]
		}, -- [33]
		{
			"MSAA disabled", -- [1]
			0, -- [2]
		}, -- [34]
		{
			"MSAA for alpha-test disabled.", -- [1]
			0, -- [2]
		}, -- [35]
		{
			"Variable Rate Shading not supported on this hardware", -- [1]
			0, -- [2]
		}, -- [36]
		{
			"CVar 'vrsWorldGeo' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [37]
		{
			"Variable Rate Shading not supported on this hardware", -- [1]
			0, -- [2]
		}, -- [38]
		{
			"CVar 'vrsParticles' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [39]
		{
			"lodObjectSizeScale cannot be changed.", -- [1]
			0, -- [2]
		}, -- [40]
		{
			"Volume fog enabled.", -- [1]
			0, -- [2]
		}, -- [41]
		{
			"Particulate volumes enabled.", -- [1]
			0, -- [2]
		}, -- [42]
		{
			"dynamicLod enabled", -- [1]
			0, -- [2]
		}, -- [43]
		{
			"World preload object sort enabled.", -- [1]
			0, -- [2]
		}, -- [44]
		{
			"World load object sort enabled.", -- [1]
			0, -- [2]
		}, -- [45]
		{
			"World preload non critical enabled.", -- [1]
			0, -- [2]
		}, -- [46]
		{
			"World preload high res textures enabled.", -- [1]
			0, -- [2]
		}, -- [47]
		{
			"SSAO mode set to 3", -- [1]
			0, -- [2]
		}, -- [48]
		{
			"Projected textures enabled.", -- [1]
			0, -- [2]
		}, -- [49]
		{
			"Sunshafts quality changed to 2", -- [1]
			0, -- [2]
		}, -- [50]
		{
			"Terrain mip level changed to 0.", -- [1]
			0, -- [2]
		}, -- [51]
		{
			"Spell Clutter set to dynamic", -- [1]
			0, -- [2]
		}, -- [52]
		{
			"Shadow mode changed to 3 - 3 band dynamic shadows on units and terrain, 2048", -- [1]
			0, -- [2]
		}, -- [53]
		{
			"Shadow texture size changed to 2048.", -- [1]
			0, -- [2]
		}, -- [54]
		{
			"Soft shadows changed to 0.", -- [1]
			0, -- [2]
		}, -- [55]
		{
			"Water detail changed to 2", -- [1]
			0, -- [2]
		}, -- [56]
		{
			"Reflection mode changed to 0", -- [1]
			0, -- [2]
		}, -- [57]
		{
			"Ripple detail changed to 1", -- [1]
			0, -- [2]
		}, -- [58]
		{
			"Render scale changed to 1", -- [1]
			0, -- [2]
		}, -- [59]
		{
			"Texture filtering mode updated.", -- [1]
			0, -- [2]
		}, -- [60]
		{
			"MSAA disabled", -- [1]
			0, -- [2]
		}, -- [61]
		{
			"MSAA for alpha-test disabled.", -- [1]
			0, -- [2]
		}, -- [62]
		{
			"Resample quality changed to 0", -- [1]
			0, -- [2]
		}, -- [63]
		{
			"set pending gxRestart", -- [1]
			0, -- [2]
		}, -- [64]
		{
			"Shadow RT mode changed to 0 (Disabled)", -- [1]
			0, -- [2]
		}, -- [65]
		{
			"SSAO type set to 0", -- [1]
			0, -- [2]
		}, -- [66]
		{
			"GxApi set pending GxRestart", -- [1]
			0, -- [2]
		}, -- [67]
		{
			"FFX: Color Blind Test Mode Disabled", -- [1]
			0, -- [2]
		}, -- [68]
		{
			"CVar 'fullDump' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [69]
		{
			"Error display disabled", -- [1]
			0, -- [2]
		}, -- [70]
		{
			"Error display shown", -- [1]
			0, -- [2]
		}, -- [71]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [72]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [73]
		{
			"Now filtering: all messages", -- [1]
			0, -- [2]
		}, -- [74]
		{
			"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [75]
		{
			"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [76]
		{
			"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [77]
		{
			"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [78]
		{
			"[GlueLogin] Starting loginlauncherPortal=\"cn.actual.battle.net\" loginPortal=\"cn.actual.battle.net:1119\"", -- [1]
			0, -- [2]
		}, -- [79]
		{
			"[GlueLogin] Resetting", -- [1]
			0, -- [2]
		}, -- [80]
		{
			"[IBN_Login] Initializing", -- [1]
			0, -- [2]
		}, -- [81]
		{
			"[IBN_Login] Attempting logonhost=\"cn.actual.battle.net\" port=\"1119\"", -- [1]
			0, -- [2]
		}, -- [82]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [83]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [84]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [85]
		{
			"[GlueLogin] Logon complete.", -- [1]
			0, -- [2]
		}, -- [86]
		{
			"[GlueLogin] Reconnect token saved; creationTime=\"1642411118\" expirationTime=\"1642425518\"", -- [1]
			0, -- [2]
		}, -- [87]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [88]
		{
			"[IBN_Login] Requesting realm list ticket", -- [1]
			0, -- [2]
		}, -- [89]
		{
			"[IBN_Login] Received realm list ticketcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [90]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [91]
		{
			"[IBN_Login] Received sub region listcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [92]
		{
			"[IBN_Login] Requesting last played charsnumSubRegions=\"2\"", -- [1]
			0, -- [2]
		}, -- [93]
		{
			"[GlueLogin] Realm list ready.", -- [1]
			0, -- [2]
		}, -- [94]
		{
			"[IBN_Login] Joining realmsubRegion=\"45-1-89\" realmAddress=\"45-1-9\"", -- [1]
			0, -- [2]
		}, -- [95]
		{
			"[IBN_Login] OnRealmJoincode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [96]
		{
			"NetClient::HandleConnect()\n", -- [1]
			0, -- [2]
		}, -- [97]
		{
			"[GlueLogin] Received AuthedToWoWresult=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [98]
		{
			"[IBN_Login] Front disconnectingconnectionId=\"1\"", -- [1]
			0, -- [2]
		}, -- [99]
		{
			"[GlueLogin] Disconnecting from authentication server.", -- [1]
			0, -- [2]
		}, -- [100]
		{
			"[IBN_BackInterface] Session with Battle.net established.", -- [1]
			0, -- [2]
		}, -- [101]
		{
			"[IBN_Login] Front disconnectedconnectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [102]
		{
			"[GlueLogin] Disconnected from authentication server.", -- [1]
			0, -- [2]
		}, -- [103]
		{
			"[WowEntitlements] [BNetAccount-0-0000091B5BAC] [WowAccount-0-000001AAEC3B] Initialized with 3 entitlements.", -- [1]
			0, -- [2]
		}, -- [104]
		{
			"[IBN_Login] Requesting change realm list", -- [1]
			0, -- [2]
		}, -- [105]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [106]
		{
			"[IBN_Login] Received realm list ticketcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [107]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [108]
		{
			"[IBN_Login] Received sub region listcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [109]
		{
			"[IBN_Login] Requesting realm listsnumSubRegions=\"2\"", -- [1]
			0, -- [2]
		}, -- [110]
		{
			"[GlueLogin] Realm list ready.", -- [1]
			0, -- [2]
		}, -- [111]
		{
			"[IBN_Login] Joining realmsubRegion=\"45-1-89\" realmAddress=\"45-1-9\"", -- [1]
			0, -- [2]
		}, -- [112]
		{
			"[IBN_Login] OnRealmJoincode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [113]
		{
			"Disconnecting for reason 12", -- [1]
			0, -- [2]
		}, -- [114]
		{
			"NetClient::HandleDisconnect()\n", -- [1]
			0, -- [2]
		}, -- [115]
		{
			"[IBN_BackInterface] Session with Battle.net destroyed.", -- [1]
			0, -- [2]
		}, -- [116]
		{
			"NetClient::HandleConnect()\n", -- [1]
			0, -- [2]
		}, -- [117]
		{
			"[GlueLogin] Received AuthedToWoWresult=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [118]
		{
			"[IBN_BackInterface] Session with Battle.net established.", -- [1]
			0, -- [2]
		}, -- [119]
		{
			"[IBN_Login] Requesting change realm list", -- [1]
			0, -- [2]
		}, -- [120]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [121]
		{
			"[IBN_Login] Received realm list ticketcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [122]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [123]
		{
			"[IBN_Login] Received sub region listcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [124]
		{
			"[IBN_Login] Requesting realm listsnumSubRegions=\"2\"", -- [1]
			0, -- [2]
		}, -- [125]
		{
			"[GlueLogin] Realm list ready.", -- [1]
			0, -- [2]
		}, -- [126]
		{
			"[IBN_Login] Joining realmsubRegion=\"45-1-89\" realmAddress=\"45-5-29\"", -- [1]
			0, -- [2]
		}, -- [127]
		{
			"[IBN_Login] OnRealmJoincode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [128]
		{
			"Disconnecting for reason 12", -- [1]
			0, -- [2]
		}, -- [129]
		{
			"NetClient::HandleDisconnect()\n", -- [1]
			0, -- [2]
		}, -- [130]
		{
			"[IBN_BackInterface] Session with Battle.net destroyed.", -- [1]
			0, -- [2]
		}, -- [131]
		{
			"NetClient::HandleConnect()\n", -- [1]
			0, -- [2]
		}, -- [132]
		{
			"[GlueLogin] Received AuthedToWoWresult=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [133]
		{
			"[IBN_BackInterface] Session with Battle.net established.", -- [1]
			0, -- [2]
		}, -- [134]
		{
			"[IBN_Login] Requesting change realm list", -- [1]
			0, -- [2]
		}, -- [135]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [136]
		{
			"[IBN_Login] Received realm list ticketcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [137]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [138]
		{
			"[IBN_Login] Received sub region listcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [139]
		{
			"[IBN_Login] Requesting realm listsnumSubRegions=\"2\"", -- [1]
			0, -- [2]
		}, -- [140]
		{
			"[GlueLogin] Realm list ready.", -- [1]
			0, -- [2]
		}, -- [141]
		{
			"[IBN_Login] Joining realmsubRegion=\"45-1-89\" realmAddress=\"45-1-9\"", -- [1]
			0, -- [2]
		}, -- [142]
		{
			"[IBN_Login] OnRealmJoincode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [143]
		{
			"Disconnecting for reason 12", -- [1]
			0, -- [2]
		}, -- [144]
		{
			"NetClient::HandleDisconnect()\n", -- [1]
			0, -- [2]
		}, -- [145]
		{
			"[IBN_BackInterface] Session with Battle.net destroyed.", -- [1]
			0, -- [2]
		}, -- [146]
		{
			"NetClient::HandleConnect()\n", -- [1]
			0, -- [2]
		}, -- [147]
		{
			"[GlueLogin] Received AuthedToWoWresult=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [148]
		{
			"Got new connection 2", -- [1]
			0, -- [2]
		}, -- [149]
		{
			"[IBN_BackInterface] Session with Battle.net established.", -- [1]
			0, -- [2]
		}, -- [150]
		{
			"[IBN_Login] Requesting change realm list", -- [1]
			0, -- [2]
		}, -- [151]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [152]
		{
			"[IBN_Login] Received realm list ticketcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [153]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [154]
		{
			"[IBN_Login] Received sub region listcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [155]
		{
			"[IBN_Login] Requesting realm listsnumSubRegions=\"2\"", -- [1]
			0, -- [2]
		}, -- [156]
		{
			"[GlueLogin] Realm list ready.", -- [1]
			0, -- [2]
		}, -- [157]
		{
			"[IBN_Login] Joining realmsubRegion=\"45-1-89\" realmAddress=\"45-5-6\"", -- [1]
			0, -- [2]
		}, -- [158]
		{
			"[IBN_Login] OnRealmJoincode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [159]
		{
			"Disconnecting for reason 12", -- [1]
			0, -- [2]
		}, -- [160]
		{
			"NetClient::HandleDisconnect()\n", -- [1]
			0, -- [2]
		}, -- [161]
		{
			"[IBN_BackInterface] Session with Battle.net destroyed.", -- [1]
			0, -- [2]
		}, -- [162]
		{
			"NetClient::HandleConnect()\n", -- [1]
			0, -- [2]
		}, -- [163]
		{
			"[GlueLogin] Received AuthedToWoWresult=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [164]
		{
			"[IBN_BackInterface] Session with Battle.net established.", -- [1]
			0, -- [2]
		}, -- [165]
		{
			"[IBN_Login] Requesting change realm list", -- [1]
			0, -- [2]
		}, -- [166]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [167]
		{
			"[IBN_Login] Received realm list ticketcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [168]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [169]
		{
			"[IBN_Login] Received sub region listcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [170]
		{
			"[IBN_Login] Requesting realm listsnumSubRegions=\"2\"", -- [1]
			0, -- [2]
		}, -- [171]
		{
			"[GlueLogin] Realm list ready.", -- [1]
			0, -- [2]
		}, -- [172]
		{
			"[IBN_Login] Joining realmsubRegion=\"45-1-89\" realmAddress=\"45-5-29\"", -- [1]
			0, -- [2]
		}, -- [173]
		{
			"[IBN_Login] OnRealmJoincode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [174]
		{
			"Disconnecting for reason 12", -- [1]
			0, -- [2]
		}, -- [175]
		{
			"NetClient::HandleDisconnect()\n", -- [1]
			0, -- [2]
		}, -- [176]
		{
			"[IBN_BackInterface] Session with Battle.net destroyed.", -- [1]
			0, -- [2]
		}, -- [177]
		{
			"NetClient::HandleConnect()\n", -- [1]
			0, -- [2]
		}, -- [178]
		{
			"[GlueLogin] Received AuthedToWoWresult=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [179]
		{
			"[IBN_BackInterface] Session with Battle.net established.", -- [1]
			0, -- [2]
		}, -- [180]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [181]
		{
			"Failed to set SpellClutter callback on graphicsQuality CVar - using default of 30.0", -- [1]
			0, -- [2]
		}, -- [182]
		{
			"Failed to set SpellClutter callback on RAIDgraphicsQuality CVar - using default of 30.0", -- [1]
			0, -- [2]
		}, -- [183]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [184]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [185]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [186]
		{
			"Proficiency in item class 2 set to 0x0000000085", -- [1]
			0, -- [2]
		}, -- [187]
		{
			"Proficiency in item class 2 set to 0x000000008d", -- [1]
			0, -- [2]
		}, -- [188]
		{
			"Proficiency in item class 2 set to 0x000000009d", -- [1]
			0, -- [2]
		}, -- [189]
		{
			"Proficiency in item class 2 set to 0x000000019d", -- [1]
			0, -- [2]
		}, -- [190]
		{
			"Proficiency in item class 2 set to 0x000000059d", -- [1]
			0, -- [2]
		}, -- [191]
		{
			"Proficiency in item class 2 set to 0x00000005bd", -- [1]
			0, -- [2]
		}, -- [192]
		{
			"Proficiency in item class 2 set to 0x00000005bf", -- [1]
			0, -- [2]
		}, -- [193]
		{
			"Proficiency in item class 2 set to 0x00000085bf", -- [1]
			0, -- [2]
		}, -- [194]
		{
			"Proficiency in item class 2 set to 0x00000185bf", -- [1]
			0, -- [2]
		}, -- [195]
		{
			"Proficiency in item class 4 set to 0x0000000001", -- [1]
			0, -- [2]
		}, -- [196]
		{
			"Proficiency in item class 2 set to 0x000001c5bf", -- [1]
			0, -- [2]
		}, -- [197]
		{
			"Proficiency in item class 2 set to 0x000005c5bf", -- [1]
			0, -- [2]
		}, -- [198]
		{
			"Proficiency in item class 2 set to 0x000005c5ff", -- [1]
			0, -- [2]
		}, -- [199]
		{
			"Proficiency in item class 4 set to 0x0000000011", -- [1]
			0, -- [2]
		}, -- [200]
		{
			"Proficiency in item class 4 set to 0x0000000019", -- [1]
			0, -- [2]
		}, -- [201]
		{
			"Proficiency in item class 4 set to 0x000000001d", -- [1]
			0, -- [2]
		}, -- [202]
		{
			"Proficiency in item class 4 set to 0x000000001f", -- [1]
			0, -- [2]
		}, -- [203]
		{
			"Proficiency in item class 4 set to 0x000000005f", -- [1]
			0, -- [2]
		}, -- [204]
		{
			"Proficiency in item class 2 set to 0x000005e5ff", -- [1]
			0, -- [2]
		}, -- [205]
		{
			"Proficiency in item class 2 set to 0x000005e5ff", -- [1]
			0, -- [2]
		}, -- [206]
		{
			"Proficiency in item class 4 set to 0x000000005f", -- [1]
			0, -- [2]
		}, -- [207]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [208]
		{
			"Time set to 1/17/2022 (Mon) 17:19", -- [1]
			0, -- [2]
		}, -- [209]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [210]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [211]
		{
			"set pending gxRestart", -- [1]
			0, -- [2]
		}, -- [212]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [213]
		{
			"[GlueLogin] Explicitly disconnecting from realm server", -- [1]
			0, -- [2]
		}, -- [214]
		{
			"Disconnecting for reason 14", -- [1]
			0, -- [2]
		}, -- [215]
		{
			"NetClient::HandleDisconnect()\n", -- [1]
			0, -- [2]
		}, -- [216]
		{
			"[IBN_BackInterface] Session with Battle.net destroyed.", -- [1]
			0, -- [2]
		}, -- [217]
		{
			"[GlueLogin] Disconnected from WoWpreviouslyConnected=\"false\"", -- [1]
			0, -- [2]
		}, -- [218]
	},
	["height"] = 300,
	["fontHeight"] = 14,
	["isShown"] = false,
	["commandHistory"] = {
	},
}
